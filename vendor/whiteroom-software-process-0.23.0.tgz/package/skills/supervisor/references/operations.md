# Supervisor operations

Operate one project and only the lane tree you started. The supervisor skill
defines ownership. This reference supplies check-ins, authority, contact routes,
names, and the rule for continuing while Jon is away.

## Check in

1. Recover the issue log, handoff, roster, review holder, publication checkout,
   frozen tip, and known jobs. Check actual state before repeating work.
2. Run `wrsp-agents check`. Read version and warning lines for both CLIs.
   A version warning alone does not fail the command.
3. Upgrade a behind Codex with `npm i -g @openai/codex@latest` only when no lane
   has a live worker or runner job. Recheck. Jon trusts changed hooks in the
   desktop app; the CLI 0.163.0 trust attempt did not persist.
4. Claude updates itself. Report which sessions and Remote Control servers
   started before the installed version. Schedule their handoffs normally.
5. Inspect this session's grant with `wrsp-session-role inspect`. To record Jon's
   assignment, run `wrsp-session-role grant <request.json>` in this session's own
   shell. Copy their words and source verbatim. The helper reads the native id
   from the harness environment. Do not infer it from a Remote label or grant
   after a denial without an existing instruction. Resume and compaction retain it.
6. Read context and status for each lane. Use its model budget from installed
   `tiers.members`; unknown model or usage stays unknown. Request a checkpoint
   before more work when either is unknown. At 80%, request a handoff, start a
   successor, and obtain its acknowledgment before retirement.
7. Confirm priorities, queue requests, publication needs, and Jon's instructions.
   Log each decision with its source and exact affected scope.

## Claude supervisor

| Capability | Claude lane | Codex lane |
| --- | --- | --- |
| Start | Remote session create with title, model, permission mode, and tags. Select the Agent Mini Remote Control environment. A cloud environment skips the host hooks. | Detached `codex exec --json`; record the thread id. |
| Message | Remote send-message with priority now, next, or later. | Next turn: `codex exec resume <id>`. |
| Receive | The lane sends a message to `@parent`. | Read the turn's output. |
| Context use | Remote get-session → `context_usage`. | Latest `token_count.last_token_usage` in the rollout, under `payload.info`; use input tokens, not cumulative totals. |
| Rename | Remote set-title, including the supervisor's own session. | `thread/name/set` only for app-server threads; otherwise update the roster title. |
| Transcript | Remote list-events / get-event. | Rollout matched by `session_meta.id`. |
| Status / retire | Remote get-session status bucket; archive after handoff acknowledgment. | Recorded handle and exit state; retire after handoff acknowledgment. |

## Codex supervisor

| Capability | Claude lane | Codex lane |
| --- | --- | --- |
| Start | Escalated, detached `claude -p --session-id <uuid> --name "<thread name>" --output-format json`. | Detached `codex exec --json`; record the thread id. |
| Message | `claude -p --resume <uuid>`, one turn at a time. | `codex exec resume <id>`, one turn at a time. |
| Receive | Read the turn's JSON output. | Read the turn's output. |
| Context use | `usage` in the turn's JSON. | Latest `token_count.last_token_usage` in the rollout, under `payload.info`. |
| Rename | `--name` on start or resume; qualify resume naming on the host. | `thread/name/set` only for app-server threads; otherwise update the roster title. |
| Transcript | `~/.claude/projects/<slug>/<uuid>.jsonl`. | Rollout matched by `session_meta.id`. |
| Status / retire | Recorded handle and exit state; retire after handoff acknowledgment. | Recorded handle and exit state; retire after handoff acknowledgment. |

Use exact tier, model, effort, and budget at start. A route that cannot select
the required pair cannot start that lane. The permission profiles and handle
format are owned by `scripts/lane.sh`; it supplies start, send, read, and status.
Remote sessions use host coordinator permissions and hooks, not a worker profile.
OpenRouter-backed Codex follows the Codex routes and provider limits.

## Lane turns

- The Codex harness kills background processes when a call ends. A Codex
  supervisor cannot keep an app-server alive between turns. Each headless lane
  turn runs detached under launchd and is waited on with
  `~/.agents/skills/coordinator/scripts/wrsp-wait.sh`, as workers are today.
- The app-server experiment proved two turns inside one process only.
  `codex exec resume` appears in the 0.163.0 help but was not tested there.
  Host qualification must prove it before this route is enabled for live lanes.
- Hold one lock per lane from turn admission through process exit. Two turns
  never overlap. A failed submission releases only its own lock. Recover an
  interrupted turn from its handle and exit record, not elapsed time.
- A headless lane cannot receive mid-turn. It ends its turn at a queue request,
  handoff, or question for Jon. A queue “go” arrives as its next turn.
  A send during a live turn reports busy; it does not start a second writer.
- Never resume a headless lane interactively while its supervisor may send turns.
  Transfer ownership explicitly first. A fresh successor gets a fresh identity.
- A headless Claude lane has no Remote tools. Its tree is whatever it launches
  through `~/.agents/skills/coordinator/scripts/launch-worker.sh`.
- Persist lane identity, title, family, provider, host, project, issue, worktree,
  tier, model, effort, budget, contact route, launch handle, and next exchange.
  Match #196 launch attribution; a resume is a turn of the same lane.
- Require acknowledgment for queue ownership, scope changes, and handoffs.
  If contact fails, inspect the handle, read bounded output, and recover that lane.
  An issue comment records intent but does not wake an idle headless process.
  Independent lanes continue. Missing delivery never supplies queue permission.

### Lane script

Installed path: `~/.agents/skills/supervisor/scripts/lane.sh`.

```text
lane.sh start --role coordinator|designer --cli claude|codex --tier <tier> --model <model> --effort <effort> --worktree <dir> --issue <N> --brief <file> --title <text> --log <file>
lane.sh send <handle> <message-file>
lane.sh read <handle> [--cursor <bytes>]
lane.sh status <handle>
lane.sh recover <handle>
lane.sh title --role <role> [--lane <name>] --task <text> [--issues "#1 #2"] [--state done|waiting]
```

The handle is `<log without .log>.lane.json`; turn logs are
`<log without .log>.turn-<n>.log`. A `<handle>.lock` directory admits one
turn and remains held until the runner exits. A live turn refuses sends;
an interrupted turn needs `recover`, which checks the pid and exit record.
Failed submission releases the lock and preserves the previous handle.
Every turn removes its launchd job on exit, including refusals and aborts; an aborted turn is recorded as exit 70 with its launch-record exit fact.
A launchd respawn of a killed turn is refused (exit 79) and leaves the turn interrupted for `recover`; no input is replayed.
Wait on a turn with
`~/.agents/skills/coordinator/scripts/wrsp-wait.sh <turn-log>`.

## Names and instructions

Use the supervisor skill's role emoji table. The coordinator skill carries the
same table. Shape: `<emoji>[ <Lane>]: <task>[ #issues]`. Follow these examples:

- `😺 Agent Mini migration #174 #196 #197`
- `💬 G: event capture #196`
- `💬 👋 H: supervisor role #197`
- `💀 F: laptop ledger #192`

The colon appears only after a lane letter. Rename on assignment, changed work,
successor pickup, and completion. Replace the role emoji with 💀 at completion
and keep task text. Add 👋 after the role emoji while waiting on Jon; remove it
when unblocked. Promotion changes 💬 to 😺. Titles grant no authority.

Jon names a Codex supervisor's thread at start. Tell them the new name when its
scope changes. Use Remote titles for Remote lanes, `--name` for Claude headless
lanes, and `thread/name/set` for Codex app-server threads. Other Codex CLI lanes
keep their desired title in the roster. Never edit app databases to rename.
Name descendant launch records with 🔨, 🖼️, ⚖️, 🔬, or 🔍 as appropriate.
Keep #196 launch identities intact; this work does not change the worker launcher.

Lanes in this tree forward Jon's direct instructions verbatim to the supervisor
and record their source on the issue in the same turn. Workers without issue
access send the exact words through their coordinator. A lane outside this tree
records Jon's words on its issue; it is not managed by this supervisor.

Never hand Jon a bare file path. They read from the laptop and cannot see Agent
Mini files. Link a pushed file, or publish the content on the issue. Apply this
to drafts, handoffs, logs, proof, and decisions as well as finished documents.

## Pushes while Jon is away

Jon approved this rule; “you” refers to Jon:

> a push proceeds without you when it has full review coverage or recorded acceptance and passing evidence at the exact commit. It waits for you only when it does one of these:
>
> - changes review, receipt, evidence or gate semantics, or a contract consumers see;
> - installs hooks that need re-trust;
> - tags or releases;
> - force-pushes or deletes a remote ref.

Reuse Jon's existing approval when it covers that risky action and exact scope.
Otherwise hold the push and continue independent lanes. A supervisor assignment
is role authority, not findings acceptance or approval of every risky action.
Use the landing-queue and operator-acceptance references for the actual checks.
Publishing from a frozen checkout lets reviews and landings continue on main.

## Visibility

See only the tree you started. Jon accepts missing visibility into threads they
start in another app. Discovery of every chat is not a completion requirement.
Do not send peer messages to laptop sessions; their inbound refusal still applies.

Remote events expose the connected conversation, subject to pagination and tool
availability. They do not expose private reasoning or promise every local tool
byte. Same-host Claude transcripts and Codex rollouts expose persisted events
and usage. Match identity and read only relevant, bounded ranges for this project.
Missing files, truncation, persistence settings, and provider differences limit
that view. OpenRouter adds no Remote or cross-session capability. Missing usage
stays unknown; request a checkpoint. The usage ledger is counters, not a transcript.
