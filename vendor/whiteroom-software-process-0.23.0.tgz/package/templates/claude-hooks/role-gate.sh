#!/bin/sh
# WRSP #178 worker limits and #197 role gate; the logic lives in the helper.
input=$(cat)
if command -v node >/dev/null 2>&1 && [ -f "$HOME/.agents/hooks/session-role.mjs" ]; then
  printf '%s' "$input" | WRSP_SESSION_ROLE_HELPER="$HOME/.agents/hooks/session-role.mjs" \
    node --input-type=module -e 'import { pathToFileURL } from "node:url"; const m = await import(pathToFileURL(process.env.WRSP_SESSION_ROLE_HELPER).href); m.main(process.argv.slice(1))' -- gate "$@"
  status=$?
  [ "$status" -eq 0 ] && exit "$status"
fi

if printf '%s' "$input" | grep -Eiq 'git[[:space:]]+push|send-pack|subtree[[:space:]]+push|gh[[:space:]]+(pr[[:space:]]+merge|repo[[:space:]]+sync|release|workflow[[:space:]]+run|api)|git[[:space:]]+tag|update-ref|publish|deploy|dist-tag|docker[[:space:]]+push|wrangler|netlify|firebase|flyctl|fly[[:space:]]+deploy|vercel|scp[[:space:]]|rsync|pkill|killall|xargs[[:space:]]+kill|kill[[:space:]]|wrsp-agents|agents\.mjs|install-runner-daemon|launchctl|operator-authorization|\.claude|\.codex|\.agents|collaboration|\*\*\* (Add|Update|Delete) File|\*\*\* Move to'; then
  printf '%s\n' '{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"deny","permissionDecisionReason":"The WRSP role gate helper is unavailable (node or ~/.agents/hooks/session-role.mjs) and this call mentions publication, host administration, protected paths or process kills; refused until wrsp-agents install restores the helper. (WRSP #197)"}}'
fi
exit 0
