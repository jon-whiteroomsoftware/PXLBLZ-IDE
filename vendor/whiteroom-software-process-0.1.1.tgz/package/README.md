# White Room software process

Shared process tooling for repositories developed by many agents and reviewed
once: an exact-range review gate with immutable receipts and cross-model-family
routing, staged-test selection, and test-suite meta-checks. Consumed as a
vendored release tarball; configured per repository by one `wrsp.config.mjs`.

## The process

This section describes the target process. The tooling in this repository
implements the review, landing, and publication mechanics; the land-queue
executor and the dispatch coordinator are target-state, not yet built.

### Principles

- Every load-bearing claim gets a machine-generated artifact. No artifact, no progress.
- Anything that should be running emits a liveness signal. Silence is an alarm.
- Humans own intent and acceptance. Machines own scheduling and verification.
- Unattended wall-clock is cheap. Tokens and human attention are not.

### State

- Repository files and issues are the durable state. Agent memory never is.
- `AGENTS.md` instructs agents; `CLAUDE.md` is a symlink to it. `CONTEXT.md` defines domain language.
- `docs/plans/` holds intent. `docs/reference/` holds as-built truth. Issues hold executable progress.

### Development

- The shared checkout stays clean on `main`. All substantive work happens in worktrees.
- One issue per slice. Slices are vertical and independently shippable.
- Each agent gets its own worktree, dev server, and synthetic identity.
- Every commit names its authoring model in an `X-Authored-Model:` trailer.

### Testing

- TDD for behavior changes. Coverage concentrates in pure logic; UI stays thin.
- Oracle strategy is chosen per subsystem at design time: property-based and differential tests wherever dual implementations or invertible transforms exist.
- Meta-checks gate the suite itself: every spec runs in some gate; locators match live source.
- Flaky tests enter a registry with owner and expiry, not lore.
- Mutation testing is periodic qualification of high-risk engines, not a routine gate.

### Review and landing

- Every slice is reviewed once, before landing, as an exact commit range.
- Approval is an immutable receipt keyed to exact hashes. Amend, rebase, or policy change voids it.
- Review routes to the opposite model family. Fallbacks are recorded, never silent.
- P0/P1 findings block and void coverage. P2/P3 findings record advisory coverage, cleared by reviewing the exact corrective range.
- Landing is a serialized queue: rebase, review, fast-forward merge, delete the worktree.
- After each landing, an executor runs the affected suites against the landed tip and writes a result artifact.

### Publication

- Push requires a contiguous receipt chain and green suite artifacts covering the outgoing range.
- Pushing is a deliberate human choice. Deploying is decoupled from pushing.

### Dispatch

- A standing coordinator polls ready-labeled issues, spawns implementers into worktrees, and owns the review and landing queue.
- Stuck work escalates as an issue comment, never a silent retry.
- The coordinator posts a periodic digest. A missing digest is the alarm.
- Concurrency stays small: extra implementers buy rebase churn, not throughput.

## Mechanism

**Receipts.** `wrsp-review-candidate <base> <tip>` resolves both refs to exact
Git objects, requires linear ancestry, rejects merge commits, and sends the
complete commit list and per-commit patch series to the reviewer. A clean pass
(zero findings) or a P2/P3-only advisory failure writes an immutable JSON
receipt under `.git/wrsp/review-approvals/v1/` in the shared git common
directory, recording base and tip identities, reviewer, per-commit content
ids, signalled authoring models, cross-family status, policy fingerprint, and
timestamp. Receipt files are created without overwrite permission. Amend,
rebase, squash, cherry-pick, changed tip, or changed policy invalidates reuse.

**Routing.** Commits signal their authoring model with an
`X-Authored-Model:` trailer. A range authored entirely by one model family
routes to the opposite family's reviewer first; if the primary reviewer cannot
return a valid structured decision, the other reviewer receives the same
immutable input and any same-family fallback is recorded on the receipt as
`crossFamily: false` — warned about loudly, never silent.

**Severity.** P0/P1 findings block and create no coverage; after correction
the complete replacement range needs a new review. A P2/P3-only failure
records non-terminal advisory coverage: fix the findings in a new commit, then
review only that exact follow-up range. A clean pass is valid only with zero
findings; contradictory output is malformed and fails closed.

**Carry.** Receipts record a byte-exact sha256 of each commit's full
`diff-tree` patch text. A rebase whose content-id sequence is identical and
whose intervening commits touch a disjoint file set carries the approved chain
forward without re-review, with provenance recorded in `carriedFrom`.
Everything else — conflict resolutions, reordering, overlapping files,
reworded authorship — falls through to a fresh review.

**Serialization.** Concurrent reviews queue on `.git/wrsp/review.lock`,
claimed by `mkdir` (the one POSIX create-if-absent that refuses even an empty
existing directory). Locks are never reaped automatically; a dead holder fails
the run with explicit cleanup instructions, exactly like git's `index.lock`.

**Publication.** The pre-push hook reads Git's exact ref-update packet and
requires, for every changed ref, one current approval or a contiguous receipt
chain from its remote base to its pushed tip. Advisory receipts can be
intermediate edges but never the final one. Missing or stale coverage blocks
with the exact `review:candidate` command to run; pre-push never repeats
substantive review, then runs the consumer's comprehensive suites once.

**Policy fingerprint.** The reviewer prompt, output schema, reviewer models,
and the consumer's `review.projectPolicy` paragraph hash into a policy
fingerprint recorded on every receipt. Changing any of them invalidates older
receipts: process policy changes force fresh review, by construction.

**Staged-test selection.** `wrsp-test-staged` typechecks when staged paths can
affect a TypeScript project, runs staged and colocated tests, and adds fixed
regression suites for configured high-risk boundaries (path prefixes or exact
files mapped to test lists).

**Suite meta-checks.** `wrsp-check-e2e-coverage` fails when an authenticated
Playwright spec is named by no npm script — an unrun spec is indistinguishable
from a passing one. `wrsp-check-e2e-locators` fails when a spec names a
user-facing string live source no longer produces, with a shrink-only ratchet
for known staleness and a separate never-gating bucket for names assembled
mostly from runtime data.

## Adoption

1. **Install** from a vendored release tarball. In this repository, at the
   release tag, run `npm pack` and commit the tarball into the consumer
   (e.g. `vendor/whiteroom-software-process-0.1.1.tgz`):

   ```json
   "devDependencies": {
     "@whiteroom/software-process": "file:vendor/whiteroom-software-process-0.1.1.tgz"
   }
   ```

   A `file:` tarball needs no credentials, so clean `npm ci` succeeds in
   unauthenticated builders — CI runners and git-integrated deploy builds
   (Cloudflare Pages) included. A `github:...#tag` pin on this private
   repository works only where GitHub credentials are available and will
   break any unauthenticated build; use it for local-only experiments, not
   for a repository that deploys. Upgrading is replacing the tarball and
   updating the pinned filename.

2. **Configure** with an optional `wrsp.config.mjs` at the repository root.
   Every section is optional; defaults suit a plain TypeScript repository.

   ```js
   export default {
     review: {
       // Appended to the review prompt. Participates in the policy
       // fingerprint: editing it invalidates existing receipts.
       projectPolicy: 'Project-specific reviewer instructions.',
     },
     selection: {
       typecheckExact: ['vite.config.ts'],
       typecheckPatterns: ['^src/.*\\.[cm]?[jt]sx?$'],
       typecheckArgs: ['tsc', '-b', 'tsconfig.json', '--pretty', 'false'],
       boundaries: [{
         name: 'compiler',
         exact: ['src/engine/compiler.ts'],
         prefixes: ['src/engine/passes/'],
         tests: ['src/engine/compiler.test.ts'],
       }],
     },
     e2e: {
       specDirectory: 'e2e',
       authSpecSuffix: '.auth.spec.ts',
       staleLocatorAllowlist: 'e2e/known-stale-locators.json',
       liveSourceDirectory: 'src',
     },
   }
   ```

3. **Wire npm scripts** to the bins, keeping the canonical names:

   ```json
   "review:candidate": "wrsp-check-node && wrsp-review-candidate",
   "review:status": "wrsp-check-node && wrsp-review-status",
   "review:push": "wrsp-check-node && wrsp-review-push",
   "test:staged": "wrsp-check-node && wrsp-test-staged",
   "check:e2e-coverage": "wrsp-check-e2e-coverage",
   "check:e2e-locators": "wrsp-check-e2e-locators"
   ```

4. **Install hooks** from `hooks/` into `.husky/` (or your hook manager),
   adjusting the comprehensive pre-push suites to the repository.

5. **Round-trip once**: commit on a branch, run
   `npm run review:candidate -- <base> <tip>`, confirm the receipt with
   `npm run review:status -- <base> <tip>`, land with `git merge --ff-only`,
   and push through the gate.

## Development

`npm test` runs the package's own suite. The repository dogfoods its own gate:
commits are reviewed through `npm run review:candidate` and pushes pass
through `hooks/pre-push` semantics via `.husky/`.
