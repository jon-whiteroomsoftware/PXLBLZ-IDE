- Files: before sharing an artifact, read the [Files-view contract](~/src/whiteroom-software-process/docs/reference/contracts/runner-dashboard.md#files-view-199)
  for the current repository's configured artifact root and URL. Give Jon its Files link.
- Preview runtimes on this agent host bind all interfaces; no SSH tunnels.
- Give Jon preview links as `http://Agent-Mini.local:<port>/...`, never `localhost`.
- Run `wrsp-preflight preview <port>` before giving Jon a preview link.
- Each project declares its standard preview port and port set in its
  `wrsp.config.mjs` or `AGENTS.md`; WRSP hard-codes no project ports.
- Serve latest `main` on the project's standard preview port; serve other
  work on other declared ports on the same host.
- Developers, builders and eng leads may run one or several previews at once.
- Jon's screenshots reach Agent Mini only when Jon sends them, into
  `~/inbox/screenshots/`; when one is missing, ask Jon to send it.
