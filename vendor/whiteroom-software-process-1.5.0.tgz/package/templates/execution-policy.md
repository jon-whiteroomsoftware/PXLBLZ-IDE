# Execution builder policy

Read before launching implementation builders, new execution tasks, or scheduled
execution work, and when choosing a fallback, handling Git/GitHub failures, or
responding to non-convergence.
This is the authoritative execution policy. Its canonical installed location is
`~/.agents/execution-policy.md`; this tracked file is its adoption source.
The installed role table is rendered from WRSP `templates/roles.yaml` by `wrsp-agents install`; edit the template, never the installed copy (#287). Roles name models registered in WRSP `templates/models.yaml`; no role may list `gpt-6-astra` at `high` or `xhigh`. All other docs reference role names, never restate membership. Launchers take the role id with `--role-id` (#243).

## Roles

Each role is an ordered preference list. At launch, walk the role top-down and
skip unavailable models. An exhausted role STOPS: the operator names a specific
model for any further attempt. No cross-role fallback, no urgency inference.

<!-- roles:begin (rendered from roles.yaml by wrsp-agents; edit the YAML, never the table) -->
| Role | Ordered members (model / effort) |
| --- | --- |
| `batch` | `gpt-6.1-sol` / `low` -> `claude-haiku-5-5` / `high` |
| `locator` | `claude-haiku-5-5` / `med` -> `gpt-6-luna` / `high` |
| `researcher` | `gpt-6.1-sol` / `med` -> `claude-opus-5-5` / `low` |
| `builder` | `gpt-6.1-sol` / `med` -> `claude-opus-5-5` / `med` |
| `developer` | `gpt-6.1-sol` / `xhigh` -> `claude-opus-5-5` / `high` |
| `eng-lead` | `claude-opus-5-5` / `high` -> `gpt-6-astra` / `med` |
| `reviewer` | `gpt-6-astra` / `low` -> `claude-opus-5-5` / `high`; explicit pairs: `claude-opus-5-5` / `xhigh`, `gpt-6.1-sol` / `xhigh` (legacy `principal`) |
| `ux-principal` | `claude-fable-5-1` / `high` -> `claude-opus-5-5` / `high` |
| `principal-engineer` | `gpt-6-astra` / `med` -> `claude-opus-5-5` / `xhigh` |
<!-- roles:end -->

## Function map

| Function | Role |
| --- | --- |
| eng lead | `eng-lead` by default; `principal-engineer`, launched with an explicit pair (`--model claude-opus-5-5 --effort xhigh` or `--model gpt-6-astra --effort med`) when Jon names it |
| implementation | `builder` |
| code review | `reviewer`; its explicit pairs for review selection only |
| design | `ux-principal` |
| ux design | `ux-principal` |
| research | `researcher`: native `researcher` agent in Claude; `launch-worker.sh --research` in Codex |
| bulk | `batch` |
| hardest escalation | `principal-engineer`, launched with an explicit pair (`--model claude-opus-5-5 --effort xhigh` or `--model gpt-6-astra --effort med`) |

No role named -> `builder`. Role word -> role id with aliases
(`supervisor` -> `eng-lead` unless Jon names `principal-engineer`,
`engineer` -> `builder`,
`hourly worker` -> `batch`). Function word -> role with the map above.
Unknown word -> ask; never guess. The launch line names the role as
`role:<id>` (for example `role:builder`). Then walk the role,
skipping unavailable; exhausted stops.
`launch-worker.sh` refuses a `--model`/`--effort` pair that is not a member of the `--role-id` role in `~/.agents/roles.members`.
Model ids are exact `--model` strings. Codex: `--model <id>` with
`--config 'model_reasoning_effort="<effort>"'`; `-p <profile>` layers a config
selecting the model connection. Claude: `--model <claude-*>` with
`--effort <effort>`. GPT-family ids run only on the Codex default connection;
Claude-family ids only on the Claude CLI; the OpenRouter connection (today
`-p muse`) never carries GPT or Claude ids: subscription versus PAYG
multiples, and OpenRouter guardrails fail it closed. New profiles are named
here when added; never guess a profile. `gpt-6-sol`, `gpt-6-luna`, and
`claude-sonnet-5` confirm on first launch; unproven ids are skipped as
unavailable, never invented. Each launch still names the exact model and
effort explicitly; inheritance, aliases, and configured defaults do not
establish the pair. Existing authorization, scope, concurrency, security, and
review gates remain in force. A model choice supplies no permission to launch
additional builders.

Unavailability, exhausted quota, or provider failure advances to the next
eligible member within the named role only. Record the reason and selected pair
in the handoff. Skip models on a provider already known to be exhausted or
unavailable; a model-specific failure does not establish provider-wide failure.
Keep independent work moving. If the named role is exhausted, report the
unavailable choices and stop that launch; do not fall through to another role.
Authority failures follow the global failure-scope rule and **Route failures**
below; they are not provider unavailability.

## Route failures

Global `AGENTS.md` owns failure scope. Before changing a Git/GitHub connection:

1. Preserve the original operation, route and exact failure evidence. Identify
   the refusing authority and its scope from explicit evidence; a status such as
   403 or EPERM alone cannot do that. Unresolved provenance holds the uncertain
   action. A sandbox refusal supplies no host verdict or host retry authority;
   use only an already-authorized diagnostic or role handoff.
2. For a connection-only credential/capability failure, verify the existing
   alternative is independently authenticated as a permitted principal on the
   intended repository, supports the same already-authorized operation, and
   respects current session/tool/role/sandbox restrictions and Git gates
   (hooks, review, receipts, evidence, protection, signing and landing).
   Another tool's existence or urgency supplies no authority. Authority for
   push does not grant other mutations, installation, trust or release.
   A route change grants no credential, permission or configuration changes.
3. Check response fidelity: required fields, identity and history must remain
   available; after an authorized mutation, verify the same operation's result
   through normal read-back. Missing fidelity leaves that result unproved.
   Retain the failed-route evidence and report the replacement and its limits.
4. Ordinary syntax/usage, commit-subject, lint or test failures use the role's
   existing repair/handoff procedure. Before a normal gated retry, state the
   diagnosed cause, changed input and remaining proof. Builder hook failures
   retain the builder skill's staged stop/report boundary; developer repair and
   lander return duties remain in their skills. A gate refusal stays in force
   until its normal prerequisite is satisfied; never substitute raw Git, skip
   hooks, alter protection or force push.

Service/transport failures use existing bounded diagnostic and availability
guidance; they grant no retry-policy or provider-selection exception.

## Diagnose non-convergence

A builder failing to solve a problem is a reasoning or approach problem, not
provider unavailability. Preserve its evidence and diagnose the invariant,
approach, or enforcement layer before another attempt. Escalation means the
operator names a specific role or a specific model/effort pair with a concrete
changed approach, for example `role:principal-engineer` with an explicit pair or a fresh `builder` attempt
with a new hypothesis. State why that attempt should help; do not cycle models
indefinitely. A harder role is an explicit escalation, never an automatic
fallback or an inference from urgency.

Model changes preserve candidate lineage and the existing review breaker.
Three consecutive P0/P1-blocking reviews still require discussion with Jon
before a fourth review; a new builder, model, task, or fresh context cannot reset
that count. Repeated failure without a new hypothesis requires discussion,
not another automatic attempt. Review outcomes and availability failures remain
distinct.

## Use a capable launch interface

Codex collaboration, task, or scheduled-work tools must expose both exact fields.
When supported, use `model` and `reasoning_effort` (or the tool's named equivalent)
explicitly, plus `role:<id>` in the launch line. If a chosen tool cannot express
a role plus pair, use an authorized capable CLI route or report the limitation.
Never translate an unsupported member launch into a different model.

For CLI execution, provide the prompt and authorized workspace through the
CLI's normal input/workspace options, and explicitly set:

- Codex: `--model <exact-model>` and `--config 'model_reasoning_effort="<effort>"'`.
- Claude: `--model claude-fable-5-1 --effort high`.

The launcher runs Claude builders with `--permission-mode auto` (#151): a headless builder cannot answer a prompt, and auto mode lets ordinary commands run while its classifier refuses risky ones.

Keep normal permission and sandbox controls. These flags express selection;
they do not prove availability or authorize changing permissions. Preserve the
actual launch arguments and returned outcome rather than claiming an unobserved
model ran. TBD launch IDs must be resolved before launch, never invented.
This policy does not supply a new dispatcher or automatic retry loop.

The installed Claude native `Agent|Task` hook allows only the `researcher` agent, whose definition pins the first Claude member of the `researcher` role, provides read-only web tools (`WebFetch`, `WebSearch`), and refuses a per-call model override. Every other native launch is refused; execution uses the CLI routes above.
Codex research uses `launch-worker.sh --research --role-id researcher`, which runs read-only with `web_search="live"` and needs no git repository (#133).

## Role tool limits

Builders, implementation and batch on both CLIs, run with the installed builder profile, which `launch-worker.sh` applies and refuses to launch without (#178). WebFetch, WebSearch and read-only `gh` stay allowed (Jon, 2026-10-18). The `role-gate` hook backs the `gh`, push, tag and settings denies. The eng lead and developers share the machine settings.

- Claude: `~/.agents/roles/builder.claude.json` denies session, scheduling and subagent tools, `gh` issue, PR, release and label writes, `git push`, `wrsp-agents install` and `wrsp-agents roles apply`, and edits under `~/.claude`, `~/.codex`, `~/.agents` and `~/.claude.json`.
- Codex: `~/.agents/roles/builder.codex.args` turns off the apps, browser, computer-use, image-generation and multi-agent features for execution and research launches. The six `collaboration.*` tools (`spawn_agent`, `send_message`, `followup_task`, `wait_agent`, `interrupt_agent`, `list_agents`) stay available: Codex 0.163.0's bundled model presets select `multi_agent_version = "v2"`, neither `features.multi_agent=false` nor `features.multi_agent_v2=false` removes them, and the `disabled_tools` key covers only MCP server tools (#183, probed 2026-10-18). For builder sessions the `role-gate` hook, registered for tool names matching `^collaboration` (Codex passes them as `collaborationspawn_agent` and so on), denies all six once Jon trusts that hook in the Codex desktop app (#186).
- Codex skills: every Codex launch lists the skills in `~/.agents/skills`. `-c 'skills.config=[{name="<skill>", enabled=false}]'`, or `path=` the skill's `SKILL.md`, hides that skill from the launch (#183, verified on 0.163.0). The builder profile hides `developer` and `eng-lead` this way; `launch-worker.sh` accepts that one `skills.config` disable-list shape besides `key=true|false` lines (#186).
- Claude skills: WRSP installs per-skill `~/.claude/skills/<name>` links to `~/.agents/skills/<name>`, where Claude Code discovers them.
- Reviewers: the Codex reviewer launch passes the same five feature overrides from code, without the builder-only `skills.config` line (`CODEX_REVIEW_FEATURE_LIMITS` in `src/push-review.ts`), and the Claude reviewer stays limited to Read, Grep and Glob. Researchers: Codex research launches take the same overrides, and the Claude `researcher` agent keeps its Read, Grep, Glob, WebFetch and WebSearch tool list.

## Brief builders through the builder skill

Every builder brief starts with the body of the `builder` skill
(`~/.agents/skills/builder/SKILL.md`, tracked in WRSP `skills/`). It carries the
builder role, the reporting format, and the Codex harness-fault rules for WRSP
#69 and #70 in one place. The developer skill's
`scripts/launch-worker.sh` prepends it, runs the banned-phrase check below,
sets `WRSP_ROLE=builder`, and writes the builder's output to a log. The
developer launches with `--detach` and waits with `wrsp-wait.sh`; launchd,
not the developer's shell, owns the builder process. The builder itself never
backgrounds anything.

## Brief content

The developer settles design before launching an execution builder. A builder
implements a settled design; it never decides one.

1. A brief names the files and functions to change, with signatures; the data
   mapping; the behaviour to match, with file:line citations; refusal codes or
   messages; and each test's setup and expected assertion.
2. A brief that asks for a new test cites an existing test to copy by
   file:line range and gives the helper signatures it uses.
3. A brief never asks the builder to establish, decide, choose, find out, figure
   out, determine, investigate or explore anything the developer could read.
   `launch-worker.sh` runs the check before every execution launch; it ignores
   inline code spans and fenced code blocks, matches the stems `establish`,
   `decid`, `choos`, `choic`, `investigat`, `explor`, the verb forms
   determine/determines/determined/determining, "decision on/about/between",
   and find or figure followed by "out" even across a line break; remove or
   explicitly justify every hit, then relaunch with `--allow-phrase-hits`.
   Bare "find" is allowed
   ("grep to find callers").
4. Questions the developer cannot answer go to Jon before launch, never to
   the builder.
5. Builder discretion is local implementation only. When the brief looks wrong
   or incomplete, the builder prints one line starting `BRIEF GAP:` naming the
   missing decision and exits without edits.
6. The brief is posted to the issue before launch. Before candidate review the
   developer checks the diff against the brief; any departure is a finding.

## Separate review and design

WRSP candidate review follows its own ranked, cross-family policy and records
native receipt provenance. Read-only review and design workflows retain their
explicit model/effort selections, including `dual-model-design`. They grant no
implementation exception. Use their capable CLI or API routes; native Claude subagents other than `researcher` remain refused. Separate planning sessions retain
their existing explicit authorization requirement.
