#!/usr/bin/env bash
# WRSP #197: one detached process per lane turn; identity survives process exit.
set -euo pipefail
readonly sender="From: eng lead, not Jon. Jon's words appear only as quoted text with their source."

refuse() { printf 'REFUSED: %s\n' "$2" >&2; exit "$1"; }
absolute() { case $1 in /*) printf '%s\n' "$1";; *) printf '%s/%s\n' "$PWD" "$1";; esac; }
load() {
  local loaded
  [[ -r $1 ]] && loaded=$(cat "$1") && jq -e 'type == "object" and (.turn | type == "number")' <<< "$loaded" >/dev/null 2>&1 || refuse 65 'handle missing or unreadable'
  handle=$1
  n=$(jq -r .turn <<< "$loaded")
  log=$(jq -r .contact <<< "$loaded")
}
atomic() { cat > "$handle.tmp.$$"; mv -f "$handle.tmp.$$" "$handle"; }
view() {
  node - "$@" <<'NODE'
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const count = value => Number.isSafeInteger(value) && value >= 0;
const safeLane = value => typeof value === 'string' && /^[A-Za-z0-9.-]+$/.test(value);
const read = file => { try { return fs.readFileSync(file, 'utf8'); } catch { return null; } };
const records = file => {
  const text = read(file) ?? '';
  return text.slice(0, text.lastIndexOf('\n') + 1).split('\n').flatMap(line => {
    try { const row = JSON.parse(line); return row && typeof row === 'object' && !Array.isArray(row) ? [row] : []; } catch { return []; }
  });
};
function context(handle) {
let tokens, budget;
try {
  budget = handle.budget;
  // Existing handles store the selected budget as a decimal string.
  if (typeof budget === 'string' && /^[0-9]+$/.test(budget)) budget = Number(budget);
  if (!count(budget) || budget === 0 || !handle.thread || !['codex', 'claude'].includes(handle.cli)) throw new Error('unknown metadata');
  const text = fs.readFileSync(handle.verification.source.path, 'utf8');
  // Only newline-terminated records are complete; a writer may be mid-record.
  const lines = text.slice(0, text.lastIndexOf('\n') + 1).split('\n');
  for (let index = lines.length - 1; index >= 0; index--) {
    let record;
    try { record = JSON.parse(lines[index]); } catch { continue; }
    if (!record || typeof record !== 'object' || Array.isArray(record)) continue;
    if (handle.cli === 'codex' && record.payload?.type === 'token_count') {
      tokens = record.payload.info?.last_token_usage?.input_tokens;
      break;
    }
    if (handle.cli === 'claude' && record.type === 'assistant' && !record.isSidechain && !record.parentToolUseID && !record.parent_tool_use_id && record.message?.usage != null) {
      const usage = record.message.usage;
      const values = [usage.input_tokens, usage.cache_read_input_tokens ?? 0, usage.cache_creation_input_tokens ?? 0];
      tokens = values.every(count) ? values.reduce((sum, value) => sum + value, 0) : undefined;
      break;
    }
  }
} catch { tokens = undefined; }
return count(tokens) ? { status: `context: ${tokens} / ${budget} (${(tokens / budget * 100).toFixed(1)}%)`, percent: `${(tokens / budget * 100).toFixed(1)}%` } : { status: 'context: unknown', percent: 'unknown' };
}
const [mode, target, ...args] = process.argv.slice(2);
if (mode === 'context') {
  let handle; try { handle = JSON.parse(read(target)); } catch {}
  console.log(context(handle).status);
} else if (mode === 'event') {
  try {
    const handle = JSON.parse(fs.readFileSync(target, 'utf8'));
    const [event, ...options] = args;
    if (!safeLane(handle.lane) || !count(handle.turn) || !['started','work-sent','assigned','released','blocked','retired'].includes(event)) throw new Error('invalid event metadata');
    let issue = Number(handle.issue), reason = null, input;
    const seen = new Set();
    for (let i = 0; i < options.length; i += 2) {
      const key = options[i], value = options[i+1];
      if (seen.has(key) || value === undefined) throw new Error('invalid event arguments');
      seen.add(key);
      if (key === '--issue' && /^[0-9]+$/.test(value)) issue = Number(value);
      else if (key === '--reason') reason = value;
      else if (key === '--input' && event === 'work-sent') input = value;
      else throw new Error('invalid event arguments');
    }
    if (!count(issue)) throw new Error('invalid event issue');
    const row = { at: new Date().toISOString(), event, lane: handle.lane, slot: handle.slot ?? handle.lane, turn: handle.turn, issue, reason };
    if (event === 'work-sent') {
      const bytes = fs.readFileSync(input);
      row.sha256 = require('node:crypto').createHash('sha256').update(bytes).digest('hex');
      row.firstLine = bytes.toString('utf8').split('\n')[0];
    }
    fs.appendFileSync(path.join(path.dirname(target), handle.lane + '.events.jsonl'), JSON.stringify(row) + '\n');
  } catch (error) { console.error('REFUSED: event not written: ' + error.message); process.exit(65); }
} else if (mode === 'board') {
  const clean = value => String(value ?? 'unknown').replace(/[\t\r\n]/g, ' ');
  const validEvent = (row, lane) => typeof row.at === 'string' && /^\d{4}-\d\d-\d\dT.*Z$/.test(row.at) && Number.isFinite(Date.parse(row.at)) && row.lane === lane && typeof row.slot === 'string' && count(row.turn) && count(row.issue) && (row.reason === null || typeof row.reason === 'string') && ['started','work-sent','assigned','released','blocked','retired'].includes(row.event) && (row.event !== 'work-sent' || (typeof row.sha256 === 'string' && /^[a-f0-9]{64}$/.test(row.sha256) && typeof row.firstLine === 'string'));
  const rows = [];
  let files;
  try { files = fs.readdirSync(target).filter(name => name.endsWith('.lane.json')); }
  catch (error) { console.error('REFUSED: board directory unreadable: ' + error.message); process.exit(65); }
  for (const file of files) {
    const filename = path.join(target, file), fallback = file.slice(0, -10);
    let handle;
    try {
      handle = JSON.parse(fs.readFileSync(filename, 'utf8'));
      if (!handle || !safeLane(handle.lane) || !count(handle.turn) || typeof handle.contact !== 'string') throw new Error('invalid handle');
    } catch { rows.push([fallback, fallback, 'unknown', 'unknown', 'unknown', 'unknown', 'unknown']); continue; }
    const log = handle.contact;
    let state;
    if (fs.existsSync(log + '.exit')) state = 'exited ' + (read(log + '.exit') ?? 'unknown').trim();
    else {
      const pid = (read(log + '.pid') ?? '').trim();
      const live = /^[0-9]+$/.test(pid) && spawnSync('ps', ['-p', pid], { stdio: 'ignore' }).status === 0;
      state = live ? 'live' : fs.existsSync(filename + '.lock') ? 'interrupted' : 'none';
    }
    const events = records(path.join(target, handle.lane + '.events.jsonl')).filter(row => validEvent(row, handle.lane));
    let message, messageTurn;
    if (state.startsWith('exited ')) {
      const turns = Array.isArray(handle.turns) ? handle.turns.filter(turn => turn && count(turn.n) && typeof turn.log === 'string') : [];
      if (!turns.some(turn => turn.n === handle.turn)) turns.push({ n: handle.turn, log });
      turns.sort((a, b) => b.n - a.n);
      for (const turn of turns) {
        for (const row of records(turn.log).reverse()) {
          const text = handle.cli === 'codex' && row.type === 'item.completed' && row.item?.type === 'agent_message' ? row.item.text : handle.cli === 'claude' && row.type === 'result' ? row.result : undefined;
          if (typeof text === 'string' && text.length) { message = text.split(/\r?\n/)[0]; messageTurn = turn.n; break; }
        }
        if (message !== undefined) break;
      }
      if (message !== undefined && (/^\S+ review (start|done)\b/.test(message) || /\b(handoff|handed off|milestone)\b/i.test(message)) && !events.some(row => row.event === 'work-sent' && row.turn > messageTurn)) state = 'needs-reply';
      if (events.at(-1)?.event === 'retired') state = 'retired';
    }
    rows.push([handle.lane, handle.slot ?? handle.lane, state, handle.turn, context(handle).percent, events.at(-1)?.event ?? 'unknown', message ?? 'unknown']);
  }
  rows.sort((a, b) => Number(a[2] === 'retired') - Number(b[2] === 'retired') || Number(b[2] === 'needs-reply') - Number(a[2] === 'needs-reply') || (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0));
  console.log('lane\tslot\tstate\tturn\tcontext\tlast-event\tlast-message');
  for (const row of rows) console.log(row.map(clean).join('\t'));
} else process.exit(64);
NODE
}
context() { view context "$handle"; }
event_success() {
  view event "$handle" "$@" || printf 'WARNING: event append failed after successful submission; admitted work was not replayed or rolled back.\n' >&2
}
manual_event_options() {
  while [[ $# -gt 0 ]]; do
    [[ $# -ge 2 && $2 != --* ]] || refuse 64 'missing event argument'
    case $1 in --issue|--reason) ;; *) refuse 64 'invalid manual event argument';; esac
    shift 2
  done
}
# Native metadata only: never infer served configuration from argv or assistant prose.
native() {
  node - "$@" <<'NODE'
const fs = require('node:fs');
const path = require('node:path');
const args = process.argv.slice(2);
const normalize = value => value === 'medium' ? 'med' : value;
if (args[0] === 'find') {
  const [, cli, session] = args;
  if (!session || /[/\\]/.test(session)) process.exit(81);
  const root = path.join(process.env.HOME, cli === 'claude' ? '.claude/projects' : '.codex/sessions');
  const matches = [];
  function walk(dir, depth) {
    for (const entry of fs.readdirSync(dir, {withFileTypes:true})) {
      const file = path.join(dir, entry.name);
      if (entry.isDirectory() && (cli === 'codex' || depth === 0)) walk(file, depth + 1);
      else if (entry.isFile() && (cli === 'claude' ? entry.name === session + '.jsonl' : entry.name.startsWith('rollout-') && entry.name.endsWith('-' + session + '.jsonl'))) matches.push(file);
    }
  }
  try { walk(root, 0); } catch (error) { if (error.code !== 'ENOENT') { console.error(error.message); process.exit(81); } }
  if (matches.length !== 1) { console.error('native transcript ' + (matches.length ? 'ambiguous' : 'missing') + ' for ' + session); process.exit(matches.length ? 81 : 82); }
  console.log(path.resolve(matches[0]));
  process.exit(0);
}
if (args.shift() !== 'verify') process.exit(64);
const options = {};
const allowed = new Set(['--cli','--role-id','--model','--effort','--session','--transcript','--offset']);
for (let i = 0; i < args.length; i += 2) {
  if (!allowed.has(args[i]) || options[args[i]] !== undefined || !args[i+1] || args[i+1].startsWith('--')) process.exit(64);
  options[args[i]] = args[i+1];
}
if (!['claude','codex'].includes(options['--cli']) || ['--role-id','--model','--effort','--session','--transcript'].some(key => !options[key]) || !/^\d+$/.test(options['--offset'] || '0')) process.exit(64);
const start = Number(options['--offset'] || 0);
if (!Number.isSafeInteger(start)) process.exit(64);
const cli = options['--cli'];
const session = options['--session'];
const report = {
  state:'refused', phase:'bootstrap',
  requested:{role:options['--role-id'],model:options['--model'],effort:normalize(options['--effort'])},
  reported:{model:null,effort:null,nativeEffort:null},
  source:{provider:cli,session,path:path.resolve(options['--transcript']),start,end:start}, reason:''
};
function fail(reason) { throw new Error(reason); }
function field(values, label, norm = value => value) {
  const supplied = values.filter(value => value !== undefined);
  if (!supplied.length) return null;
  if (supplied.some(value => typeof value !== 'string' || !value.trim())) fail('unknown native ' + label);
  if (new Set(supplied.map(norm)).size !== 1) fail('conflicting native ' + label);
  return supplied[0];
}
try {
  const bytes = fs.readFileSync(report.source.path);
  report.source.end = bytes.length;
  if (start > bytes.length || (start > 0 && bytes[start-1] !== 10)) fail('invalid native offset or truncation');
  if (bytes.length && bytes[bytes.length-1] !== 10) fail('truncated native record');
  let position = 0;
  const rows = new TextDecoder('utf-8', {fatal:true}).decode(bytes).split('\n').slice(0,-1).map(line => {
    const at = position; position += Buffer.byteLength(line) + 1;
    try {
      const row = JSON.parse(line);
      if (!row || typeof row !== 'object' || Array.isArray(row)) fail('malformed native record');
      return {at,row};
    } catch { if (at < start) return {at,row:{}}; fail('malformed native record'); }
  });
  if (cli === 'codex') {
    const ids = rows.filter(({row}) => row.type === 'session_meta').map(({row}) => row.payload?.id);
    if (!ids.length || ids.some(id => id !== session)) fail('native session identity mismatch or missing');
  }
  let context;
  let assistant;
  for (const {at,row} of rows) {
    if (at < start) continue;
    if (cli === 'codex' && row.type === 'turn_context') context = row.payload;
    if (cli === 'claude' ? row.type === 'assistant' && !row.isSidechain && !row.parentToolUseID && !row.parent_tool_use_id : row.type === 'response_item' && row.payload?.type === 'message' && row.payload.role === 'assistant') {
      assistant = row; break;
    }
  }
  if (!assistant) fail('missing fresh parent assistant metadata');
  if (cli === 'claude' && assistant.sessionId !== session) fail('native session identity mismatch');
  if (cli === 'claude' && assistant.message?.role !== 'assistant') fail('missing native assistant role');
  const value = cli === 'claude' ? assistant : context;
  if (!value) fail('missing fresh turn context before first assistant');
  const settings = cli === 'codex' ? value.collaboration_mode?.settings : undefined;
  report.reported.model = field(cli === 'claude' ? [value.message?.model] : [value.model], 'model');
  report.reported.nativeEffort = field(cli === 'claude' ? [value.perTurnEffort,value.effort] : [value.effort,value.reasoning_effort], 'effort', normalize);
  report.reported.effort = normalize(report.reported.nativeEffort);
  if (cli === 'codex') {
    field([value.model,settings?.model], 'model');
    field([value.effort,value.reasoning_effort,settings?.reasoning_effort], 'effort', normalize);
  }
  if (!report.reported.model || !report.reported.effort) fail('missing native model or effort');
  let members;
  try { members = fs.readFileSync(process.env.WRSP_ROLES_MEMBERS || path.join(process.env.HOME,'.agents/roles.members'),'utf8').split('\n').map(line => line.split('\t')); }
  catch { fail('role membership source missing or unreadable'); }
  const member = (model,effort) => members.some(([role,m,e,budget]) => role === report.requested.role && m === model && normalize(e) === effort && /^\d+$/.test(budget) && Number(budget) > 0);
  if (!member(report.reported.model,report.reported.effort)) fail('native pair is not a current positive-budget role member');
  if (!member(report.requested.model,report.requested.effort)) fail('requested pair is not a current positive-budget role member');
  if (report.requested.model !== report.reported.model || report.requested.effort !== report.reported.effort) fail('native pair differs from requested pair');
  report.state = 'accepted';
} catch (error) { report.reason = error.message; }
console.log(JSON.stringify(report));
process.exit(report.state === 'accepted' ? 0 : 81);
NODE
}
pending() {
  jq '.verification={state:"pending",phase:(if .turn == 1 then "bootstrap" else "resume" end),requested:{role:.role_id,model:.model,effort:(if .effort == "medium" then "med" else .effort end)},reported:{model:null,effort:null,nativeEffort:null},source:{provider:.cli,session:.thread,path:null,start:0,end:0},reason:""} | .turns[-1].verification=.verification' "$handle" | atomic
}
save_verification() {
  jq --argjson report "$verification" --arg preserve "${1:-no}" '.verification=$report | .turns[-1].verification=$report | if $report.state == "accepted" and ($report.phase == "bootstrap" or $report.phase == "work") then .qualification=$report elif $report.state == "refused" and $preserve != "yes" then .qualification=null else . end' "$handle" | atomic
  jq -nr --argjson v "$verification" --arg selection "$(jq -r '.selection_reason // ""' "$handle")" '$v | "PAIR \(.state | ascii_upcase) phase=\(.phase) requested=\(.requested.model)/\(.requested.effort) native=\(.reported.model // "unknown")/\(.reported.effort // "unknown") source=\(.source | tojson) reason=\(.reason) selection-reason=\($selection)"' >> "$log"
}
provider_command() {
  local fresh=$1 cli_effort=$effort override members reserve auto_compact_window settings
  [[ $cli_effort != med ]] || cli_effort=medium
  cmd=(env WRSP_ROLE=developer "WRSP_CONTEXT_BUDGET=$budget")
  if [[ $cli == claude ]]; then
    members=${WRSP_ROLES_MEMBERS:-$HOME/.agents/roles.members}
    if ! reserve=$(awk -F '\t' '/^# claude-auto-compact-reserve([[:space:]]|$)/ { count++; if (NF == 2 && $1 == "# claude-auto-compact-reserve" && $2 ~ /^[1-9][0-9]*$/) value=$2; else invalid=1 } END { if (count != 1 || invalid) exit 1; print value }' "$members"); then
      printf 'Refusing launch: %s has no valid Claude compaction reserve (WRSP #325). Run wrsp-agents install.\n' "$members" | tee -a "$log" >&2
      return 66
    fi
    auto_compact_window=$((budget + reserve))
    settings=$(jq -c --argjson b "$auto_compact_window" '. + {autoCompactWindow: $b}' "$roles/developer.claude.json") || return 66
    cmd+=(claude -p --model "$model" --effort "$cli_effort" --settings "$settings" --permission-mode bypassPermissions)
    if [[ $fresh == yes ]]; then cmd+=(--session-id "$thread" --name "$(jq -r .title "$handle")"); else cmd+=(--resume "$thread"); fi
    cmd+=(--output-format json)
  else
    cmd+=(codex exec)
    [[ $fresh == yes ]] || cmd+=(resume "$thread")
    cmd+=(--json -m "$model" -c "model_reasoning_effort=$cli_effort" -c "model_auto_compact_token_limit=$budget")
    while IFS= read -r override || [[ -n $override ]]; do
      [[ -z $override || $override == \#* ]] || cmd+=(-c "$override")
    done < "$roles/developer.codex.args"
    [[ $fresh != yes ]] || cmd+=(-C "$worktree")
    cmd+=(-)
  fi
}
bootstrap() {
  # The issue file is never opened here. Bound only the metadata exchange (#390: start validated the wait).
  node -e '
    const {spawnSync} = require("node:child_process");
    const seconds = Number(process.argv[2]);
    const result = spawnSync(process.argv[3], process.argv.slice(4), {
      input:process.argv[1] + "\n\nStartup metadata verification only. Reply exactly LANE_READY. Do not use tools, claim an issue, edit files, launch children, or perform issue work. The issue brief arrives in a later message.",
      stdio:["pipe",1,2], timeout:seconds * 1000
    });
    const waited = result.error?.code === "ETIMEDOUT" ? "; no reply within " + seconds + "s; set WRSP_LANE_BOOTSTRAP_TIMEOUT=<seconds> to wait longer" : "";
    if (result.error || result.signal) { console.error("bootstrap timeout/abort: " + (result.error?.message || result.signal) + waited); process.exit(70); }
    process.exit(result.status ?? 70);
  ' "$sender" "${WRSP_LANE_BOOTSTRAP_TIMEOUT:-90}" "${cmd[@]}"
}
live() {
  [[ -s ${log}.pid ]] || return 1
  pid=$(cat "${log}.pid")
  [[ $pid =~ ^[0-9]+$ ]] && ps -p "$pid" >/dev/null 2>&1
}
state() {
  if [[ -f ${log}.exit ]]; then printf 'exited %s' "$(cat "${log}.exit")"
  elif live; then printf live
  elif [[ -d $handle.lock ]]; then printf interrupted
  else printf none; fi
}
record_fact() { # Same best-effort boundary as launch-worker.sh (#196).
  if ! command -v "$usage_bin" >/dev/null 2>&1; then
    echo "WARNING: launch record not written: $usage_bin is not on PATH (#196)." >> "$log"
    return 0
  fi
  "$usage_bin" "$@" >/dev/null 2>>"$log" || echo "WARNING: launch record not written: $usage_bin $1 $2 exited $? (#196)." >> "$log"
  return 0
}
remove_job() {
  if [[ -n ${WRSP_LANE_REMOVE:-} ]]; then
    "$WRSP_LANE_REMOVE" "$1" >/dev/null 2>&1 || true
  else
    launchctl remove "$1" >/dev/null 2>&1 || true
  fi
}
submit() {
  local label=$1
  local self
  self=$(absolute "$0")
  local cmd=(launchctl submit -l "$label" --)
  [[ -z ${WRSP_LANE_SUBMIT:-} ]] || cmd=("$WRSP_LANE_SUBMIT")
  cmd+=(/usr/bin/env "PATH=$PATH" "HOME=$HOME" "TMPDIR=${TMPDIR:-/tmp}")
  [[ -z ${WRSP_ROLES_DIR:-} ]] || cmd+=("WRSP_ROLES_DIR=$(absolute "$WRSP_ROLES_DIR")")
  [[ -z ${WRSP_ROLES_MEMBERS:-} ]] || cmd+=("WRSP_ROLES_MEMBERS=$(absolute "$WRSP_ROLES_MEMBERS")")
  [[ -z ${WRSP_USAGE_BIN:-} ]] || cmd+=("WRSP_USAGE_BIN=$WRSP_USAGE_BIN")
  [[ -z ${WRSP_LANE_REMOVE:-} ]] || cmd+=("WRSP_LANE_REMOVE=$WRSP_LANE_REMOVE")
  [[ -z ${WRSP_LANE_BOOTSTRAP_TIMEOUT:-} ]] || cmd+=("WRSP_LANE_BOOTSTRAP_TIMEOUT=$WRSP_LANE_BOOTSTRAP_TIMEOUT")
  cmd+=(/bin/bash "$self" run-turn "$handle" "$n" "$label")
  local code=0
  "${cmd[@]}" || code=$?
  if [[ $code != 0 ]]; then remove_job "$label"; fi
  return "$code"
}
send_error() { printf 'REFUSED: %s\n' "$2" >&2; return "$1"; }
send_role() {
  [[ -n $(jq -r '.role_id // ""' "$handle") ]] || { send_error 64 "handle $handle has no role_id: it was started with --tier, which #243 removed; relaunch the lane with --role-id"; return 64; }
  [[ $(jq -r .role "$handle") != developer || $(jq -r .role_id "$handle") == developer ]] || { send_error 64 'developer requires --role-id developer'; return 64; }
  [[ $(jq -r .role "$handle") != principal-engineer || $(jq -r .role_id "$handle") == principal-engineer ]] || { send_error 64 'principal-engineer requires --role-id principal-engineer'; return 64; }
}
send_identity() {
  send_role || return $?
  worktree=$(jq -r .worktree "$handle")
  [[ -d $worktree ]] || { send_error 80 "worktree $worktree is missing; recreate it or start a new lane"; return 80; }
  [[ -n $(jq -r '.thread // empty' "$handle") ]] || { send_error 77 'provider thread or session id missing'; return 77; }
}
admit_send() { # Caller owns the turn lock; rollback is byte-for-byte.
  local input=$1 expected_turn=${2:-} before=$handle.previous.$$ code=0
  if ! jq -e 'type == "object" and (.turn | type == "number")' "$handle" >/dev/null 2>&1; then
    rmdir "$handle.lock"; send_error 65 'handle missing or unreadable'; return 65
  fi
  n=$(jq -r .turn "$handle"); log=$(jq -r .contact "$handle")
  if [[ -n $expected_turn && $n != "$expected_turn" ]]; then
    rmdir "$handle.lock"; send_error 75 'another send advanced the lane while waiting'; return 75
  fi
  send_identity || code=$?
  if [[ $code != 0 ]]; then rmdir "$handle.lock"; return "$code"; fi
  if ! cp "$handle" "$before"; then rm -f "$before"; rmdir "$handle.lock"; return 69; fi
  n=$((n + 1)); log=${handle%.lane.json}.turn-$n.log
  label=com.whiteroom.wrsp-lane.$(jq -r .lane "$handle").$n.$(date +%s)
  if ! jq --argjson n "$n" --arg log "$log" --arg input "$input" --arg label "$label" '.turn=$n | .contact=$log | .next_exchange=$input | .turns += [{n:$n,log:$log,input:$input,label:$label}]' "$handle" | atomic; then code=69; fi
  if [[ $code == 0 ]]; then pending || code=69; fi
  if [[ $code == 0 ]]; then submit "$label" || code=69; fi
  if [[ $code != 0 ]]; then
    cat "$before" | atomic
    rm "$before"; rmdir "$handle.lock"
    send_error 69 'submission failed'; return 69
  fi
  rm "$before"
  event_success work-sent --input "$input"
}
command=${1:-}; [[ $# -eq 0 ]] || shift
case $command in
  help|--help|-h)
    cat <<'HELP'
Usage: lane.sh <command>
  start --role ROLE --cli claude|codex --role-id ID --model MODEL --effort EFFORT
        --worktree DIR --issue N --brief FILE --title TEXT --log FILE
        [--selection-reason TEXT] [--slot SLOT] [--successor-of HANDLE]
  send [--when-idle] HANDLE FILE
  event HANDLE assigned|released|blocked|retired [--issue N] [--reason TEXT]
  board [DIR]                     Read-only TSV; defaults to current directory
  status HANDLE | read HANDLE [--cursor N] | recover HANDLE
  title --role ROLE --task TEXT [--lane LANE] [--issues TEXT] [--state done]
  verify-pair --cli CLI --role-id ID --model MODEL --effort EFFORT
              --session ID --transcript FILE [--offset N]
  run-turn HANDLE N LABEL         Internal submitted turn
HELP
    ;;
  board)
    [[ $# -le 1 ]] || refuse 64 'invalid board arguments'
    view board "${1:-.}"
    ;;
  event)
    [[ $# -ge 2 ]] || refuse 64 'missing event arguments'
    case $2 in assigned|released|blocked|retired) ;; *) refuse 64 'invalid manual event';; esac
    # Internal writer options are not part of the manual command.
    manual_handle=$1; manual_event=$2; shift 2
    manual_event_options "$@"
    view event "$manual_handle" "$manual_event" "$@"
    ;;
  verify-pair) native verify "$@";;
  title)
    role= lane= task= issues= state=
    while [[ $# -gt 0 ]]; do
      [[ $# -ge 2 && -n $2 ]] || refuse 64 'missing argument'
      case $1 in
        --role) role=$2;; --lane) lane=$2;; --task) task=$2;;
        --issues) issues=$2;; --state) state=$2;; *) refuse 64 'unknown argument';;
      esac; shift 2
    done
    # Names table: keep role glyphs in this single block.
    case $role in
      eng-lead) emoji=👽;;
      developer) emoji=👩‍💻;;
      builder) emoji=🔧;;
      reviewer) emoji=👀;;
      researcher) emoji=🔬;;
      locator) emoji=🔍;;
      ux-principal) emoji=👩‍🎤;;
      principal-engineer) emoji=🧙;;
      batch) emoji=🤖;;
      *) refuse 64 'unknown role';;
    esac
    case $state in '') ;; done) emoji=💀;; *) refuse 64 'unknown state';; esac
    [[ -n $task ]] || refuse 64 'missing task'
    printf '%s%s %s%s\n' "$emoji" "${lane:+ $lane:}" "$task" "${issues:+ $issues}"
    ;;
  start)
    role= cli= role_id= model= effort= worktree= issue= brief= title= log= selection_reason= slot= successor_of=
    while [[ $# -gt 0 ]]; do
      [[ $# -ge 2 && -n $2 && $2 != --* ]] || refuse 64 'missing argument'
      case $1 in
        --role) role=$2;; --cli) cli=$2;; --role-id) role_id=$2;; --model) model=$2;;
        --effort) effort=$2;; --worktree) worktree=$2;; --issue) issue=$2;;
        --brief) brief=$2;; --title) title=$2;; --log) log=$2;; --selection-reason) selection_reason=$2;;
        --slot) slot=$2;; --successor-of) successor_of=$(absolute "$2");; *) refuse 64 'unknown argument';;
      esac; shift 2
    done
    [[ -n $role && -n $cli && -n $model && -n $effort && -n $worktree && -n $issue && -n $brief && -n $title && -n $log ]] || refuse 64 'missing argument'
    [[ -n $role_id ]] || refuse 64 '--role-id is required (#243)'
    [[ $role == developer || $role == ux-principal || $role == principal-engineer ]] || refuse 64 'unknown role'
    [[ $role != principal-engineer || $role_id == principal-engineer ]] || refuse 64 'principal-engineer requires --role-id principal-engineer'
    [[ $role != developer || $role_id == developer ]] || refuse 64 'developer requires --role-id developer'
    [[ $cli == claude || $cli == codex ]] || refuse 64 'unknown cli'
    bootstrap_timeout=${WRSP_LANE_BOOTSTRAP_TIMEOUT:-90}
    [[ $bootstrap_timeout =~ ^[1-9][0-9]*$ ]] && (( ${#bootstrap_timeout} <= 5 && bootstrap_timeout <= 86400 )) || refuse 64 "WRSP_LANE_BOOTSTRAP_TIMEOUT must be a positive integer of seconds up to 86400, not $bootstrap_timeout (#390)"
    [[ $effort != medium ]] || effort=med
    [[ $issue =~ ^[0-9]+$ && -r $brief ]] || refuse 64 'invalid issue or unreadable brief'
    stem=$(absolute "${log%.log}"); handle=$stem.lane.json
    [[ ! -e $handle ]] || refuse 65 'handle exists; use send'
    [[ -d $worktree ]] || refuse 66 'worktree not a directory'
    git_dir=$(git -C "$worktree" rev-parse --git-dir) || refuse 66 'worktree is not a Git worktree'
    common_dir=$(git -C "$worktree" rev-parse --git-common-dir) || refuse 66 'worktree is not a Git worktree'
    git_dir=$(cd "$worktree" && cd "$git_dir" && pwd -P) || refuse 66 'cannot resolve worktree Git directories'
    common_dir=$(cd "$worktree" && cd "$common_dir" && pwd -P) || refuse 66 'cannot resolve worktree Git directories'
    [[ $git_dir != "$common_dir" ]] || refuse 66 'worktree is the repository main worktree; create an issue worktree first'
    budget=$(awk -F '\t' -v role_id="$role_id" -v m="$model" -v e="$effort" '$1==role_id && $2==m && $3==e {print $4; exit}' "${WRSP_ROLES_MEMBERS:-$HOME/.agents/roles.members}" 2>/dev/null) || budget=
    [[ $budget =~ ^[0-9]+$ && $budget -gt 0 ]] || refuse 67 "role $role_id has no pair ($model, $effort)"
    if [[ $role == developer ]]; then
      preferred=$(awk -F '\t' '$1=="developer" {print $2 "\t" $3; exit}' "${WRSP_ROLES_MEMBERS:-$HOME/.agents/roles.members}")
      [[ $preferred == "$model"$'\t'"$effort" || $selection_reason =~ [^[:space:]] ]] || refuse 64 'nonpreferred developer pair requires --selection-reason'
    fi
    command -v "$cli" >/dev/null 2>&1 || refuse 69 "$cli is not on PATH"
    # WRSP #249: refuse a CLI below the model's vendor-stated minimum; an unlisted model is never refused.
    minimums=${WRSP_CLI_MINIMUMS:-$HOME/.agents/cli-minimums}
    [[ -r $minimums ]] || refuse 66 "cli-minimums not found: $minimums. Run wrsp-agents install."
    minimum=$(awk -F '\t' -v m="$model" -v c="$cli" '!/^#/ && $1 == m && $2 == c { print $3; exit }' "$minimums") || minimum=
    if [[ -n $minimum ]]; then
      installed=$("$cli" --version </dev/null 2>/dev/null | grep -Eo '[0-9]+\.[0-9]+\.[0-9]+' | head -n 1) || installed=
      [[ -n $installed ]] || refuse 69 "$cli version unreadable ($cli --version); $model needs $cli $minimum or later."
      if [[ $(awk -v a="$installed" -v b="$minimum" 'BEGIN { split(a, x, "."); split(b, y, "."); for (i = 1; i <= 3; i++) if (x[i] + 0 != y[i] + 0) { print (x[i] + 0 < y[i] + 0); exit } print 0 }') == 1 ]]; then
        refuse 69 "$cli $installed is below $model's minimum $minimum; upgrade $cli to $minimum or later"
      fi
    fi
    worktree=$(cd "$worktree" && pwd -P); brief=$(absolute "$brief")
    project=$(git -C "$worktree" rev-parse --show-toplevel)
    lane=$(basename "$stem"); lane=${lane//[^A-Za-z0-9.-]/-}
    [[ -n $slot ]] || slot=$lane
    parent=$(node -e '
      const c = process.env.CLAUDE_CODE_SESSION_ID, x = process.env.CODEX_THREAD_ID;
      const id = c ?? x;
      const known = (c !== undefined) !== (x !== undefined) && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id ?? "");
      console.log(JSON.stringify(known ? {provider:c !== undefined ? "claude-code" : "codex",sessionId:id} : null));
    ')
    launch_id=$(uuidgen | tr '[:upper:]' '[:lower:]'); thread=; provider=openai
    if [[ $cli == claude ]]; then provider=anthropic; thread=$(uuidgen | tr '[:upper:]' '[:lower:]'); fi
    n=1; log=$stem.turn-1.log
    label=com.whiteroom.wrsp-lane.$lane.$n.$(date +%s)
    mkdir "$handle.lock" 2>/dev/null || refuse 65 'handle exists; use send'
    jq -n --argjson parent "$parent" --arg slot "$slot" --arg successor_of "$successor_of" --arg lane "$lane" --arg role "$role" --arg title "$title" --arg cli "$cli" --arg provider "$provider" --arg host "$(hostname -s)" --arg project "$project" --arg issue "$issue" --arg worktree "$worktree" --arg role_id "$role_id" --arg model "$model" --arg effort "$effort" --arg budget "$budget" --arg contact "$log" --arg launch_id "$launch_id" --arg thread "$thread" --arg input "$brief" --arg label "$label" --arg selection_reason "$selection_reason" \
      '{parent:$parent,slot:$slot,successor_of:(if $successor_of == "" then null else $successor_of end),lane:$lane,role:$role,title:$title,cli:$cli,provider:$provider,host:$host,project:$project,issue:$issue,worktree:$worktree,role_id:$role_id,model:$model,effort:$effort,budget:$budget,contact:$contact,launch_id:$launch_id,thread:$thread,turn:1,next_exchange:"brief",selection_reason:$selection_reason,turns:[{n:1,log:$contact,input:$input,label:$label}]}' | atomic
    pending
    if ! submit "$label"; then rm -f "$handle"; rmdir "$handle.lock"; refuse 69 'submission failed'; fi
    event_success started
    printf 'HANDLE: %s\n' "$handle"
    ;;
  send)
    when_idle=no; expected_turn=
    if [[ ${1:-} == --when-idle ]]; then when_idle=yes; shift; fi
    [[ $# -eq 2 && $1 != --* && $2 != --* && -r $2 ]] || refuse 64 'missing argument or unreadable message'
    load "$(absolute "$1")"; input=$(absolute "$2")
    send_identity || exit $?
    if [[ $when_idle == yes ]]; then
      expected_turn=$n
      while true; do
        load "$handle"
        send_identity || exit $?
        [[ $n == "$expected_turn" ]] || refuse 75 'another send advanced the lane while waiting'
        [[ -d $handle.lock ]] || break
        if [[ ! -e $log.exit ]] && ! live; then refuse 76 "interrupted turn $n; run lane.sh recover $handle"; fi
        sleep 1
      done
    fi
    if ! mkdir "$handle.lock" 2>/dev/null; then
      load "$handle"
      if [[ -n $expected_turn && $n != "$expected_turn" ]]; then refuse 75 'another send advanced the lane while waiting'; fi
      if live; then refuse 75 "busy, turn $n live (pid $pid)"; fi
      [[ ! -e $log.exit ]] || refuse 75 "busy, turn $n admission in progress"
      refuse 76 "interrupted turn $n; run lane.sh recover $handle"
    fi
    admit_send "$input" "$expected_turn" || exit $?
    printf 'HANDLE: %s\n' "$handle"
    ;;
  read)
    [[ $# -eq 1 || ( $# -eq 3 && $2 == --cursor && $3 =~ ^[0-9]+$ ) ]] || refuse 64 'invalid read arguments'
    load "$1"; cursor=${3:-0}
    if [[ -f $log ]]; then
      size=$(wc -c < "$log"); count=$((size - cursor)); (( count >= 0 )) || count=0
      (( count <= 65536 )) || count=65536
      dd if="$log" bs=1 skip="$cursor" count="$count" 2>/dev/null
      cursor=$((cursor + count))
    fi
    printf '\nCURSOR: %s\n' "$cursor"
    ;;
  status)
    [[ $# -eq 1 ]] || refuse 64 'missing handle'; load "$1"
    jq -r '. as $h | ["lane","role","title","cli","provider","role_id","model","effort","budget","issue","worktree","thread","turn"][] | . + ": " + ($h[.] // "" | tostring)' "$handle"
    jq -r '"verification-state: \(.verification.state // "unknown")\nverification-phase: \(.verification.phase // "unknown")\nreported-model: \(.verification.reported.model // "unknown")\nreported-effort: \(.verification.reported.effort // "unknown")\nnative-source: \(.verification.source // null | tojson)\nselection-reason: \(.selection_reason // "")"' "$handle"
    context
    lane_state=$(state)
    quiet=none
    if [[ $lane_state == live ]]; then
      quiet=$(node -e '
        try { console.log(Math.max(0, Math.floor((Date.now() - require("node:fs").statSync(process.argv[1]).mtimeMs) / 1000)) + "s"); }
        catch { console.log("unknown"); }
      ' "$log")
    fi
    printf 'state: %s\nquiet: %s\nturn-log: %s\nnext-exchange: %s\n' "$lane_state" "$quiet" "$log" "$(jq -r .next_exchange "$handle")"
    ;;
  recover)
    [[ $# -eq 1 ]] || refuse 64 'missing handle'; load "$1"
    send_role || exit $?
    [[ -d $handle.lock && ! -e ${log}.exit ]] && ! live || refuse 78 'turn is not interrupted'
    printf 'EXIT:70\n' >> "$log"; printf '70\n' > "${log}.exit"
    rmdir "$handle.lock"; printf 'RECOVERED turn %s\n' "$n"
    ;;
  run-turn)
    [[ $# -eq 3 ]] || refuse 64 'missing turn'
    label=$3; trap 'remove_job "$label"' EXIT
    load "$1"
    [[ $n == "$2" && -d $handle.lock ]] || refuse 78 'turn not admitted'
    if [[ -e ${log}.pid || -e ${log}.exit ]]; then
      printf 'RESPAWN REFUSED: turn %s already ran (pid file present); run lane.sh recover %s\n' "$n" "$handle" >> "$log"
      exit 79
    fi
    launch_id=$(jq -r .launch_id "$handle"); usage_bin=${WRSP_USAGE_BIN:-wrsp-usage}
    work_input=
    finish() {
      local code=$1
      trap - EXIT
      if [[ $(jq -r '.verification.state // ""' "$handle") == pending ]]; then
        verification=$(jq --arg code "$code" '.verification | .state="refused" | .reason="turn aborted before native acceptance (exit " + $code + ")"' "$handle")
        save_verification yes
      fi
      [[ $(tail -n 1 "$log" 2>/dev/null) == "EXIT:$code" ]] || printf 'EXIT:%s\n' "$code" >> "$log"
      record_fact launch-record exit --launch-id "$launch_id" --exit-code "$code" --log "$log"
      printf '%s\n' "$code" > "${log}.exit.tmp.$$"; mv -f "${log}.exit.tmp.$$" "${log}.exit"
      [[ -z $work_input ]] || rm -f "$work_input"
      rmdir "$handle.lock" 2>/dev/null || true
      remove_job "$label"
      exit "$code"
    }
    trap 'finish 70' EXIT
    printf '%s\n' "$$" > "${log}.pid.tmp.$$"; mv -f "${log}.pid.tmp.$$" "${log}.pid"
    cli=$(jq -r .cli "$handle"); model=$(jq -r .model "$handle"); effort=$(jq -r .effort "$handle")
    budget=$(jq -r .budget "$handle"); thread=$(jq -r .thread "$handle"); worktree=$(jq -r .worktree "$handle")
    input=$(jq -r '.turns[-1].input' "$handle")
    role_id=$(jq -r '.role_id // ""' "$handle")
    roles=${WRSP_ROLES_DIR:-$HOME/.agents/roles}
    if [[ $n == 1 ]]; then
      args=(launch-record start --launch-id "$launch_id" --issue "$(jq -r .issue "$handle")" --role "$(jq -r .role "$handle")" --cli "$cli" --model "$model" --effort "$effort" --worktree "$worktree" --brief "$input" --log "$log")
      [[ $cli != claude ]] || args+=(--child-session "$thread")
      if [[ $(jq -r '.parent != null' "$handle") == true ]]; then
        args+=(--parent-provider "$(jq -r .parent.provider "$handle")" --parent-session "$(jq -r .parent.sessionId "$handle")")
      fi
      record_fact "${args[@]}"
    fi
    if [[ ! -d $worktree ]]; then
      printf 'REFUSED: worktree %s is missing; recreate it or start a new lane\n' "$worktree" >> "$log"
      trap - EXIT; finish 80
    fi
    cd "$worktree"
    pending
    fail_pair() {
      verification=$(jq --arg reason "$1" '.verification | .state="refused" | .reason=$reason' "$handle")
      save_verification "${2:-no}"
    }
    [[ $(jq -r .role "$handle") != developer || $role_id == developer ]] || { fail_pair 'developer requires --role-id developer'; finish 64; }
    [[ $(jq -r .role "$handle") != principal-engineer || $role_id == principal-engineer ]] || { fail_pair 'principal-engineer requires --role-id principal-engineer'; finish 64; }
    if ! { work_input=$(mktemp "${log}.work-input.XXXXXX") && { printf '%s\n\n' "$sender" && cat "$input"; } > "$work_input"; } 2>> "$log"; then
      printf 'REFUSED: work input could not be read: %s\n' "$input" >> "$log"
      finish 66
    fi
    validate() {
      local phase=$1 validation_code=0
      verification=$(native verify --cli "$cli" --role-id "$role_id" --model "$model" --effort "$effort" --session "$thread" --transcript "$native_path" --offset "$offset") || validation_code=$?
      if [[ -z $verification ]]; then fail_pair 'native validator aborted without a report' yes; return 81; fi
      verification=$(jq --arg phase "$phase" '.phase=$phase' <<< "$verification")
      save_verification
      return "$validation_code"
    }
    native_path=; offset=0
    if [[ -n $thread ]]; then
      discovery_code=0; native_path=$(native find "$cli" "$thread" 2>> "$log") || discovery_code=$?
      if [[ $discovery_code != 0 && ( $n != 1 || $discovery_code != 82 ) ]]; then fail_pair 'native transcript missing or ambiguous before qualification'; finish 81; fi
      # A fresh UUID normally has no file; an existing identity always starts at its current end.
      if [[ -n $native_path ]]; then offset=$(wc -c < "$native_path"); offset=${offset//[[:space:]]/}; fi
    fi
    verification=$(jq --arg path "$native_path" --argjson offset "$offset" '.verification | .source.path=(if $path == "" then null else $path end) | .source.start=$offset | .source.end=$offset' "$handle")
    save_verification
    if [[ $n == 1 ]]; then
      provider_command yes || finish 66
      code=0; bootstrap > "$log.bootstrap.log" 2>&1 || code=$?
      if [[ $cli == codex ]]; then
        thread=$(jq -Rnr 'first(inputs | fromjson? | select(.type == "thread.started") | .thread_id // empty) // empty' "$log.bootstrap.log")
        if [[ -n $thread ]]; then
          jq --arg thread "$thread" '.thread=$thread' "$handle" | atomic
          record_fact launch-record session --launch-id "$launch_id" --provider codex --session-id "$thread"
          verification=$(jq --arg thread "$thread" '.verification | .source.session=$thread' "$handle")
          save_verification
        fi
      fi
      if [[ $code != 0 ]]; then fail_pair "bootstrap CLI exited $code; see $log.bootstrap.log"; finish "$code"; fi
      [[ -n $thread ]] || { fail_pair 'native session identity missing from bootstrap'; finish 81; }
      discovered=$(native find "$cli" "$thread" 2>> "$log") || { fail_pair 'native transcript missing or ambiguous after bootstrap'; finish 81; }
      [[ -z $native_path || $native_path == "$discovered" ]] || { fail_pair 'native transcript path changed during bootstrap'; finish 81; }
      native_path=$discovered
      validate bootstrap || finish 81
    else
      qualification=$(jq -c 'if has("qualification") then .qualification else .turns[-2].verification end | select(.state == "accepted")' "$handle")
      [[ -n $qualification ]] || { fail_pair 'no accepted native qualification; start a qualified new lane'; finish 81; }
      [[ $native_path == "$(jq -r .source.path <<< "$qualification")" ]] || { fail_pair 'native transcript path changed since qualification'; finish 81; }
      offset=$(jq -r .source.start <<< "$qualification")
      validate resume || finish 81
    fi
    offset=$(jq -r .source.end <<< "$verification")
    verification=$(jq --argjson offset "$offset" '.phase="work" | .state="pending" | .reported={model:null,effort:null,nativeEffort:null} | .source.start=$offset | .source.end=$offset' <<< "$verification")
    save_verification
    provider_command no || finish 66
    code=0; "${cmd[@]}" < "$work_input" >> "$log" 2>&1 || code=$?
    validation_code=0; validate work || validation_code=$?
    if [[ $code != 0 ]]; then
      printf 'NATIVE CLI EXIT: %s during work; pair report does not replace the native exit\n' "$code" >> "$log"
    elif [[ $validation_code != 0 ]]; then code=81; fi
    trap - EXIT; finish "$code"
    ;;
  *) refuse 64 'unknown subcommand';;
esac
