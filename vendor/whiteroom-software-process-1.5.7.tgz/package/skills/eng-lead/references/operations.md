# Eng lead operations

Operate one project and only the lane tree you started. The eng-lead skill
defines ownership. A Claude eng lead is the unattended default, with mixed
Claude and Codex developers. A Codex eng lead runs only while Jon drives the
session, with Codex and headless Claude developers.

Invoke `git` before the first commit and `issue-workflow` before the first issue write.

## Lead files

Use a Files-area directory named by issue number, or thread name without an
issue. Obey the global Files contract and issue-folder layout. No dashboard page.

- `lead-activity.md` is append-only history. Each notable event is one line of
  at most 20 words. Append nudges, starts and publications here; link issue
  dispositions rather than duplicating them.
  Use `wrsp-lead append <dir> --text TEXT`; the command stamps the entry in UTC.
- Rewrite `lead-decisions.md` in place with exactly these sections: **Needs your
  answer**, **Proceeding unless you redirect**, **Coming later**. Link governing
  issues; do not duplicate transcripts.
  For a stamped addition, use `wrsp-lead append <dir> --text TEXT --section SECTION`
  with the exact section name. Keep current state accurate through rewrites.
- `lead-handoff.md` is current state only, rewritten on each lane/queue change,
  at most about 800 words. Hold live lanes, review holders, pending timers and
  background jobs, ready list, findings no issue holds yet, and links to issues
  recording Jon's decisions. Preserve exact frozen/publication tips, checkout,
  research/review/runner identities and handles, next owners, recovery commands
  and steps, pending requests, broadcasts and held pushes.

Run `wrsp-lead render <dir>` after every decisions or handoff edit. Resolve
named section errors and caps: Proceeding allows 8 items and 800 words;
handoff allows 800 words. Check flagged stale or unstamped items for completion
or supersession; remove them only on that basis. General shell remains available.

For repeated issue or file reads, use `wrsp-lead view issue REPO N --state FILE`
or `wrsp-lead view file PATH --state FILE`. The first or changed read prints the
complete content and SHA-256; an unchanged read prints one line after a fresh
source read. Resolve named failures before proceeding.

A successor, resumed or compacted lead reads `lead-handoff.md` first and
reconciles issue, job, queue and native grant state before action, including
current queue permission. Consult activity/history only when relevant. Update
the appropriate files before risky steps; give Jon their Files links and point
to them instead of repeating their content in chat.

## Check in

1. On resume and after every compaction, follow [Lead files](#lead-files) to
   reload and reconcile current state before the next real action.
   Saved wakes and review go messages prompt this check; they never authorize
   replay. Unanswered questions remain pending through every compaction.
   Compaction preserves this session's native identity and grant. If the grant
   is no longer this session's, stop leading: actual supersession ends its role.
2. Run `wrsp-agents check`. Read version and warning lines for both CLIs.
   A version warning alone does not fail the command.
3. Upgrade a behind Codex with `npm i -g @openai/codex@latest` only when no lane
   has a live execution, eval-harness or runner job. Recheck. Jon trusts changed hooks in the
   desktop app; the CLI 0.163.0 trust attempt did not persist.
4. Claude updates itself. Report which sessions and Remote Control servers
   started before the installed version. Schedule their handoffs normally.
5. Inspect this session's grant with `wrsp-session-role inspect`. To record Jon's
   assignment, run `wrsp-session-role grant <request.json>` in this session's own
   shell. Copy their words and source verbatim. The helper reads the native id
   from the harness environment. Do not infer it from a Remote label or grant
   after a denial without an existing instruction. Resume and compaction retain it.
6. Read context and status for each developer lane. Use its model budget from
   installed `roles.members`; unknown model, budget or usage stays unknown and
   does not by itself require a checkpoint. At 80% of a known budget, request a
   handoff, start a successor, and obtain its acknowledgment before retirement.
7. Choose a successor at a quiet point, with no push, install or landing in
   flight. Use lead judgment about continuity; around 70% context use is the
   backstop for preparing a handover. The same granted eng lead keeps authorized
   work and lane checks moving until transfer succeeds. Natural auto-compaction
   remains the fallback, whether Jon is present or away.
   In Claude remote, read this session's Remote lineage from get-session →
   `lineage`; headroom is `limit − depth`. At headroom 0 a session has no
   `send_later`, scheduled tasks or session creation; its background-`sleep`
   wake remains available (Lane check; #469). Every lane runs one level deeper
   and needs its own wake timer (#308).
   - At headroom 3 or less, ask Jon to start a fresh lineage and record the pending
     request in `lead-decisions.md` and `lead-handoff.md`. Keep existing authorized work moving while
     this session remains the grant holder.
   - At headroom 1 or less, start no lanes or successors.
   - Unknown lineage requires a checkpoint.
8. Confirm priorities, queue requests, publication needs, and Jon's instructions.
   Record decisions through `issue-workflow`; link them from the lead files.
9. Read the A · Budget Session coverage panel's counts for the selected window and report each nonzero gap class to Jon. Report an unavailable panel as unavailable.

Start developer lanes in the installed `developer` role's order:
`gpt-6.1-sol` first through `lane.sh start --cli codex`. Use Opus only when
Sol is unavailable or Jon asks for Opus.

## Claude eng-lead handover

Claude grant transfer needs no new Jon grant. Follow the
[session-grant transfer contract](../../../docs/reference/contracts/supervisor-session.md#transfer)
for authority, refusal and failure semantics.

1. Create a successor at the quiet point chosen during Check in, within the
   Remote lineage limits above.
2. Have the successor read the Lead files and acknowledge readiness.
3. Run `wrsp-session-role offer` in the predecessor's own shell. Pass the offer
   id to the successor. From its own shell in the shared checkout, the successor
   runs `wrsp-session-role accept <offer>` as a single plain command (no
   `cd … &&`, `;` or pipes) so the installed
   `Bash(wrsp-session-role accept:*)` allow rule matches. That rule is Jon's
   standing approval. Authority changes only on successful accept. Failed offer
   or accept leaves the predecessor leading while it still holds its grant; check the
   contract's zero-holder failure case before continuing after a write failure.
4. After successful accept, the predecessor cancels its own timers and watcher,
   replaces its role emoji with 💀, and stops.

## Claude eng lead

Developer lanes use the headless `lane.sh` routes from either eng-lead home.
The Remote capability column below is reference for other sessions.

| Capability | Claude lane | Codex lane |
| --- | --- | --- |
| Start | Remote session create with title, model, permission mode, and tags. Select the Agent Mini Remote Control environment. A cloud environment skips the host hooks. | Detached `codex exec --json`; record the thread id. |
| Message | Remote send-message with priority now, next, or later. | Next turn: `codex exec resume <id>`. |
| Receive | The lane sends a message to `@parent`. | Read the turn's output. |
| Context use | Remote get-session → `context_usage`. | Latest `token_count.last_token_usage` in the rollout, under `payload.info`; use input tokens, not cumulative totals. |
| Rename | Remote set-title, including the eng lead's own session. | `thread/name/set` only for app-server threads; otherwise update the roster title. |
| Transcript | Remote list-events / get-event. | Rollout matched by `session_meta.id`. |
| Status / retire | Remote get-session status bucket; archive after handoff acknowledgment. | Recorded handle and exit state; retire after handoff acknowledgment. |

## Codex eng lead

| Capability | Claude lane | Codex lane |
| --- | --- | --- |
| Start | Escalated, detached `claude -p --session-id <uuid> --name "<thread name>" --output-format json`. | Detached `codex exec --json`; record the thread id. |
| Message | `claude -p --resume <uuid>`, one turn at a time. | `codex exec resume <id>`, one turn at a time. |
| Receive | Read the turn's JSON output. | Read the turn's output. |
| Context use | `usage` in the turn's JSON. | Latest `token_count.last_token_usage` in the rollout, under `payload.info`. |
| Rename | `--name` on start or resume; qualify resume naming on the host. | `thread/name/set` only for app-server threads; otherwise update the roster title. |
| Transcript | `~/.claude/projects/<slug>/<uuid>.jsonl`. | Rollout matched by `session_meta.id`. |
| Status / retire | Recorded handle and exit state; retire after handoff acknowledgment. | Recorded handle and exit state; retire after handoff acknowledgment. |

Use exact role, model, effort, and budget at start. A route that cannot select
the required pair cannot start that lane. Native bootstrap verification precedes
initial issue input; later turns revalidate native qualification offline before
dispatch. Unknown or off-policy pairs refuse. Remote cannot
select developer effort, so its developer route is refused. Non-preferred
developer starts record `--selection-reason` for Sol unavailability or Jon's
explicit Opus request. Permission profiles and handle format remain owned by
`scripts/lane.sh`; it supplies start, send, read, and status.
OpenRouter-backed Codex follows the Codex routes and provider limits.

## Lane turns

- The Codex harness kills background processes when a call ends. A Codex
  eng lead cannot keep an app-server alive between turns. Each headless lane
  turn runs detached under launchd and is waited on with
  `wrsp-wait`.
- Separate `codex exec resume <id>` turns are qualified on Agent Mini with
  codex-cli 0.163.0 (#258). `exec resume` has no `-C`, so `lane.sh` passes it
  on turn 1 only; every turn runs from the lane worktree.
- Hold one lock per lane from turn admission through its exit record. Provider
  turns never overlap. A failed submission releases only its own lock. Recover an
  interrupted turn from its handle and exit record, not elapsed time.
- A headless lane cannot receive mid-turn. It ends its turn at a queue request,
  handoff, or question for Jon. A queue “go” arrives as its next turn.
  A plain send during a live turn reports busy. `send --when-idle` waits in the
  client until the observed turn finishes, then attempts one ordinary send.
  After exit, run `lane.sh read <handle> --finished`, reconcile the complete
  handoff against grants and queue state, then send. A waiting client needs that
  explicit read before admission too; waiting itself acknowledges nothing.
- Never resume a headless lane interactively while its eng lead may send turns.
  Transfer ownership explicitly first. A fresh successor gets a fresh identity.
- A headless Claude lane has no Remote tools. Its tree is whatever it launches
  through `~/.agents/skills/developer/scripts/launch-worker.sh`.
- Persist lane identity, title, family, provider, host, project, issue, worktree,
  role id, requested and reported model/effort, native source, selection reason,
  budget, contact route, launch handle, and next exchange.
  Match #196 launch attribution; a resume is a turn of the same lane.
### Acknowledgment

- Require acknowledgment for queue ownership, scope changes, and handoffs.
  If contact fails, inspect the handle and process table, read output only after
  exit, and recover that lane.
  An issue body records intent but does not wake an idle headless process.
  Independent lanes continue. Missing delivery never supplies queue permission.

### Brief rules

Use [lane-brief-template.md](lane-brief-template.md) for the issue and scope,
limits, oracle plus sketch, bounded reads and operating rules. At assignment,
name the oracle and put a test/proof sketch of at most 10 bullets into the
issue's Required proof and Tests. The developer implements and tests its own
slice and expands that sketch with `systematic-test-design` into its detailed
issue plan before code.

Every developer-lane brief carries these rules:

- Invoke `git` for commits and review freshness; invoke `issue-workflow` for issue writes.
- A non-fast-forward land refusal means rebase and carry under the lane's go,
  following `reviewed-main-workflow`, so concurrent landings preserve review
  coverage.
- A question to the eng lead ends the turn; the eng lead reads only end-of-turn
  messages.
- The eng lead creates the worktree before `lane.sh start`, because lane startup
  requires an existing issue worktree (#386).
- A successor brief is the handoff link plus named reads; name sections, not
  whole skills, in its read-first list. Name a whole skill only when the
  successor needs all of it. Name a line range for every read of a file over
  200 lines, so startup reads stay bounded.

Candidate repairs follow
[Candidate repairs](../../developer/references/recovery.md#candidate-repairs).

### Lane script

Installed path: `~/.agents/skills/eng-lead/scripts/lane.sh`.

```text
lane.sh start --role developer|ux-principal|principal-engineer --cli claude|codex --role-id <role> --model <model> --effort <effort> --worktree <dir> --issue <N> --brief <file> --title <text> --log <file> [--selection-reason <text>]
lane.sh send [--when-idle] <handle> <message-file>
lane.sh read <handle> [--cursor <bytes>]
lane.sh read <handle> --finished
lane.sh status <handle>
lane.sh recover <handle>
lane.sh check <handle-directory> --repo <repository> --state <state-file> --threshold <percent>
lane.sh title --role <role> [--lane <name>] --task <text> [--issues "#1 #2"] [--state done]
lane.sh verify-pair --cli claude|codex --role-id <id> --model <requested> --effort <requested> --session <native-id> --transcript <path> [--offset <nonnegative-byte-offset>]
```

Developer and principal-engineer lanes require the matching `--role-id`.

`start` refuses the repository main worktree (exit 66) before creating a handle,
lock or launch; create an issue worktree first. Linked worktrees, including
detached checkouts, remain accepted.

Every provider input starts with the fixed line `From: eng lead, not Jon. Jon's words appear only as quoted text with their source.`,
then a blank line. Work inputs carry the headless browser preamble before the
original input; metadata-only bootstrap prompts retain their original input
directly after the stamp. Handles and launch records retain source attribution. Ordinary turn
history and `next_exchange` retain the original absolute message path. The message
file must remain readable until dispatched, when its bytes are read and stamped.

Headless `codex exec` and `claude -p` lanes record
`browser: {"runner":"repo-playwright","iab":"unavailable"}` in the lane handle.
Every work input carries the same fact and directs UI verification to the
repository's Playwright runner, skipping the in-app-browser probe and fallback
announcement. `launch-worker.sh` carries the same preamble and records the object
as `LANE_FACTS: {"browser":...}` in its existing log-path handle. The
[frontend browser rule](../../frontend-workflow/SKILL.md#browser-verification)
consumes this fact; interactive sessions retain their default and all paths
retain the existing UI proof requirements.

The handle is `<log without .log>.lane.json`; turn logs are
`<log without .log>.turn-<n>.log`. A `<handle>.lock` directory admits one
turn and remains held through turn completion. A live turn refuses plain sends;
an interrupted turn needs `recover`, which checks the pid and exit record.
Failed submission releases the lock and preserves the previous handle.
Every turn removes its launchd job on exit, including refusals and aborts; an aborted turn is recorded as exit 70 with its launch-record exit fact.
A launchd respawn of a killed turn is refused (exit 79) and leaves the turn interrupted for `recover`; no input is replayed.

One lane, one issue, one worktree: start a new lane for a new issue. Recreate a
missing lane worktree only to continue the same issue.

A missing lane worktree is refused with exit 80 and `lane <name>: worktree <path> is missing; recreate it for this issue or start a new lane for a new issue`:
`send` (including `--when-idle`) refuses before admitting a turn, and a turn whose
worktree vanished after admission writes the refusal and `EXIT:80` to its turn log
(#261, #457).
Wait on a turn with
`wrsp-wait <turn-log>`.

Use `read <handle> --finished` after completion and before the next send. It
exposes the full final message and records the current-turn read receipt. Cursor
reads remain available for inspection and confer no receipt. Unread sends refuse
77 with the finished-read remedy; missing or changed evidence refuses 65. A
successful full reread repairs a stale or malformed receipt. Recovery alone
does not acknowledge output; a recovered turn without a final message fails
closed. Receipt identity, byte preservation and lock ordering belong to
[Lane turns](../../../docs/reference/contracts/supervisor-session.md#lane-turns).

`--when-idle` polls in the client until the observed turn finishes, then attempts
the ordinary turn lock once. Background the client and track that client job's
exit; read its output only after exit:

```sh
lane.sh send --when-idle "$handle" "$message" > "$send_log" 2>&1 &
send_pid=$!
wait "$send_pid"
```

`HANDLE:` means submitted, not provider completion. Competing clients targeting
the same observed turn yield one send and refusal 75 for a loser, even if the
winning turn finishes before the loser resumes. Interruption refuses 76 with the
`recover` remedy. Keep the message file on interruption or refusal and retry
explicitly when appropriate. Recovery records exit 70 and releases an interrupted
turn's lock without submitting input.

Only turn 1 performs the metadata-only bootstrap, bounded at 90 seconds;
`WRSP_LANE_BOOTSTRAP_TIMEOUT=<seconds>` on `lane.sh start` waits longer. Later
turns rediscover the same native source and verify its bytes from the accepted
qualification's start against the requested pair and current role membership.
The `resume` phase reuses native evidence; it does not claim fresh provider
execution. Old handles may use only the immediately preceding accepted report.
Missing qualification, source changes or invalid native metadata refuse 81
before dispatch. Every work turn then verifies fresh records after the offline
check's end offset. Native refusal clears qualification; a process interruption
while verification is pending retains the previous accepted qualification.

Verification may remain pending until the turn exits; pending grants no acceptance.
Status and logs show accepted or refused (exit 81), the phase, and native source.
Status adds `context: <tokens> / <budget> (<pct>%)`, with one decimal place,
using the stored budget and native-source session record: Codex's latest
token-count input usage or Claude's latest parent assistant input and cache usage.
Missing or invalid native usage, source, provider or budget yields `context: unknown`.
A work-phase refusal reports drift after dispatch. Relative send handle and
message paths resolve from the sender's cwd.

## Lane check

Run `lane.sh check <handle-directory> --repo <repository> --state <state-file> --threshold <percent>`
at each check. Keep the state file across checks; its parent directory must exist.
Reconcile newly finished turns first with actual grant and queue state. Read
each finished handoff with `read <handle> --finished` before sending; check itself
consumes no handoff and authorizes no send. Retain
timer checks while any lane is live or the ready list is non-empty. Use
`lane.sh board <handle-directory>` for an explicit full snapshot. Check's change
and failure semantics, including completed-work context snapshots, belong to
[Lane turns](../../../docs/reference/contracts/supervisor-session.md#lane-check).

- Claude: arm a background Bash `sleep <seconds>` with `run_in_background`,
  at most 1200 s out. Its exit re-invokes the idle session. Re-arm after every
  check while any lane is live or the ready list is non-empty. Optionally add
  `send_later` (remote) or `CronCreate` (local) as a backup; whichever fires
  first runs the check (#469).
- Each wake prompts one check: recheck current issue, grant and queue state,
  then status, nudges, refill. A stale wake or saved go requires that
  reconciliation; never replay an old review go or wait in a loop inside a turn.
- Codex: a foreground `sleep` is the only in-session timer; the session cannot
  receive messages while it runs. Codex leads run only while Jon drives, so
  check at the start of each turn.
- Reserve external launchd/cron with headless resume for a wake that must
  survive a session restart; nothing needs it yet (#469).
- Read metadata only: each lane's session status, including `quiet`; `ps -p`
  on its recorded review, research and runner pids; `.exit` markers and file
  mtimes newer than the lane's last message; `git -C <worktree> status --short`;
  and one `wrsp-wait.sh <log> --max 0` per launch handle. Inspect a live turn
  quiet for more than 600 seconds; a rate-limited resume can hang without exiting.
  `quiet: unknown` means the live log is unavailable.
- Reconcile any waiting send client's exit before nudging. Read its output only
  after exit; `HANDLE:` proves submission. Use turn history and exit evidence to
  establish completion. Keep refused input and decide explicitly whether to retry.
- Never read, tail or follow a running process's log or output, and never loop
  on `sleep`. Read a log's tail once, after the process exits.
- Nudge a lane that is idle on finished work, meaning an `.exit` marker or a
  dead pid newer than its last message. Name the finished job and its exit code.
- For a lane blocked on another lane, confirm the blocker has moved since the
  last check: its session is working, or its HEAD or status has changed. If
  it hasn't, nudge the blocker.
- Append nudges to `lead-activity.md`.
- Before refill, consult `node ~/.agents/skills/developer/scripts/launch-retry-runtime.mjs marker-status`
  once. While `throttled` is true, defer fresh refill and record `throttledUntil`
  in `lead-activity.md`; retain the normal check timer, reconciliation, nudges
  and queue actions. Missing, unreadable, corrupt or overflow state leaves
  refill eligible. `WRSP_LAUNCH_BACKOFF_OVERRIDE=1` bypasses this advisory and
  fresh-launch waiting. See [lane bootstrap backoff](../../../docs/reference/contracts/job-liveness.md#first-turn-lane-bootstrap-retry-357).
- End every check by reconciling the authorized inventory and, when eligible, refilling
  executable ready-list work within the lane cap; append starts to `lead-activity.md`. Keep parked
  issues and explicit exclusions parked. Report and reconcile missing or stale issue state; it is
  uncertainty, never proof that no work remains.
- Before retiring the last lane, record concrete blocked actions and remaining
  authorized work in the existing issues and lead files, and refill executable
  work within the cap. When the authorized inventory is exhausted or every
  remaining action is blocked, retire idle lanes and stop checks. Keep no empty
  polling lanes.
- `wrsp-wait.sh` on a `lane.sh` turn handle reports only running or exited; exits 8 (not producing) and 3 (stalled) come only from `launch-worker.sh` handles.

## Names and instructions

Use the eng-lead skill's role emoji table. The developer skill carries the
same table. Shape: `<emoji>[ <Lane>]: <task>[ #issues]`. Follow these examples:

- `👽 Agent Mini migration #174 #196 #197`
- `👩‍💻 G: event capture #196`
- `💀 F: laptop ledger #192`

The colon appears only after a lane letter. Rename on assignment, changed work,
successor pickup, and completion. Replace the role emoji with 💀 at completion
and keep task text. Promotion changes 👩‍💻 to 👽. Titles grant no authority.

Jon names a Codex eng lead's thread at start. Tell them the new name when its
scope changes. Use Remote titles for Remote lanes, `--name` for Claude headless
lanes, and `thread/name/set` for Codex app-server threads. Other Codex CLI lanes
keep their desired title in the roster. Never edit app databases to rename.
Name descendant launch records with 🤖, 👩‍🎤, 👀, 🔬, or 🔍 as appropriate.
Keep #196 launch identities intact; the launcher refuses the retired builder
role (#441).

Follow `issue-workflow` for Jon's direct instructions and their source.

Never hand Jon a bare file path. Share a file the way global `AGENTS.md`
(Environment) says; where it names no Files link, link a pushed file or publish
the content on the issue. Apply this to drafts, handoffs, logs, proof, and
decisions as well as finished documents.

## Pushes while Jon is away

Jon approved this rule; “you” refers to Jon:

> a push proceeds without you when it has full review coverage or recorded acceptance and passing evidence at the exact commit. It waits for you only when it does one of these:
>
> - changes review, receipt, evidence or gate semantics, or a contract consumers see;
> - installs hooks that need re-trust;
> - tags or releases;
> - force-pushes or deletes a remote ref.

Reuse Jon's existing approval only for the risky action and exact scope it covers.
A new material release fact holds remaining release actions: a promised installed
operation fails, consumer impact changes, or release proof is invalidated. Resume
under the original go only after verified correction within that scope. Unresolved
material defects or uncovered scope wait for Jon; shipping a defect as a known
limitation requires their explicit acceptance. Unchanged limitations already
disclosed and accepted, and advisories unrelated to release promises, consumer
impact or proof, do not reopen the go. Record the new fact, scope, correction proof
or accepted limitation, and Jon's approval source on the release issue; link that
disposition from `lead-activity.md` before resuming. Disclose accepted limitations
in release notes and consumer handoffs. Otherwise hold the push. An eng lead
assignment is role authority, not findings acceptance or approval of every risky action.
Use the landing-queue and operator-acceptance references for the actual checks.
Create a detached worktree pinned to the exact publication tip; run the
publication suite, collect its evidence and push from that worktree.
Keep it pinned through push so reviews and landings can continue on main.

A step needing Jon blocks only that step. Within the assigned goal, continue
authorized preparation, analysis and independent issues while it waits; keep
parked issues and explicit exclusions parked. Report and reconcile missing or
stale issue state rather than treating it as proof that no work remains.
Group prepared sudo installs, laptop actions, hook re-trust and product questions
into one operator window; each still waits for its own required instruction.
Keep unanswered requests in `lead-decisions.md` and `lead-handoff.md` through compaction.

## Visibility

See only the tree you started. Jon accepts missing visibility into threads they
start in another app. Discovery of every chat is not a completion requirement.
Do not send peer messages to laptop sessions; their inbound refusal still applies.

Remote events expose the connected conversation, subject to pagination and tool
availability. They do not expose private reasoning or promise every local tool
byte. Same-host Claude transcripts and Codex rollouts expose persisted events
and usage. Match identity and read only relevant, bounded ranges for this project.
Missing files, truncation, persistence settings, and provider differences limit
that view. OpenRouter adds no Remote or cross-session capability. Missing usage
stays unknown and does not by itself require a checkpoint. The usage ledger is
counters, not a transcript.
