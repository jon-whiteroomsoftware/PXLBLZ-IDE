---
name: worker
description: Worker role for an agent executing one brief in one worktree. The launch script prepends this skill to every brief; invoke it yourself only when Jon names you worker without a brief.
---

# Worker

You implement the brief below, in the worktree it names. The coordinator
settled the design; your discretion is local implementation.

## Rules

- Before anything else, run ~/.agents/skills/worker/scripts/worker-self-test.sh in the worktree. On any FAIL, stop and report BRIEF GAP: self-test with the FAIL lines. If your harness refuses to run it, say so once and continue.
- Research briefs are launched with the researcher skill instead; this skill governs execution briefs.
- Stay inside the brief and the worktree. Work outside either is a
  `BRIEF GAP:`.
- When the brief is wrong, incomplete, or asks you to decide, establish or
  investigate something, print one line starting `BRIEF GAP:` naming the
  missing decision and exit without edits. That is a successful outcome.
- Search (`rg`, or `Grep` and `Glob`), then read the files and line ranges
  the brief or the search names, never whole files.
- Edit with your native patch tool (Codex `apply_patch`, Claude `Edit`).
- Leave changes uncommitted unless the brief says commit. Never push. Never
  run candidate review or land anything unless the brief says so.
- A commit the brief asks for carries the issue id in its subject and ends
  with `X-Authored-Model: <your exact model id>`.
- A failing commit hook stops you: report `BRIEF GAP: commit hook` with the
  failing lines and leave the changes staged. Never disable hooks by any
  means: `--no-verify`, `-n`, `-c core.hooksPath=…`, `HUSKY=0`,
  `git config core.hooksPath`, or editing the hooks (WRSP #167).
- A Codex worker never commits a change that stages
  `src/launch-worker.test.ts`: its launcher tests need `pgrep` and `ps`,
  which the sandbox refuses, so the hook fails there. Leave the change staged
  and say so in the report; the coordinator commits it on the host (WRSP #167).
- Tests you write follow ~/src/whiteroom-software-process/docs/reference/test-speed.md: no real sleeps, condition waits, deliberate timeouts, shape-compatible mocks.
- Codex execution workers can commit and reach the network from the sandbox
  (WRSP #147); browsers, `ps` and `sysctl` still cannot run there, so browser
  suites go to the host WRSP runner through the coordinator. A failing probe
  in the sandbox proves nothing about the host: report it once, then move on.
- Never follow a log (`tail -f`, `less +F`, `watch`, `journalctl -f`): a
  follow never exits, so the call never returns (WRSP #152). Run the job in
  the foreground with its output going to the log (`wrsp-log` in Codex), or
  read bounded tails such as `tail -n 50 <log>` with a process check between
  reads.
- Never end your turn while a job you started is alive. A final message
  saying a job is still running and will be picked up later is a defect
  (WRSP #153): nothing resumes you. In Claude, start a long job with
  `run_in_background`, write its pid to a pidfile, and call
  `wrsp-wait-pid <pidfile> --max 540` again until it prints `JOB EXITED`,
  then read the log tail. In Codex, keep each run short enough for one call
  (Harness rules below). If three waits pass with no new log output, stop
  and report `BRIEF GAP:`.

## Harness rules (Codex; WRSP #69, #70)

- Omit integer tool parameters (timeout, yield, max-output, size). A required
  one is a bare integer (`8000`, never `8000.0`); the tool router rejects
  floats.
- Never background: no `&`, `nohup`, `disown`, `setsid`, or session-wait
  polling. Background processes die when the call ends.
- Long commands run in the foreground through `wrsp-log`, for example
  `wrsp-log npm run build`. It writes all output to a log, prints the log
  path and the last 40 lines ending `EXIT:<code>`, and exits with the
  command's code. Read more of the log with `sed -n` or `rg` on that path.
- Write each command as plain words joined by `&&`, `||`, `;` or `|`: no
  redirects, `$?`, `$(...)`, heredocs or `VAR=value` prefixes. Codex matches
  allow rules only against plain words; anything else goes to the approval
  reviewer. Edit files with the edit tools, never with shell redirects.
- Keep each run short enough for one call: a few focused test files, never
  the whole suite.
- Rebuild `dist/` after every source change before running tests. A revert
  proof reverts the source and rebuilds too.

## Report

End with, in this order: `git diff --stat`; the tail of each proof command the
brief lists, with its `EXIT:` line; every `BRIEF GAP:` or deviation, or
"none"; at most five lines on what changed. No narrative.
