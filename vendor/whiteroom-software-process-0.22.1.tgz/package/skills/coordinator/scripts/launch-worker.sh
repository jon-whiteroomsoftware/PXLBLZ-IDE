#!/usr/bin/env bash
# Launch one execution worker with the worker skill prepended to its brief.
# WRSP #114. Sets WRSP_ROLE=worker so the pre-commit reminder stays silent.
set -euo pipefail

usage() {
  cat >&2 <<'USAGE'
Usage: launch-worker.sh --cli <codex|claude> --tier <name> --model <id> --effort <level>
                        --worktree <dir> --brief <file> --log <file>
                        [--profile <codex-profile>] [--allow-phrase-hits] [--research] [--locate] [--dry-run] [--detach]
                        [--launchd-label <label> (internal)] [--context-budget <tokens> (internal)]
Composes <worker skill body> + <brief> into <log>.prompt.md, refuses briefs
that fail the execution policy's banned-phrase check, and runs the worker in
the foreground with all output in <log>. --detach submits it to launchd.
--locate answers one where-question synchronously with read-only search tools and prints the answer.
USAGE
  exit 64
}

cli= tier= model= effort= worktree= brief= log= profile= allow_hits=0 research=0 locate=0 dry_run=0 detach=0 launchd_label= context_budget= before=
cleanup() {
  if [[ -n $before ]]; then rm -f "$before"; fi
  if [[ -n $launchd_label ]]; then launchctl remove "$launchd_label" >/dev/null 2>&1 || true; fi
}
while [[ $# -gt 0 ]]; do
  case "$1" in
    --cli|--tier|--model|--effort|--worktree|--brief|--log|--profile|--launchd-label|--context-budget) [[ $# -ge 2 ]] || usage ;;
  esac
  case "$1" in
    --cli) cli=$2; shift 2 ;;
    --tier) tier=$2; shift 2 ;;
    --model) model=$2; shift 2 ;;
    --effort) effort=$2; shift 2 ;;
    --worktree) worktree=$2; shift 2 ;;
    --brief) brief=$2; shift 2 ;;
    --log) log=$2; shift 2 ;;
    --profile) profile=$2; shift 2 ;;
    --allow-phrase-hits) allow_hits=1; shift ;;
    --research) research=1; shift ;;
    --locate) locate=1; shift ;;
    --dry-run) dry_run=1; shift ;;
    --detach) detach=1; shift ;;
    --launchd-label) launchd_label=$2; trap cleanup EXIT; shift 2 ;;
    --context-budget) context_budget=$2; shift 2 ;;
    *) usage ;;
  esac
done
[[ -n $cli && -n $tier && -n $model && -n $effort && -n $worktree && -n $brief && -n $log ]] || usage
case "$cli" in codex|claude) ;; *) usage ;; esac
refuse() { # refuse <exit code> <message line>...
  local code=$1 message
  shift
  message=$(printf '%s\n' "$@")
  printf '%s\n' "$message" >&2
  printf 'LAUNCH REFUSED: %s\n' "$(printf '%s' "$message" | paste -sd '|' - | sed 's/|/ | /g')"
  # A handle another launch owns keeps its state; wrsp-wait reads .refused before liveness (#122).
  if [[ -d $(dirname "$log") && ( -n $launchd_label || ( ! -e $log && ! -L $log && ! -e ${log}.pid && ! -L ${log}.pid && ! -e ${log%.log}.prompt.md && ! -L ${log%.log}.prompt.md ) ) ]]; then printf 'LAUNCH REFUSED: %s\n' "$message" > "${log}.refused"; fi
  exit "$code"
}
# WRSP #134: every path checks membership, the launchd child included, so a tier edit after submission or a direct --launchd-label cannot bypass it.
members=${WRSP_TIER_MEMBERS:-$HOME/.agents/tiers.members}
[[ -s $members ]] || { refuse 66 "Tier members not found: $members. Run wrsp-agents install or wrsp-agents tiers apply."; }
member_effort=$effort
[[ $member_effort == medium ]] && member_effort=med
# WRSP #172: the fourth field is the member's context budget in tokens.
if ! member=$(awk -F '\t' -v tier="$tier" -v model="$model" -v e="$member_effort" \
  '!/^#/ && $1==tier && $2==model && $3==e { print "match\t" $4; exit }' "$members") || [[ -z $member ]]; then
  refuse 65 "Refusing launch: $model / $effort is not a member of tier $tier in $members. Launch a listed member, or edit ~/.agents/tiers.yaml and run wrsp-agents tiers apply."
fi
if [[ -z $launchd_label ]]; then
  context_budget=${member#match$'\t'}
  if [[ ! $context_budget =~ ^[1-9][0-9]*$ ]]; then
    refuse 66 "Refusing launch: $members has no context budget for $tier / $model / $member_effort; it was rendered before WRSP #172. Run wrsp-agents tiers apply, then relaunch."
  fi
fi
if [[ -n $launchd_label && ! $context_budget =~ ^[1-9][0-9]*$ ]]; then
  refuse 66 'Refusing launch: the detached relaunch has no --context-budget (WRSP #172).'
fi
if [[ $research -eq 1 && $cli == claude ]]; then
  refuse 64 '--research runs on the codex route; Claude research uses the native researcher agent.'
fi
if [[ $locate -eq 1 && $research -eq 1 ]]; then
  refuse 64 '--locate and --research are separate modes.'
fi
if [[ $locate -eq 1 && $detach -eq 1 ]]; then
  refuse 64 '--locate runs synchronously; drop --detach.'
fi
if [[ $locate -eq 1 && -n $profile ]]; then
  refuse 64 '--locate always uses the locator Codex profile; drop --profile.'
fi
[[ -d $worktree ]] || { refuse 66 "Worktree not found: $worktree"; }
# A worktree whose configured hooks directory is missing commits without
# running any hook, and git says nothing (#137). Same rule as
# wrsp-preflight worktree: a relative core.hooksPath resolves against the
# worktree's top level. Research launches never commit; the launchd child
# was already checked at submission.
if [[ -z $launchd_label && $research -eq 0 && $locate -eq 0 ]]; then
  if hooks_configured=$(git -C "$worktree" config --type=path --get core.hooksPath 2>/dev/null) \
    && [[ -n $hooks_configured ]] \
    && hooks_top=$(git -C "$worktree" rev-parse --show-toplevel 2>/dev/null); then
    hooks_resolved=$hooks_configured
    [[ $hooks_resolved == /* ]] || hooks_resolved=$hooks_top/$hooks_resolved
    if [[ ! -d $hooks_resolved ]]; then
      case "$hooks_configured" in
        .husky/_|.husky/_/|*/.husky/_|*/.husky/_/)
          remedy="Run \`npx husky\` in $hooks_top (it needs no network), or copy \`.husky/_\` from the shared checkout, then relaunch." ;;
        *)
          remedy="Install the repository's hooks in $hooks_top so the configured hooks directory exists, then relaunch." ;;
      esac
      refuse 66 "Refusing launch: git hooks are not installed in this worktree. core.hooksPath is \"$hooks_configured\", which resolves to $hooks_resolved, and that directory does not exist, so commits there run no hooks. $remedy"
    fi
  fi
fi
[[ -s $brief ]] || { refuse 66 "Brief missing or empty: $brief"; }
[[ ! -e $log ]] || { refuse 73 "Refusing to overwrite log: $log"; }
rm -f "${log}.refused"
[[ -d $(dirname "$log") ]] || { refuse 66 "Log directory not found: $(dirname "$log")"; }
# WRSP #163: a profile on the OpenRouter provider takes its key from the login
# Keychain (service OPENROUTER_API_KEY, account = login name), never argv or launchd.
provider_key=
if [[ $cli == codex && -n $profile ]] && grep -qE '^[[:space:]]*model_provider[[:space:]]*=[[:space:]]*"openrouter"' "${CODEX_HOME:-$HOME/.codex}/$profile.config.toml" 2>/dev/null; then
  provider_key=OPENROUTER_API_KEY
fi
if [[ -n $provider_key && -z $launchd_label ]] && ! security find-generic-password -s "$provider_key" -a "$(id -un)" >/dev/null 2>&1; then
  refuse 66 "Refusing launch: profile $profile uses OpenRouter, and the login Keychain has no $provider_key item for $(id -un). Add it with: security add-generic-password -s $provider_key -a \"\$USER\" -w"
fi
# WRSP #170: a Codex worker never launches beside a retired Morph server, even
# before Jon trusts the morph-retired hook. Codex lists its own servers, so every
# config form counts; a listing that cannot be read refuses the launch.
# A detaching parent runs no codex; its launchd child checks.
if [[ $cli == codex && $dry_run -eq 0 && $detach -eq 0 ]]; then
  if ! servers=$(codex ${profile:+-p "$profile"} mcp list --json </dev/null 2>/dev/null | jq -r '.[] | select(.enabled != false) | .name' 2>/dev/null); then
    refuse 66 "Refusing launch: could not list Codex MCP servers with \`codex mcp list --json\` and jq, so a retired Morph server cannot be ruled out (#170)."
  fi
  if retired=$(printf '%s\n' "$servers" | grep -iE '^morph') ; then
    refuse 66 "Refusing launch: Codex still configures the retired Morph MCP server $(printf '%s' "$retired" | paste -sd ' ' -) (#170). Remove it from ${CODEX_HOME:-$HOME/.codex}/config.toml, then relaunch."
  fi
fi
if [[ -n $launchd_label ]]; then
  printf '%s\n' "$$" > "${log}.pid.tmp.$$" && mv -f "${log}.pid.tmp.$$" "${log}.pid"
fi

if [[ $locate -eq 1 ]]; then
  skill=${WRSP_LOCATOR_SKILL:-$(cd "$(dirname "$0")/../../locator" && pwd -P)/SKILL.md}
elif [[ $research -eq 1 ]]; then
  skill=${WRSP_RESEARCH_SKILL:-$(cd "$(dirname "$0")/../../researcher" && pwd -P)/SKILL.md}
else
  skill=${WRSP_WORKER_SKILL:-$(cd "$(dirname "$0")/../../worker" && pwd -P)/SKILL.md}
fi
if [[ $skill != /* ]]; then skill="$(cd "$(dirname "$skill")" && pwd -P)/$(basename "$skill")"; fi
[[ -s $skill ]] || { refuse 66 "Worker skill not found: $skill"; }

# Execution policy, Brief content rule 3.
read -r -d '' phrase_check <<'PERL' || true
use strict;
use warnings;
local $/;
open(my $fh, '<', $ARGV[0]) or die "cannot read $ARGV[0]: $!\n"; my $original = <$fh>; close($fh);
my $text = $original;
sub mask { my $s = shift; $s =~ s/[^\n]/ /g; return $s; }
$text =~ s{^[^\S\n]*```[^\n]*(?:\n(?![^\S\n]*```)[^\n]*)*\n[^\S\n]*```[^\n]*}{mask($&)}gme;
$text =~ s{`[^`\n]+`}{mask($&)}ge;
my %lines;
while ($text =~ /establish|decid|choos|choic|determin(?:e|es|ed|ing)\b|investigat|explor|(?:find|figur)[a-z]*\s+out\b|decisions?\s+(?:on|about|between)\b/ig) {
  my $prefix = substr($text, 0, $-[0]);
  $lines{1 + ($prefix =~ tr/\n/\n/)} = 1;
}
my @original_lines = split /\n/, $original;
for my $line (sort { $a <=> $b } keys %lines) {
  print "$line:$original_lines[$line - 1]\n";
}
PERL
if [[ -z $launchd_label && $research -eq 0 && $locate -eq 0 ]]; then
  hits=$(perl -e "$phrase_check" "$brief") || refuse 66 "Refusing launch: the brief phrase check could not run on $brief (execution policy, Brief content 3)."
  if [[ -n $hits && $allow_hits -eq 0 ]]; then
    refuse 65 "Brief fails the banned-phrase check (execution policy, Brief content 3). Remove or relaunch with --allow-phrase-hits after justifying each in the brief:" "$hits"
  fi
fi

prompt=${log%.log}.prompt.md
answer=${log%.log}.answer.md
system_prompt=
skill_body() {
  # Strip the skill's YAML frontmatter; the body is the worker's instructions.
  awk 'NR==1 && $0=="---" {skip=1; next} skip && $0=="---" {skip=0; next} !skip' "$skill"
}
if [[ -z $launchd_label ]]; then
  if [[ $dry_run -eq 1 ]]; then
    # A dry run composes into its own file so the real launch's prompt path stays free.
    prompt=${log%.log}.dry-run.prompt.md
    answer=${log%.log}.dry-run.answer.md
  else
    [[ ! -e $prompt ]] || { refuse 73 "Refusing to overwrite prompt: $prompt"; }
    [[ $locate -eq 0 || ( ! -e $answer && ! -L $answer ) ]] || refuse 73 "Refusing to overwrite answer: $answer"
  fi
  {
    if [[ $locate -eq 1 ]]; then
      # WRSP #170: a Claude locator takes the skill as its whole system prompt.
      [[ $cli == codex ]] && { skill_body; printf '\n---\n\n'; }
      printf '# Question\n\n'
    else
      skill_body
      printf '\n---\n\n# Brief (tier:%s, %s / %s)\n\n' "$tier" "$model" "$effort"
    fi
    cat "$brief"
  } > "$prompt"
  if [[ $locate -eq 1 && $cli == claude ]]; then system_prompt=$(skill_body); fi
fi

worktree=$(cd "$worktree" && pwd -P)
abs_brief="$(cd "$(dirname "$brief")" && pwd -P)/$(basename "$brief")"
abs_log="$(cd "$(dirname "$log")" && pwd -P)/$(basename "$log")"
abs_self="$(cd "$(dirname "$0")" && pwd -P)/$(basename "$0")"
codex_effort=$effort
[[ $codex_effort == med ]] && codex_effort=medium
if [[ $locate -eq 1 && $cli == codex ]]; then
  # WRSP #170: the launch command restricts a locator's tools; its instructions do not.
  cmd=(env WRSP_ROLE=locator "WRSP_CONTEXT_BUDGET=$context_budget" codex exec -p locator -m "$model" -c "model_reasoning_effort=$codex_effort" -c "model_auto_compact_token_limit=$context_budget" -s read-only -c 'web_search="disabled"' --ephemeral -o "$answer" -C "$worktree" -)
elif [[ $locate -eq 1 ]]; then
  cmd=(env WRSP_ROLE=locator "WRSP_CONTEXT_BUDGET=$context_budget" claude -p --model "$model" --effort "$effort" --settings "{\"autoCompactWindow\":$context_budget}" --system-prompt "$system_prompt" --tools Read,Grep,Glob --allowedTools Read,Grep,Glob --strict-mcp-config --disable-slash-commands --setting-sources user --no-session-persistence --output-format text)
elif [[ $cli == codex ]]; then
  role=worker
  [[ $research -eq 1 ]] && role=researcher
  cmd=(env "WRSP_ROLE=$role" "WRSP_CONTEXT_BUDGET=$context_budget" codex exec)
  [[ -n $profile ]] && cmd+=(-p "$profile")
  codex_effort=$effort; [[ $codex_effort == med ]] && codex_effort=medium
  cmd+=(-m "$model" -c "model_reasoning_effort=$codex_effort" -c "model_auto_compact_token_limit=$context_budget")
  if [[ $research -eq 1 ]]; then
    cmd+=(-s read-only --skip-git-repo-check -c 'web_search="live"')
  else
    cmd+=(-s workspace-write -c sandbox_workspace_write.network_access=true)
    # WRSP #147: linked worktree commits need the common dir writable for index and refs.
    # Network serves web research and localhost; browsers stay on the host runner.
    common=$(git -C "$worktree" rev-parse --path-format=absolute --git-common-dir 2>/dev/null || true)
    [[ -n $common ]] && cmd+=(--add-dir "$common")
    # WRSP #165: Codex 0.160 also refuses a linked worktree's own git dir unless it is a writable root.
    own_gitdir=$(git -C "$worktree" rev-parse --absolute-git-dir 2>/dev/null || true)
    [[ -n $own_gitdir && $own_gitdir != "$common" ]] && cmd+=(--add-dir "$own_gitdir")
  fi
  cmd+=(-C "$worktree" -)
else
  # WRSP #151: headless workers cannot answer prompts; auto mode runs ordinary commands and its classifier refuses risky ones.
  cmd=(env WRSP_ROLE=worker "WRSP_CONTEXT_BUDGET=$context_budget" claude -p --model "$model" --effort "$effort" --settings "{\"autoCompactWindow\":$context_budget}" --permission-mode auto)
fi

if [[ $detach -eq 1 ]]; then
  label_name=$(basename "$log" .log)
  label="com.whiteroom.wrsp-worker.${label_name//[^A-Za-z0-9.-]/-}.$(date +%s)"
  relaunch_args=(--cli "$cli" --tier "$tier" --model "$model" --effort "$effort" --worktree "$worktree" --brief "$abs_brief" --log "$abs_log" --context-budget "$context_budget")
  [[ -n $profile ]] && relaunch_args+=(--profile "$profile")
  [[ $research -eq 1 ]] && relaunch_args+=(--research)
  skill_var=WRSP_WORKER_SKILL
  [[ $research -eq 1 ]] && skill_var=WRSP_RESEARCH_SKILL
  submit=(launchctl submit -l "$label" -- /usr/bin/env "PATH=$PATH" "HOME=$HOME" "TMPDIR=${TMPDIR:-/tmp}" "$skill_var=$skill" /bin/bash "$abs_self" "${relaunch_args[@]}" --launchd-label "$label")
fi

if [[ $dry_run -eq 1 ]]; then
  echo "PROMPT: $prompt"
  printf 'COMMAND:'; printf ' %q' "${cmd[@]}"; printf ' < %q > %q 2>&1\n' "$prompt" "$log"
  echo "CWD: $worktree"
  [[ $locate -eq 1 ]] && echo "ANSWER: $answer"
  if [[ $detach -eq 1 ]]; then printf 'SUBMIT:'; printf ' %q' "${submit[@]}"; printf '\n'; fi
  exit 0
fi

command -v "$cli" >/dev/null || { rm -f "$prompt"; refuse 69 "$cli is not on PATH."; }
if [[ $detach -eq 1 ]]; then
  if ! "${submit[@]}"; then
    rm -f "$prompt"
    refuse 69 'launchctl submit failed (in Codex, run this launch as an escalated command)'
  fi
  echo "HANDLE: $(cd "$(dirname "$log")" && pwd -P)/$(basename "$log")"
  echo "LABEL: $label"
  exit 0
fi

# Provenance for hooks/coordinator-reminder.sh. A snapshot maps every dirty or
# untracked path to a content hash; the paths whose hash changed or appeared
# during the run are the ones this worker touched. Paths the coordinator left
# dirty before the launch and the worker never changed stay unattributed.
# NUL-delimited status keeps paths with whitespace intact; a path containing
# a newline is not representable in worker-touched and is skipped.
snapshot() {
  git -C "$worktree" status --porcelain=v1 -z --untracked-files=all | {
    while IFS= read -r -d '' entry; do
      code=${entry:0:2}
      path=${entry:3}
      case "$code" in R?|C?|?R|?C) IFS= read -r -d '' _old || true ;; esac
      case "$path" in *$'\n'*) continue ;; esac
      if [[ -f $worktree/$path ]]; then
        hash=$(git -C "$worktree" hash-object -- "$path" 2>/dev/null) || hash=unreadable
      else
        hash=absent
      fi
      printf '%s\t%s\n' "$hash" "$path"
    done
  }
}
if [[ $research -eq 0 && $locate -eq 0 ]]; then
  before=$(mktemp "${TMPDIR:-/tmp}/wrsp-provenance.XXXXXX")
  trap cleanup EXIT
  snapshot > "$before" 2>/dev/null || : > "$before"
fi

printf 'tier:%s model:%s effort:%s cli:%s worktree:%s brief:%s\n' "$tier" "$model" "$effort" "$cli" "$worktree" "$brief" > "$log"
if [[ -n $provider_key ]]; then
  if ! key_value=$(security find-generic-password -s "$provider_key" -a "$(id -un)" -w 2>/dev/null) || [[ -z $key_value ]]; then
    echo "LAUNCH REFUSED: could not read login Keychain item $provider_key for $(id -un); the login keychain may be locked." >> "$log"
    echo "EXIT:66" >> "$log"
    printf '66\n' > "${log}.exit.tmp.$$" && mv -f "${log}.exit.tmp.$$" "${log}.exit"
    exit 66
  fi
  export "$provider_key=$key_value"
  unset key_value
fi
set +e
if [[ $locate -eq 1 && $cli == claude ]]; then
  (cd "$worktree" && "${cmd[@]}" < "$prompt") > "$answer" 2>> "$log" &
else
  (cd "$worktree" && "${cmd[@]}" < "$prompt") >> "$log" 2>&1 &
fi
worker_pid=$!
sampler_pid=
(
  sample_sleep_pid=
  stop_sampler() {
    if [[ -n $sample_sleep_pid ]]; then
      kill "$sample_sleep_pid" 2>/dev/null
      wait "$sample_sleep_pid" 2>/dev/null
    fi
    exit 0
  }
  trap stop_sampler TERM
  descendant_pids() {
    local parent=$1 child
    while IFS= read -r child; do
      [[ $child == "$sampler_pid" ]] && continue
      printf '%s\n' "$child"
      descendant_pids "$child"
    done < <(pgrep -P "$parent" 2>/dev/null || true)
  }
  while kill -0 "$worker_pid" 2>/dev/null; do
    while IFS= read -r child_pid; do
      child_start=$(ps -o lstart= -p "$child_pid" 2>/dev/null) || continue
      [[ -n $child_start ]] && printf '%s\t%s\n' "$child_pid" "$child_start"
    done < <(descendant_pids "$worker_pid")
    sleep "${WRSP_CHILD_SAMPLE_INTERVAL:-2}" &
    sample_sleep_pid=$!
    wait "$sample_sleep_pid"
    sample_sleep_pid=
  done
) >> "${log}.children" &
sampler_pid=$!
wait "$worker_pid"; status=$?
kill "$sampler_pid" 2>/dev/null
wait "$sampler_pid" 2>/dev/null
live_pids=()
while IFS=$'\t' read -r child_pid child_start; do
  [[ -n $child_pid && -n $child_start ]] || continue
  live_start=$(ps -o lstart= -p "$child_pid" 2>/dev/null) || continue
  [[ $live_start == "$child_start" ]] && live_pids+=("$child_pid")
done < <(sort -u "${log}.children")
if [[ ${#live_pids[@]} -gt 0 ]]; then
  printf '%s\n' "${live_pids[@]}" > "${log}.live"
  echo "LIVE CHILDREN: ${live_pids[*]}" >> "$log"
fi
rm -f "${log}.children"
echo "EXIT:$status" >> "$log"

if [[ $locate -eq 1 ]]; then
  revision=$(git -C "$worktree" rev-parse HEAD 2>/dev/null) || revision=unknown
  if porcelain=$(git -C "$worktree" status --porcelain 2>/dev/null); then
    dirty=no
    [[ -n $porcelain ]] && dirty=yes
  else
    dirty=unknown
  fi
  echo "REPOSITORY: $worktree REVISION: $revision DIRTY: $dirty"
  if [[ -s $answer ]]; then
    head -c 8192 "$answer"
    if [[ $(wc -c < "$answer") -gt 8192 ]]; then
      printf '\n[answer truncated at 8192 bytes; full answer in %s]\n' "$answer"
    fi
  else
    echo 'STATUS: ERROR'
    echo "the locator produced no answer; see $log"
    [[ $status -eq 0 ]] && status=70
  fi
fi

# Everything below is best effort: the worker's exit status and its BRIEF GAP
# report are never lost to a provenance failure.
record_provenance() {
  local gitdir after
  gitdir=$(git -C "$worktree" rev-parse --git-dir) || return 1
  [[ $gitdir == /* ]] || gitdir=$worktree/$gitdir
  [[ -d $gitdir/wrsp ]] || mkdir "$gitdir/wrsp" || return 1
  after=$(snapshot) || return 1
  [[ -n $after ]] || return 0
  # Lines present after the run and absent before: new paths or changed content.
  # An empty pattern file matches nothing, so a clean baseline attributes all.
  printf '%s\n' "$after" | grep -vxF -f "$before" | cut -f2- | grep -v '^$' >> "$gitdir/wrsp/worker-touched" || true
  return 0
}
if [[ $research -eq 0 && $locate -eq 0 ]]; then
  if ! record_provenance 2>>"$log"; then
    echo "WARNING: worker provenance not recorded; the pre-commit reminder may name this worker's paths." | tee -a "$log" >&2
  fi
fi
if grep -q '^BRIEF GAP:' "$log"; then
  echo "BRIEF GAP reported; see $log" >&2
fi
printf '%s\n' "$status" > "${log}.exit.tmp.$$" && mv -f "${log}.exit.tmp.$$" "${log}.exit"
exit "$status"
