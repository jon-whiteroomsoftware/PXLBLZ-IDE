#!/bin/sh
# WRSP #171: provision node_modules in a Claude-made worktree at session start,
# because a worktree under .claude/worktrees/ without node_modules resolves the
# main checkout's. Clones the main checkout's node_modules and runs npm ci when
# the lockfiles differ or the clone does not match the lockfile. Then installs
# git hooks with husky when the configured core.hooksPath directory is missing
# in the worktree, because it is generated and exists only where husky ran.
# Never blocks a session: every path exits 0.

input=$(cat)
cwd=
if command -v jq >/dev/null 2>&1; then
  cwd=$(printf '%s' "$input" | jq -r '.cwd // empty' 2>/dev/null)
fi
[ -n "$cwd" ] || cwd=$PWD

top=$(git -C "$cwd" rev-parse --show-toplevel 2>/dev/null) || exit 0
case $top in
  */.claude/worktrees/*) ;;
  *) exit 0 ;;
esac

common=$(git -C "$top" rev-parse --path-format=absolute --git-common-dir 2>/dev/null) || exit 0
main=$(dirname "$common")
[ "$main" = "$top" ] && exit 0

# Main's lockfile can move past its installed node_modules (a pull without
# npm ci), so a clone counts only when every installed package.json carries
# the version its lockfile entry names. The hidden lockfile lists every installed
# package, so a package the lockfile no longer names also fails the check (#171).
clone_matches_lock() {
  node -e '
const fs = require("fs")
const path = require("path")
const top = process.argv[1]
const lock = JSON.parse(fs.readFileSync(path.join(top, "package-lock.json"), "utf8"))
const packages = lock && lock.packages
if (!packages || typeof packages !== "object") process.exit(1)
let hidden
try {
  hidden = JSON.parse(fs.readFileSync(path.join(top, "node_modules", ".package-lock.json"), "utf8"))
} catch {
  process.exit(1)
}
const installedPackages = hidden && hidden.packages
if (!installedPackages || typeof installedPackages !== "object") process.exit(1)
for (const [key, entry] of Object.entries(installedPackages)) {
  if (!Object.hasOwn(packages, key)) process.exit(1)
  const locked = packages[key]
  if (entry.link !== true && locked.link !== true && entry.version !== locked.version) process.exit(1)
}
for (const [key, entry] of Object.entries(packages)) {
  if (key.includes("node_modules/") && entry.link !== true && entry.optional !== true &&
      !Object.hasOwn(installedPackages, key)) process.exit(1)
}
for (const [key, entry] of Object.entries(packages)) {
  if (!key.includes("node_modules/") || entry.link === true) continue
  let installed
  try {
    installed = JSON.parse(fs.readFileSync(path.join(top, key, "package.json"), "utf8"))
  } catch (error) {
    if (entry.optional === true && error.code === "ENOENT") continue
    process.exit(1)
  }
  if (!installed || installed.version !== entry.version) process.exit(1)
}
' "$top"
}

provision_deps() {
  [ -f "$top/package.json" ] || return
  if [ -e "$top/node_modules" ] || [ -L "$top/node_modules" ]; then return; fi

  log=$(mktemp "${TMPDIR:-/tmp}/wrsp-worktree-deps.XXXXXX") || return

  if [ -d "$main/node_modules" ] && [ ! -L "$main/node_modules" ]; then
    if cp -Rc "$main/node_modules" "$top/node_modules" >>"$log" 2>&1; then
      if cmp -s "$main/package-lock.json" "$top/package-lock.json"; then
        if clone_matches_lock >>"$log" 2>&1; then
          rm -f "$log"
          echo "WRSP worktree-deps (#171): cloned node_modules from $main; the lockfiles match."
          return
        fi
        rm -rf "$top/node_modules"
      fi
    else
      rm -rf "$top/node_modules"
    fi
  fi

  if (cd "$top" && npm ci --prefer-offline) >>"$log" 2>&1; then
    rm -f "$log"
    echo "WRSP worktree-deps (#171): ran npm ci --prefer-offline in $top."
  else
    echo "WRSP worktree-deps (#171): could not provision node_modules in $top (log: $log). Node will resolve $main/node_modules instead. Remedy: cd $top && cp -Rc $main/node_modules node_modules && npm ci --prefer-offline"
  fi
}

provision_hooks() {
  configured=$(git -C "$top" config --get core.hooksPath)
  [ -n "$configured" ] || return
  case $configured in
    /*) return ;;
    */_) ;;
    *) return ;;
  esac
  husky_dir=${configured%/_}
  hooks=$top/$configured
  [ -d "$hooks" ] && return
  [ -x "$top/node_modules/.bin/husky" ] || return

  hooklog=$(mktemp "${TMPDIR:-/tmp}/wrsp-worktree-hooks.XXXXXX") || return
  if (cd "$top" && ./node_modules/.bin/husky "$husky_dir") >>"$hooklog" 2>&1 && [ -d "$hooks" ] &&
    [ "$(git -C "$top" config --get core.hooksPath)" = "$configured" ]; then
    rm -f "$hooklog"
    echo "WRSP worktree-deps (#171): installed git hooks with husky in $top."
  else
    echo "WRSP worktree-deps (#171): could not install git hooks in $top (log: $hooklog); commits there run no hooks. Remedy: cd $top && npx --no-install husky"
  fi
}

provision_deps
provision_hooks
exit 0
