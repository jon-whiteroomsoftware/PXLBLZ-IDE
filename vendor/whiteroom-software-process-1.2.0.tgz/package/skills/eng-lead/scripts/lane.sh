#!/usr/bin/env bash
# WRSP #197: one detached process per lane turn; identity survives process exit.
set -euo pipefail

refuse() { printf 'REFUSED: %s\n' "$2" >&2; exit "$1"; }
absolute() { case $1 in /*) printf '%s\n' "$1";; *) printf '%s/%s\n' "$PWD" "$1";; esac; }
load() {
  [[ -r $1 ]] && jq -e 'type == "object" and (.turn | type == "number")' "$1" >/dev/null 2>&1 || refuse 65 'handle missing or unreadable'
  handle=$1
  n=$(jq -r .turn "$handle")
  log=$(jq -r .contact "$handle")
}
atomic() { cat > "$handle.tmp.$$"; mv -f "$handle.tmp.$$" "$handle"; }
live() {
  [[ -s ${log}.pid ]] || return 1
  pid=$(cat "${log}.pid")
  [[ $pid =~ ^[0-9]+$ ]] && ps -p "$pid" >/dev/null 2>&1
}
state() {
  if [[ -f ${log}.exit ]]; then printf 'exited %s' "$(cat "${log}.exit")"
  elif live; then printf live
  elif [[ -d $handle.lock ]]; then printf interrupted
  else printf none; fi
}
record_fact() { # Same best-effort boundary as launch-worker.sh (#196).
  if ! command -v "$usage_bin" >/dev/null 2>&1; then
    echo "WARNING: launch record not written: $usage_bin is not on PATH (#196)." >> "$log"
    return 0
  fi
  "$usage_bin" "$@" >/dev/null 2>>"$log" || echo "WARNING: launch record not written: $usage_bin $1 $2 exited $? (#196)." >> "$log"
  return 0
}
remove_job() {
  if [[ -n ${WRSP_LANE_REMOVE:-} ]]; then
    "$WRSP_LANE_REMOVE" "$1" >/dev/null 2>&1 || true
  else
    launchctl remove "$1" >/dev/null 2>&1 || true
  fi
}
submit() {
  local label=$1
  local self
  self=$(absolute "$0")
  local cmd=(launchctl submit -l "$label" --)
  [[ -z ${WRSP_LANE_SUBMIT:-} ]] || cmd=("$WRSP_LANE_SUBMIT")
  cmd+=(/usr/bin/env "PATH=$PATH" "HOME=$HOME" "TMPDIR=${TMPDIR:-/tmp}")
  [[ -z ${WRSP_ROLES_DIR:-} ]] || cmd+=("WRSP_ROLES_DIR=$(absolute "$WRSP_ROLES_DIR")")
  [[ -z ${WRSP_USAGE_BIN:-} ]] || cmd+=("WRSP_USAGE_BIN=$WRSP_USAGE_BIN")
  [[ -z ${WRSP_LANE_REMOVE:-} ]] || cmd+=("WRSP_LANE_REMOVE=$WRSP_LANE_REMOVE")
  cmd+=(/bin/bash "$self" run-turn "$handle" "$n" "$label")
  local code=0
  "${cmd[@]}" || code=$?
  if [[ $code != 0 ]]; then remove_job "$label"; fi
  return "$code"
}
command=${1:-}; [[ $# -eq 0 ]] || shift
case $command in
  title)
    role= lane= task= issues= state=
    while [[ $# -gt 0 ]]; do
      [[ $# -ge 2 && -n $2 ]] || refuse 64 'missing argument'
      case $1 in
        --role) role=$2;; --lane) lane=$2;; --task) task=$2;;
        --issues) issues=$2;; --state) state=$2;; *) refuse 64 'unknown argument';;
      esac; shift 2
    done
    # Names table: keep role glyphs in this single block.
    case $role in
      eng-lead) emoji=👽;;
      developer) emoji=👩‍💻;;
      builder) emoji=🔧;;
      reviewer) emoji=👀;;
      researcher) emoji=🔬;;
      locator) emoji=🔍;;
      ux-principal) emoji=👩‍🎤;;
      principal-engineer) emoji=😺;;
      batch) emoji=🤖;;
      *) refuse 64 'unknown role';;
    esac
    case $state in '') ;; done) emoji=💀;; *) refuse 64 'unknown state';; esac
    [[ -n $task ]] || refuse 64 'missing task'
    printf '%s%s %s%s\n' "$emoji" "${lane:+ $lane:}" "$task" "${issues:+ $issues}"
    ;;
  start)
    role= cli= role_id= model= effort= worktree= issue= brief= title= log=
    while [[ $# -gt 0 ]]; do
      [[ $# -ge 2 && -n $2 && $2 != --* ]] || refuse 64 'missing argument'
      case $1 in
        --role) role=$2;; --cli) cli=$2;; --role-id) role_id=$2;; --model) model=$2;;
        --effort) effort=$2;; --worktree) worktree=$2;; --issue) issue=$2;;
        --brief) brief=$2;; --title) title=$2;; --log) log=$2;; *) refuse 64 'unknown argument';;
      esac; shift 2
    done
    [[ -n $role && -n $cli && -n $model && -n $effort && -n $worktree && -n $issue && -n $brief && -n $title && -n $log ]] || refuse 64 'missing argument'
    [[ -n $role_id ]] || refuse 64 '--role-id is required (#243)'
    [[ $role == developer || $role == ux-principal ]] || refuse 64 'unknown role'
    [[ $cli == claude || $cli == codex ]] || refuse 64 'unknown cli'
    [[ $issue =~ ^[0-9]+$ && -r $brief ]] || refuse 64 'invalid issue or unreadable brief'
    stem=$(absolute "${log%.log}"); handle=$stem.lane.json
    [[ ! -e $handle ]] || refuse 65 'handle exists; use send'
    [[ -d $worktree ]] || refuse 66 'worktree not a directory'
    budget=$(awk -F '\t' -v role_id="$role_id" -v m="$model" -v e="$effort" '$1==role_id && $2==m && $3==e {print $4; exit}' "${WRSP_ROLES_MEMBERS:-$HOME/.agents/roles.members}" 2>/dev/null) || budget=
    [[ $budget =~ ^[0-9]+$ ]] || refuse 67 "role $role_id has no pair ($model, $effort)"
    command -v "$cli" >/dev/null 2>&1 || refuse 69 "$cli is not on PATH"
    # WRSP #249: refuse a CLI below the model's vendor-stated minimum; an unlisted model is never refused.
    minimums=${WRSP_CLI_MINIMUMS:-$HOME/.agents/cli-minimums}
    [[ -r $minimums ]] || refuse 66 "cli-minimums not found: $minimums. Run wrsp-agents install."
    minimum=$(awk -F '\t' -v m="$model" -v c="$cli" '!/^#/ && $1 == m && $2 == c { print $3; exit }' "$minimums") || minimum=
    if [[ -n $minimum ]]; then
      installed=$("$cli" --version </dev/null 2>/dev/null | grep -Eo '[0-9]+\.[0-9]+\.[0-9]+' | head -n 1) || installed=
      [[ -n $installed ]] || refuse 69 "$cli version unreadable ($cli --version); $model needs $cli $minimum or later."
      if [[ $(awk -v a="$installed" -v b="$minimum" 'BEGIN { split(a, x, "."); split(b, y, "."); for (i = 1; i <= 3; i++) if (x[i] + 0 != y[i] + 0) { print (x[i] + 0 < y[i] + 0); exit } print 0 }') == 1 ]]; then
        refuse 69 "$cli $installed is below $model's minimum $minimum; upgrade $cli to $minimum or later"
      fi
    fi
    worktree=$(cd "$worktree" && pwd -P); brief=$(absolute "$brief")
    project=$(git -C "$worktree" rev-parse --show-toplevel)
    lane=$(basename "$stem"); lane=${lane//[^A-Za-z0-9.-]/-}
    launch_id=$(uuidgen | tr '[:upper:]' '[:lower:]'); thread=; provider=openai
    if [[ $cli == claude ]]; then provider=anthropic; thread=$(uuidgen | tr '[:upper:]' '[:lower:]'); fi
    n=1; log=$stem.turn-1.log
    label=com.whiteroom.wrsp-lane.$lane.$n.$(date +%s)
    mkdir "$handle.lock" 2>/dev/null || refuse 65 'handle exists; use send'
    jq -n --arg lane "$lane" --arg role "$role" --arg title "$title" --arg cli "$cli" --arg provider "$provider" --arg host "$(hostname -s)" --arg project "$project" --arg issue "$issue" --arg worktree "$worktree" --arg role_id "$role_id" --arg model "$model" --arg effort "$effort" --arg budget "$budget" --arg contact "$log" --arg launch_id "$launch_id" --arg thread "$thread" --arg input "$brief" --arg label "$label" \
      '{lane:$lane,role:$role,title:$title,cli:$cli,provider:$provider,host:$host,project:$project,issue:$issue,worktree:$worktree,role_id:$role_id,model:$model,effort:$effort,budget:$budget,contact:$contact,launch_id:$launch_id,thread:$thread,turn:1,next_exchange:"brief",turns:[{n:1,log:$contact,input:$input,label:$label}]}' | atomic
    if ! submit "$label"; then rm -f "$handle"; rmdir "$handle.lock"; refuse 69 'submission failed'; fi
    printf 'HANDLE: %s\n' "$handle"
    ;;
  send)
    [[ $# -eq 2 && -r $2 ]] || refuse 64 'missing argument or unreadable message'
    load "$1"; input=$(absolute "$2")
    [[ -n $(jq -r '.role_id // ""' "$handle") ]] || refuse 64 "handle $handle has no role_id: it was started with --tier, which #243 removed; relaunch the lane with --role-id"
    worktree=$(jq -r .worktree "$handle")
    [[ -d $worktree ]] || refuse 80 "worktree $worktree is missing; recreate it or start a new lane"
    if ! mkdir "$handle.lock" 2>/dev/null; then
      if live; then refuse 75 "busy, turn $n live (pid $pid)"; fi
      refuse 76 "interrupted turn $n; run lane.sh recover $handle"
    fi
    if [[ -z $(jq -r '.thread // empty' "$handle") ]]; then rmdir "$handle.lock"; refuse 77 'provider thread or session id missing'; fi
    before=$(cat "$handle")
    n=$((n + 1)); log=${handle%.lane.json}.turn-$n.log
    label=com.whiteroom.wrsp-lane.$(jq -r .lane "$handle").$n.$(date +%s)
    jq --argjson n "$n" --arg log "$log" --arg input "$input" --arg label "$label" '.turn=$n | .contact=$log | .next_exchange=$input | .turns += [{n:$n,log:$log,input:$input,label:$label}]' "$handle" | atomic
    if ! submit "$label"; then printf '%s\n' "$before" | atomic; rmdir "$handle.lock"; refuse 69 'submission failed'; fi
    printf 'HANDLE: %s\n' "$handle"
    ;;
  read)
    [[ $# -eq 1 || ( $# -eq 3 && $2 == --cursor && $3 =~ ^[0-9]+$ ) ]] || refuse 64 'invalid read arguments'
    load "$1"; cursor=${3:-0}
    if [[ -f $log ]]; then
      size=$(wc -c < "$log"); count=$((size - cursor)); (( count >= 0 )) || count=0
      (( count <= 65536 )) || count=65536
      dd if="$log" bs=1 skip="$cursor" count="$count" 2>/dev/null
      cursor=$((cursor + count))
    fi
    printf '\nCURSOR: %s\n' "$cursor"
    ;;
  status)
    [[ $# -eq 1 ]] || refuse 64 'missing handle'; load "$1"
    jq -r '. as $h | ["lane","role","title","cli","provider","role_id","model","effort","budget","issue","worktree","thread","turn"][] | . + ": " + ($h[.] // "" | tostring)' "$handle"
    printf 'state: %s\nturn-log: %s\nnext-exchange: %s\n' "$(state)" "$log" "$(jq -r .next_exchange "$handle")"
    ;;
  recover)
    [[ $# -eq 1 ]] || refuse 64 'missing handle'; load "$1"
    [[ -d $handle.lock && ! -e ${log}.exit ]] && ! live || refuse 78 'turn is not interrupted'
    printf 'EXIT:70\n' >> "$log"; printf '70\n' > "${log}.exit"
    rmdir "$handle.lock"; printf 'RECOVERED turn %s\n' "$n"
    ;;
  run-turn)
    [[ $# -eq 3 ]] || refuse 64 'missing turn'
    label=$3; trap 'remove_job "$label"' EXIT
    load "$1"
    [[ $n == "$2" && -d $handle.lock ]] || refuse 78 'turn not admitted'
    if [[ -e ${log}.pid || -e ${log}.exit ]]; then
      printf 'RESPAWN REFUSED: turn %s already ran (pid file present); run lane.sh recover %s\n' "$n" "$handle" >> "$log"
      exit 79
    fi
    launch_id=$(jq -r .launch_id "$handle"); usage_bin=${WRSP_USAGE_BIN:-wrsp-usage}
    finish() {
      local code=$1
      trap - EXIT
      [[ $(tail -n 1 "$log" 2>/dev/null) == "EXIT:$code" ]] || printf 'EXIT:%s\n' "$code" >> "$log"
      record_fact launch-record exit --launch-id "$launch_id" --exit-code "$code" --log "$log"
      printf '%s\n' "$code" > "${log}.exit.tmp.$$"; mv -f "${log}.exit.tmp.$$" "${log}.exit"
      rmdir "$handle.lock" 2>/dev/null || true
      remove_job "$label"
      exit "$code"
    }
    trap 'finish 70' EXIT
    printf '%s\n' "$$" > "${log}.pid.tmp.$$"; mv -f "${log}.pid.tmp.$$" "${log}.pid"
    cli=$(jq -r .cli "$handle"); model=$(jq -r .model "$handle"); effort=$(jq -r .effort "$handle")
    budget=$(jq -r .budget "$handle"); thread=$(jq -r .thread "$handle"); worktree=$(jq -r .worktree "$handle")
    input=$(jq -r '.turns[-1].input' "$handle")
    roles=${WRSP_ROLES_DIR:-$HOME/.agents/roles}
    if [[ $n == 1 ]]; then
      role_id=$(jq -r '.role_id // ""' "$handle")
      args=(launch-record start --launch-id "$launch_id" --issue "$(jq -r .issue "$handle")" --role "$(jq -r .role "$handle")" --cli "$cli" --model "$model" --effort "$effort" --worktree "$worktree" --brief "$input" --log "$log")
      [[ $cli != claude ]] || args+=(--child-session "$thread")
      record_fact "${args[@]}"
    fi
    cmd=(env WRSP_ROLE=developer "WRSP_CONTEXT_BUDGET=$budget")
    if [[ $cli == claude ]]; then
      cmd+=(claude -p --model "$model" --effort "$effort" --settings "$roles/developer.claude.json" --permission-mode bypassPermissions)
      if [[ $n == 1 ]]; then cmd+=(--session-id "$thread" --name "$(jq -r .title "$handle")"); else cmd+=(--resume "$thread"); fi
      cmd+=(--output-format json)
    else
      [[ $effort != med ]] || effort=medium
      cmd+=(codex exec)
      [[ $n == 1 ]] || cmd+=(resume "$thread")
      cmd+=(--json -m "$model" -c "model_reasoning_effort=$effort" -c "model_auto_compact_token_limit=$budget")
      while IFS= read -r override || [[ -n $override ]]; do
        [[ -z $override || $override == \#* ]] || cmd+=(-c "$override")
      done < "$roles/developer.codex.args"
      # WRSP #258: codex exec resume has no -C; every turn already runs after cd "$worktree".
      [[ $n != 1 ]] || cmd+=(-C "$worktree")
      cmd+=(-)
    fi
    if [[ ! -d $worktree ]]; then
      printf 'REFUSED: worktree %s is missing; recreate it or start a new lane\n' "$worktree" >> "$log"
      trap - EXIT; finish 80
    fi
    cd "$worktree"
    code=0; "${cmd[@]}" < "$input" >> "$log" 2>&1 || code=$?
    if [[ $n == 1 && $cli == codex ]]; then
      thread=$(jq -Rnr 'first(inputs | fromjson? | select(.type == "thread.started") | .thread_id // empty) // empty' "$log")
      if [[ -n $thread ]]; then
        jq --arg thread "$thread" '.thread=$thread' "$handle" | atomic
        record_fact launch-record session --launch-id "$launch_id" --provider codex --session-id "$thread"
      fi
    fi
    trap - EXIT; finish "$code"
    ;;
  *) refuse 64 'unknown subcommand';;
esac
