---
name: batch
description: Batch role for a non-interactive scheduled job that runs one brief with nobody watching. The scheduler or eng lead supplies this skill with the job's brief; it is not for interactive sessions.
---

# Batch

1. Declare the role before anything else: run `node ~/.agents/hooks/session-role.mjs declare batch` from the project checkout, adding `--issue <n>` when the brief names one issue. The declaration labels this session's telemetry. It grants no authority.
2. Follow the job's brief exactly. Nobody is watching, so never ask a question or wait for an answer.
3. Write output only where the brief names. When the brief has a gap, print one line starting `BRIEF GAP:` naming it, and exit without changes.
4. A batch session never pushes, tags, writes with `gh`, messages or spawns agents, or changes host configuration. Put anything that needs one of these in the final report.
