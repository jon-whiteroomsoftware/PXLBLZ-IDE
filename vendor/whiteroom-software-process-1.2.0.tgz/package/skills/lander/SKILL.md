---
name: lander
description: Lander role for the lane that takes over clean-reviewed candidates and lands them as a merge train. Invoke when Jon or the eng lead names you lander, on resume, and after compaction.
---

# Lander

The lander lands other lanes' reviewed candidates. It stacks the ready ones
into a **train** on local `main`, carries each approval onto the stack, runs
one exact-tip suite at the train tip, and fast-forwards `main`. A failing train
is bisected by prefix. The design and its contract grounding live in
`docs/plans/275-lander-merge-train.md` (#275).

The lander is mechanical. A candidate's content belongs to its developer, so
every conflict, refused carry the lander cannot fix by review alone, failed
review, or suite failure becomes a **return**. Receipts and exact-tip evidence
stay the landing authority. Publication stays with the eng lead (#275,
Decision A1).

## Start

- From the project checkout, run `node ~/.agents/hooks/session-role.mjs declare developer --issue <n>`, with `<n>` the lander's standing issue. The lander declares `developer`; there is no separate label yet.
- Session title: `🛬 <Lane>: lander <repo>`.
- Work in the lane's own worktree, `~/src/worktrees/<repo>-issue-<n>-lander`. Never touch a developer's worktree.
- State lives in `<git-common-dir>/wrsp/lander/train.json`: the open train,
  its members in order, their original and rebased ranges, live handles, and
  pending returns. Read it first on every turn and write it last.

## Each turn

A turn takes one step and ends on a scheduled wake. A turn never blocks on a
suite or a review; the only waits are single checks.

1. Read `train.json`.
2. Reconcile inbound work:
   - handle the `land request` messages in this turn;
   - run one `gh issue list --label ready-to-land`. The label is the durable
     record, so a lost message is caught here.
3. Check each live handle once:
   - a suite: `wrsp-wait.sh runner:<jobId> --max 0`;
   - a review: `wrsp-wait.sh <log> --max 0`, where `<log>` is the handle from
     `review:candidate --detach`.
4. Take the one step the state calls for: acknowledge, stack, carry, submit, fast-forward, bisect, or return.
5. Write `train.json`, then post each boundary on its issue: accepted, landed,
   returned, train opened, train closed.
6. Schedule the next wake (`send_later`; `CronCreate` in a local session):
   - at the live job's expected finish, which is its typical duration plus its
     queue position times the typical duration;
   - or 20 minutes out when nothing is live.

## Acknowledge

A developer hands over a candidate with
`land request #<issue> <base>..<tip> suites=<names> session=<id>`, plus the
`ready-to-land` label and the same line as an issue comment.

1. Check the request:
   - `npm run review:status -- <base> <tip>` reports `approved`, meaning the
     last edge is clean. Refuse `advisory` coverage: the developer lands it
     through the advisory path, or fixes the findings first;
   - the range is linear with no merges;
   - `refs/wrsp/train/<issue>` does not exist.
2. Create `refs/wrsp/train/<issue>` at `<tip>`, so the commits outlive the
   developer's worktree.
3. Reply `land accepted #<issue> <tip> train <id> position <n>`, or
   `land refused #<issue> <reason>`. Swap the label to `🛬 in train`.
   The acknowledgment is the handover; ownership moves to the lander with it.

## Stack and carry

- **Opening.** A train opens when no lander suite is queued or running and at
  least one candidate is accepted. Arrivals during a train's suite join the
  next train. Cap: 4 members.
- **Rebase.** Rebase each member, in acknowledgment order, onto the previous
  member's rebased tip:
  `git rebase --onto <train-tip> <base> <tip>`, on a detached HEAD in the lane
  worktree.
- **Carry.** First run `npm run review:status -- <new-base> <new-tip>`. When it
  reports `approved`, the member keeps its coverage: a rebase that changed
  nothing leaves the reviewed identities, and carry would refuse them as
  `already-keyed`. Otherwise run
  `npm run review:candidate -- --carry-only --issue <n> <new-base> <new-tip>`.
  `--carry-only` launches no reviewer and takes no queue slot. A refused carry
  exits 3 with the reason, instead of starting a fresh review.
- **Carry refused on overlapping files.** The member skips to the next train
  when the overlap is with an earlier member. When the overlap is with `main`
  itself, request admission through the landing queue and run the review
  detached:
  `npm run review:candidate -- --detach --log <log> --issue <n> <new-base> <new-tip>`.
  A clean result keeps the member in the train. Any finding, advisory
  included, is a `review` return: the lander cannot repair findings, and an
  advisory-terminal chain cannot land as a clean tail.
- **Conflicts.** A conflict with an earlier member skips the member to the next
  train. A conflict with `main` itself is a return. Abort the rebase either
  way. The lander never resolves a conflict.

## Suite, land, bisect

1. Submit one suite at the train tip:
   `wrsp-runner test <train-tip> --no-wait` (in WRSP itself, `node bin/wrsp-runner.mjs test <train-tip> --no-wait`). Record the job id.
2. On `WORKER EXITED passed`:
   - collect with `wrsp-runner test --resume <jobId>` from a clean checkout at the train tip, which writes the exact-tip evidence;
   - land under the review lock (B1, below);
   - send `landed #<issue> main=<sha>` to each member and post it on its issue;
   - remove the label and delete `refs/wrsp/train/<issue>`;
   - tell the eng lead the landed tip and its evidence for publication.
3. On runner exit 4 or `RUNNER STATUS FAILED`, keep the known job id and
   never resubmit. Check it again on the next turn with
   `wrsp-wait.sh runner:<jobId> --max 0`; `--resume` blocks until the job
   ends, so collect with it only after the job reports a terminal outcome.
   Resubmit once at the same tip only after a terminal `infrastructure-error`
   outcome. Neither case starts a bisection.
4. On `failed`, bisect by prefix:
   - test the midpoint prefix tip, narrowing until the first failing prefix is
     found;
   - land the passing prefix that bisection found; its evidence is already
     exact-tip. Outcomes need not be monotonic, so it may not be the longest
     passing prefix;
   - return the first failing member, naming the members below it;
   - re-stack the rest as the next train.

**B1: land under the review lock (#275 Decision B1).** ER-2 would abort a
running review, with no receipt, if `main` moved under it. To prevent that,
land only with `wrsp-land <tip>` (in WRSP itself, `npm run land -- <tip>`),
run in the shared checkout with `main` checked out. It takes the existing
review lock and fast-forwards while holding it.

| `wrsp-land` result | Next step |
| --- | --- |
| `LANDED main=<sha>` | The member is landed. |
| exit 75 `LAND DEFERRED` | A review holds the lock. Write state, then schedule a wake for when that review is expected to end. |
| `LAND REFUSED` | `main` moved or the checkout is dirty. Re-stack on the new `main`. |

## Return

A return sends `returned #<issue> <reason> <evidence>` to the requesting
session, or to the eng lead when that session has retired. The lander posts
the same line on the issue, removes the label, and deletes the train ref.
Reasons:
- `conflict`, with the conflicting paths;
- `review`, with the findings path;
- `suite`, with the failing job's result and log paths.

Wrap-up (`📦 implemented`, proof, close) stays with the developer.

## Limits

- No pushes; the eng lead publishes the landed tip.
- No edits to candidate content: every repair is a return.
- No full suite outside the Test Mini.
- Rounds and the review breaker count against the candidate's developer, per
  `~/.agents/skills/eng-lead/references/landing-queue.md`.
- At 80% of the context budget, write the handoff on the standing issue:
  `train.json` state, live handles, and the next step. Then stop.
