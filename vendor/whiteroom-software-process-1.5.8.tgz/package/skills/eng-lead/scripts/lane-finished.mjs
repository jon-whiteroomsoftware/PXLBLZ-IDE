import fs from 'node:fs';
import path from 'node:path';
import { createHash, randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
const nonempty = value => typeof value === 'string' && value.length > 0;
const positive = value => Number.isSafeInteger(value) && value > 0;
const fail = (file, reason) => { throw new Error(`${file}: ${reason}`); };

// Only complete JSONL events in this turn's log can supply its final message.
export function finalMessage(cli, logBytes) {
  if (!['claude', 'codex'].includes(cli) || !Buffer.isBuffer(logBytes)) throw new Error('invalid final-message input');
  const lines = logBytes.toString('utf8').split('\n');
  lines.pop();
  let final;
  for (const line of lines) {
    let event;
    try { event = JSON.parse(line); } catch { continue; }
    if (cli === 'codex' && event?.type === 'item.completed' && event.item?.type === 'agent_message' && typeof event.item.text === 'string') final = event.item.text;
    if (cli === 'claude' && event?.type === 'result' && typeof event.result === 'string') final = event.result;
  }
  if (final === undefined) throw new Error('no complete final message');
  return final;
}

function identity(handle) {
  const { lane, cli, thread, turn, handlePath, logPath } = handle;
  if (!nonempty(lane) || !['claude', 'codex'].includes(cli) || !nonempty(thread) || !positive(turn)
      || !nonempty(handlePath) || !path.isAbsolute(handlePath) || !nonempty(logPath) || !path.isAbsolute(logPath)) throw new Error('invalid finished-turn identity');
  return { version: 1, lane, cli, thread, turn, handlePath, logPath };
}

function outputFor(cli, logBytes) {
  const text = finalMessage(cli, logBytes);
  return Buffer.from(text.endsWith('\n') ? text : `${text}\n`, 'utf8');
}

export function receiptFor(handle, logBytes, exitBytes) {
  const id = identity(handle);
  if (!Buffer.isBuffer(exitBytes) || !/^[+-]?\d+\s*$/.test(exitBytes.toString('utf8'))
      || !Number.isSafeInteger(Number(exitBytes.toString('utf8')))) throw new Error('invalid integer exit marker');
  return { ...id, outputSha256: sha256(outputFor(id.cli, logBytes)), logSha256: sha256(logBytes), exitSha256: sha256(exitBytes) };
}

function source(file, action) {
  try { return action(); } catch (error) { fail(file, error.message); }
}

const canonicalHandle = file => source(file, () => fs.realpathSync(file));

function writeOutput(bytes) {
  source('stdout', () => {
    for (let offset = 0; offset < bytes.length;) {
      const written = fs.writeSync(1, bytes, offset, bytes.length - offset);
      if (written <= 0) throw new Error('incomplete output write');
      offset += written;
    }
  });
}

function regularBytes(file) {
  return source(file, () => {
    const fd = fs.openSync(file, fs.constants.O_RDONLY | fs.constants.O_NONBLOCK);
    try {
      if (!fs.fstatSync(fd).isFile()) throw new Error('expected readable regular file');
      return fs.readFileSync(fd);
    } finally { fs.closeSync(fd); }
  });
}

function snapshot(file) {
  const handlePath = canonicalHandle(file);
  const handleBytes = regularBytes(handlePath);
  const handle = source(handlePath, () => JSON.parse(handleBytes.toString('utf8')));
  source(handlePath, () => {
    if (!handle || !positive(handle.turn) || !nonempty(handle.contact)) throw new Error('invalid handle/current contact');
    const current = Array.isArray(handle.turns) ? handle.turns.at(-1) : null;
    const expected = `${handlePath.replace(/\.lane\.json$/, '')}.turn-${handle.turn}.log`;
    const contact = path.join(fs.realpathSync(path.dirname(handle.contact)), path.basename(handle.contact));
    if (contact !== expected || current?.n !== handle.turn || current?.log !== handle.contact) throw new Error('invalid current-turn contact');
  });
  // Exit evidence is validated before opening or resolving the log.
  const exitPath = `${handle.contact}.exit`;
  const exitBytes = regularBytes(exitPath);
  source(exitPath, () => {
    if (!/^[+-]?\d+\s*$/.test(exitBytes.toString('utf8')) || !Number.isSafeInteger(Number(exitBytes.toString('utf8')))) throw new Error('invalid integer exit marker');
  });
  const logPath = source(handle.contact, () => fs.realpathSync(handle.contact));
  if (logPath !== `${handlePath.replace(/\.lane\.json$/, '')}.turn-${handle.turn}.log`) fail(handle.contact, 'current log resolves outside this turn');
  const logBytes = regularBytes(logPath);
  const receipt = source(logPath, () => receiptFor({ ...handle, handlePath, logPath }, logBytes, exitBytes));
  return { handlePath, handleBytes, logPath, logBytes, exitBytes, receipt, output: outputFor(handle.cli, logBytes) };
}

function validReceipt(value) {
  try { identity(value); } catch { return false; }
  return value.version === 1 && ['outputSha256', 'logSha256', 'exitSha256'].every(key => typeof value[key] === 'string' && /^[a-f0-9]{64}$/.test(value[key]));
}

export function run(mode, file) {
  let temp, ownedTemp = false;
  try {
    if (!['guard', 'read', 'canonical-handle'].includes(mode) || !nonempty(file)) throw new Error('expected guard HANDLE, read HANDLE or canonical-handle HANDLE');
    if (mode === 'canonical-handle') {
      writeOutput(Buffer.from(`${canonicalHandle(file)}\n`, 'utf8'));
      return 0;
    }
    const before = snapshot(file);
    const receiptFile = `${before.handlePath}.read.json`;
    if (mode === 'guard') {
      let prior;
      try {
        const fd = fs.openSync(receiptFile, fs.constants.O_RDONLY | fs.constants.O_NONBLOCK);
        try {
          if (!fs.fstatSync(fd).isFile()) throw new Error('expected readable regular receipt');
          prior = JSON.parse(fs.readFileSync(fd, 'utf8'));
        } finally { fs.closeSync(fd); }
      }
      catch (error) {
        if (error.code !== 'ENOENT') fail(receiptFile, error.message);
      }
      if (prior !== undefined && !validReceipt(prior)) fail(receiptFile, 'malformed receipt');
      if (prior === undefined || prior.turn !== before.receipt.turn) {
        fs.writeSync(2, `REFUSED: unread finished turn ${before.receipt.turn}; run lane.sh read ${before.handlePath} --finished\n`);
        return 77;
      }
      for (const [key, value] of Object.entries(before.receipt)) {
        if (prior[key] !== value) fail(key === 'logSha256' || key === 'outputSha256' ? before.logPath : key === 'exitSha256' ? `${before.logPath}.exit` : receiptFile, 'finished-turn receipt mismatch');
      }
      return 0;
    }
    temp = `${receiptFile}.tmp.${process.pid}.${randomUUID()}`;
    source(temp, () => {
      const fd = fs.openSync(temp, 'wx', 0o600);
      ownedTemp = true;
      try { fs.writeFileSync(fd, `${JSON.stringify(before.receipt)}\n`); }
      finally { fs.closeSync(fd); }
    });
    writeOutput(before.output);
    const after = snapshot(file);
    if (before.handlePath !== after.handlePath || !before.handleBytes.equals(after.handleBytes)) fail(file, 'handle changed during exposure');
    if (before.logPath !== after.logPath || !before.logBytes.equals(after.logBytes)) fail(before.logPath, 'log changed during exposure');
    if (!before.exitBytes.equals(after.exitBytes)) fail(`${before.logPath}.exit`, 'exit marker changed during exposure');
    source(receiptFile, () => fs.renameSync(temp, receiptFile));
    temp = undefined;
    return 0;
  } catch (error) {
    fs.writeSync(2, `REFUSED: ${error.message}\n`);
    return 65;
  } finally {
    if (temp && ownedTemp) { try { fs.unlinkSync(temp); } catch { /* Only this invocation's temp is owned. */ } }
  }
}

function isEntry() {
  try { return process.argv[1] && fs.realpathSync(process.argv[1]) === fileURLToPath(import.meta.url); }
  catch { return false; }
}
if (isEntry()) process.exitCode = run(process.argv[2], process.argv[3]);
