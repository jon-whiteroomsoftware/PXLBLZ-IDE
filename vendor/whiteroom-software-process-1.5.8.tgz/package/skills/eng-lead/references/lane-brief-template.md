# Developer lane brief

The eng lead fills this template at assignment. Replace each answer with current
issue state; use `none: <reason>` where inapplicable.

## Issue and scope

Name the lane, issue/spec URL and governing slice, claim step, worktree/branch,
verified base, shared hot-file ownership and handoff destination. Attribute the
brief to the eng lead; quote Jon's words only with their source.

## Limits

Name off-limits paths, authority, named decision points and stop boundaries.
Size the slice for about 70% context and the review-round limit; split before
assignment when it will not fit.

## Oracle and sketch

Name the consumer surface and expected result. Put a test/proof sketch of at
most 10 bullets into the issue's Required proof and Tests at assignment. Include
must-test cases and preservation obligations. Before code, the developer expands
the sketch with `systematic-test-design` into cases, partitions, setup and expected
assertions in the issue's Tests, linking large detail from the body.

## Reads: only these

List exact files and sections needed for this slice. Give line ranges for files
over 200 lines; successors receive the handoff link plus named phase reads.

## Operating rules

The developer implements and tests its own slice at its current effort. Name
review admission/slot and round count, local targeted checks and the final-suite
owner, live-job protocol, eng-lead contact route and turn-ending exchange points.
Invoke `git` for commits and review freshness, `issue-workflow` for issue writes.
On a non-fast-forward landing refusal, rebase and carry under the lane's go via
`reviewed-main-workflow`. Preserve every gate. The eng lead creates the worktree
before lane startup. A question to the eng lead ends the turn; the eng lead reads
only end-of-turn messages. Keep issue state current and report the landed tip,
proof, residual gaps and next owner.
