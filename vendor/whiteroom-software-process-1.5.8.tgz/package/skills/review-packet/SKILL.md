---
name: review-packet
description: Use before exact-range candidate review or when native review-input assembly reports a gap. Routes semantic inputs to the native candidate command and bounded diagnostics to the developer.
metadata:
  wrsp-min-version: "1.4.0"
---

# Native review input

Run the repository's normal candidate command:

```bash
npm run review:candidate -- <base> <tip> [--test-design <json>]
```

The native command owns complete ephemeral input assembly and validation.
[ER-7](../../docs/reference/contracts/exact-range-review.md#invariants)
owns completeness, identity, freshness and size refusals. The bounded
`Native review input v1` diagnostic reports construction facts, never approval
or proof adequacy.

The developer supplies requirements, source context, systematic test-design
semantics and proof obligations through project policy and `--test-design`.
Researchers remain factual and read-only.

On native refusal, report the exact gap and stop the affected action. Report
an installed command/version mismatch to the eng lead. Source changes require
separate installation and installed qualification before claiming deployment.
