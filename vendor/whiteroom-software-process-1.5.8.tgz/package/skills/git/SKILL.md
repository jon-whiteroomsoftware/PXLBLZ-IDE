---
name: git
description: Git procedure for staging, commits, worktree and hook setup, rebasing before candidate review, and push. Invoke before these operations; publication authority remains role-owned.
metadata:
  wrsp-min-version: "1.3.0"
---

# Git

## Commits

- Issue commit subjects start `#<n> `; no auto-close keywords. Small process/docs
  maintenance without an issue may use `no-issue:`. Normal product, architecture,
  implementation or multi-step process changes need an issue or plan reference.
- End agent commits with `X-Authored-Model: <exact model id>`. The
  prepare-commit-msg hook adds missing attribution from the session transcript
  (#303). When a harness forbids typing model ids, leave it to the hook.
- Stage and commit by path; preserve unrelated and overlapping user work. Stage
  a useful new project file; keep scratch unstaged.
- Never bypass hooks: `--no-verify`/`-n`, `HUSKY=0`, `core.hooksPath`
  overrides and hook edits are bypasses.
- Batch Git work into few calls. Run `git push` alone. Publication follows
  [eng-lead operations](../eng-lead/references/operations.md); this skill grants
  no authority.

## Worktrees

Source lives under `~/src`; isolate work in
`~/src/worktrees/<repo>-issue-<n>-<slug>`. Keep the shared checkout on Jon's
selected branch. The issue segment enables usage attribution; preflight warns
when absent. Complete documented install/build and hooks before
`wrsp-preflight worktree` (`npm run preflight -- worktree` in source).

Offline, clone shared dependencies and build output:
`cp -Rc ~/src/<repo>/node_modules ~/src/<repo>/dist <worktree>/` on APFS;
use `cp -a` elsewhere, preserving symlinks. Build as tooling permits. Copying
these directories does not install generated hooks: run `npx husky` in each
worktree using husky. After landing, rebuild shared `dist/` before bin commands.

## Review freshness

Rebase unreviewed work onto current local `main` before review. Immediately before
`review:candidate`, recheck local `main` and rebase if it moved. Landing broadcasts
prompt earlier refresh. Keep the
reviewed checkout and exact range still during review. Rewriting approved ranges
requires eligible carry or fresh review through `reviewed-main-workflow`.
[Landing queue](../eng-lead/references/landing-queue.md) owns admission and
conflict-slot ownership.

For failures, apply global failure scope and `~/.agents/execution-policy.md`,
**Route failures**; this skill adds no recovery route.
