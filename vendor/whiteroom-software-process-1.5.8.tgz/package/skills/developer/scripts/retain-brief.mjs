#!/usr/bin/env node
import { execFileSync } from 'node:child_process'
import { lstat, mkdir, readFile, readdir, realpath, writeFile } from 'node:fs/promises'
import { homedir } from 'node:os'
import { basename, isAbsolute, join, relative, resolve, sep } from 'node:path'
import { pathToFileURL } from 'node:url'

function refuse(path, reason) { throw new Error(`REFUSED: ${path}: ${String(reason).replace(/[\r\n]+/g, ' ')}`) }
async function at(path, operation) {
  try { return await operation() } catch (error) { refuse(path, error.message) }
}
function parseRoots(value, file) {
  if (!value || typeof value !== 'object' || !Array.isArray(value.roots)) refuse(file, 'expected an object with a roots array')
  const names = new Set(), marked = new Set()
  return value.roots.map(root => {
    if (!root || typeof root !== 'object' || typeof root.name !== 'string' || typeof root.path !== 'string') refuse(file, 'each root must have a string name and path')
    const { name, path } = root
    if ('repository' in root && (typeof root.repository !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9-]*\/[A-Za-z0-9._-]+$/.test(root.repository))) refuse(file, `root "${name}" repository must be owner/name`)
    const repository = 'repository' in root ? root.repository.toLowerCase() : null
    if (!/^[a-z0-9][a-z0-9-]*$/.test(name)) refuse(file, `root name "${name}" must be lowercase letters, digits and hyphens`)
    if (names.has(name)) refuse(file, `duplicate root name "${name}"`)
    names.add(name)
    if (!isAbsolute(path) && !path.startsWith('~/')) refuse(file, `root "${name}" path must be absolute or start with ~/`)
    const stars = path.split(sep).filter(part => part.includes('*'))
    if (stars.length > 1 || stars.some(part => part !== '*')) refuse(file, `root "${name}" path may contain one * segment`)
    if ('artifacts' in root && typeof root.artifacts !== 'boolean') refuse(file, `root "${name}" artifacts must be boolean`)
    if (root.artifacts === true) {
      if (!repository || stars.length) refuse(file, `root "${name}" artifacts requires a repository and no wildcard path`)
      if (marked.has(repository)) refuse(file, `duplicate artifacts repository "${repository}"`)
      marked.add(repository)
    }
    return { ...root, repository, path: path.startsWith('~/') ? join(homedir(), path.slice(2)) : path }
  })
}
function repositoryOf(worktree) {
  try {
    const remote = execFileSync('git', ['remote', 'get-url', 'origin'], { cwd: worktree, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }).trim()
    const match = /^(?:https:\/\/(?:[^/@]+@)?github\.com\/|git@github\.com:|ssh:\/\/git@github\.com\/)([A-Za-z0-9][A-Za-z0-9-]*\/[A-Za-z0-9._-]+?)(?:\.git)?\/?$/.exec(remote)
    return match?.[1].toLowerCase() ?? null
  } catch { return null }
}
async function runnerHome(environment) {
  if (environment.WRSP_RUNNER_HOME) return environment.WRSP_RUNNER_HOME
  const plist = join(homedir(), 'Library/LaunchAgents/com.whiteroom.wrsp-dashboard.plist')
  await at(plist, () => readFile(plist))
  let home
  try {
    home = execFileSync('plutil', ['-extract', 'EnvironmentVariables.WRSP_RUNNER_HOME', 'raw', plist], { encoding: 'utf8', env: environment, stdio: ['ignore', 'pipe', 'pipe'] }).trim()
  } catch { refuse(plist, 'plutil failed: missing key or unreadable/invalid plist') }
  if (!home) refuse(plist, 'empty EnvironmentVariables.WRSP_RUNNER_HOME')
  return home
}
function contained(root, path) {
  const rel = relative(root, path)
  return !isAbsolute(rel) && rel !== '..' && !rel.startsWith(`..${sep}`)
}
async function directory(root, path) {
  let info
  try { info = await lstat(path) } catch (error) {
    if (error.code !== 'ENOENT') refuse(path, error.message)
    await at(path, () => mkdir(path).catch(error => { if (error.code !== 'EEXIST') throw error }))
    info = await at(path, () => lstat(path))
  }
  if (info.isSymbolicLink() || !info.isDirectory()) refuse(path, 'destination component must be a directory, not a symlink or file')
  const real = await at(path, () => realpath(path))
  if (!contained(root, real)) refuse(path, 'destination escapes artifacts root')
}
async function countFiles(path) {
  let count = 0
  for (const entry of await at(path, () => readdir(path, { withFileTypes: true }))) {
    if (entry.isFile()) count++
    else if (entry.isDirectory()) count += await countFiles(join(path, entry.name))
  }
  return count
}

export async function retainBrief({ worktree, brief, issue, launchId, environment = process.env }) {
  const home = await runnerHome(environment), file = join(home, 'files.json')
  let bytes
  try { bytes = await readFile(file, 'utf8') } catch (error) {
    if (error.code === 'ENOENT') { console.log(`WARNING: brief retention unconfigured: ${file}`); return }
    refuse(file, error.message)
  }
  const roots = parseRoots(await at(file, () => JSON.parse(bytes)), file)
  const repository = repositoryOf(worktree)
  const selected = roots.find(root => root.artifacts === true && repository && root.repository === repository)
  if (!selected) { console.log(`WARNING: brief retention unconfigured: ${file}: no artifacts root for worktree repository`); return }
  if (!/^[1-9][0-9]*$/.test(issue ?? '')) refuse(file, 'brief retention requires a positive decimal issue')
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(launchId ?? '')) refuse(file, 'brief retention requires a launch UUID')
  const root = await at(selected.path, () => realpath(selected.path))
  const folders = []
  for (const entry of await at(root, () => readdir(root, { withFileTypes: true }))) {
    if (!entry.name.startsWith(`${issue}-`) || entry.name.length === issue.length + 1) continue
    const path = join(root, entry.name)
    if (entry.isSymbolicLink()) refuse(path, 'issue folder must not be a symlink')
    if (entry.isDirectory()) folders.push({ name: entry.name, count: await countFiles(path) })
  }
  folders.sort((a, b) => b.count - a.count || (a.name < b.name ? -1 : a.name > b.name ? 1 : 0))
  let folder = folders[0]?.name
  if (!folder) {
    const slug = new RegExp(`(?:^|-)issue-${issue}-([A-Za-z0-9][A-Za-z0-9._-]*)$`).exec(basename(resolve(worktree)))?.[1]
    if (!slug) refuse(worktree, `no safe ASCII issue-${issue}-<slug> suffix`)
    folder = `${issue}-${slug}`
  }
  let destination = root
  for (const component of [folder, 'work', 'briefs']) {
    destination = join(destination, component)
    await directory(root, destination)
  }
  const original = await at(brief, () => readFile(brief))
  const timestamp = new Date().toISOString().replace(/[-:.]/g, '')
  const safeName = basename(brief).replace(/[^A-Za-z0-9._-]/g, '-') || 'brief'
  destination = join(destination, `${timestamp}-${launchId}-${safeName}`)
  await at(destination, () => writeFile(destination, original, { flag: 'wx' }))
  console.log(`RETAINED BRIEF: ${destination}`)
  return destination
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  try {
    const args = process.argv.slice(2), options = {}
    const keys = { '--worktree': 'worktree', '--brief': 'brief', '--issue': 'issue', '--launch-id': 'launchId' }
    for (let i = 0; i < args.length; i += 2) {
      if (!keys[args[i]] || args[i + 1] === undefined) refuse(args[i], 'invalid argument')
      options[keys[args[i]]] = args[i + 1]
    }
    if (!options.worktree || !options.brief) refuse('arguments', '--worktree and --brief are required')
    await retainBrief(options)
  } catch (error) { console.error(error.message); process.exitCode = 66 }
}
