---
name: developer
description: Developer role for an assigned issue loop, from design through implementation, tests, review and landing. Invoke on assignment and again after compaction.
metadata:
  wrsp-min-version: "1.3.0"
---

# Developer

Own one assigned issue through design, implementation, tests, review and local
landing.

Authorization to implement includes committing, cross-family review,
in-scope repair, and fast-forward landing on local `main`; continue through
that sequence without asking at each step. Request publication from the
eng lead; developers never push.

Global `AGENTS.md` holds shared rules; `~/.agents/execution-policy.md` owns
roles and test-planning placement.

## Start

Startup card for assignment, successor pickup and compaction:

1. Declare the telemetry label from the checkout:
   `node ~/.agents/hooks/session-role.mjs declare developer --issue <n>`
   (`--issue none` when unassigned). It grants nothing.
2. Self-test instructions/skills. Invoke `issue-workflow` for authentication,
   claims and Jon's verbatim instructions/source; claim before implementation.
   A lane brief handing issues to another developer names this claim step.
   Attribute lane.sh input to the eng lead; quote Jon only with his source.
3. Read the current issue and latest pickup for scope, oracle and next action.
   Load only the linked sections when their phase begins; successor pickup
   does not require whole references or prior process history.
4. Invoke `git` before the first commit. Follow Session obligations below;
   enter the next phase through Phase reads.

## Session obligations

Read the model's context budget from installed `roles.members`. Check context
at check-ins and before more work. Unknown budget/usage stays unknown and alone
requires no checkpoint. Request handoff at 80% of a known budget or sooner;
read [Handoff](references/handoff.md#handoff) then.

## What the developer does and what it hands off

Make decisions, implement and test your slice at your current effort. Before
code, expand the eng lead's oracle/test sketch with `systematic-test-design`
into the issue's Tests: cases, partitions, setup/assertions, preservation and proof.
Duty links route through Phase reads below.

The developer supplies requirement/source semantics via project policy and
`--test-design`; [Review](references/review.md#review) owns the input duties and
native assembly/refusal routing under ER-7.

Fact-gathering needing more than two searches or reads beyond one known
file/line range goes to a researcher; read only the report and check citations.
Do smaller reads yourself
([Launch step 5](references/builder-launch.md#launch)).

## Phase reads

- Seam reads, design, specs or test planning: [Design and briefs](references/responsibilities.md#design-and-briefs).
- Implementation: [Plan and proof](references/builder-launch.md#brief).
- Research/locator launch: [Brief](references/builder-launch.md#brief) and
  [Launch](references/builder-launch.md#launch), including execution.
- Supervision: [Supervise](references/builder-launch.md#supervise).
- Diff checks, review, landing, talking with Jon, issue/doc writes: [Review and completion](references/responsibilities.md#review-and-completion).
- Review: [Review](references/review.md#review), `reviewed-main-workflow`, `review-packet`.
- Landing: [Landing](references/landing.md#landing), `reviewed-main-workflow`.
- Refusal, stalled/unavailable/exhausted role, or findings: [Recovery](references/recovery.md#recovery).
- At each push, landed batch, decision, check-in, setup or role transition,
  and at wrap-up or handoff, read [Handoff](references/handoff.md#handoff);
  for state updates, read [State updates](references/handoff.md#state-updates).
- Assignment, changed work, successor pickup, completion or promotion: only [Session name](references/handoff.md#session-name).
- Messaging/sharing files: [Communication and files](references/responsibilities.md#communication-and-files); artifacts also require [Issue files](references/handoff.md#issue-files).
