# Recovery

## Candidate repairs

After review rejects a candidate, repair and test the slice directly. Keep
repairs in the candidate authors' model family to keep it single-family:
split review checks each run at its own tip and stops at the first rejection.
Run required host proof once before commit. Preserve retained changes and
record the remaining correction in the issue's plan.

When an approach stalls, narrow to exact files and lines, or write the interface
before the bodies. Diagnose the invariant, approach or enforcement layer before
another attempt. Exhausted roles stop and go to Jon; they do not fall through.

- Repairable findings or failed checks block landing, not authorized
  repair. Classify the outcome, never the word BLOCKED or a nonzero exit.
- Count the allocated task's review rounds. Round 5 is the last: a task without a clean approval after it
  stops and goes to the eng lead, under the round limit in
  `~/.agents/skills/eng-lead/references/landing-queue.md`.
- Three consecutive P0/P1 reviews on one lineage pause it before a fourth:
  discuss the invariant, approach or enforcement layer with Jon, even when
  finding counts fall. P2/P3-only outcomes take the advisory landing path.
- Batch: file P3s and fix several in one candidate with one review. A P3 gets
  its own round only when it blocks a release.

At role, provider or route failure, follow `~/.agents/execution-policy.md`'s
**Route failures** and **Diagnose non-convergence** as applicable.
For normal landing refusal handling, follow [Landing](landing.md#landing)
and its `reviewed-main-workflow` procedure.
