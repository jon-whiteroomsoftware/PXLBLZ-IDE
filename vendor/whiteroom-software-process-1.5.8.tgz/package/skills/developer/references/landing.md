# Landing

When landing locally, follow `reviewed-main-workflow`'s **Land without
invalidating approval** for the `wrsp-land` procedure and refusal handling.
This section adds role policy and lander handoff.

- **Handing over to a lander.** When the project runs a 🛬 lander lane, hand
  over a candidate whose coverage ends clean (`review:status` reports
  `approved`) instead of landing it. Advisory coverage stays on your advisory
  path: land it yourself and fix the findings in a follow-up, or fix them
  first and hand over the clean tail. To hand over:
  - In one turn, send the lander
    `land request #<n> <base>..<tip> suites=<names> session=<id>`.
    `<base>` and `<tip>` are full 40-character SHAs; `<id>` is your CCR
    session id (`session_…`, from `get_session`), which the lander's
    `send_message` replies reach. The lander refuses any other form (#285).
  - Add the `ready-to-land` label to the issue and record the same line in
    its body through `issue-workflow`.
  - The candidate is the lander's once it replies `land accepted`. Until then
    it is still yours.
  - A `returned` reply hands it back, with the reason and the evidence.
  - More commits on an accepted candidate go as a new request for
    `<accepted-tip>..<new-tip>`. A `land refused #<n> stacked` reply means
    the train already holds it: send the follow-up after `landed`, rebased
    onto `main`.
- A worktree ends when its commit is reachable from shared `main`; remove it
  and its branch. A headless lane keeps its own lane worktree (the handle's
  `worktree`) until the lane retires; remove only disposable worker worktrees (#261).
