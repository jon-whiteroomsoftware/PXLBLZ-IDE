# Execution brief template

`launch-worker.sh` checks every confined execution launch's brief against this
template's seven slots (#426). Ordinary developer lanes use their issue's
detailed plan and the eng-lead lane-brief template instead.

The eval parent fills this template after settling the design. Replace every
answer below with the named artifacts; paste source the worker needs. Use
`none: <reason>` for an inapplicable answer. Keep the seven level-two headings.
The launcher checks answer presence outside fences, including every duplicate
section; artifact truth and completeness remain the eval parent's review.

## Source

Give the issue/spec URL and governing clause, the requested observable artifact
and path, and its expected behavior. Record the brief pointer in the issue body
through `issue-workflow` before launch; name that recorded pointer here.

## Worktree

Give the absolute checkout path, branch, verified HEAD, clean status or retained
paths, and shared hot-file ownership. Name the single commit subject. Bound the
work to 15–40 minutes and <=70% context; split larger work before launch.

## Changes

List every edited path:function and signature, input/output mapping, and ordered
implementation skeleton. Cite current behavior by file:line and give exact
refusal codes/messages where relevant. Paste required source and context here;
the worker cannot read a sibling brief folder, log or note through its path.

## Preservation

Cite the existing contract clauses and concrete outputs/objects that must stay
unchanged. Name what the eval parent will compare in the completed diff against
this brief; every departure is a finding.

## Tests

Give every test path/case, setup and exact expected assertion. Cite an existing
exemplar by file:line range and paste the helper signatures. Give red/green
commands and expected results. Full suites run on the Test Mini as
`node bin/wrsp-runner.mjs test <tip>` (consumer: `wrsp-runner test <tip>`);
targeted tests, lint, typecheck and build stay local.

## Proof

Name the consumer artifact/path or command, expected result, proof-log
destination, and required report end lines with commit and results. Assign
host-only checks to the eval parent once before commit.

## Limits

List off-limits paths, allowed commands and scope, authority and stop boundary.
Send unresolved questions to Jon before launch. Worker discretion stays local
to implementation; a wrong or incomplete brief yields one `BRIEF GAP:` line
naming the missing decision, then exit without edits.
