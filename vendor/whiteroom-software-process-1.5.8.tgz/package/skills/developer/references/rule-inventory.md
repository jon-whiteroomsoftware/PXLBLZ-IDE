# Rule inventory

Review evidence only; no operational read requirement.
Source: tracked developer skill at `71fdb2a207b98948db3dd33c66441f7c437979fc`.
Each row identifies an original paragraph or list/table item, including
delegated policy and provenance. Source headings are organization.

This is historical provenance, not current instructions. #441 supersedes the
source's execution-delegation rules: implementation and repair belong to the
developer; detailed test planning moves into the issue before code, after the
eng lead's assignment sketch. Builder duration/concurrency, interface-only edits,
execution briefs and correction relaunches are retired from normal issue work.
Historical rule names and the retained `builder-launch.md` filename below do
not reinstate them. Current duties live in [responsibilities](responsibilities.md),
[plan/proof and research launches](builder-launch.md), and
[candidate repairs](recovery.md#candidate-repairs).

| Immutable source | Rule identity | After location |
|---|---|---|
| [L1-L6](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L1-L6) | Frontmatter invocation trigger and minimum version | [../SKILL.md#developer](../SKILL.md#developer) |
| [L10-L12](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L10-L12) | Developer ownership, assigned loop and publication owner | [../SKILL.md#developer](../SKILL.md#developer) |
| [L13-L14](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L13-L14) | Review admission and publication routing | [review.md#review](review.md#review) |
| [L15-L19](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L15-L19) | Global rules and phase-conditioned dependency delegation | [../SKILL.md#developer](../SKILL.md#developer) |
| [L23-L23](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L23-L23) | Git and issue workflow entry conditions | [../SKILL.md#start](../SKILL.md#start) |
| [L25-L25](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L25-L25) | Lane input attribution and quoted human source | [../SKILL.md#start](../SKILL.md#start) |
| [L27-L27](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L27-L27) | Session telemetry declaration and authority limit | [../SKILL.md#start](../SKILL.md#start) |
| [L31-L31](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L31-L31) | Decision and execution ownership | [../SKILL.md#what-the-developer-does-and-what-it-hands-off](../SKILL.md#what-the-developer-does-and-what-it-hands-off) |
| [L33-L37](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L33-L37) | Semantic inputs, test design, proof and native review assembly | [../SKILL.md#what-the-developer-does-and-what-it-hands-off](../SKILL.md#what-the-developer-does-and-what-it-hands-off) |
| [L39-L39](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L39-L39) | Nondelegable developer responsibilities | [../SKILL.md#what-the-developer-does-and-what-it-hands-off](../SKILL.md#what-the-developer-does-and-what-it-hands-off) |
| [L41-L42](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L41-L42) | Spec and seam inspection | [../SKILL.md#what-the-developer-does-and-what-it-hands-off](../SKILL.md#what-the-developer-does-and-what-it-hands-off) |
| [L43-L44](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L43-L44) | Implementation design choices | [../SKILL.md#what-the-developer-does-and-what-it-hands-off](../SKILL.md#what-the-developer-does-and-what-it-hands-off) |
| [L45-L45](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L45-L45) | Brief design recording | [../SKILL.md#what-the-developer-does-and-what-it-hands-off](../SKILL.md#what-the-developer-does-and-what-it-hands-off) |
| [L46-L48](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L46-L48) | Interface-only source edit exception | [../SKILL.md#what-the-developer-does-and-what-it-hands-off](../SKILL.md#what-the-developer-does-and-what-it-hands-off) |
| [L49-L50](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L49-L50) | Diff check, review, landing and communication | [../SKILL.md#what-the-developer-does-and-what-it-hands-off](../SKILL.md#what-the-developer-does-and-what-it-hands-off) |
| [L52-L52](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L52-L52) | Delegated responsibilities | [../SKILL.md#what-the-developer-does-and-what-it-hands-off](../SKILL.md#what-the-developer-does-and-what-it-hands-off) |
| [L54-L55](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L54-L55) | Settled source implementation delegation | [../SKILL.md#what-the-developer-does-and-what-it-hands-off](../SKILL.md#what-the-developer-does-and-what-it-hands-off) |
| [L56-L59](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L56-L59) | Factual research and citation verification | [../SKILL.md#what-the-developer-does-and-what-it-hands-off](../SKILL.md#what-the-developer-does-and-what-it-hands-off) |
| [L60-L60](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L60-L60) | Mechanical bulk delegation | [../SKILL.md#what-the-developer-does-and-what-it-hands-off](../SKILL.md#what-the-developer-does-and-what-it-hands-off) |
| [L62-L66](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L62-L66) | Decision delegation boundary and wording check | [../SKILL.md#what-the-developer-does-and-what-it-hands-off](../SKILL.md#what-the-developer-does-and-what-it-hands-off) |
| [L68-L72](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L68-L72) | Mandatory research threshold and small-read exception | [../SKILL.md#what-the-developer-does-and-what-it-hands-off](../SKILL.md#what-the-developer-does-and-what-it-hands-off) |
| [L74-L75](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L74-L75) | Exhausted or restalled builder recovery order | [recovery.md#recovery](recovery.md#recovery) |
| [L77-L77](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L77-L77) | Narrowed relaunch | [recovery.md#recovery](recovery.md#recovery) |
| [L78-L78](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L78-L78) | Interface and body split | [recovery.md#recovery](recovery.md#recovery) |
| [L79-L79](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L79-L79) | Exhaustion escalation | [recovery.md#recovery](recovery.md#recovery) |
| [L81-L84](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L81-L84) | Self-implementation prohibition and single-family consequence | [recovery.md#recovery](recovery.md#recovery) |
| [L88-L89](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L88-L89) | One-commit brief sizing | [builder-launch.md#brief](builder-launch.md#brief) |
| [L91-L94](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L91-L94) | Explicit changed files and tests | [builder-launch.md#brief](builder-launch.md#brief) |
| [L95-L97](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L95-L97) | Sandbox-self-contained brief and provenance | [builder-launch.md#brief](builder-launch.md#brief) |
| [L98-L101](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L98-L101) | Builder duration target and measured reading cost | [builder-launch.md#brief](builder-launch.md#brief) |
| [L102-L104](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L102-L104) | Context budget and approval sizing | [builder-launch.md#brief](builder-launch.md#brief) |
| [L105-L107](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L105-L107) | Oversized brief split and interface order | [builder-launch.md#brief](builder-launch.md#brief) |
| [L108-L111](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L108-L111) | Execution and research stall thresholds | [builder-launch.md#brief](builder-launch.md#brief) |
| [L115-L117](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L115-L117) | Role resolution and exhaustion refusal | [builder-launch.md#launch](builder-launch.md#launch) |
| [L118-L119](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L118-L119) | Brief policy and issue pointer | [builder-launch.md#launch](builder-launch.md#launch) |
| [L120-L125](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L120-L125) | Launcher refusals, attribution, detach and wait protocol | [builder-launch.md#launch](builder-launch.md#launch) |
| [L127-L131](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L127-L131) | Complete launch command syntax | [builder-launch.md#launch](builder-launch.md#launch) |
| [L133-L135](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L133-L135) | Standing concurrency and human opt-in provenance | [builder-launch.md#launch](builder-launch.md#launch) |
| [L136-L136](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L136-L136) | Harness-specific researcher routes | [builder-launch.md#launch](builder-launch.md#launch) |
| [L137-L137](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L137-L137) | Locator routes, arguments, output and partial retry | [builder-launch.md#launch](builder-launch.md#launch) |
| [L139-L139](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L139-L139) | Review selection policy continuity | [review.md#review](review.md#review) |
| [L141-L142](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L141-L142) | Reviewer role order, family and native provenance | [review.md#review](review.md#review) |
| [L143-L145](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L143-L145) | Candidate-scoped same-family direction and flags | [review.md#review](review.md#review) |
| [L146-L149](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L146-L149) | Mixed-family capability and carry-only exception | [review.md#review](review.md#review) |
| [L150-L155](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L150-L155) | Operator authorization delegation and production admission limit | [review.md#review](review.md#review) |
| [L156-L157](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L156-L157) | Planning model and separate authorization | [review.md#review](review.md#review) |
| [L158-L159](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L158-L159) | Dual-model pairing and execution authority limit | [review.md#review](review.md#review) |
| [L163-L163](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L163-L163) | Exact-PID stop safety and incident provenance | [builder-launch.md#supervise](builder-launch.md#supervise) |
| [L164-L165](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L164-L165) | Live-log and sleep restrictions | [builder-launch.md#supervise](builder-launch.md#supervise) |
| [L166-L171](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L166-L171) | Background wake, handle and post-exit collection | [builder-launch.md#supervise](builder-launch.md#supervise) |
| [L172-L181](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L172-L181) | Product signals, deadlines, silent commands and polling | [builder-launch.md#supervise](builder-launch.md#supervise) |
| [L182-L189](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L182-L189) | Reportable exits, stall limits and provider availability qualification | [builder-launch.md#supervise](builder-launch.md#supervise) |
| [L190-L190](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L190-L190) | Process-table liveness oracle | [builder-launch.md#supervise](builder-launch.md#supervise) |
| [L191-L192](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L191-L192) | Review worktree immutability | [review.md#review](review.md#review) |
| [L193-L197](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L193-L197) | Unchanged staged handoff, hooks and builder attribution | [recovery.md#recovery](recovery.md#recovery) |
| [L198-L199](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L198-L199) | Brief-gap correction and relaunch | [recovery.md#recovery](recovery.md#recovery) |
| [L200-L201](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L200-L201) | Task naming and allocated port | [builder-launch.md#supervise](builder-launch.md#supervise) |
| [L205-L207](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L205-L207) | Local landing and refusal procedure delegation | [landing.md#landing](landing.md#landing) |
| [L209-L213](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L209-L213) | Lander admission and advisory path | [landing.md#landing](landing.md#landing) |
| [L214-L218](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L214-L218) | Exact land-request protocol and reply handle | [landing.md#landing](landing.md#landing) |
| [L219-L220](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L219-L220) | Ready label and issue-body request | [landing.md#landing](landing.md#landing) |
| [L221-L222](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L221-L222) | Accepted-candidate ownership transition | [landing.md#landing](landing.md#landing) |
| [L223-L223](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L223-L223) | Returned-candidate ownership and evidence | [landing.md#landing](landing.md#landing) |
| [L224-L227](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L224-L227) | Accepted-candidate follow-up and stacked refusal | [landing.md#landing](landing.md#landing) |
| [L228-L230](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L228-L230) | Freshness, admission and conflict-slot delegation | [review.md#review](review.md#review) |
| [L231-L234](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L231-L234) | Hot-file ownership coordination | [builder-launch.md#brief](builder-launch.md#brief) |
| [L236-L237](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L236-L237) | Lander policy delegation | [builder-launch.md#brief](builder-launch.md#brief) |
| [L238-L239](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L238-L239) | Repair authority under failed checks | [recovery.md#recovery](recovery.md#recovery) |
| [L240-L243](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L240-L243) | Five-round cap and escalation | [recovery.md#recovery](recovery.md#recovery) |
| [L244-L246](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L244-L246) | P0/P1 lineage breaker and advisory exception | [recovery.md#recovery](recovery.md#recovery) |
| [L247-L248](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L247-L248) | P3 batching and release exception | [recovery.md#recovery](recovery.md#recovery) |
| [L249-L251](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L249-L251) | Proportional and host proof ownership | [builder-launch.md#brief](builder-launch.md#brief) |
| [L252-L255](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L252-L255) | Remote full-suite requirement and local-check exception | [builder-launch.md#brief](builder-launch.md#brief) |
| [L256-L258](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L256-L258) | Frozen-tip suite ownership and repair-suite permission | [review.md#review](review.md#review) |
| [L259-L262](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L259-L262) | Implementation authority through local landing; no developer push | [../SKILL.md#developer](../SKILL.md#developer) |
| [L263-L265](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L263-L265) | Completion labels, attribution, proposed type and close proof | [handoff.md#handoff](handoff.md#handoff) |
| [L266-L266](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L266-L266) | Review issue attribution flag | [review.md#review](review.md#review) |
| [L270-L271](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L270-L271) | Eng-lead operations ownership | [handoff.md#handoff](handoff.md#handoff) |
| [L275-L275](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L275-L275) | Session icon table columns | [handoff.md#session-name](handoff.md#session-name) |
| [L277-L277](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L277-L277) | Eng-lead icon | [handoff.md#session-name](handoff.md#session-name) |
| [L278-L278](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L278-L278) | Developer icon | [handoff.md#session-name](handoff.md#session-name) |
| [L279-L279](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L279-L279) | Builder icon | [handoff.md#session-name](handoff.md#session-name) |
| [L280-L280](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L280-L280) | Reviewer icon | [handoff.md#session-name](handoff.md#session-name) |
| [L281-L281](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L281-L281) | Researcher icon | [handoff.md#session-name](handoff.md#session-name) |
| [L282-L282](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L282-L282) | Locator icon | [handoff.md#session-name](handoff.md#session-name) |
| [L283-L283](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L283-L283) | Lander icon | [handoff.md#session-name](handoff.md#session-name) |
| [L284-L284](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L284-L284) | UX principal icon | [handoff.md#session-name](handoff.md#session-name) |
| [L285-L285](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L285-L285) | Principal engineer icon | [handoff.md#session-name](handoff.md#session-name) |
| [L286-L286](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L286-L286) | Batch icon | [handoff.md#session-name](handoff.md#session-name) |
| [L287-L287](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L287-L287) | Done icon and replacement semantics | [handoff.md#session-name](handoff.md#session-name) |
| [L289-L292](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L289-L292) | Icon dates, human sources and issue provenance | [handoff.md#session-name](handoff.md#session-name) |
| [L294-L297](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L294-L297) | Session-name syntax and examples | [handoff.md#session-name](handoff.md#session-name) |
| [L298-L299](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L298-L299) | Rename triggers, completion and promotion | [handoff.md#session-name](handoff.md#session-name) |
| [L300-L300](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L300-L300) | Direct-instruction source policy delegation | [../SKILL.md#session-obligations](../SKILL.md#session-obligations) |
| [L301-L303](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L301-L303) | File sharing and Files-link fallback | [../SKILL.md#session-obligations](../SKILL.md#session-obligations) |
| [L304-L305](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L304-L305) | Startup self-test and authentication delegation | [../SKILL.md#session-obligations](../SKILL.md#session-obligations) |
| [L306-L308](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L306-L308) | Issue claim timing and lane brief responsibility | [../SKILL.md#session-obligations](../SKILL.md#session-obligations) |
| [L309-L310](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L309-L310) | Laptop peer-message limit and alternate recipient | [../SKILL.md#session-obligations](../SKILL.md#session-obligations) |
| [L311-L313](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L311-L313) | Rich specs and controlled-domain invariants | [../SKILL.md#session-obligations](../SKILL.md#session-obligations) |
| [L314-L316](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L314-L316) | Worktree lifecycle and headless-lane exception | [landing.md#landing](landing.md#landing) |
| [L317-L318](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L317-L318) | Boundary issue-body handoff updates | [handoff.md#handoff](handoff.md#handoff) |
| [L319-L322](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L319-L322) | Context budget, unknowns and handoff threshold | [../SKILL.md#session-obligations](../SKILL.md#session-obligations) |
| [L322-L324](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L322-L324) | Atomic finish, exact state, live handles, pickup and successor acknowledgment | [handoff.md#handoff](handoff.md#handoff) |
| [L328-L330](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L328-L330) | Issue-folder identity and current top level | [handoff.md#issue-files](handoff.md#issue-files) |
| [L332-L333](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L332-L333) | Superseded deliverable history and HTML assets | [handoff.md#issue-files](handoff.md#issue-files) |
| [L334-L334](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L334-L334) | Working logs and sidecars | [handoff.md#issue-files](handoff.md#issue-files) |
| [L335-L335](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L335-L335) | Subfolder limit | [handoff.md#issue-files](handoff.md#issue-files) |
| [L336-L337](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L336-L337) | Files-page link requirement | [handoff.md#issue-files](handoff.md#issue-files) |
| [L339-L340](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/71fdb2a207b98948db3dd33c66441f7c437979fc/skills/developer/SKILL.md#L339-L340) | Layout checker output contract | [handoff.md#issue-files](handoff.md#issue-files) |

## New routing and organization

| Source | Identity | After location |
|---|---|---|
| [#413](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/issues/413) | Mandatory phase reads | [Phase reads](../SKILL.md#phase-reads) |
| [#413 native review correction](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/issues/413) | Complete handoff/check-in routing: push, landed batch, decision, check-in, setup or role transition, wrap-up or handoff | [Phase reads](../SKILL.md#phase-reads), [Handoff](handoff.md#handoff) |
| [#413](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/issues/413) | Phase-conditioned dependency routing | [Developer](../SKILL.md#developer), [Review](review.md#review) |
| [#413](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/issues/413) | Lean current issue and successor pickup | [Handoff](handoff.md#handoff) |
| [#413](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/issues/413) | Failure policy pointers | [Recovery](recovery.md#recovery) |
| [#416](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/issues/416) | Retired by #441: fresh builder correction/continuation routing | [Authoritative rule](recovery.md#candidate-repairs), [Builder launch pointer](builder-launch.md#supervise), Builder pointer (skill removed by #441) |
| [#429](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/issues/429) | Repair family, split-review reason and developer-owned host proof; delegation retired by #441 | [Authoritative rule](recovery.md#candidate-repairs) |

## Text size evidence

Pre-#441 snapshot at `f3091532`; these counts describe that version, not the
current operational text.

Reproduce whitespace counts with `git show 71fdb2a207b98948db3dd33c66441f7c437979fc:skills/developer/SKILL.md | wc -w`
and `wc -w skills/developer/SKILL.md skills/developer/references/{builder-launch,review,landing,handoff,recovery}.md`.
Inventory is excluded from the operational total.

| Document | Whitespace words |
|---|---:|
| Source | 3005 |
| SKILL.md | 589 |
| references/builder-launch.md | 1108 |
| references/review.md | 296 |
| references/landing.md | 246 |
| references/handoff.md | 382 |
| references/recovery.md | 410 |
| Operational total | 3031 |

First-invocation core reduction: 80.4%.
This is a text-size measure, not measured lifetime reduction or criterion-1 success.

## Startup card preservation (#472)

Review evidence only; no operational read requirement. Source locations below
refer to `skills/developer/SKILL.md` at
`1f3e9680321230c763745a292819512b300aa623`, unless a reference is named.
Each original rule and read trigger has a destination; later-phase material
remains mandatory when that phase begins. Pickup reaches exact sections rather
than whole references. This table measures text/routing, not post-deployment
startup tokens.

| Source lines | Rule or trigger | Current location / phase |
|---|---|---|
| 10–11 | One assigned issue; design through landing; publication ownership | [Developer](../SKILL.md#developer) |
| 13–16 | Implement authority covers commit, cross-family review, repair and local fast-forward landing without repeated permission; publication request | [Review and completion](responsibilities.md#review-and-completion), before diff/review/landing or issue/doc work |
| 18–21 | Shared rules, issue state, must-test cases, role and test-planning policy | [Developer](../SKILL.md#developer), [Start](../SKILL.md#start), [Duties](../SKILL.md#what-the-developer-does-and-what-it-hands-off) |
| 22–23 | Candidate/landing workflow and native review-input procedures | [Phase reads](../SKILL.md#phase-reads), Review and Landing entries |
| 27 | Git before first commit; issue workflow before issue writes | [Start](../SKILL.md#start), ordered steps 2 and 4 |
| 29 | Lane input belongs to eng lead; Jon quoted with source | [Start](../SKILL.md#start), step 2 |
| 31 | First telemetry declaration from checkout; assigned issue/none; no authority granted | [Start](../SKILL.md#start), step 1 |
| 35–38 | Own decisions, implementation/tests at current effort; oracle/test sketch expanded before code, including cases, partitions, setup/assertions, preservation and proof | [Duties](../SKILL.md#what-the-developer-does-and-what-it-hands-off) |
| 40–43 | Duty links reach design or completion responsibilities | [Phase reads](../SKILL.md#phase-reads), Seam/design and Diff/completion entries |
| 45–50 | Developer semantic inputs: requirements/source, test invariants, partitions, sequences, oracles, gaps and proof; native assembly/refusal ownership; reviewer judgment | [Review](review.md#review); compact pointer remains in [Duties](../SKILL.md#what-the-developer-does-and-what-it-hands-off) |
| 52–56 | Mandatory researcher above two-search/one-known-file-or-range threshold; report-only read and citation check; small reads stay local | [Duties](../SKILL.md#what-the-developer-does-and-what-it-hands-off), before fact-gathering |
| 60–61 | Design responsibilities before seam reads, design, spec or test plan | [Phase reads](../SKILL.md#phase-reads), Seam/design entry |
| 62 | Plan/proof before implementation | [Phase reads](../SKILL.md#phase-reads), Implementation entry |
| 63–65 | Brief and launch before research/locator execution; supervision procedure while supervising | [Phase reads](../SKILL.md#phase-reads), Research/locator and Supervision entries |
| 66–68 | Own diff check, review, landing, Jon conversation and issue/doc writing | [Review and completion](responsibilities.md#review-and-completion), routed by [Phase reads](../SKILL.md#phase-reads) |
| 69 | Review procedure before review | [Review](review.md#review), routed by [Phase reads](../SKILL.md#phase-reads) |
| 70 | Landing procedure before landing | [Landing](landing.md#landing), routed by [Phase reads](../SKILL.md#phase-reads) |
| 71–73 | Push, landed batch, decision, check-in, setup and role-transition routing; wrap-up/handoff and artifact duties | [State updates](handoff.md#state-updates), [Handoff](handoff.md#handoff), [Issue files](handoff.md#issue-files), separate triggers in [Phase reads](../SKILL.md#phase-reads) |
| 74–75 | Recovery on refusal, stalled/unavailable/exhausted role or findings | [Recovery](recovery.md#recovery), routed by [Phase reads](../SKILL.md#phase-reads) |
| 76–77 | Exact session-name section at assignment, changed work, successor pickup, completion or promotion | [Session name](handoff.md#session-name), routed by [Phase reads](../SKILL.md#phase-reads) |
| 78–79 | Communication/files before messaging or sharing | [Communication and files](responsibilities.md#communication-and-files), routed by [Phase reads](../SKILL.md#phase-reads) |
| 83–85 | Direct instructions/source, startup self-test and GitHub auth/claims through issue workflow | [Start](../SKILL.md#start), step 2 |
| 86–88 | Claim before implementation; lane handoff names claim step | [Start](../SKILL.md#start), step 2 |
| 89–92 | Installed context budget; checks before work/check-ins; unknown stays unknown, alone no checkpoint; handoff by 80% or sooner | [Session obligations](../SKILL.md#session-obligations); handoff reference loads at that trigger |
| handoff.md 3–9 | Wrap-up proof/labels/attribution unchanged; push/batch/decision body updates and eng-lead check-in/setup/role-transition ownership separated from handoff | [Handoff](handoff.md#handoff), [State updates](handoff.md#state-updates) |
| review.md 7–8 | Developer ownership pointer replaced by original complete semantic-input rule | [Review](review.md#review) |
