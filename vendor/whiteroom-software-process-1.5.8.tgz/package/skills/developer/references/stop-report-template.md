# Stop/trial report template

The reporting writer replaces these six answers with artifacts and exact state.
Use `none: <reason>` for an inapplicable field. Keep verified and unproved
results distinct; the recipient receives the filled report.

## Result

Give the status and result artifact/path or URL.

## Trigger

Give the exact complete command, cwd, job/session id, exit code and exact
failure/end line.

## Evidence

Give the proof URL with line/case references, expected versus actual result,
and what is verified or still unproved.

## Retained state

Give the checkout, base/tip, staged paths and every live handle/pid.

## Next action

Give the specific next command or decision and its owner.

## Authority

Give the issue/go/stop boundary and, for trials, spent and remaining budget.
