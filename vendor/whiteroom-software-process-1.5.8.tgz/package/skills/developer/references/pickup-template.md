# Pickup template

The outgoing writer replaces these six answers with exact state and artifacts.
Use `none: <reason>` for an inapplicable field. Give the successor only the
filled pickup, self-contained and <=800 words, within the current issue body's
<=800-word target. Replace prior pickups and link superseded history; preserve
scope, criteria and source. Read exact references at their phase (#413).

## Issue

Give the issue URL and spec/source links governing the remaining scope.

## Checkout

Give the absolute worktree, branch, base/tip and all retained paths, including
staged changes.

## Evidence

Give the commit range, test results/job ids, receipt and proof URLs. Separate
verified results from pending checks.

## Live jobs

Give each live handle/pid, expected finish and product signal, or a reason none
remain.

## Next action

Give one exact next command or artifact, its owner and the references to read
at that phase.

## Stop conditions

Give the named decision or exact refusal line that halts work, the authority
boundary and remaining scope. Obtain the successor's acknowledgment before
retirement.
