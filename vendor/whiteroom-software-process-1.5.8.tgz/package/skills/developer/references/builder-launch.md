# Plan, proof and research launches

## Brief

Before code, record the detailed issue plan from
[Design and briefs](responsibilities.md#design-and-briefs). Size each slice for
about 70% context and approval within the round limit. Each part lands on its
own: interface, bodies, then callers when that split is needed.

Research and bulk requests produce reports, not edits; their stall signal is
ten minutes without log growth. A research request asks factual questions and
supplies the context needed for cited answers.

- **Hot files.** Your lane brief names the shared hot files your lane owns. Before
  changing a hot file another lane owns, coordinate with that owner through
  the eng lead, which may connect you directly, or wait (landing-queue, Hot
  files).

  The landing queue's Lander section has the rules
  (`~/.agents/skills/eng-lead/references/landing-queue.md`).

- Proportional proof: revert proof plus lint, typecheck and build for gate or
  CLI behaviour changes; the affected test file for doc and text changes.
  Host-side checks are the developer's, once, before commit.
- Every full suite runs on the Test Mini as `node bin/wrsp-runner.mjs test <tip>`
  (consumers: `wrsp-runner test <tip>`), never as a local `npm test` or
  `vitest run`; on Agent Mini those refuse (#256). Lint, typecheck, build and
  targeted test files stay local. Briefs say the same.

## Launch

1. Resolve role and pair through the execution policy: role or function
   word -> role id -> exact model/effort. Unknown word: ask. Exhausted role:
   stop; never fall through.
2. Write the factual request and record its pointer
   in the issue body through `issue-workflow`.
3. Codex research uses `scripts/launch-worker.sh --research --role-id researcher`.
   It refuses a model/effort pair outside the named role, a worktree with a
   missing configured hooks directory (exit 66), or a missing `--issue <N>`.
   It records the launch and snapshots the issue (#196). Launch with `--detach`;
   it returns a handle once the researcher has started and refuses with exit 69
   when it does not start (#228). In
   Codex, run the launch as an escalated command. Then wait with
   `wrsp-wait <handle>` and call it
   again on `WORKER RUNNING`. The same two commands serve Claude and Codex.

   ```bash
   ~/.agents/skills/developer/scripts/launch-worker.sh --cli codex \
     --research --role-id researcher --issue <N> --model <role-member> --effort <effort> \
     --worktree <dir> --brief <file> --log <file> --detach
   ```

4. Standing concurrency, without asking: up to 2 researchers at once
   (Jon, 2026-09-23). More needs Jon's opt-in,
   with the count and budget stated.
5. Research goes to the native `researcher` agent in Claude. Other native Claude Agent|Task launches are hook-refused. In Codex, research uses `launch-worker.sh --research --role-id researcher --detach`.
6. A "where is X / who calls Y / which file defines Z" question goes to a locator in either harness: `launch-worker.sh --locate --role-id locator --cli claude --model claude-haiku-5-5 --effort med` (or `--cli codex --model gpt-6-luna --effort high`), with the question as `--brief`, the repository as `--worktree`, a `--log`, and `--issue <n>` so the run is attributed to that issue as role locator (#240). It runs synchronously and prints `REPOSITORY/REVISION/DIRTY` and the answer: a status, the scope searched and at most ten `path:start-end` hits. `PARTIAL` means narrow the question and launch again. "How does X work" stays with the researcher.

## Supervise

- Stop a process only by its exact PID, after checking it with `ps -p <pid>`. Never use `pkill`, `killall`, `kill $(pgrep …)` or `pgrep … | xargs kill`: on 2026-10-19 a misordered `pkill -f` killed five agent sessions.
- Never read a running research worker's log or output file, and never loop on `sleep`:
  `wrsp-wait.sh` is the only wait. Each peek re-reads the whole session context.
- Never wait on a task notification alone: one can be lost (#245). Before
  ending a turn while your own background job is alive, record its pid or log
  handle and its expected finish, and schedule a wake shortly after that
  (`send_later` in Claude remote, `CronCreate` in Claude local). Each later turn
  checks the job once, with `ps -p`, its `.exit` marker, or
  `wrsp-wait.sh <log> --max 0`. Read the log tail only after exit.
- Every background start names its product signal before it starts and is
  checked within 60 s: the launcher's `PRODUCING:` line for a research worker, a
  growing log for a suite or review, `wrsp-telemetry.sh verify` after a
  `launchctl` load or restart. Missing or empty output at that check is a
  failed start. A command that prints nothing until it exits (`tsc`,
  `npm run build`) has no product signal; a live pid stands in for one only
  up to a stated expected duration or the brief's cap, and passing that cap
  is a failure, never more waiting. For an ad-hoc wait on a condition, use
  `wrsp-poll`
  ([job-liveness](../../../docs/reference/contracts/job-liveness.md)).
- Report on four events only: exit, a `BRIEF GAP:` line, `WORKER NOT
  PRODUCING` (`wrsp-wait.sh` exit 8) and `WORKER STALLED` (exit 3: the
  session record unchanged for `--stall` seconds, default 600). Exits 8
  and 3 are failures to act on, never states to wait out. Exit 10 is provider
  availability: inspect retained worktree changes before relaunch; relaunch
  only by developer selection under the existing execution policy. See
  [job-liveness](../../../docs/reference/contracts/job-liveness.md#provider-availability-outcomes-332)
  for the outcome and wait contract.
- Liveness comes from the process table, never from the log's last line.
- Task names: `#<issue> <short task> [<actual port>]`; omit the port when
  none is allocated.

For other failures, read [Recovery](recovery.md#recovery).
