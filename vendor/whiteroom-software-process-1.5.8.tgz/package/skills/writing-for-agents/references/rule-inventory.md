# Rule inventory

Review evidence only; no operational read requirement.
Source: tracked skill mechanics at `cfb4681ab6d102be917f157b11873f393c2d107f`.
Each row identifies an original paragraph or list item, including all
qualifications and delegated policy. Source headings are organization.
This inventory is new review evidence, with no original normative rules of
its own to relocate. The new terseness section is identified separately below.

| Immutable source | Rule identity | After location |
|---|---|---|
| [L3-L3](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/cfb4681ab6d102be917f157b11873f393c2d107f/skills/writing-for-agents/SKILL-MECHANICS.md#L3-L3) | Skill-specific scope: frontmatter, invocation choice and routers; universal writing reference delegated to `SKILL.md` | [../SKILL-MECHANICS.md#skill-mechanics](../SKILL-MECHANICS.md#skill-mechanics) |
| [L9-L9](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/cfb4681ab6d102be917f157b11873f393c2d107f/skills/writing-for-agents/SKILL-MECHANICS.md#L9-L9) | Model invocation permits autonomous and cross-skill reach while retaining human invocation; the always-loaded description trades permanent context load for discovery; an all-reference skill can house shared reference | [../SKILL-MECHANICS.md#invocation](../SKILL-MECHANICS.md#invocation) |
| [L9-L9](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/cfb4681ab6d102be917f157b11873f393c2d107f/skills/writing-for-agents/SKILL-MECHANICS.md#L9-L9) | Model invocation omits `disable-model-invocation` and uses a model-facing description with trigger branches; root `SKILL.md` pointer-writing rules apply in full | [../SKILL-MECHANICS.md#invocation](../SKILL-MECHANICS.md#invocation) |
| [L10-L10](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/cfb4681ab6d102be917f157b11873f393c2d107f/skills/writing-for-agents/SKILL-MECHANICS.md#L10-L10) | User invocation requires the human to type the name; other skills cannot invoke it; zero context load trades for human indexing; set `disable-model-invocation: true` and a human-facing one-line description with trigger lists stripped | [../SKILL-MECHANICS.md#invocation](../SKILL-MECHANICS.md#invocation) |
| [L12-L12](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/cfb4681ab6d102be917f157b11873f393c2d107f/skills/writing-for-agents/SKILL-MECHANICS.md#L12-L12) | Autonomous or other-skill need admits model invocation; hand-only use is user-invoked with no context load | [../SKILL-MECHANICS.md#invocation](../SKILL-MECHANICS.md#invocation) |
| [L14-L14](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/cfb4681ab6d102be917f157b11873f393c2d107f/skills/writing-for-agents/SKILL-MECHANICS.md#L14-L14) | Two user-invoked skills cannot fire each other without descriptions; shared reference lives outside the skill system in a plain file either can point at | [../SKILL-MECHANICS.md#invocation](../SKILL-MECHANICS.md#invocation) |
| [L18-L18](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/cfb4681ab6d102be917f157b11873f393c2d107f/skills/writing-for-agents/SKILL-MECHANICS.md#L18-L18) | Split for a distinct leading word actually used in prompts or another skill's need; independent reach must justify the always-loaded description cost; sequence splitting remains in root `SKILL.md` | [../SKILL-MECHANICS.md#splitting-by-invocation](../SKILL-MECHANICS.md#splitting-by-invocation) |
| [L22-L22](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/cfb4681ab6d102be917f157b11873f393c2d107f/skills/writing-for-agents/SKILL-MECHANICS.md#L22-L22) | Excessive human indexing warrants one user-invoked router naming other skills and when to reach them; it only hints, never invokes, because only humans can reach skills without descriptions | [../SKILL-MECHANICS.md#router-skills](../SKILL-MECHANICS.md#router-skills) |

## New instruction

| Source | Rule identity | After location |
|---|---|---|
| [Jon's #413 comment 6429891996](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/issues/413#issuecomment-6429891996), eng-lead conversation, 2026-10-26: "Yes, definitely add a terseness instruction for skills" | Terse operational skill wording retains trigger, action, conditions, exceptions and completion criterion; rationale and examples resolve execution ambiguity; context pointers disclose branch detail; every edit prunes repetition and filler while preserving every normative qualification | [../SKILL-MECHANICS.md#terseness](../SKILL-MECHANICS.md#terseness) |
