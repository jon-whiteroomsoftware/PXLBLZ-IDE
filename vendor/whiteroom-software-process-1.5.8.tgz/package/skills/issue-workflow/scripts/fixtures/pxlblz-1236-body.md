## Parent

Epic #1235. Spec: **#1229 → Spec: slow-mo lab v1**. Read the whole section, plus Jon's decisions in #1229's comments, before claiming. Record the #1229 body revision you read in your claim.

## What to build

Slice A of the spec, roadmap item 1:

- **Preview transform hook.** `Preview.tsx:176` calls `bundleWithPasses(previewSource, libraries, previewRecipe)`. The recipe is empty unless `slowMoEnabled()` is true and the lab needs the wrapper.
- **`slowmo` pass.** Lives in `src/engine/slowMo.ts`, dispatched from `passEngine.ts`. It provides:
  - the fixed-step clock: default `stepMs` 16; lab stops 16 and 32;
  - the overflow-free `time()` redirect, with T wrapping at 2^14;
  - scope-aware RGB capture of `rgb`/`hsv`/`hsv24`;
  - the two-frame A/B blend with the `hold`, `blend` and `eased` curves;
  - the catch-up cap of 4;
  - the `declined` summary and every refusal reason (palette Patterns refused, per Jon);
  - tunables appended to `metadata.runtimeVars`.
- **`clock` baseline.** Today's Speed path: `getSpeed` = speed × rate, with no wrapper.
- **Session-only `slowMo` state** in `previewStore`, and the `?slowmo=1` flag in `src/dev/slowMoFlag.ts`.
- **`SlowMoLab.tsx` panel** in `PreviewDeck`: Tempo and In-between groups, refusal reason, array words, Copy generated code. Live tunables go through `setRuntimeVar`; a structural change rebuilds. No mock-up (Jon, 2026-10-27).
- **`scripts/render-pattern.ts`:** `--slowmo '<json>'` and `--fidelity fast|precise`.
- **Fixture:** a committed per-frame sparkle Pattern (one `random()` pixel per frame, per-frame fade, no `delta`).

The wrapper skeleton, contract points, refusal table and file/function list are in the spec. Leave stagger hooks as `width = 0` and persistence absent; slices B (stagger) and C (persistence) add them.

## Limits

- The spec's Limits apply: preview only, Patterns only, slow only. The push path, Shows and the Show compiler stay untouched.
- No product presentation and no Feature Guide entry.
- A deviation from the spec needs Jon's yes first.

## Acceptance criteria

- [ ] Without `?slowmo=1`, preview `code`/`fxCode` are byte-identical to `bundle()` for every stock Pattern, and no panel shows.
- [ ] With the flag, `clock`, `hold`, `blend` and `eased` run at every rate stop in Fast and Precise. Changing rate, step or curve among `hold`/`blend`/`eased` does not restart the Pattern.
- [ ] Every refusal reason shows in the lab while the unwrapped Pattern keeps running. Only the four palette stock Patterns decline.
- [ ] Copy generated code yields the exact `code` the preview runs, with the current tunables written in as initializers.

## Required proof

- **Browser proof** (UI proof gate) at `http://Agent-Mini.local:5174/PXLBLZ-IDE/?slowmo=1`:
  - the panel at desktop and narrow width;
  - a palette-Pattern refusal;
  - the route without the flag;
  - no console errors.
- **Comparison renders** (`npm run render -- --fps 60 --fidelity precise --slowmo …`, 16×16 map):
  - KaleidoBloom, WavyBands and the sparkle fixture;
  - full speed, plus 1/4 and 1/16 under `clock`, `hold`, `blend` and `eased`.
- **Matrix side by side.** Jon pastes Copy generated code for the sparkle fixture and KaleidoBloom (1/4 and 1/16 `blend`) onto the 16×16 matrix at desk brightness. Record:
  - that it compiles and runs (1,560 array words);
  - device FPS wrapped vs unwrapped;
  - whether low-brightness fades step;
  - Jon's verdict, verbatim, in #1229.

## Tests

**L2 Lab A qualification:** boundary is the loaded Pattern editor and copied Pixelblaze artifact. Partitions: flag absent/present; Off/Clock/Hold/Blend/Eased; Fast/Precise; live rates and 16/32 ms; accepted stock/palette refusal; desktop 1440 and narrow 900; keyboard option activation and clipboard copy. Preserve complete stock baseline artifacts without the flag, runtime continuity for live values, session-only state, I17 push isolation and refusal identity. Existing lifecycle sequences cover stop/resume, source and map changes; hardware/UX verdicts remain separate. [Review semantics and residual gaps](http://Agent-Mini.local:8642/files/pxlblz-briefs/1235-slowmo/work/l2-lab-a-test-design.json). At standalone code tip `c61f75da`, TypeScript and 1,047 focused tests in 13 files PASS. Fresh Playwright route checks PASS (keyboard 1/4, 32 ms, Blend/Eased/Blend, Precise, actual clipboard, narrow fit, refusal, no flag, zero errors); all five lifecycle Playwright cases PASS in Fast/Precise. Fresh records and captures are committed at `e9a813ff57d057c433a6ae4acc7bde24967c8efc`; lint and proof-commit hooks PASS. Clean cross-family review approved the exact tip; L3 collected all seven final-tip runner suites PASS and landed it. Proof: [Lab A landing evidence](http://Agent-Mini.local:8642/files/pxlblz-briefs/1235-slowmo/l3-lab-a-landed.md).

**L1 rebase/landing proof plan (pending):** preserve the existing generated-artifact RGB/time oracles in Fast and Precise for clock/hold/blend/eased, live rate, stagger width 0/boundaries, persistence off/on and bypass entry/exit. Recheck refusal byte identity, stock Off identity without the flag and I17 push isolation. Each prefix must typecheck and pass its focused suites on its own. UI prefixes require a fresh committed route capture at the rebased code tip, including the named desktop/narrow, refusal, keyboard/live-control and no-console-error cases. One exact-tip `npx wrsp-runner test <tip>` supplies required full-suite evidence before each landing. An e2e-shows recurrence at `shows.auth.spec.ts:2730` stops L1 with its job ID (#1209). Existing qualification is historical until rerun; hardware/Jon verdict stays with the eng lead.

The floor is #1229 Tests I1–I7 and I10–I18, minus the stagger and persistence parts. Oracle surface: wrapped-artifact pixels through `createFastReplayRuntime` in Fast and Precise. I18 is Playwright (`e2e/slowmo.spec.ts`).

## Docs impact

- Technical Reference §6 (the `slowmo` pass, the `declined` summary, the clock contract; marked lab).
- Technical Reference §9 (the preview recipe hook, `getSpeed` composition).
- Technical Reference §31 (nominal per-frame pace, clock-wrap disclosure).
- Device behaviour notes only if the matrix shows a surprise.

## Progress

- **L5 Lab B landed, 2026-10-30:** clean local main `e95b8e361ba8945b3eeb700f3d27957afdcbdcd8`; current-main coverage approved, clean Opus 5.5/high receipt, no findings. Resumed all seven original runner jobs and collected PASS; exact-tip evidence gate PASS; collector session `67294` exited 0. No #1209 recurrence or source repairs. Proof: [Lab B landing, changed files, receipt and seven job IDs](http://Agent-Mini.local:8642/files/pxlblz-briefs/1235-slowmo/l5-lab-b-landed.md). Preview `1236:5176` stays up. Lab C and Knob remain; #1246 stays separate. Older lane records below are historical.

- **L3 Lab A landed / handoff, 2026-10-30:** main `e9a813ff57d057c433a6ae4acc7bde24967c8efc`, clean after `wrsp-land`; approved coverage from `3270d3c6`, no findings. All seven runner suites PASS from one submission; exact-tip evidence gate PASS. Vitest 14,292 passed / 57 skipped; auth/public/Shows/MCP counts 46/28/111/4/4/3, no retries or #1209 recurrence. [Landing record, receipt, jobs and changed files](http://Agent-Mini.local:8642/files/pxlblz-briefs/1235-slowmo/l3-lab-a-landed.md). [Canonical L3 pickup](http://Agent-Mini.local:8642/files/pxlblz-briefs/1235-slowmo/handoff-l3.md). No source repairs or additional candidate started; no live collectors. Next owner restacks Lab B/C/Knob; preview 5176 stays up. Prior L2/L1 records below are historical.

- **L2 handoff, 2026-10-30; successor ACK pending:** harness reported 177k/220k (80%), above the requested 65% point. [Canonical pickup](http://Agent-Mini.local:8642/files/pxlblz-briefs/1235-slowmo/handoff-l2.md). Engine is landed on clean main `3270d3c6`. Lab A is frozen at `e9a813ff57d057c433a6ae4acc7bde24967c8efc` on `issue-1236-lab-a-candidate` in the runtime-owning full-ladder worktree. TypeScript, 1,047 focused tests, five lifecycle Playwright cases, fresh UI proof and hooks PASS. Native Opus 5.5/high review is clean; `review:status` is **approved**. No Lab A runner campaign submitted and no live local jobs remain. Next owner submits its seven suites once, checks coverage and lands, then restacks the remaining 12 commits from the full ladder branch `524b83ae`. Runtime 1236:5176 remains up, serving Lab A; U2 #1246 stays separate and follows Knob. L2 hands the claim back; no source repairs, push, Controller contact or closure.

- **L2 Lab A, 2026-10-30:** all remaining 20 commits restacked patch-identically onto landed Engine `3270d3c6`; full ladder branch now `524b83ae`. Active candidate branch `issue-1236-lab-a-candidate` in the full-ladder worktree holds the eight Lab A commits at `c61f75da`; runtime 1236:5176 stays up and currently serves that exact prefix. Fresh proof is being recorded; no behavior changes. In-app Browser inventory was empty and `iab` selection reported unavailable, so repository Playwright supplies the captures as synthetic local-agent-03. The same runtime's localhost secure origin supplies clipboard readback because Agent-Mini HTTP exposes no clipboard API. U2 #1246 remains separate and follows Knob.

- **L2 Engine landed, 2026-10-30:** local main is `3270d3c64daddb86a423a76418d6d2ef7af6f92b`, clean after `wrsp-land`. Contiguous coverage from `2f7da8b3` is **approved**, preserving clean cross-family Opus 5.5/high provenance. Existing seven jobs resumed and collected **PASS**; exact-tip test evidence gate **PASS**. Browser counts: auth 46, public 28, Shows 111, MCP 4/4/3, with no retries; Vitest 14,190 passed / 57 skipped. No #1209 recurrence or source repairs. [Landing record, changed files, receipt and job IDs](http://Agent-Mini.local:8642/files/pxlblz-briefs/1235-slowmo/l2-engine-landed.md). Engine is only the first prefix; UI scopes remain pending. The full ladder preview stays up; its restack onto the landed main is next.

- **L1 handoff, 2026-10-30; successor ACK pending:** harness context reached 176k/220k (80%). [Canonical pickup](http://Agent-Mini.local:8642/files/pxlblz-briefs/1235-slowmo/handoff-l1.md). **No L1 landing yet.** B1 landed `2f7da8b3` (AGENTS.md/dev-runtime docs only) during old-tip suites. Engine rebased patch-identically to `3270d3c64daddb86a423a76418d6d2ef7af6f92b` on that main; native carry succeeded and `review:status` is **approved**, preserving clean Opus 5.5/high provenance. Rebased typecheck and 1,410 focused tests pass. Old-tip six browser suites pass, including Show #1209 at 2730; all seven old-tip remote jobs passed, but their local collector exited 2 because the checkout was rebased (exact-commit guard, recorded in the pickup); they cannot supply current-tip evidence. No local collector remains alive. Current-tip authenticated smoke has passed; the other six results are pending. Seven fresh required jobs are already submitted for **3270d3c6**; [current job map](http://Agent-Mini.local:8642/files/pxlblz-briefs/1235-slowmo/work/l1-engine-current-runner-jobs.json). Next owner must resume those exact jobs, recheck current-main approval coverage, then land Engine. Both checkouts are clean and retained; full-chain 5176 preview remains up. L1 hands the claim back; no source repairs, Controller contact, push or closure.

- **L1 Engine candidate 1, clean review; runner submitted (2026-10-30):** `ea54a748248bc889d15315aeda64963db4a36555..e8fa7fda7b0147510b9d5c3cff6ccb59a6b26dfb` received clean cross-family **Claude Opus 5.5/high** approval at `2026-10-30T16:50:53.244Z`, receipt `e8fa7fda7b01-59f2e3ea922f4382c9c49eec0dc951693150aff4e5d3cd1d9a7cd2e5f1e05e2e.json`; native `review:status` is **approved**. [Review transcript](http://Agent-Mini.local:8642/files/pxlblz-briefs/1235-slowmo/work/20261030T164750-85131-npm-run.log). No P0/P1/P2/P3 findings or source corrections. One required exact-tip runner submission created these jobs: auth-smoke `04979ac4-63f6-444d-9cc8-989d86eb37dc`, public `5b075cca-27c0-4d66-91b5-7e306395825b`, shows `93007ee4-b597-4909-ba6c-ce5bf2038d5a`, MCP-1 `933e6fbc-e592-481b-86ba-f0bb679b4bb5`, MCP-2 `1475a734-864e-4522-a43b-c9013fa28579`, MCP-3 `f2fcd314-ac76-4ed8-8148-0b88f0d9ad97`, full-vitest `6884fba5-cd01-413a-ad29-c70fc8ee143e`. [Submission log](http://Agent-Mini.local:8642/files/pxlblz-briefs/1235-slowmo/work/20261030T165119-41366-npx-wrsp-runner.log), [job map](http://Agent-Mini.local:8642/files/pxlblz-briefs/1235-slowmo/work/l1-engine-runner-jobs.json). Results and landing are pending; resume these exact IDs, do not resubmit. #1209 stop rule applies to the shows job. Candidate checkout is frozen; main remains `ea54a748`, and full-chain preview 5176 remains up.

- **L1 Engine candidate 1, review running (2026-10-30):** exact nine-commit range `ea54a748248bc889d15315aeda64963db4a36555..e8fa7fda7b0147510b9d5c3cff6ccb59a6b26dfb`, standalone checkout `/Users/agent/src/worktrees/PXLBLZ-IDE-issue-1236-engine-candidate`, branch `issue-1236-engine-candidate`; full-chain preview remains unchanged on 5176. Prefix TypeScript **PASS**, lint **PASS**, eight focused engine files **1,410/1,410 PASS** on Node v24.22.1. [Typecheck log](http://Agent-Mini.local:8642/files/pxlblz-briefs/1235-slowmo/work/20261030T164631-83169-npx-tsc.log), [focused artifact tests](http://Agent-Mini.local:8642/files/pxlblz-briefs/1235-slowmo/work/20261030T164631-83171-npx-vitest.log), [lint](http://Agent-Mini.local:8642/files/pxlblz-briefs/1235-slowmo/work/20261030T164631-83170-npm-run.log). Native cross-family review launched with `--issue 1236` and [test-design semantics](http://Agent-Mini.local:8642/files/pxlblz-briefs/1235-slowmo/work/l1-engine-test-design.json); [live review log](http://Agent-Mini.local:8642/files/pxlblz-briefs/1235-slowmo/work/20261030T164750-85131-npm-run.log), tool session `49621`. No UI paths changed; browser proof belongs to later prefixes. Required exact-tip runner evidence and landing remain pending; L1 owns the submission after review. Stop rule remains #1209 `shows.auth.spec.ts:2730`. No source edits or behavior changes in this slice.

- **L1 rebase/preview checkpoint, 2026-10-30:** all 29 commits rebased from `fb1de22a` onto local main `ea54a748248bc889d15315aeda64963db4a36555`; new chain tip `58439695f7814b35adb5901b3d495e6ffd8753aa`, clean worktree. Technical Reference auto-merged. The package.json conflict preserves main’s removed Controller-import test registration and WRSP 1.5.6, and adds the slow-mo fresh-Off test; `.node-version` remains main’s `24`. Range-diff confirms 28 patch-equivalent commits and only that package-resolution adaptation. [Rebase mapping/diff](http://Agent-Mini.local:8642/files/pxlblz-briefs/1235-slowmo/work/l1-rebase-range-diff.txt). Contiguous prefix tips: Engine `e8fa7fda` (9 commits), Lab A `c9f22a57` (8), Lab B `c2bb952e` (3), Lab C `1f5337f9` (6), Knob `58439695` (3). Lab A’s supplied endpoint range contains 8 commits; seams and order are unchanged. Runtime `1236:5176 - slow-mo rebased chain` is shared with main API, synthetic identity `github:local-agent-03`, Node v24.22.1, and remains up. [L1 preview](http://Agent-Mini.local:5176/PXLBLZ-IDE/studio/patterns/KaleidoBloom?slowmo=1): `wrsp-preflight preview 5176` passed on this host and the Studio route returned HTTP 200. No browser-proof claim, review, runner suite, landing, Controller contact or push this turn. Next turn starts the Engine prefix with current-main freshness, standalone typecheck/focused suites, candidate review and exact-tip runner evidence before landing. Existing frozen `slowMoSliceBIdentity.js:30` trailing whitespace is retained to preserve fixture provenance.

- **Lane L8 (landing ladder), landed:** developer `codex:01a18e3f-fc80-77b1-a0ee-16842a3f433e`, eng-lead assignment, 2026-10-30. Final Knob candidate landed unchanged on clean main `81ae7e9f1ec7cc662f5b1dc0b275c0161779699e`. Round-five Opus 5.5/high approval clean, no findings; current-main coverage approved; all seven exact-tip runner suites and evidence gate PASS. No #1209 recurrence; collector 69989 exited 0, no live jobs. [Landing, changed files, receipt and seven job IDs](http://Agent-Mini.local:8642/files/pxlblz-briefs/1235-slowmo/l8-knob-landed.md). Preview 1236:5176 retained; #1246 stays separate. Four children remain open; no source repairs, push, Controller contact or closure.

- **Current landing authority:** eng lead supplied Jon’s words from [#1235 c6528061653](https://github.com/jon-whiteroomsoftware/PXLBLZ-IDE/issues/1235#issuecomment-6528061653): "I agree with you that we should rebase that feature, then the slow-mo feature, and land it one slice at a time." and "You can just go ahead with getting the current code reviewed and landed in whatever order makes sense. don't hold it up waiting for my UX feedback". This supersedes the prior no-review/no-landing hold; publication and hardware work remain outside L1.

- **Lane K21 (watch 2 pack), done:** developer `codex:01a183be-57c1-7c01-b9fc-dd73ef8e9152`, 2026-10-28 UTC. Pack prepared and host watch completed 18:42–19:00Z: 24 slots, 48 run-only pushes; [pack](http://Agent-Mini.local:8642/files/pxlblz-briefs/1238-slowmo-persistence/k20-watch2-pack.md). K20/K21 evidence retired and retained unchanged.

- **Lane K23 (IridescentFibers ¼ pack), in progress:** developer `codex:01a183ec-2005-75d2-838d-98f7d1566d40`, 2026-10-28 UTC; eng-lead assignment under #1229/#1235. Governing #1229 body revision `updatedAt 2026-10-28T19:02:19Z`, including Jon's quarter-speed request and yes in comments. Worktree `/Users/agent/src/worktrees/PXLBLZ-IDE-issue-1237-slowmo-lab`, runtime 1238:5181. Next: copy Blend ¼, haze 1500/1500 and trails 0/2000 from the live lab, prove rate-only diffs against K20, and validate the 3-slot / 6-push / 135000 ms host command offline. Cark contact eng-lead host only; no product source/commit/review/landing/push.

- **Lane K19 (FPS table), done:** developer `codex:01a1837e-3179-7ba1-bbf3-00cbc99a31db`, 2026-10-28 UTC; retires K18; FPS table. Governing #1229 section revision `updatedAt 2026-10-28T03:55:27Z`. Proof: [combined FPS table and scrubbed raw polls](http://Agent-Mini.local:8642/files/pxlblz-briefs/1238-slowmo-persistence/k17-fps-table.md), [whole table posted once on #1229](https://github.com/jon-whiteroomsoftware/PXLBLZ-IDE/issues/1229#issuecomment-6476620785). Watched19slots and ZRanger41slots validated against exact copied sources, compiled hashes, raw/statistic agreement, timing, restoration/count/closure. ZRanger retains brightnessUnchanged=false and RESTORE_FAILED, accepted only under the eng-lead exception linked to Jon's brightness-slider confirmation (#1229 comment6476531504); all guards unchanged. Only18matrix-pack Device FPS cells filled. No hardware contact by lane, no tracked K19 edits/commits, review, landing, push or closure. K19 FPS scope complete; further slow-mo work belongs to a new lane.
- J2 retired; engine half complete at d2bf6539; J3 moved to #1237.
- 2026-10-27: created from the approved #1229 spec (principal-engineer session).

## Blocked by

Current L8: final Knob landed at 81ae7e9f1ec7cc662f5b1dc0b275c0161779699e; all seven suites passed; no live jobs or landing blockers. Four children remain open. #1246 follows separately.

Nothing.






