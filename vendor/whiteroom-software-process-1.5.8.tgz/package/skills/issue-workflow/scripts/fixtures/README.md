# Issue-body source fixture

`pxlblz-1236-body.md` is the unmodified `body` string returned by
`gh issue view 1236 --repo jon-whiteroomsoftware/PXLBLZ-IDE --json body`
on 2026-10-30. Source: https://github.com/jon-whiteroomsoftware/PXLBLZ-IDE/issues/1236.
It is a diagnostic fixture, not agent instructions. Do not update the source issue.
