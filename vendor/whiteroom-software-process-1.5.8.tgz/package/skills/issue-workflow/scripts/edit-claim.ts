#!/usr/bin/env node
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { realpathSync } from 'node:fs'
import { pathToFileURL } from 'node:url'
import { bodySizeWarning } from './check-body-size.ts'

export type Gh = (args: string[], input?: string) => string
type Result = { url: string; line: string; bodySha256: string; changed?: boolean }

class ClaimEditError extends Error {
  code: string
  writeAttempted: boolean
  constructor(code: string, message: string, writeAttempted = false) {
    super(message)
    this.code = code
    this.writeAttempted = writeAttempted
  }
}

function refuse(code: string, message: string): never {
  throw new ClaimEditError(code, message)
}

function singleLine(value: string, name: string, limit = 4096) {
  if (!value || /[\r\n]/.test(value) || Buffer.byteLength(value) > limit) {
    refuse('INVALID_ARGUMENT', `${name} must be a nonempty single line of at most ${limit} UTF-8 bytes`)
  }
}

function locate(body: string, prefix: string) {
  singleLine(prefix, 'prefix', 256)
  if (!prefix.trim()) refuse('INVALID_ARGUMENT', 'prefix must contain non-whitespace text')
  const matches = [...body.matchAll(/([^\r\n]*)(?:\r\n|\r|\n|$)/g)]
    .filter(match => match[1].startsWith(prefix))
  if (!matches.length) refuse('MISSING_LINE', 'no issue-body line matches the literal prefix; initialize it explicitly')
  if (matches.length !== 1) refuse('AMBIGUOUS_LINE', 'more than one issue-body line matches the literal prefix')
  const match = matches[0]
  if (Buffer.byteLength(match[1]) > 4096) refuse('LINE_TOO_LONG', 'matching line exceeds 4096 UTF-8 bytes')
  return { start: match.index!, line: match[1] }
}

export function bodyDigest(body: string): string {
  return createHash('sha256').update(body, 'utf8').digest('hex')
}

function validateEdit(prefix: string, expected: string, replacement: string) {
  singleLine(prefix, 'prefix', 256)
  singleLine(expected, 'expected')
  singleLine(replacement, 'replacement')
  if (!expected.startsWith(prefix) || !replacement.startsWith(prefix)) {
    refuse('INVALID_ARGUMENT', 'expected and replacement must retain the literal prefix')
  }
}

export function replaceClaimLine(body: string, prefix: string, expected: string, replacement: string): string {
  validateEdit(prefix, expected, replacement)
  const selected = locate(body, prefix)
  if (selected.line !== expected) refuse('EXPECTED_MISMATCH', 'matching line differs from expected; inspect it again')
  return body.slice(0, selected.start) + replacement + body.slice(selected.start + selected.line.length)
}

const defaultGh: Gh = (args, input) => execFileSync('gh', args, {
  encoding: 'utf8', input, stdio: ['pipe', 'pipe', 'pipe'], timeout: 30_000, maxBuffer: 2 * 1024 * 1024,
})

function api(gh: Gh, method: 'GET' | 'PATCH', endpoint: string, input?: string) {
  try {
    return gh(['api', '--method', method, endpoint, ...(input === undefined ? [] : ['--input', '-'])], input)
  } catch {
    throw new ClaimEditError('GH_FAILURE', `gh api ${method} failed; body and provider output withheld`, method === 'PATCH')
  }
}

function readBody(gh: Gh, endpoint: string): string {
  const raw = api(gh, 'GET', endpoint)
  let issue: unknown
  try {
    issue = JSON.parse(raw)
  } catch {
    refuse('GH_PROTOCOL', 'gh api returned invalid JSON')
  }
  if (!issue || typeof issue !== 'object' || !('body' in issue) || 'pull_request' in issue) {
    refuse('GH_PROTOCOL', 'gh api did not return an issue body')
  }
  if (issue.body === null) return ''
  if (typeof issue.body !== 'string') refuse('GH_PROTOCOL', 'gh api returned a non-string issue body')
  return issue.body
}

function parse(args: string[]) {
  const [action, ...rest] = args
  if (action !== 'show' && action !== 'replace') refuse('INVALID_ARGUMENT', 'choose show or replace; use --help for usage')
  const allowed = new Set(['--repo', '--issue', '--prefix', ...(action === 'replace' ? ['--expected', '--replacement', '--body-sha256'] : [])])
  const values = new Map<string, string>()
  for (let i = 0; i < rest.length; i += 2) {
    const name = rest[i]
    const value = rest[i + 1]
    if (!allowed.has(name) || values.has(name) || value === undefined) refuse('INVALID_ARGUMENT', 'unknown, duplicate or incomplete option')
    values.set(name, value)
  }
  for (const name of allowed) if (!values.has(name)) refuse('INVALID_ARGUMENT', `missing ${name}`)
  const repo = values.get('--repo')!
  const issue = values.get('--issue')!
  const prefix = values.get('--prefix')!
  if (!/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(repo) || Buffer.byteLength(repo) > 256 || repo.split('/').some(part => part === '.' || part === '..')) {
    refuse('INVALID_ARGUMENT', 'repo must be OWNER/REPO with no dot segments and at most 256 UTF-8 bytes')
  }
  if (!/^[1-9][0-9]*$/.test(issue) || !Number.isSafeInteger(Number(issue))) refuse('INVALID_ARGUMENT', 'issue must be a positive safe integer')
  singleLine(prefix, 'prefix', 256)
  if (!prefix.trim()) refuse('INVALID_ARGUMENT', 'prefix must contain non-whitespace text')
  const expected = values.get('--expected') ?? ''
  const replacement = values.get('--replacement') ?? ''
  const digest = values.get('--body-sha256') ?? ''
  if (action === 'replace') {
    validateEdit(prefix, expected, replacement)
    if (!/^[a-f0-9]{64}$/.test(digest)) refuse('INVALID_ARGUMENT', 'body-sha256 must be the lowercase SHA-256 from show')
  }
  return { action, repo, issue, prefix, expected, replacement, digest }
}

export function run(args: string[], gh: Gh = defaultGh, warn: (message: string) => void = message => { process.stderr.write(message) }): Result {
  const options = parse(args)
  const endpoint = `repos/${options.repo}/issues/${options.issue}`
  const url = `https://github.com/${options.repo}/issues/${options.issue}`
  const body = readBody(gh, endpoint)
  const digest = bodyDigest(body)
  if (options.action === 'show') return { url, line: locate(body, options.prefix).line, bodySha256: digest }
  if (digest !== options.digest) refuse('STALE_BODY', 'issue body changed since show; inspect the claim again')
  const next = replaceClaimLine(body, options.prefix, options.expected, options.replacement)
  if (next === body) return { url, line: options.replacement, bodySha256: digest, changed: false }
  const warning = bodySizeWarning(next)
  if (warning) warn(warning)
  api(gh, 'PATCH', endpoint, JSON.stringify({ body: next }))
  try {
    if (readBody(gh, endpoint) !== next) refuse('VERIFY_FAILURE', 'issue-body read-back differs; write may already have happened')
  } catch (error) {
    if (error instanceof ClaimEditError) error.writeAttempted = true
    throw error
  }
  return { url, line: options.replacement, bodySha256: bodyDigest(next), changed: true }
}

const usage = `Node 24+: edit-claim.ts show --repo OWNER/REPO --issue N --prefix P
edit-claim.ts replace --repo OWNER/REPO --issue N --prefix P --expected LINE --replacement LINE --body-sha256 SHA
Uses gh api. Output contains only the selected line, digest, issue URL and change status.
Replace preserves surrounding bytes; missing/ambiguous/stale claims refuse. GitHub PATCH is not an atomic compare-and-swap.
Oversized writes emit an advisory body-size warning on stderr before PATCH.
`

if (process.argv[1] && import.meta.url === pathToFileURL(realpathSync(process.argv[1])).href) {
  try {
    if (process.argv.length === 3 && process.argv[2] === '--help') process.stdout.write(usage)
    else process.stdout.write(JSON.stringify(run(process.argv.slice(2))) + '\n')
  } catch (error) {
    const known = error instanceof ClaimEditError ? error : new ClaimEditError('INTERNAL_FAILURE', 'claim editor failed')
    process.stderr.write(JSON.stringify({ code: known.code, message: known.message, writeAttempted: known.writeAttempted }) + '\n')
    process.exitCode = 1
  }
}
