#!/usr/bin/env node
import { readFileSync, realpathSync } from 'node:fs'
import { pathToFileURL } from 'node:url'

const target = 800
const wordCount = (text: string) => text.match(/\S+/gu)?.length ?? 0

/** Advisory only: never transforms the body or prevents claim maintenance. */
export function bodySizeWarning(body: string): string | undefined {
  const total = wordCount(body)
  if (total <= target) return undefined
  const sections = [{ name: '(preamble/unsectioned)', words: 0 }]
  let section = sections[0]
  let fence: { character: string; length: number } | undefined
  for (const line of body.split(/\r\n|\r|\n/u)) {
    const heading = !fence && line.match(/^ {0,3}##(?:[ \t]+(.*?))?[ \t]*$/u)
    if (heading) {
      section = { name: heading[1]?.replace(/[ \t]+#+[ \t]*$/u, '').trim() || '(untitled)', words: 0 }
      sections.push(section)
    }
    const marker = line.match(/^ {0,3}(`{3,}|~{3,})(.*)$/u)
    if (marker) {
      if (fence) {
        if (marker[1][0] === fence.character && marker[1].length >= fence.length && !marker[2].trim()) fence = undefined
      } else if (marker[1][0] === '~' || !marker[2].includes('`')) {
        fence = { character: marker[1][0], length: marker[1].length }
      }
    }
    section.words += wordCount(line)
  }
  const largest = sections.filter(s => s.words).sort((a, b) => b.words - a.words).slice(0, 3)
    .map(s => `${JSON.stringify(s.name.length > 96 ? s.name.slice(0, 95) + '…' : s.name)}: ${s.words} words`).join('; ')
  return `ISSUE_BODY_SIZE warning: ${total} words; target ${target}.\nLargest sections: ${largest}.\n`
    + "Collapse Progress to current state; move specs to a linked plan doc. Preserve Jon's verbatim words. Advisory only; body unchanged.\n"
}

const usage = 'Node 24+: check-body-size.ts --body-file FILE\nAdvisory body-size check; warnings go to stderr with exit 0. The file is never modified.\n'

if (process.argv[1] && import.meta.url === pathToFileURL(realpathSync(process.argv[1])).href) {
  const args = process.argv.slice(2)
  if (args.length === 1 && args[0] === '--help') process.stdout.write(usage)
  else if (args.length !== 2 || args[0] !== '--body-file' || !args[1]) {
    process.stderr.write('ISSUE_BODY_SIZE error: use --body-file FILE; see --help.\n')
    process.exitCode = 1
  } else {
    try {
      const body = readFileSync(args[1], 'utf8')
      process.stderr.write(bodySizeWarning(body) ?? '')
    } catch {
      process.stderr.write('ISSUE_BODY_SIZE error: cannot read --body-file.\n')
      process.exitCode = 1
    }
  }
}
