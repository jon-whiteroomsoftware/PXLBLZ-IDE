import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { delimiter, join } from 'node:path'
import { test } from 'node:test'
import { fileURLToPath } from 'node:url'
import { bodyDigest, replaceClaimLine, run, type Gh } from './edit-claim.ts'
import { bodySizeWarning } from './check-body-size.ts'

const prefix = '**Owner:** '
const oldLine = prefix + 'A198'
const newLine = prefix + 'A198 (developer)'
const endpoint = 'repos/example/project/issues/472'
const baseArgs = ['--repo', 'example/project', '--issue', '472', '--prefix', prefix]
const showArgs = ['show', ...baseArgs]
function replaceArgs(body: string) {
  return ['replace', ...baseArgs, '--expected', oldLine, '--replacement', newLine, '--body-sha256', bodyDigest(body)]
}

function transport(initial: string) {
  let body = initial
  const calls: { args: string[]; input?: string }[] = []
  const gh: Gh = (args, input) => {
    calls.push({ args, input })
    if (args[2] === 'PATCH') body = JSON.parse(input!).body
    return JSON.stringify({ body, html_url: 'https://github.com/example/project/issues/472', labels: [{ name: 'WIP' }] })
  }
  return { gh, calls, body: () => body }
}

test('one-line replacement preserves the complete body across line endings and positions', () => {
  for (const eol of ['\n', '\r\n', '\r']) {
    for (const tail of ['', eol]) {
      for (const [before, after] of [['', ''], ['intro 🦋' + eol, ''], ['', eol + '## Tests'], ['intro' + eol + eol, eol + '## Tests' + eol + 'café']]) {
        const body = before + oldLine + after + tail
        assert.equal(replaceClaimLine(body, prefix, oldLine, newLine), before + newLine + after + tail)
      }
    }
  }
  const progress = '- A198, old progress'
  assert.equal(replaceClaimLine('## Progress\n' + progress + '\nnext', '- A198,', progress, '- A198, new progress'), '## Progress\n- A198, new progress\nnext')
})

test('missing, ambiguous, mismatched and multiline edits refuse', () => {
  const cases: [string, string, string, string, string][] = [
    ['## Tests', prefix, oldLine, newLine, 'MISSING_LINE'],
    [oldLine + '\n' + oldLine, prefix, oldLine, newLine, 'AMBIGUOUS_LINE'],
    [oldLine, prefix, prefix + 'someone else', newLine, 'EXPECTED_MISMATCH'],
    [oldLine, '', oldLine, newLine, 'INVALID_ARGUMENT'],
    [oldLine, '\n', oldLine, newLine, 'INVALID_ARGUMENT'],
    [oldLine, prefix, oldLine + '\nextra', newLine, 'INVALID_ARGUMENT'],
    [oldLine, prefix, oldLine, newLine + '\r\nextra', 'INVALID_ARGUMENT'],
    [oldLine, prefix, oldLine, 'different prefix', 'INVALID_ARGUMENT'],
    [prefix + 'x'.repeat(5000), prefix, oldLine, newLine, 'LINE_TOO_LONG'],
  ]
  for (const [body, p, expected, replacement, code] of cases) {
    assert.throws(() => replaceClaimLine(body, p, expected, replacement), { code })
  }
})

test('show, replace and show expose metadata while preserving the persisted body', () => {
  const body = oldLine + '\n\n## Tests\nretain all of this 🦋\n'
  const api = transport(body)
  assert.deepEqual(run(showArgs, api.gh), {
    url: 'https://github.com/example/project/issues/472', line: oldLine, bodySha256: bodyDigest(body),
  })
  assert.deepEqual(run(replaceArgs(body), api.gh), {
    url: 'https://github.com/example/project/issues/472', line: newLine,
    bodySha256: bodyDigest(body.replace(oldLine, newLine)), changed: true,
  })
  assert.equal(api.body(), body.replace(oldLine, newLine))
  assert.deepEqual(api.calls.map(c => c.args), [
    ['api', '--method', 'GET', endpoint], ['api', '--method', 'GET', endpoint],
    ['api', '--method', 'PATCH', endpoint, '--input', '-'], ['api', '--method', 'GET', endpoint],
  ])
  assert.deepEqual(JSON.parse(api.calls[2].input!), { body: body.replace(oldLine, newLine) })
  assert.equal(run(showArgs, api.gh).line, newLine)
  const mutations = api.calls.filter(c => c.args[2] === 'PATCH').length
  assert.throws(() => run(replaceArgs(body), api.gh), { code: 'STALE_BODY' })
  assert.equal(api.calls.filter(c => c.args[2] === 'PATCH').length, mutations)
})

test('all pre-write refusals make no PATCH and leave the complete prior body unchanged', () => {
  for (const body of ['absent', oldLine + '\n' + oldLine, prefix + 'other']) {
    const api = transport(body)
    assert.throws(() => run(replaceArgs(body), api.gh))
    assert.equal(api.body(), body)
    assert.equal(api.calls.some(c => c.args[2] === 'PATCH'), false)
  }
  const api = transport(oldLine)
  const badArgs = [
    [], ['show', ...baseArgs, '--unknown', 'x'], ['show', ...baseArgs, '--issue', '1'],
    ['show', ...baseArgs.slice(0, 2), '--issue', '../472', '--prefix', prefix],
    ['show', '--repo', 'x/y/z', '--issue', '1', '--prefix', prefix],
    ['show', '--repo', '../..', '--issue', '1', '--prefix', prefix],
    ['show', '--repo', 'x/' + 'y'.repeat(300), '--issue', '1', '--prefix', prefix],
    ['show', ...baseArgs, '--replacement', newLine], ['replace', ...baseArgs],
    ['replace', ...baseArgs, '--expected', oldLine, '--replacement', newLine, '--body-sha256', 'bad'],
  ]
  for (const args of badArgs) assert.throws(() => run(args, api.gh), { code: 'INVALID_ARGUMENT' })
  assert.equal(api.calls.length, 0)
})

test('a no-op is reported without a write', () => {
  const api = transport(oldLine)
  const args = replaceArgs(oldLine)
  args[args.indexOf('--replacement') + 1] = oldLine
  assert.equal(run(args, api.gh).changed, false)
  assert.equal(api.calls.length, 1)
})

test('transport/protocol failures are bounded and distinguish attempted writes', () => {
  assert.throws(() => run(showArgs, () => { throw Error('PRIVATE BODY') }), { code: 'GH_FAILURE', writeAttempted: false })
  for (const response of ['PRIVATE BODY', '{}', '{"body":23}', '{"body":null}', '{"body":"x","pull_request":{}}']) {
    assert.throws(() => run(showArgs, () => response))
  }
  assert.throws(() => run(replaceArgs(oldLine), args => {
    if (args[2] === 'PATCH') throw Error('PRIVATE BODY')
    return JSON.stringify({ body: oldLine })
  }), { code: 'GH_FAILURE', writeAttempted: true })
  let read = 0
  assert.throws(() => run(replaceArgs(oldLine), args => {
    if (args[2] === 'PATCH') return '{}'
    return JSON.stringify({ body: ++read === 1 ? oldLine : 'concurrent write' })
  }), { code: 'VERIFY_FAILURE', writeAttempted: true })
})

test('the actual CLI keeps stdout bounded, updates only body, and makes refusals observable', () => {
  const dir = mkdtempSync(join(tmpdir(), 'wrsp-claim-'))
  try {
    const statePath = join(dir, 'state.json')
    const body = oldLine + '\n\n## Tests\nPRIVATE_BODY_MARKER\n' + 'evidence\n'.repeat(1000)
    writeFileSync(statePath, JSON.stringify({ body, labels: ['WIP'], writes: 0 }))
    writeFileSync(join(dir, 'gh'), `#!/usr/bin/env node
const fs = require('node:fs');
const p = process.env.CLAIM_TEST_STATE;
const s = JSON.parse(fs.readFileSync(p, 'utf8'));
if (process.argv[4] === 'PATCH') {
  const input = JSON.parse(fs.readFileSync(0, 'utf8'));
  if (Object.keys(input).join() !== 'body') process.exit(9);
  s.body = input.body; s.writes++; fs.writeFileSync(p, JSON.stringify(s));
}
process.stdout.write(JSON.stringify({body:s.body}));
`, { mode: 0o755 })
    const script = join(dir, 'edit-claim.ts')
    writeFileSync(script, readFileSync(fileURLToPath(new URL('./edit-claim.ts', import.meta.url))))
    writeFileSync(join(dir, 'check-body-size.ts'), readFileSync(new URL('./check-body-size.ts', import.meta.url)))
    const call = (args: string[]) => spawnSync(process.execPath, [script, ...args], {
      encoding: 'utf8', env: { ...process.env, PATH: dir + delimiter + process.env.PATH, CLAIM_TEST_STATE: statePath },
    })
    const show = call(showArgs)
    assert.equal(show.status, 0, show.stderr)
    assert.equal(JSON.parse(show.stdout).line, oldLine)
    const changed = call(replaceArgs(body))
    assert.equal(changed.status, 0, changed.stderr)
    assert.match(changed.stderr, /ISSUE_BODY_SIZE.*1006 words/)
    assert.equal(show.stderr, '')
    assert.equal(changed.stderr.includes('PRIVATE_BODY_MARKER'), false)
    assert.equal(JSON.parse(changed.stdout).line, newLine)
    assert.equal(show.stdout.includes('PRIVATE_BODY_MARKER'), false)
    assert.equal(changed.stdout.includes('PRIVATE_BODY_MARKER'), false)
    assert.ok(Buffer.byteLength(show.stdout + changed.stdout) < 1024)
    assert.deepEqual(JSON.parse(readFileSync(statePath, 'utf8')), { body: body.replace(oldLine, newLine), labels: ['WIP'], writes: 1 })
    const stale = call(replaceArgs(body))
    assert.equal(stale.status, 1)
    assert.equal(stale.stdout, '')
    assert.equal(JSON.parse(stale.stderr).code, 'STALE_BODY')
    assert.equal(stale.stderr.includes('PRIVATE_BODY_MARKER'), false)
    assert.equal(JSON.parse(readFileSync(statePath, 'utf8')).writes, 1)
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

const words = (count: number) => Array(count).fill('word').join(' ')
const sizeScript = fileURLToPath(new URL('./check-body-size.ts', import.meta.url))

test('body-size target is inclusive, whitespace-delimited and silent under or at it', () => {
  for (const body of ['', ' \n\t', words(600), words(800), Array(800).fill('café🦋').join('\r\n\t')]) {
    assert.equal(bodySizeWarning(body), undefined)
  }
  assert.match(bodySizeWarning(words(801))!, /801 words; target 800/)
})

test('warning ranks the three largest sections and counts fenced headings as content', () => {
  const body = [words(50), '## Tests', words(100), '## Progress', words(400),
    '```md', '## Fake heading', '```', '## What to build', words(300)].join('\r\n')
  const warning = bodySizeWarning(body)!
  assert.match(warning, /863 words; target 800/)
  assert.match(warning, /Largest sections: "Progress": 407 words; "What to build": 304 words; "Tests": 102 words/)
  assert.equal(warning.includes('Fake heading'), false)
  assert.match(warning, /Collapse Progress to current state; move specs to a linked plan doc/)
  assert.match(warning, /Preserve Jon's verbatim words/)
  assert.match(bodySizeWarning(words(810))!, /"\(preamble\/unsectioned\)": 810 words/)
  assert.match(bodySizeWarning(words(810) + '\n## Tiny\nshort')!, /"\(preamble\/unsectioned\)": 810 words/)
})

test('section diagnostics are bounded and escape terminal controls', () => {
  const warning = bodySizeWarning('## ' + '\u001b[31m' + 'x'.repeat(5000) + '\n' + words(801))!
  assert.ok(warning.length < 600)
  assert.equal(warning.includes('\u001b'), false)
  assert.ok(warning.includes('\\u001b'))
})

test('claim check observes the next body before PATCH while preserving bytes and no-op/refusal behavior', () => {
  // 798 + the two-token owner = 800; the replacement adds a word across the boundary.
  const body = oldLine + '\r\n' + words(798)
  const api = transport(body)
  const warnings: string[] = []
  const warn = (message: string) => {
    assert.equal(api.calls.some(c => c.args[2] === 'PATCH'), false)
    warnings.push(message)
  }
  run(showArgs, api.gh, warn)
  assert.deepEqual(warnings, [])
  run(replaceArgs(body), api.gh, warn)
  assert.match(warnings[0], /801 words/)
  assert.equal(warnings.length, 1)
  assert.equal(api.body(), body.replace(oldLine, newLine))
  assert.throws(() => run(replaceArgs(body), api.gh, () => assert.fail('stale edit warned')), { code: 'STALE_BODY' })
  const noOp = replaceArgs(api.body())
  noOp[noOp.indexOf('--expected') + 1] = newLine
  run(noOp, api.gh, () => assert.fail('no-op warned'))
  const small = transport(oldLine)
  run(replaceArgs(oldLine), small.gh, () => assert.fail('small claim warned'))
})

test('standalone CLI warns on the captured PXLBLZ #1236 body, stays silent on 600/800 words and never edits files', () => {
  const fixture = new URL('./fixtures/pxlblz-1236-body.md', import.meta.url)
  const original = readFileSync(fixture, 'utf8')
  const actual = spawnSync(process.execPath, [sizeScript, '--body-file', fileURLToPath(fixture)], { encoding: 'utf8' })
  assert.equal(actual.status, 0, actual.stderr)
  assert.equal(actual.stdout, '')
  assert.match(actual.stderr, /ISSUE_BODY_SIZE.*2249 words; target 800/)
  assert.match(actual.stderr, /Largest sections: "Progress": 1360 words; "Tests": 298 words; "What to build": 220 words/)
  assert.equal(actual.stderr, bodySizeWarning(original))
  assert.equal(readFileSync(fixture, 'utf8'), original)
  const dir = mkdtempSync(join(tmpdir(), 'wrsp-body-size-'))
  try {
    const bodyFile = join(dir, 'body.md')
    for (const count of [600, 800, 801]) {
      const body = words(count) + '\n'
      writeFileSync(bodyFile, body)
      const result = spawnSync(process.execPath, [sizeScript, '--body-file', bodyFile], { encoding: 'utf8' })
      assert.equal(result.status, 0, result.stderr)
      assert.equal(result.stdout, '')
      assert.equal(result.stderr, count > 800 ? bodySizeWarning(body) : '')
      assert.equal(readFileSync(bodyFile, 'utf8'), body)
    }
    for (const args of [[], ['--body-file'], ['--wrong', bodyFile], ['--body-file', bodyFile, '--extra'], ['--body-file', join(dir, 'absent')]]) {
      const result = spawnSync(process.execPath, [sizeScript, ...args], { encoding: 'utf8' })
      assert.equal(result.status, 1)
      assert.equal(result.stdout, '')
      assert.match(result.stderr, /ISSUE_BODY_SIZE error:/)
    }
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})
