---
name: issue-workflow
description: GitHub issue writes, claims, implementation state, proof, closure, feature epics, typed children, specs, handoffs, and recording Jon's direct instructions.
metadata:
  wrsp-min-version: "1.3.0"
---

# Issue Workflow

Verify `gh auth status` before authenticated GitHub work. Failures follow global
failure scope and `~/.agents/execution-policy.md`, **Route failures**.
Invoke `git` for staging and commits.

## Issue role

The body is current implementation state: scope, done/remaining work, blockers,
tests/proof and docs impact. Required edits keep it current. Durable product
intent, architecture, technical design, domain language and reference behavior
live in linked PRDs/plans, design docs, ADRs/reference docs, `CONTEXT.md` and commits.

## Feature and typed work

Before feature work, reuse its epic (including an existing PRD issue) and a
bounded typed child; create only missing work within authorized scope. UX work
uses a UX child; PRD authorship uses a definition child. Epics group specs and
children; preserve reused labels/history. Attribute sessions/commits to the work
child, without a second spend unit or new epic category. Shared/maintenance work
may stand alone. Future rollups remain future work.

Read the adopted work-type catalog and contract when creating or claiming work
(`docs/reference/contracts/work-types.md` in WRSP). Select/check one purpose label;
missing/multiple types are unknown diagnostics, not gates. Keep state labels
separate. Link corrections to their bugs/findings and follow contract history,
capture and effective-time rules. Use the adopted guide for native parent/child
attachment and read-back, or explicit reciprocal links when native grouping is
confirmed unavailable (`docs/reference/work-types.md` in WRSP). Preserve ambiguous
epics, conflicting parents and claims pending resolution; never silently replace
a parent. Connection failures follow Route failures above.

Prefer bounded sessions. A meaningful task/category change normally starts
another; incidental tests/docs stay with the feature, prototypes remain design.
Mixed sessions are allowed and unknown. Reuse provider-qualified session IDs,
issue worktrees and trailers; review activity and machine time remain separate
from issue purpose.

## Specs and template

Split plans into vertical slices. Use this template:

```text
## Parent
## What to build
## Limits
## Acceptance criteria
## Required proof
## Tests
## Docs impact
## Progress
## Blocked by
```

Describe the end-to-end slice without copying the PRD. Name limits and non-goals;
named points such as "decide with Jon" halt work. Acceptance criteria are
observable conditions. Required proof names the consumer surface and cases at
creation; attach completion evidence before close. Tests name must-test cases and
oracles at creation, then actual results. Spec cases are the floor. Docs impact
names applicable contracts and expected/actual updates. Progress holds meaningful
milestones; blockers are issue IDs or concrete dependencies. Link large designs.

- At assignment, the eng lead names the oracle and writes a test/proof sketch
  of at most 10 bullets into Required proof and Tests. Before code, the developer
  expands it with `systematic-test-design` into cases, partitions, setup and
  expected assertions in Tests; link large detail from the body. At spec time,
  invoke `systematic-test-design` for must-test cases and oracles.
  Name preserved/changed contract clauses;
  keep proposed guarantees out of current reference until accepted and implemented.
- Each criterion becomes a review invariant. Closed domains are our files,
  objects and config; open domains need enumerated forms, a fail-closed default
  with named residual, or explicit threat-model scope.
- Beyond trivial UI, link a mock-up/prototype; it and Limits bound the build,
  while Required proof carries interaction checks.
- Settle the approach with exact files, functions, call-stack/algorithm skeleton,
  refusal behavior and tests in the developer's plan before implementation.
  Unresolved design goes to Jon; execution-policy Test planning governs detail.
- Pin primary-source facts as cited issue artifacts; derive work from those
  bytes, not an agent's restatement. Record chat-settled decisions on the issue
  in the same turn.

## Updating issues

Record Jon's direct instructions verbatim with source in the same turn. Within
the assigned tree, forward them verbatim to the eng lead. Outside lanes record
them on their own issue.

Comments are only short verbatim Jon quotes plus one source/context line,
decisions/scope changes, or proof the body cannot hold. Claims, releases, brief
pointers, ready-to-land, accepted/landed/returned states and handoffs are label
changes or body edits. Record owner, live jobs and next step; still deliver role
protocol messages. Developer/lander own the land-request protocol.

Rewrite/reorganize the body for clarity. Call out meaningful scope changes;
weakening scope or acceptance needs Jon's confirmation. Update Progress, Tests
and Docs impact on commits or discoveries. Cite commits when practical. Record
completed work after commit; claims, blockers, scope and acceptance clarifications
before commit. Show pending checks separately from passing proof.

Before `gh issue edit --body-file FILE`, run
`node <skill-path>/scripts/check-body-size.ts --body-file FILE`; proceed only if
the file was checked (exit 0). Above 800 whitespace-delimited words it warns with
the total and largest sections: collapse Progress to current state; move specs
to a linked plan doc, preserving Jon's verbatim words. This advisory leaves the
file unchanged and permits the write; at or below the target it is silent.
The claim-line editor runs the same check automatically before PATCH. Arbitrary
`gh` invocations are not intercepted.

## Claiming And Coordination

- For an existing Owner or lane Progress line, use the Node 24+
  [claim-line editor](scripts/edit-claim.ts): `show --repo OWNER/REPO --issue N
  --prefix P` returns only the unique line, body SHA-256 and URL. Then `replace`
  with the same options plus `--expected LINE --replacement LINE --body-sha256 SHA`
  from that inspection. Run it as `node <skill-path>/scripts/edit-claim.ts`.
  Prefixes are literal and replacements retain them. Missing/duplicate lines,
  changed bodies or expected-line mismatches refuse; initialize a missing line
  through an explicit body edit first. The tool privately fetches/writes the
  body and verifies read-back, preserving surrounding bytes. Its digest detects
  changes since inspection; GitHub PATCH still has a last-writer-wins race.
  A failure with `writeAttempted: true` needs inspection before another write.
- Before substantial work, add `WIP` and record session/date in the body. Respect
  stale claims: ask before takeover unless explicitly assigned. Successors keep
  the claim. If work stops or is handed back, remove WIP and update the body.
- On Agent Mini, snapshot after claim, label changes and close:
  `wrsp-usage snapshot-issue --source claim|close OWNER/REPO N`; use claim for
  label changes. Failure warns but never blocks work.
- Only `WIP` and `📦 implemented` have Jon's standing creation approval (WIP:
  2026-10-18). Ask for any other missing label/status. If WIP cannot be created,
  put `Status: in progress`, identity and date in the body.

## Implemented

Use `📦 implemented` only after identified commits in the body claim the whole
implementation scope; uncommitted or partial work does not qualify. Swap out WIP
and old `ready-for-review`. State the claim, proof, docs/contracts and remaining
review, landing, release or adoption work. This signals available implementation,
not successful review, landing, release or Jon's acceptance. Continue those gates.

Remove implemented when closing or when further implementation is needed; restore
it after replacement commits. Leave issues open for Jon unless explicitly asked
to close. The label grants no closure authority. Link affected contracts and the
evidence for changed/preserved obligations. Put a concrete `Proof:` line in the
body by default; comment only if the body cannot hold it. For
`wrsp-check-issue-proof`, keep `## Required proof` nonempty; bold text is not the
marker. The checker proves presence, not sufficiency.

## Follow-ups and splits

Feature work authorizes missing tracking issues only within its scope. Propose
additional splits/follow-ups by default; ask before creation unless the project
workflow authorizes it. Create actionable, low-controversy work
within an approved plan. Work required by current acceptance stays here;
separable adjacent work becomes a proposal or follow-up section.
