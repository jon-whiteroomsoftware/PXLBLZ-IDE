# White Room Software brand assets

These four files are byte-for-byte copies of members of `white-room-assets.zip`
(sha256 `b26f2aee2520e18d7d3b7572c37451eea974534f6f3bb359795360df10345819`),
which Jon supplied on 2026-10-29 for
[#448](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/issues/448).
Another agent designed the assets for Jon, in direction E4 "Snow Room": brand blue
`#3771E0`, ink `#0E1526` and tint `#9DB9F2`, with the Sora wordmark outlined in
the SVGs.

| File | Zip member | sha256 |
| --- | --- | --- |
| `favicon.ico` (16 hand-pixelled, 32, 48) | `white-room-assets/favicon/favicon.ico` | `ee8cbb2d3ce9bc407201dda678781742d7add71abb6a9c4c12e78f086062d63c` |
| `favicon.svg` | `white-room-assets/favicon/favicon.svg` | `0f81bd0bf847e48fa7c1d466d1243c5ade43d2f7bbed119d52381426eb083f88` |
| `apple-touch-icon.png` (180 px) | `white-room-assets/favicon/apple-touch-icon.png` | `3fda0cfa44fb28efe38097267f00dcf0425e560b4a84b7c04dbf16fe8f402694` |
| `wrs-icon.svg` (master tile) | `white-room-assets/icon/wrs-icon.svg` | `a2db6b4c3ff71dfbce84c33a47ab0643e86b4bc876a1edbf0121b06e0588cd4d` |

The runner dashboard serves the first three at `/favicon.ico`, `/favicon.svg`
and `/apple-touch-icon.png` ([brand.ts](../../src/runner/dashboard/brand.ts)).
The head links are the snippet's first three lines. The master tile remains
vendored; the header uses the wordmark supplied below.

## Wordmark pack (#453)

Jon supplied a second pack on 2026-10-29 for
[#453](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/issues/453):
[white-room-assets-wordmark.zip](http://Agent-Mini.local:8642/files/briefs/453-dashboard-wordmark/white-room-assets-wordmark.zip),
sha256 `0781ae5a6e2d69aaf3038e93b05d36e1d8e0833473d1b685a799cf1d11416b29`.
Its README credits the same E4 "Snow Room" direction. All 38 members are
preserved byte-for-byte under `design/brand/white-room-assets/`, outside the
published package. The four files above are identical in both packs.

Only this additional member is copied into `assets/brand/` and served at
`/wrs-header-dark.svg`. Its outlined Sora wordmark needs no font request;
the light/mono variants and live-text snippet are preserved without being served.

| File | Zip member | sha256 |
| --- | --- | --- |
| `wrs-header-dark.svg` | `white-room-assets/header/wrs-header-dark.svg` | `666dc182b37c129e365d88259006933308e1f9c4ac441773b21ea036cb42b9bf` |

## Sora title and tab font (#463)

The dashboard's live-text page titles and header tabs use Sora from the primary
[`google/fonts` source](https://github.com/google/fonts/tree/a926665019d3f7f25c8b1212cecbfa871e70de82/ofl/sora),
commit `a926665019d3f7f25c8b1212cecbfa871e70de82`. That source directory supplies
a variable TTF, not a prebuilt WOFF2. The font is copyright 2019 The Sora Project
Authors and licensed under SIL Open Font License 1.1; `OFL.txt` is copied
unmodified beside the font.

| File | Primary source / derivation | sha256 |
| --- | --- | --- |
| Source `Sora[wght].ttf` (not shipped) | [Pinned TTF](https://raw.githubusercontent.com/google/fonts/a926665019d3f7f25c8b1212cecbfa871e70de82/ofl/sora/Sora%5Bwght%5D.ttf) | `84ff7096ae3ec6c8be47d906d1a0ba4de7f2ce78c615275c77301964a316e16c` |
| `OFL.txt` | [Pinned licence](https://raw.githubusercontent.com/google/fonts/a926665019d3f7f25c8b1212cecbfa871e70de82/ofl/sora/OFL.txt) | `ba0b9729c9428ba79a0459ab8ec575791b51509dbec213e383d0316d37fec299` |
| `sora-400-700.woff2` | Weight subset and WOFF2 conversion of the pinned TTF | `be5339968841c1ea637775cf52bc2abebf514f352205f3c78dd5950a720528cb` |

The subset retains the minimum continuous variable interval covering tab weight
400, shared title weight 500 and Work/legacy title weight 700. Weights below 400
and above 700 are removed; all 378 source Unicode mappings remain, including
Latin accents and punctuation for issue/file titles. Unsupported glyphs use the
existing system fallback. The font is served locally at `/sora-400-700.woff2`;
the original outlined wordmark bytes are unchanged.

Conversion used Python 3.9.6, fontTools 4.60.2 and Brotli 1.2.1 in a temporary
isolated virtualenv. Raw downloads and intermediates stay outside the package.
Reproduce from the pinned TTF with those versions:

```python
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont

font = TTFont('Sora-wght.ttf', recalcTimestamp=False)
font = instantiateVariableFont(font, {'wght': (400, 700)}, inplace=True)
font.recalcTimestamp = False
font.flavor = 'woff2'
font.save('sora-400-700.woff2')
```

## Preserved pack members

Paths below are archive member names, relative to `design/brand/` in this repository.

| Zip member | sha256 |
| --- | --- |
| `white-room-assets/README.txt` | `bbcaa5f3c7ca55db2f26db3bcbeaffbdf9221903885c0d146a888d4017dfebdc` |
| `white-room-assets/favicon/apple-touch-icon.png` | `3fda0cfa44fb28efe38097267f00dcf0425e560b4a84b7c04dbf16fe8f402694` |
| `white-room-assets/favicon/favicon-16.png` | `eb3b75c714219e9a8c4d6940d38c8ec833c5c14261017f281dca2f95d743f66d` |
| `white-room-assets/favicon/favicon-32.png` | `1e9ae2fded7b411ab11df893b59417eaf5948d3db3dff357e2127863cbeb9896` |
| `white-room-assets/favicon/favicon.ico` | `ee8cbb2d3ce9bc407201dda678781742d7add71abb6a9c4c12e78f086062d63c` |
| `white-room-assets/favicon/favicon.svg` | `0f81bd0bf847e48fa7c1d466d1243c5ade43d2f7bbed119d52381426eb083f88` |
| `white-room-assets/favicon/head-snippet.html` | `1096e4ef723578222338e0ed962ba361951bce514b0e8e5ca535bcfa34e6979d` |
| `white-room-assets/favicon/icon-192.png` | `17b88b5cbb527803ee8fabf3f4b804ba8d0566698ffbaa4d494bc44d1c9a8cf2` |
| `white-room-assets/favicon/icon-512.png` | `773c331e871fbf8d844de2826d1941735b5859ddfa85b848965870e39b6d899c` |
| `white-room-assets/favicon/site.webmanifest` | `f86fb8c4fd8ab13bd22e4a10b9e043a12e15501e654a8a1c6d155fe163581bdb` |
| `white-room-assets/header/header-snippet.html` | `5e9190fb2e90b7632b67a09f5871f442eaf38e18a9d3a67bcf52532286f9cb57` |
| `white-room-assets/header/wrs-header-dark.svg` | `666dc182b37c129e365d88259006933308e1f9c4ac441773b21ea036cb42b9bf` |
| `white-room-assets/header/wrs-header-dark@1x.png` | `0ffb231a687a749e05f96a968a1432c6b517a052ffca4d14fe7759e01507ea4c` |
| `white-room-assets/header/wrs-header-dark@2x.png` | `2afa11faeb8b2e22588c79507ad15b911a5c621317ed059adb74437ca8600fca` |
| `white-room-assets/header/wrs-header-dark@3x.png` | `46b7761adfade7eb23afd7c6240aba1397b24c69ddd6b19a43c21306603ca6b4` |
| `white-room-assets/header/wrs-header-light.svg` | `3a8a1d2459c5515d2b59d77b603757662b54cc01675236f167893570f87d6faa` |
| `white-room-assets/header/wrs-header-light@1x.png` | `93d7f929c5b25832736af45399015634a3f096ddea8e06ced87dbbc87469e0c7` |
| `white-room-assets/header/wrs-header-light@2x.png` | `680bdb18782c70c59fbb947cb9ae25aab617b2867aec5e06e168a629059c8f98` |
| `white-room-assets/header/wrs-header-light@3x.png` | `f73b2e19d5b0a31dc5a7399778574c263a447b961fbf199b409da1a31d765d01` |
| `white-room-assets/header/wrs-header-mono-white.svg` | `122091cbe8edec4bfc2d33a06a67f54e25942b1d67297e31b4119361c218df97` |
| `white-room-assets/header/wrs-header-mono-white@1x.png` | `fbee31dd590bd722fa7b97c593f2d267b38d9cd4c7abef3bb7d81dfeecd0561f` |
| `white-room-assets/header/wrs-header-mono-white@2x.png` | `9e7c51f095347998ff04fb3ca65f6b90e194a29397926f1227ead37aa713ccbc` |
| `white-room-assets/header/wrs-header-mono-white@3x.png` | `074d99863359490f9d58e79d22cd8ae1d368704b024445109d7b4e12d200e89a` |
| `white-room-assets/icon/wrs-icon-1024.png` | `b2bddfea73e26b4486bd4aedc7f8156de78017080d3d14402711bbfaaf35d9a0` |
| `white-room-assets/icon/wrs-icon-256.png` | `51c3c2dcd9650cff233b0916fcc77a988d63c7e1ec6aa2211713121523a6e6f2` |
| `white-room-assets/icon/wrs-icon-512.png` | `773c331e871fbf8d844de2826d1941735b5859ddfa85b848965870e39b6d899c` |
| `white-room-assets/icon/wrs-icon.svg` | `a2db6b4c3ff71dfbce84c33a47ab0643e86b4bc876a1edbf0121b06e0588cd4d` |
| `white-room-assets/icon/wrs-mark-blue.svg` | `1ceb8ac0bb9da1b297c555a30a00123b46bc0b4c626d9144e64170b8b08b2b28` |
| `white-room-assets/icon/wrs-mark-ink.svg` | `7328dad5305c50832b145ad515f42d32905367b1d8b6dd0c0f585fea777832b2` |
| `white-room-assets/icon/wrs-mark-white.svg` | `1f4d05faa3febae8cda3d8e746976bcb8e0b09f3b36e67e7a5b28d93005ee1a7` |
| `white-room-assets/logo/wrs-logo-mono-ink.svg` | `83117ffbf33497587775a503541019f4092a459517fc9278a92d25824c87d17d` |
| `white-room-assets/logo/wrs-logo-mono-ink@2x.png` | `2630cb070480d97d7c29105ff272b1844a4f4a0ed809f6ddcb52eae682d0dafb` |
| `white-room-assets/logo/wrs-logo-on-blue.svg` | `30a03cbf19cd07d0143085841a15259a62cfbba890fa806dfa6178c54a3228a9` |
| `white-room-assets/logo/wrs-logo-on-blue@2x.png` | `a035235909febe31107163cefe9077b7b7ee5b90d16d8de0fbbde11d2b0bdb75` |
| `white-room-assets/logo/wrs-logo-reversed.svg` | `c2134d2fe26dfbd068e4a70d6491ac00a31a5e514149497518a07a68159618a0` |
| `white-room-assets/logo/wrs-logo-reversed@2x.png` | `768c5dd86a003061752b19030271c4770b81288de2395b956b8fd36dfc36aaa7` |
| `white-room-assets/logo/wrs-logo.svg` | `2e8d8ecdc98487e7db061ba0b3d718b92395a92b090d817cb687d27877b6f42f` |
| `white-room-assets/logo/wrs-logo@2x.png` | `1149892ab0cf36bf575cfea455b3805dc339315283ab85c0952c73dd9b40173a` |
