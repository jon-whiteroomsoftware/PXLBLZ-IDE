# White Room software process

Shared process tooling for repositories developed by many agents and reviewed
once: an exact-range review gate with immutable receipts and cross-model-family
routing, staged-test selection, and test-suite meta-checks. Consumed as a
vendored release tarball; configured per repository by one `wrsp.config.mjs`.

## The process

This section describes the target process. The tooling in this repository
implements the review, landing, and publication mechanics; the land-queue
executor and the dispatch coordinator are target-state, not yet built.

### Principles

- Every load-bearing claim gets a machine-generated artifact. No artifact, no progress.
- Anything that should be running emits a liveness signal. Silence is an alarm.
- Humans own intent and acceptance. Machines own scheduling and verification.
- Unattended wall-clock is cheap. Tokens and human attention are not.

### State

- Repository files and issues are the durable state. Agent memory never is.
- `📦 implemented` marks issues with identified commits claiming to satisfy their implementation scope. The issue body records review, landing, release, and adoption separately. Jon owns closure; the shared `issue-workflow` skill owns label transitions.
- `AGENTS.md` instructs agents; `CLAUDE.md` is a symlink to it. `CONTEXT.md` defines domain language.
- `docs/plans/` holds proposed intent. `docs/reference/` holds as-built truth. Issues hold executable progress.
- [Engineering contracts](docs/reference/engineering-contracts.md) hold current obligations at seams inside reference; ADRs hold accepted consequential choices and rationale.

### Development

- The shared checkout stays clean on `main`. All substantive work happens in worktrees.
- One issue per slice. Slices are vertical and independently shippable.
- Each agent gets its own worktree, dev server, and synthetic identity.
- Every commit names its authoring model in an `X-Authored-Model:` trailer.
- Read applicable contracts before changing a seam. Preserve them unless the spec authorizes a change; update accepted behavior and its contract in the same slice.

### Testing

- TDD for behavior changes. Coverage concentrates in pure logic; UI stays thin.
- Oracle strategy is chosen per subsystem at design time: property-based and differential tests wherever dual implementations or invertible transforms exist.
- Contract evidence exercises the observable agreement at its interface and identifies clauses or residual gaps the cited checks do not prove.
- Meta-checks gate the suite itself: every spec runs in some gate; locators match live source.
- Flaky tests enter a registry with owner and expiry, not lore.
- Mutation testing is periodic qualification of high-risk engines, not a routine gate.

### Review and landing

- Every slice is reviewed once, before landing, as an exact commit range.
- Direct approval is bound to exact hashes. Rewrites need fresh coverage or a qualifying content-identical carry recorded in new receipts; later policy changes preserve valid native approvals under their recorded rules.
- Review routes to the opposite model family. Fallbacks are recorded, never silent.
- P0/P1 findings block and void coverage, then require repair, verification, and replacement-range review while the candidate converges. P2/P3 findings record advisory coverage, cleared by reviewing the exact corrective range.
- Three consecutive P0/P1-blocked reviews on one candidate lineage stop the next reviewer launch and require contract renegotiation or an explicit one-attempt acknowledgement.
- Review checks changed behavior against applicable engineering contracts and their observable evidence.
- Landing is a serialized queue: rebase, review, fast-forward merge, delete the worktree.
- After each landing, an executor runs the affected suites against the landed tip and writes a result artifact.

### Publication

- Push requires a contiguous receipt chain and green suite artifacts covering the outgoing range.
- Pushing is a deliberate human choice. Deploying is decoupled from pushing.

### Agent-side hook protection

Jon's installed Claude and Codex command guards reject the supported Git
verification-bypass forms before execution. They cover direct commit, push,
and merge commands, including absolute paths ending in `/git`, at enumerated
shell command boundaries. Codex also has narrow forbidden prefix rules.
Wrappers, Git global options before the subcommand, aliases, and specialized
tool paths remain outside the declared scope; quoting can cause false positives.
Codex's wider user hook requires explicit trust after restart or modification.
Installation alone is not live enforcement proof. Issue #8 tracks activation.
The generic Fable subagent restriction remains separate and unchanged.

### Dispatch

- A standing coordinator polls ready-labeled issues, spawns implementers into worktrees, and owns the review and landing queue.
- Stuck work escalates as an issue comment, never a silent retry.
- The coordinator posts a periodic digest. A missing digest is the alarm.
- Concurrency stays small: extra implementers buy rebase churn, not throughput.

## Mechanism

The [local runner host guide](docs/reference/local-runner.md) records the Mac mini trust boundary, pinned prerequisites, provisioning procedure, and `wrsp-runner doctor` check.
The [test-evidence contract](docs/reference/contracts/test-evidence.md) defines how collected runner results bind to one exact tip and when the independent publication gate refuses them.

The [exact-range review engineering contract](docs/reference/contracts/exact-range-review.md)
owns the current identity, outcome, coverage, carry, freshness, and failure
obligations. This section keeps only the operational map and command context.
The [non-convergence contract](docs/reference/contracts/review-non-convergence.md)
owns repeated-terminal admission, control records, and round telemetry.

**Candidate review.** `wrsp-review-candidate <base> <tip>` resolves an explicit
Git range. It either carries eligible existing coverage into receipts for the
new identities or sends the complete commit list, every per-commit changed line,
and one shared set of unchanged endpoint context to the configured reviewer
path. The changed-line series retains intermediate edits and reversions; shared
context carries immutable revision, blob, path, and line references for
readable source inspection without repeating it around every commit. Before
either reviewer starts, the gate measures the complete request, including
project policy and systematic test-design context, and fails with the measured
size and remediation when it exceeds 1,048,576 characters. It never truncates
the review packet. Resulting immutable JSON receipts live under
`.git/wrsp/review-approvals/v1/` in the shared Git common directory.

**Non-convergence.** Completed review outcomes are immutable control facts under
`.git/wrsp/review-outcomes/v1/`. After three consecutive P0/P1 outcomes sharing
an exact base and following the current tip's ancestry, the next candidate
review exits before reviewer launch with the renegotiate-contract message.
Clean and advisory outcomes reset the streak; sibling histories do not combine.
`--acknowledge-non-convergence` admits one deliberate attempt and creates no
durable override. Every completed or refused attempt also appends best-effort
measurement to `.git/wrsp/review-rounds.jsonl`; that log never drives behavior.

**Routing.** Commits signal their authoring model with an
`X-Authored-Model:` trailer. The reviewer tier is ordered Fable High, Astra
Medium, Sol 5.6 High, then Opus 5 Extra High. For work authored by one known
model family, the route tries only reviewers from the other family in that
order. GPT-authored work therefore tries Fable, then Opus; Claude-authored work
tries Astra, then Sol.

An unavailable or unusable reviewer advances to the next eligible model. A
valid review with findings stops the route so correction can proceed. Exhausting
eligible models fails the review. Mixed-family ranges cannot establish full
cross-family coverage and need to be split; unsignalled authorship remains
explicitly unverified.

An explicit reviewer choice applies to one candidate:

```bash
npm run review:candidate -- <base> <tip> \
  --reviewer-model claude-opus-5 --reviewer-effort xhigh
```

This selects Opus 5 Extra High with no fallback. To permit a fallback, supply
both `--fallback-reviewer-model` and `--fallback-reviewer-effort` from the
supported pairs. Unsupported selections fail before provider launch. The next
invocation without selection flags uses the ranked tier.

Native approvals retain the reviewer, effort, and policy facts that authorized
them. A later model or policy change does not revoke an existing approval;
status and push checks still require exact, contiguous commit coverage ending
in a clean approval. Runtime permission to invoke a provider remains separate.
See the [exact-range review contract](docs/reference/contracts/exact-range-review.md)
for supported selections, identity validation, carry, and the trusted local
receipt boundary.

**Review outcomes.** A completed P0/P1 review reports `CANDIDATE REPAIR
REQUIRED`; the three-round non-convergence breaker reports `CANDIDATE REVIEW
PAUSED` before a fourth launch; provider, prerequisite, validation, and other
gate execution failures report `CANDIDATE REVIEW ERROR`. Each remains nonzero
and preserves the existing fail-closed receipt rules.

**Carry diagnostics.** Every carry attempt appends one JSON line to
`.git/wrsp/carry-log.jsonl` with a carried, refused, or no-candidate outcome.
This telemetry makes refused-carry cost measurable without making the log an
approval authority.

**Serialization.** Concurrent reviews queue on `.git/wrsp/review.lock`,
claimed by `mkdir` (the one POSIX create-if-absent that refuses even an empty
existing directory). Locks are never reaped automatically; a dead holder fails
the run with explicit cleanup instructions, exactly like git's `index.lock`.

**Publication.** The pre-push hook reads Git's ref-update packet and checks the
relevant outgoing ranges against stored receipts. Missing coverage prints the
exact `review:candidate` command; pre-push never repeats substantive review,
then enforces the repository's publication checks. Runner-enabled consumers
can require [exact-tip test evidence](docs/reference/contracts/test-evidence.md)
from their configured authoritative suites. Their hook consumes those records;
it does not execute the same suites again. This package's `.husky/pre-push`
requires the configured `package-tests` evidence after review coverage. Run
`node bin/wrsp-runner.mjs test HEAD` on the final committed tip before pushing.

**Staged-test selection.** `wrsp-test-staged` typechecks when staged paths can
affect a TypeScript project, runs staged and colocated tests, and adds fixed
regression suites for configured high-risk boundaries. A boundary may use the
default Vitest command or a named specialized runner. Exact paths and prefixes
are authoritative ownership; staged-content predicates inspect additions and
deletions only to advise when a matching file has no owner. Renames preserve
both old and new paths, so moving a covered source cannot shed its gate. When
a test is selected by a specialized runner, that ownership removes the same
test from default focused and invariant work instead of running it twice.

**Layout fault gate.** `findLayoutFaults` walks a rendered subtree and returns
structured collapsed-text, overflow, containment-escape, and must-fit faults.
Consumers declare intentional overflow or escape and ignored subtrees through
DOM annotations instead of maintaining product-specific forks of the detector.
Rendered text uses browser text rectangles rather than `clientWidth`, which is
legitimately zero for inline elements.

`wrsp-check-layout-gate` runs a consumer-owned browser test through a configured
runner. The package fixture contains both a 64px positive control and a
deliberate overflow. The command must exit zero and emit exactly one valid
report; zero-width/no-layout controls, missing or wrong faults, missing,
duplicate, or malformed reports, and command failures all fail closed. This
proves real geometry. The consumer separately proves that its production
stylesheet and fonts are loaded, because the package cannot know those
product-specific entrypoints.

Consumers import the browser-safe modules through
`@whiteroom/software-process/layout-faults` and
`@whiteroom/software-process/layout-canary`. The auditor recognizes three
policy annotations by default:

- `data-layout-ignore` excludes a complete subtree.
- `data-layout-allow="overflow-x overflow-y escape-x escape-y"` records
  intentional geometry; `escape` permits both axes.
- `data-layout-must-fit` requires the element's full horizontal content to
  remain visible even when ordinary overflow is allowed.

The nearest enclosing `data-testid` becomes the stable location in each fault.
Options can replace the annotation and location names or supply measurement
adapters for contract tests.

**UI proof gate.** A green component or jsdom suite says nothing about the
route a user actually opens, and "done" claims backed by nothing else were the
audit's largest automatable failure cluster. When a consumer commits a
`wrsp-ui-proof.json` policy file at the repository root —
`{ "pathPatterns": ["^src/components/", "\\.css$"], "proofDirectory":
".wrsp/ui-proof" }` (proofDirectory optional) — a candidate whose diff
touches any matching path cannot reach review without at least one valid,
fresh UI proof record: a JSON file in the proof directory of the form
`{ "version": 1, "issue": "861", "route": "/studio/shows/new", "operation":
"Create a three-scene Show and play it through", "captures":
["docs/proof/new-show.png"], "capturedAtCommit": "<full commit id>" }`.
Records and captures are read from the candidate tip's tree, never the live
filesystem — an untracked file or a path outside the repository cannot
satisfy a gate whose approval covers the exact range. Captures must carry
real screenshot or recording bytes (PNG, JPEG, WebM, or MP4 magic bytes) — a
passing test run has no such artifact to point at. The record doubles as the
proof attached to the issue.

Freshness binds proof to content: `capturedAtCommit` must be a full immutable
commit id (a ref like `HEAD` would re-resolve to every future tip) that is an
ancestor of (or equal to) the candidate tip, with no UI-pattern path changed
since; diffs run rename-blind so renaming a matched file away still counts as
changing it. Only the record files themselves and captures validated as real
capture bytes are exempt from counting as UI-affecting changes — a rejected
record's claimed "captures" stay in the triggering set — so committing honest
proof cannot trigger the gate or mark the proof stale, and dishonest records
cannot erase the paths that triggered it. The normal flow is capture at the
implementation commit, then commit the record and captures as the tip. A
stale or malformed record is reported but does not veto a separate valid
fresh record; everything ambiguous fails closed.

Policy binds to the range, not the checkout — and it is deliberately a
pure-data file rather than a `wrsp.config.mjs` section, because the gate
must evaluate policy at historical revisions and executable configuration
cannot be trusted there: code controls its own output and serialization,
reads files that resolve against the wrong revision, and cannot be
faithfully materialized. The gate reads `wrsp-ui-proof.json` as a blob from
BOTH ends of the range and gates the candidate under the union, so a range
that narrows or deletes the policy is still held to the policy it started
from, while policy changes stay reviewable as ordinary candidates. A policy
file that exists but cannot be read or parsed fails closed; whatever branch
the check happens to run from can never substitute its own patterns.
`wrsp-review-candidate` enforces the gate before taking the review lock;
`wrsp-check-ui-proof <base> <tip>` runs the same check standalone for
self-checks and hooks.

**Exported-artifact oracle.** Generator-internal assertions cannot prove that
the file a consumer opens contains the intended result. Consumer oracle tests
call `runArtifactOracle` with the real export entrypoint and assertions over
the exported bytes. The helper rejects a missing or empty export, reads the
file before invoking those assertions, then emits one versioned report naming
the deliverable and recording its path, byte count, and sha256 digest.

`wrsp-check-artifact-oracle` runs every configured deliverable test, using the
built-in Vitest/basic command unless that deliverable names a specialized
runner. Each command must exit zero and emit exactly one valid report whose
name matches the configured deliverable and whose byte count is positive.
Command errors and nonzero exits, absent, duplicate, malformed, mismatched, or
zero-byte reports all produce a per-deliverable failure. The checker evaluates
every deliverable before failing the gate, so one broken export cannot hide
another. Consumers import the Node-safe helper through
`@whiteroom/software-process/artifact-oracle`.

**Suite meta-checks.** `wrsp-check-e2e-coverage` fails when an authenticated
Playwright spec is named by no npm script — an unrun spec is indistinguishable
from a passing one. `wrsp-check-e2e-locators` fails when a spec names a
user-facing string live source no longer produces, with a shrink-only ratchet
for known staleness and a separate never-gating bucket for names assembled
mostly from runtime data.

**Environment preflight.** A probe that fails inside an agent sandbox is not
evidence about host state, and the audit counted seven "gh auth is broken /
the network is down" claims manufactured exactly that way. `wrsp-preflight
blocker <gh-auth|network> [--host]` runs a sandbox canary first — an
attempted write outside the workspace root, which agent sandboxes deny — and
a denied canary yields `SANDBOX-LOCAL` (exit 3) regardless of the probe
result and regardless of `--host`: the canary is direct evidence of a
sandbox, so it vetoes a mistaken attestation. A passing probe is `HOST OK`
(a real success is real anywhere). A failing probe is promoted to
`HOST FAILURE` only under an explicit `--host` attestation that the shell
runs unsandboxed — a write canary proves only filesystem freedom, and a
sandbox can allow the write while still blocking network or credential
access — otherwise the verdict is `INDETERMINATE` (exit 3) with the
re-run-elevated instruction, so no blocker claim reaches the user on
sandbox-shaped evidence. `wrsp-preflight
worktree` refuses substantive work started in the shared checkout (a linked
worktree's git dir differs from the common dir — mechanical, no path
conventions), and `wrsp-preflight port <n>` reports the owning process of a
port collision before a dev server claims it, instead of after the second
server wedges the first.

**Closed-issue proof check.** Issues name their required proof at planning
time (a `## Required proof` section: which surface, which cases) and attach
the evidence before close. `wrsp-check-issue-proof [--since-days N]` makes
the closure half mechanical: every issue closed as completed in the window
must have a non-empty `## Required proof` section and an attached proof — a
line beginning `Proof:` with content, in the body or any comment. Issues
closed as not planned are exempt. The check exits nonzero listing each
violating issue, so it runs standalone, in CI, or as a periodic sweep. It
proves a proof was attached, not that it is honest or sufficient — that
stays with candidate review. It is a best-effort audit report over an
eventually consistent tracker API: every detectable inconsistency —
truncated listings, unstable or duplicate-bearing pagination walks,
malformed timestamps, unknown arguments — fails closed, but transactional
completeness against concurrent tracker mutation is impossible over this
API and is not claimed; a closure racing one run is caught by the next
sweep.

## Adoption

Adopt executable WRSP tooling from the vendored release tarball. Adopt process
guidance and templates from the same tagged source: start with
[`templates/engineering-contract.md`](templates/engineering-contract.md), put
current contracts under the consumer's reference tree, and point project
instructions to the applicable contracts. The
[engineering-contract guidance and distribution manifest](docs/reference/engineering-contracts.md#adoption-and-distribution-manifest)
records the canonical shared-skill sources and their separate deployment path.

1. **Install** from a vendored release tarball. In this repository, at the
   release tag, run `npm pack` and commit the tarball into the consumer
   (e.g. `vendor/whiteroom-software-process-0.4.0.tgz`):

   ```json
   "devDependencies": {
     "@whiteroom/software-process": "file:vendor/whiteroom-software-process-0.4.0.tgz"
   }
   ```

   A `file:` tarball needs no credentials, so clean `npm ci` succeeds in
   unauthenticated builders — CI runners and git-integrated deploy builds
   (Cloudflare Pages) included. A `github:...#tag` pin on this private
   repository works only where GitHub credentials are available and will
   break any unauthenticated build; use it for local-only experiments, not
   for a repository that deploys. Upgrading is replacing the tarball and
   updating the pinned filename. Add the repository to the Consumers list in
   this package's `AGENTS.md` in the same change that vendors the first
   tarball — that list is how releases find every repository needing a bump.

2. **Configure** with an optional `wrsp.config.mjs` at the repository root.
   Every section is optional; defaults suit a plain TypeScript repository.

   ```js
   export default {
     review: {
       // Appended to the review prompt. Participates in the policy
       // fingerprint: receipts retain the policy used for their review.
       projectPolicy: 'Project-specific reviewer instructions.',
     },
     selection: {
       typecheckExact: ['vite.config.ts'],
       typecheckPatterns: ['^src/.*\\.[cm]?[jt]sx?$'],
       typecheckArgs: ['tsc', '-b', 'tsconfig.json', '--pretty', 'false'],
       runners: {
         layout: ['npm', 'run', 'test:layout', '--'],
         node: ['node', '--test'],
       },
       boundaries: [
         {
           name: 'compiler',
           exact: ['src/engine/compiler.ts'],
           prefixes: ['src/engine/passes/'],
           tests: ['src/engine/compiler.test.ts'],
         },
         {
           name: 'controller-layout',
           exact: ['src/components/ControllerPanel.tsx'],
           tests: ['src/components/ControllerPanel.layout.test.tsx'],
           runner: 'layout',
         },
       ],
       advisories: [{
         name: 'unmapped-layout-change',
         pathPatterns: ['^src/.*\\.(tsx|css)$'],
         // Regexes inspect staged additions and deletions.
         diffPatterns: ['(?:flex|grid|min-w-|overflow-|truncate)'],
         message: 'Add the affected surface to the layout manifest.',
       }],
     },
     layout: {
       runner: 'layout',
       canaryTest: 'src/test/layout-canary.layout.test.ts',
     },
     artifacts: {
       deliverables: [
         {
           name: 'show-export',
           test: 'src/export/show-export.oracle.test.ts',
           runner: 'node',
         },
       ],
     },
     e2e: {
       specDirectory: 'e2e',
       authSpecSuffix: '.auth.spec.ts',
       staleLocatorAllowlist: 'e2e/known-stale-locators.json',
       liveSourceDirectory: 'src',
     },
   }
   ```

3. **Wire npm scripts** to the bins, keeping the canonical names:

   ```json
   "review:candidate": "wrsp-check-node && wrsp-review-candidate",
   "review:status": "wrsp-check-node && wrsp-review-status",
   "review:push": "wrsp-check-node && wrsp-review-push",
   "test:staged": "wrsp-check-node && wrsp-test-staged",
   "check:artifact-oracle": "wrsp-check-artifact-oracle",
   "check:layout-gate": "wrsp-check-layout-gate",
   "check:ui-proof": "wrsp-check-ui-proof",
   "check:e2e-coverage": "wrsp-check-e2e-coverage",
   "check:e2e-locators": "wrsp-check-e2e-locators"
   ```

   The consumer canary test must match the configured real-browser project:

   ```ts
   import { expect, it } from 'vitest'
   import {
     assertLayoutCanaryReport,
     formatLayoutCanaryReport,
     runLayoutCanary,
   } from '@whiteroom/software-process/layout-canary'

   it('proves the layout runner can measure', () => {
     const report = runLayoutCanary()
     console.log(formatLayoutCanaryReport(report))
     expect(assertLayoutCanaryReport(report)).toBe(report)
   })
   ```

   Add a consumer-owned sentinel that asserts a production CSS utility's
   computed geometry after `document.fonts.ready`. The package canary's inline
   styles prove browser measurement, not product stylesheet fidelity.

4. **Install hooks** from `hooks/` into `.husky/` (or your hook manager),
   adjusting publication checks to the repository. For runner-enabled
   consumers, declare required suites and have pre-push check their exact-tip
   evidence. Keep the [verification plan](docs/reference/local-runner.md#verification-plan)
   aligned with the actual hook; copying a hook does not wire evidence reuse.

5. **Round-trip once**: commit on a branch, run
   `npm run review:candidate -- <base> <tip>`, confirm the receipt with
   `npm run review:status -- <base> <tip>`, land with `git merge --ff-only`,
   and push through the gate.

## Development

`npm test` runs the package's own suite. The repository dogfoods its own gate:
commits are reviewed through `npm run review:candidate` and pushes pass
through the evidence-consuming `.husky/pre-push`. The generic `hooks/pre-push`
template retains direct local tests for consumers that have not adopted runner
evidence.

### Reusable authenticated captures

Consumers can import `captureScenario` from
`@whiteroom/software-process/capture-scenario` and supply their maintained
browser adapter. A named scenario declares route, viewport, synthetic session,
distinct device count and visible prerequisites. WRSP checks those observations
around capture and writes an external, copy-ready package containing the current
UI proof record and PNG. Inspect it, commit its proof files, then run authoritative
verification on the final clean tip. See the
[capture scenario contract](docs/reference/contracts/capture-scenarios.md) for
adapter ownership, failure cleanup and the unchanged proof boundary.
