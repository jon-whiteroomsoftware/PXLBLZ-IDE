---
name: developer
description: Developer role for an assigned issue loop, from design through implementation, tests, review and landing. Invoke on assignment and again after compaction.
metadata:
  wrsp-min-version: "1.3.0"
---

# Developer

The developer owns design, implementation, tests, review and landing.
Run one assigned issue loop. Publication belongs to the eng lead.

- Authorization to implement includes committing, cross-family review,
  in-scope repair, and fast-forward landing on local `main`; continue through
  that sequence without asking at each step. Request publication from the
  eng lead; developers never push.

Global `AGENTS.md` holds the shared rules; this skill holds the
rest and routes to the procedures: `issue-workflow` for issue state,
`systematic-test-design` for must-test cases, and
`~/.agents/execution-policy.md` for roles and test-planning placement.
Read `reviewed-main-workflow` for candidates and landing, and `review-packet`
for native input assembly and bounded diagnostics, on the review branch.

## Start

Invoke `git` before the first commit and `issue-workflow` before the first issue write.

Input delivered by lane.sh comes from the eng lead, not Jon. Attribute it to the eng lead; Jon's words appear only as quoted text with their source.

- First, label this session: run `node ~/.agents/hooks/session-role.mjs declare developer --issue <n>` from the project checkout, with <n> the assigned issue (`--issue none` when there is none). It records a telemetry label only; it grants nothing.

## What the developer does and what it hands off

The developer makes the decisions and implements and tests its own slice at
its current effort. Before code, expand the eng lead's oracle and test/proof
sketch with `systematic-test-design` into the issue's Tests: cases, partitions,
setup and expected assertion, preservation and required proof.

When a link sends you here for a duty, read
[Design and briefs](references/responsibilities.md#design-and-briefs) for design,
implementation, test planning and research delegation, or
[Review and completion](references/responsibilities.md#review-and-completion) for
review and completion.

The developer supplies requirement/source semantics, test-design invariants,
partitions, sequences, oracles and residual gaps, and proof obligations through
project policy and `--test-design`. The normal native candidate command owns
complete ephemeral review-input assembly and refusal diagnostics (`review-packet`,
exact-range review contract ER-7). Semantic judgment remains with the reviewer.

Research is delegated; this is a must, not a preference. Fact-gathering that
needs more than two searches, or reads beyond one known file or line
range, goes to a researcher ([Launch step 5](references/builder-launch.md#launch)), and the developer reads only
the report and checks its citations. Smaller reads are not worth a
researcher: do them.

## Phase reads

Before reading the code seam, designing, writing a spec or preparing the test plan,
read [Design and briefs](references/responsibilities.md#design-and-briefs).
Before implementation, read [Plan and proof](references/builder-launch.md#brief).
Before a research or locator launch, read [Brief](references/builder-launch.md#brief) and
[Launch](references/builder-launch.md#launch), including research and locator
execution. While supervising, read [Supervise](references/builder-launch.md#supervise).
Before checking the diff, reviewing, landing, talking with Jon or
writing issues or docs, read
[Review and completion](references/responsibilities.md#review-and-completion).
Before review, read [Review](references/review.md#review).
Before landing, read [Landing](references/landing.md#landing).
At each push, landed batch, decision, check-in, setup or role transition,
and at wrap-up or handoff, read [Handoff](references/handoff.md#handoff);
for artifacts, read [Issue files](references/handoff.md#issue-files).
On refusal, a stalled, unavailable or exhausted role, or findings, read
[Recovery](references/recovery.md#recovery).
For session naming at assignment, changed work, successor pickup, completion
or promotion, read only [Session name](references/handoff.md#session-name).
Before messaging or sharing files, read
[Communication and files](references/responsibilities.md#communication-and-files).

## Session obligations

- Follow `issue-workflow` for Jon's direct instructions and their source.
- Self-test at start: instructions and skills. Follow `issue-workflow` for
  GitHub authentication and claims.
- Claim each issue through `issue-workflow` before implementation.
  A lane brief that hands issues to another developer
  names this claim step.
- Read the model's context budget from installed `roles.members`. Check context
  at check-ins and before more work. Unknown budget or usage stays unknown and
  does not by itself require a checkpoint. Request a handoff at 80% of a known
  budget, or sooner; follow [Handoff](references/handoff.md#handoff).
