# Handoff

Wrap-up: replace `WIP` with `📦 implemented`, commits in body; check
attribution, propose a work-type label and ask before applying; attach proof
before close. Eng-lead check-in, setup and role transitions belong to
`~/.agents/skills/eng-lead/references/operations.md`.

At each push, landed batch or decision, update the issue body through
`issue-workflow`. On request, finish the atomic step, record exact state/live
handles, give a pickup and obtain successor acknowledgment before retirement.

Writers use [pickup-template.md](pickup-template.md) and
[stop-report-template.md](stop-report-template.md). Give successors only the
filled pickup: self-contained, <=800 words, current issue body target <=800
including pickup. Replace prior pickups and history with links; preserve scope,
criteria and source. Read exact references at their phase (#413).

## Session name

| Role | Emoji |
|---|---|
| Eng lead | 👽 |
| Developer | 👩‍💻 |
| Reviewer | 👀 |
| Researcher | 🔬 |
| Locator | 🔍 |
| Lander | 🛬 |
| UX principal | 👩‍🎤 |
| Principal engineer | 🧙 |
| Batch | 🤖 |
| Done | 💀 (replaces the role emoji when the thread is finished) |

Emoji per Jon, 2026-10-19 (#197).
1.0 roles and icons per Jon, 2026-10-20 (#240).
Lander icon per Jon, 2026-10-21 (#275).
Principal engineer icon per Jon, 2026-10-21 (#298).

- Shape: `<emoji>[ <Lane>]: <task>[ #issues]`. The colon appears only after a
  lane letter: `👽 Agent Mini migration #174 #196 #197`,
  `👩‍💻 G: event capture #196`,
  `💀 F: laptop ledger #192`.
- Rename on assignment, changed work, successor pickup, and completion.
  Done replaces the role emoji with 💀 and preserves task text. Promotion replaces 👩‍💻 with 👽.

## Issue files

Briefs, plans, designs and proofs for an issue live in a folder named
`<issue>-<slug>` in a Files root. The folder's top level holds only what is
current: what Jon should read now.

- When you replace a deliverable, move the old one to `history/`, keeping
  its file name. Move an HTML page together with the images it references.
- Logs, prompts and `.exit`, `.live` and `.pid` sidecars go to `work/`.
- No other subfolders.
- Link Jon to the Files page as global `AGENTS.md` (Environment) gives it,
  never to a bare path.

`wrsp-agents check` prints a `layout:` line for a working file at the top
level or a subfolder other than `history/` and `work/`.
