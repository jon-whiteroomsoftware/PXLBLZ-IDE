# Developer responsibilities

## Design and briefs

The developer does these itself and never hands them off:

- Reads the spec and the code at the seam the change touches. Search
  first, then the exact files and line ranges it names.
- Chooses the approach: which module, which function, which data shape,
  which refusal message, which tests.
- Before code, expands the eng lead's oracle and at-most-10-bullet test/proof
  sketch with `systematic-test-design` into the issue's Tests. Record cases,
  partitions, setup and expected assertions. Name exact files/functions and
  signatures, data mapping, current behavior by file:line, refusal codes/messages,
  and the implementation skeleton. New tests cite an existing exemplar and helper
  signatures. Include preserved contract clauses/outputs, red/green commands,
  consumer proof, host-only checks and log destinations. Link large detail from
  the body. Unresolved design goes to Jon before implementation.
- Writes an interface when a split needs one: types, signatures, empty
  bodies, test names. Then implements the bodies and callers in shippable slices.
- Implements, tests and repairs its own slice at its current effort.

The developer hands off these:

- Gathering facts. A research brief asks questions with factual answers and
  cited paths: where is this called, what does this return, which tests
  cover it. The developer checks the citations before designing from
  them.
- Mechanical bulk: transcript mining and suite runs on the runner.

The developer never hands off a decision. A brief or research request that
asks how something should work, whether to do it, or which option to take
has handed off design. The test is whether the researcher could answer with a
design instead of a fact.

- Specs are rich: limits, mock-ups for UI, must-test cases, exact change
  locations, required proof. Invariants quantify over domains we control; an
  open-domain invariant declares its shape.

## Review and completion

The developer does these itself and never hands them off:

- Checks the diff against the issue and its plan; any departure is a finding.
  Runs cross-family reviews. Lands. Talks
  with Jon. Writes issues and docs.

## Communication and files

- Never hand Jon a bare file path. Share a file the way global `AGENTS.md`
  (Environment) says; where it names no Files link, link a pushed file or
  publish the content on the issue.

- Never message a laptop session. The laptop refuses peer messages (#169);
  reach Jon through the issue or an Agent Mini session.
