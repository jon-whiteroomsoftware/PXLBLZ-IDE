---
name: blind-spot-check
description: Audit strategic/technical plans for the most consequential blind spot, load-bearing assumption and weakest-supported conclusion. Use after substantial planning, before committing, or when Jon asks what is missing, doubtful, inverted, reframed or stress-tested.
metadata:
  wrsp-min-version: "1.3.0"
---

# Blind Spot Check

Audit the current conversation, plan and available artifacts using existing
context; do not ask Jon to restate the plan. Keep this end-of-planning check
concise; avoid comprehensive risk registers or extended interviews.

## What to look for

Blind spots hide among load-bearing assumptions, omitted actors or
dependencies, irreversible choices, sequencing and feedback problems,
opportunity costs, operational burden, and failure despite competent
execution. Report only the strongest, judged by consequence, plausibility and
how little attention it received. If misunderstanding the objective,
approach or important constraints would invalidate the audit, say so;
do not fabricate confidence.

Interrogate its underlying belief: what the plan treats as true,
what is known versus inferred, what evidence could disprove it, how believing
it shapes choices or hides alternatives, and what plan emerges if it cannot be
relied on or its opposite is true.

## Response

### Biggest thing you may be missing

Make one direct claim. Explain why it matters, identify the belief the
plan requires, and show what changes when the plan cannot depend on it.

### What I am least confident about

Complete: "I am least confident that..." Explain why, distinguish evidence from
inference, and name what information would materially change the assessment.
Say whether the uncertainty comes from missing facts, ambiguous goals, an
untested assumption, an external dependency, or inherent unpredictability.

### Best next move

Give one question, experiment or decision that most improves the plan or
reduces the important uncertainty. Prefer the smallest effective action.

## Rules

- Prefer one deep observation over an inventory of generic risks.
- Separate known facts, inferences, and speculation.
- Do not confuse an unknown claim with a false one.
- Do not manufacture novelty or reopen settled decisions without material cause.
- If no major blind spot is apparent, say so and report the largest residual risk.
- Critique the plan, not Jon. Recommend investigation before wholesale change.
