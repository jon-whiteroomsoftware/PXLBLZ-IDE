---
name: reviewed-main-workflow
description: Clean-main/worktree delivery with bounded exact-range review admission, fast-forward landing, reusable approvals and gated publication. Use for substantive implementation, concurrent-agent coordination, candidate preparation/review, main landing or push in reviewed-main repositories.
metadata:
  wrsp-min-version: "1.3.0"
---

# Reviewed Main Workflow

## Governing model

Invoke `git` for staging, commits, worktree setup and review freshness;
invoke `issue-workflow` before GitHub writes and issue-state changes.

Keep the shared checkout clean; local `main` is for reviewed integration, never implementation.
Implement substantive vertical slices on short-lived worktree branches.

Implement concurrently. `review.concurrency` bounds review admission (default 1,
serialized); opted-in repositories may admit independent siblings up to capacity.
Follow `git` for freshness/checkout stability. Serialize landings; check coverage
from current main first. WRSP's
[ER-2](~/src/whiteroom-software-process/docs/reference/contracts/exact-range-review.md#invariants) owns
freshness and [ER-6](~/src/whiteroom-software-process/docs/reference/contracts/exact-range-review.md#invariants)
owns carry eligibility.

Repository commands, receipt format, deployment target and issue workflow
override these examples.

For Git/GitHub failures, apply the global failure-scope rule and
`~/.agents/execution-policy.md`, **Route failures**. Repair, landing and
publication duties below remain role-owned.

## Start a slice

1. Verify the shared checkout is clean, on `main`, and synchronized with the intended reviewed base; follow `git` for worktree readiness.
2. Read the engineering contracts applicable to the changed seams. Record
   preserved, changed, or proposed obligations in the issue's docs impact.
3. Claim the issue through `issue-workflow` before substantial work.
4. Prepare the isolated worktree through `git`.
5. Name tasks `#<issue> <short task> [<actual port>]`; omit unallocated ports.
   With a runtime coordinator, use its explicit shared/isolated profile,
   allocated port and lifecycle status/release operations.
6. Implement, test, and commit only in that worktree. Update an affected
   contract and its interface evidence in the same slice as an authorized
   behavior change.
7. Keep dependent work stacked on its unreviewed base; start unrelated work from
   the latest reviewed `main`.

If implementation begins accidentally in the shared checkout, preserve the
complete state in the correct worktree before restoring clean `main`.

## Prepare the candidate

1. Request admission through `~/.agents/skills/eng-lead/references/landing-queue.md`.
   Start only on explicit go for the lane/issue; independent siblings may review
   concurrently within capacity.
2. Follow `git` for pre-review freshness and approved-range stability.
3. Resolve the final base and tip commit identities.
4. Run focused verification and repository-required fault-sensitive checks.
   Identify final full suites/owner from the verification guide. Run full suites
   on the runner host with `wrsp-runner test <tip>`, never locally on an agent
   host. The eng lead submits/collects final publication suites at the frozen
   tip; later gates consume matching records. Preserve repository requirements
   to finish those suites before landing.
5. Compare changed behavior with applicable contract clauses. Check that claims
   match observable evidence and that overview reference does not duplicate
   specialist obligations.
6. When `systematic-test-design` applies, supply its invariants, partitions,
   representative sequences, oracles, and residual gaps as semantic arrays via
   `--test-design <json>`. Supply requirement/source and proof semantics through
   project policy and that context. `review-packet` points to native assembly
   and bounded diagnostics under the exact-range review contract ER-7; stop
   the affected action on a concrete native refusal.
7. Run the repository's explicit-range candidate review, for example:

   ```bash
   npm run review:candidate -- <base> <tip> [--test-design <json>]
   ```

For Jon's explicit supported same-family reviewer on one exact candidate, use
the repository's explicit model/effort pair, `--allow-same-family` and nonblank
`--override-reason` without duplicate permission. This changes only that
candidate's reviewer eligibility. Never infer it from provider unavailability,
apply it to mixed-family candidates or carry it to rewritten ranges. Proof,
test, landing and publication gates stay independent.

P0/P1 withholds candidate approval. Within scope, repair the defect class, verify,
commit and review the replacement exact range while reviews converge, without
fresh permission. Keep the failed candidate unlanded.

Classify the actual outcome rather than the word "BLOCKED" or exit code 1:
P0/P1 findings require repair; P2/P3-only findings use advisory coverage below.
Route and authority failures follow **Governing model**. Never bypass a
protection or treat missing review evidence as approval.

## Review while UI proof is pending

When installed support permits deferred UI proof, follow the exact-range review
contract to review code while captures are produced. Keep the code commit and
native pending-record identity unchanged. Pending review grants no landing or
publication approval.

Complete through supported proof-only attachment; the proof reviewer inspects
actual capture bytes and final coverage records both stages. Unsupported source,
policy or test-design changes need normal review. Preserve original pending
records/capture identities after failed completion. Final suites bind to the
final committed tip.

A `contract-infeasible` result requires discussion of the named requirement,
unsupported domain, and bounded rescope with Jon. It creates no approval and
does not authorize automatic rescoping or another reviewer to seek a different
judgment. Missing proof remains a prerequisite, not contract infeasibility.

## Land early, land often

When `main` moves, eligible approved ranges can carry; other new identities
need fresh review, which can reopen findings closed by earlier per-range reviews.

When repository policy records advisory-grade findings (for example P2/P3) as
non-terminal coverage, land the reviewed tip immediately on that receipt and
carry each corrective as a new, small candidate cut from the landed main.
Hold a chain unlanded only for terminal findings that block approval outright.

Satisfy publication's clean-tail requirement with a short corrective on main,
rather than repeated corrections on an unlanded chain.

## Non-convergence is a stop point

After three consecutive P0/P1 reviews on one lineage, pause before a fourth and
discuss the invariant, approach or enforcement layer with Jon, even if finding
counts fall. Never reset the lineage or automatically acknowledge the breaker
to evade this threshold.

Below threshold, continue authorized repairs with evidence of progress: covered
previous failures, correction of the underlying cause and narrowing findings.
Fewer findings alone do not prove convergence; surface repeated unsound approaches
earlier. P2/P3-only results follow advisory landing and end the blocking streak.
Repeated advisory corrections or prerequisite/setup failures still require
assessment: what changed, what remains unproved, why retry should help. On
stalled progress, preserve evidence and discuss changing approach, narrowing
scope or deferral with Jon. Gates remain; no automatic waiver. Pause independent
work only if it shares the blocker.

## Land without invalidating approval

When an assigned lander owns an accepted candidate, follow the developer/lander
handoff procedure. Otherwise the developer lands locally:

1. Resolve current local `main` and the candidate tip. Inspect contiguous
   coverage from that main to the tip with the repository's `review:status`
   command, for example `npm run review:status -- <main-sha> <tip>`.
   Preserve clean/advisory eligibility under the role's existing policy.
   Queue go alone grants no coverage. If main moved and coverage no longer
   matches, use eligible carry or fresh review for the new identities.
   A failed carry is not approval; fresh review takes queue admission.
   The repository's exact-range review contract
   ([ER-6 in WRSP](~/src/whiteroom-software-process/docs/reference/contracts/exact-range-review.md#invariants))
   owns carry eligibility.
2. In the clean shared checkout with `main` checked out, run `wrsp-land <tip>`;
   in WRSP's source checkout, run `npm run land -- <tip>`. The command
   takes shared `review.lock` in every mode. At concurrency 1 it excludes
   reviews and landings together; at concurrency > 1, numbered reviews
   continue independently.
   It does not check coverage; the preceding inspection is required.

| Result | Action |
| --- | --- |
| `LANDED main=<sha>` | Verify the intended reviewed tip is reachable from local main, then report the landing. |
| usage, exit 64 | Correct the invocation to one supported tip argument. |
| `LAND REFUSED: HEAD is not branch main` | Use the shared checkout on main; preserve unrelated state. |
| `LAND REFUSED: checkout is not clean` | Preserve and resolve that checkout's dirty state with its owner; do not discard another lane's work. |
| `LAND REFUSED: unknown tip ...` | Resolve the intended existing candidate commit and its coverage before retrying. |
| `LAND REFUSED: ... is not a fast-forward of main` | Reconcile the moved main with the candidate using eligible carry or fresh review, then recheck coverage. |
| exit 75 `LAND DEFERRED` naming a live lock holder | Record `review.lock` and its holder/state in every mode. The holder can be a legacy/default reviewer or a lander. Defer until that exact holder finishes, then recheck main, tip and coverage and retry normally. |
| abandoned/ownerless lock diagnostic | Stop and report the diagnostic. Locks are never reaped; follow its exact cleanup command for the named lock only after confirming its owning process is no longer running. |
| another lock-acquisition error, or `LAND REFUSED: fast-forward failed: ...` | Stop this landing, preserve the exact diagnostic, and reconcile actual main, candidate and checkout state with the eng lead. Retry only after the diagnosed cause is resolved and coverage is rechecked; an error code alone supplies no recovery or bypass authority. |

No raw Git fallback after refusal or deferral.

Changed commit identities or content require new review or the repository's
eligible carry path. In WRSP, later reviewer or policy changes preserve valid
native approvals under their recorded policy; never rewrite their provenance.

After landing, follow existing lifecycles for disposable slice/worker worktrees;
headless developers retain lane worktrees until retirement (developer skill,
Session). Update the issue with commits, tests, docs and remaining risk. Close
only once the reviewed tip is reachable from `main`; commits alone are progress.

## Publish

Hand publication needs, findings, and known job handles to the eng lead.
Developers never push. Follow
`~/.agents/skills/eng-lead/references/landing-queue.md` and
`~/.agents/skills/eng-lead/references/operator-acceptance.md` for publication
and authorization; those references own the shared procedures.

Inspect approval coverage before pushing when the repository provides a status
command:

```bash
npm run review:status -- <remote-base> <local-tip>
```

Pre-push must require current approval or a contiguous approval chain for each
exact outgoing ref update. Missing/stale/rewritten/gapped coverage blocks
publication without repeating review of approved work. Then enforce repository
publication gates. For hooks consuming authoritative runner evidence, collect
required full suites once at the final tip; let the hook inspect records. If
hooks execute full suites, let them own execution. Changed tips/evidence
identities need fresh results; focused retries cannot replace missing full-suite
evidence. Resume known jobs after collection failure before submitting more.

A failed publication check blocks the push. For a repairable test failure or
missing/stale approval, repair the cause and satisfy the required checks before
retrying publication within existing authorization. Route and authority failures
follow **Governing model**; failed checks supply no passing proof.
