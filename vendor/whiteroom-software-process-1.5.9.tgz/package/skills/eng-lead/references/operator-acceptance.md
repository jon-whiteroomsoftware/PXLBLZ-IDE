# Record Jon's authorization

Record Jon's explicit words for the exact inspected scope. Recording authority
does not decide to accept risk. The operator-authorization contract controls
eligibility, immutable records, expiry, revocation, and reuse.

| Purpose | Who records | Inspect / record |
| --- | --- | --- |
| Publication findings | Eng lead | `inspect <base> <tip>` / `accept <request.json>` |
| Missing-review coverage | Eng lead | `inspect-coverage <base> <tip>` / `accept-coverage <request.json>` |
| Named-suite waiver | Eng lead | `suite-inspect <tip>` / `suite-accept <request.json>` |
| Diverged candidate review | Developer | `inspect-freshness <base> <tip>` / `accept-freshness <request.json>` |
| One more non-converged attempt | Developer | `inspect-non-convergence <base> <tip>` / `accept-non-convergence <request.json>` |
| Mixed-family review admission | Developer | Supported mixed-family admission interface when enabled. |

Named verbs above belong to `wrsp-operator-authorization`. Mixed-family admission
has library validators and no production recording path.
For normal mixed-family review, follow the installed repository's supported
path (WRSP: `docs/reference/contracts/exact-range-review.md`, ER-3).

1. The responsible role resolves full IDs and runs the matching inspection.
   For publication, use the frozen checkout. Read eligibility, scope, existing
   permission, and required identities. For suites, read command, digest, and
   versions; for freshness, current main; for non-convergence, lineage facts.
2. Reuse authority the evaluator already matches. Cite its record and source.
   Do not ask Jon to repeat an explicit instruction. Missing authority is not
   implied by a role grant, queue go, a fix, or a general wish for autonomy.
3. Present the remaining exact scope and facts to Jon unless their existing words
   cover them. A lane forwards a direct instruction verbatim, with source, to the
   responsible recorder. Publish content or links, never bare Mini paths.
4. Copy Jon's words verbatim into the request. Set `actor` to Jon; include the
   inspected base/tip or `tipSha`/`suiteName`, all adapter-required fields,
   `instruction`, `source`, and actual `reason`. Findings require all inspected
   `sourceIds` and `findingIds`. Freshness requires `mainTipSha`; non-convergence
   requires `lineageRound`, `previousOutcomeId`, and `terminalStreak`. Use
   structured file writes and treat their text as data.
5. The responsible role runs the matching record verb. Keep its immutable ID.
   Reinspect that scope and confirm permission. Log ID, source, and scope on the
   issue and in the review or publication log. Supported mixed-family admission
   must precede the first sub-review and bind its family set and reviewer choices.
6. Continue only the authorized action. Publication records do not authorize
   candidate review. Review-loop records do not authorize publication or reset
   history. A suite waiver leaves the suite missing/failed/stale, never passed.

If inspection refuses, keep its reason and repair or discuss the prerequisite.
Never replace known findings with a missing-review waiver. Pending reviews,
count-only history, changed findings, new commits, policy changes, main movement,
or consumed attempts need the contract's remedy and fresh inspection. Acceptance
supplies no passing tests, clean receipt, or general release approval. Hold
affected publication while independent lanes continue.
