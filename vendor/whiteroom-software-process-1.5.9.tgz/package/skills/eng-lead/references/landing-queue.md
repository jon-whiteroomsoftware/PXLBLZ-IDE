# Landing queue

## Contents

- [Landing broadcast (#300)](#landing-broadcast-300)
- [Hot files (#300)](#hot-files-300)
- [Lander (#275)](#lander-275)
- [Round limit (#238)](#round-limit-238)
- [Publication](#publication)

The eng lead admits up to `review.concurrency` holders per project: a safe
integer >= 1, default 1, without an extra quota. Developers review and
fast-forward their candidates; landings stay
serialized. Receipts remain the landing authority. Scheduling changes neither
receipt format, fingerprint, reviewer selection nor
[ER-6 carry authority](../../../docs/reference/contracts/exact-range-review.md#invariants).

1. The developer sends `X review start base..tip` with full commit IDs, issue,
   worktree, and any review in flight. This requests a slot, not permission to run.
2. The eng lead records each holder independently and keeps a waiting list.
   Reconcile `lane.sh check`'s `review-request` signal when it appears, even
   while that lane's turn continues; never wait for all developer turns to end.
   When capacity exists, reply `go` naming the waiting lane and issue. A go
   admits that lane for that issue, not an exact range (#300). A transport
   receipt is not go; a waiting lane never self-grants admission.
3. Follow `git` for pre-review rebase and freshness. Go admits the lane/issue;
   rewritten unreviewed IDs need no new request or go. A rebase conflict
   keeps the slot only while the holder resolves it promptly, in the same
   turn; otherwise the holder sends `done` unreviewed and the slot is released.
   Resolve final IDs, verify, and run exact-range review. Follow `git` for the
   fixed checkout/range during review, grounded in
   [ER-2 freshness](../../../docs/reference/contracts/exact-range-review.md#invariants).
4. Follow reviewed-main-workflow. P0/P1 stays unlanded. A clean or advisory receipt
   permits local fast-forward landing under that contract. Check that a
   contiguous receipt chain from the current main covers the tip, direct or
   carried (`review:status <main> <tip>`). A successful receipt binds the
   reviewed identities. A disjoint content-identical rebase can use ER-6 carry;
   overlap requires fresh review and admission. Neither go nor available
   capacity waives receipt or coverage requirements.
5. Send `X review done tip` with the final reviewed range, landed tips,
   receipt/outcome, findings, corrective work, and publication needs. A failed review also sends
   done, explicitly unlanded. The eng lead acknowledges done and releases only
   that holder's slot. Corrections rejoin the queue.
6. On interruption or missing acknowledgment, preserve the affected holder.
   Recover its actual review process and main state before release; other
   holders remain independently tracked. Elapsed time never proves release.
   Duplicate requests or done messages have no second effect.

With concurrency 1, native review and landing share exclusive legacy
`review.lock`. With concurrency N > 1, reviews take `review.lock.1` through
`review.lock.N`; every landing still takes legacy `review.lock`, independently
of numbered slots. Legacy review/land holders block new landing; new landing
blocks legacy review/land. Receipt-file and telemetry-note writes take the short
`receipt-write.lock`. All locks retain mkdir ownership and are never reaped.
Follow the diagnostic's exact cleanup command for that named lock only after
confirming its owner is gone. The [exact-range review contract](../../../docs/reference/contracts/exact-range-review.md)
owns the full lock agreement and freshness rules.

## Landing broadcast (#300)

On every landing, the lander reports the new `main`
tip and touched files to the eng lead, who forwards that line to
every developer lane that holds a slot, is queued for one, or has announced a
candidate:

- A lane that can receive, including Remote sessions that queue messages,
  gets it within a minute.
- A headless lane in a live turn (`lane.sh send` exit 75) cannot receive. The
  eng lead records the broadcast as pending in `lead-handoff.md` and re-sends it at the
  lane's next exchange or at the next lane check, whichever comes first.

Queued lanes and holders refresh through `git`; running reviews follow its
checkout/range stability rule. An ordinary landing does not require a
concurrent-mode review to abort. The eng lead
also tells the lander, in each broadcast and at each go, which lanes are in
review or have announced a candidate; the lander's second-candidate wait
(`lander` skill, Stack and carry) reads the latest such message.

## Hot files (#300)

Every lane brief names the shared hot files it owns: skill sections, contracts and
core modules. A lane that
needs a hot file another lane owns coordinates with the owner first, through
the eng lead, or waits. The eng lead may connect the two owners directly for
a quick exchange. The lander trains candidates that touch the same files
next to each other.

## Lander (#275)

When the project runs a 🛬 lander lane, a developer whose candidate coverage
ends clean (`review:status` reports `approved`) hands the candidate to the
lander (`lander` skill) instead of landing it, and sends `done` once the
lander acknowledges. The request is
`land request #<n> <base>..<tip> suites=<names> session=<id>`, with full
40-character SHAs and the requester's CCR session id (#285). Advisory coverage stays on the developer's advisory path.
From then on the lander
owns rebase, carry, the exact-tip suite and the fast-forward, and it lands
batches as a merge train.

- **Carry-only runs** (`review:candidate --carry-only`) take no queue slot.
  They launch no reviewer and exit on a refused carry. Concurrent-mode receipt
  writes take the short `receipt-write.lock`.
- **Fresh reviews** by the lander take a slot like any other review. Trains
  save suites, not reviews: expect a member that overlaps `main` or an
  earlier member to need one. These reviews do not count as developer rounds.
- **Order.** Send ordering requests before the lander stacks a train. A
  reorder after stacking costs carries, and the lander pushes back on it.
- **Landing** goes through `wrsp-land <tip>`. Every landing takes legacy
  `review.lock`; numbered concurrent reviewer slots continue independently.
- **Second candidate.** After accepting a candidate, the lander holds the
  train's suite up to about 5 minutes while another lane is in review or has
  announced a candidate, then starts it.
- **Publication** stays with the eng lead. The lander reports each landed tip,
  the files the landing touched, and its exact-tip evidence; the eng lead
  broadcasts the tip and files (Landing broadcast, above).

## Round limit (#238)

A round is one exact-range review, initial or follow-up, whatever its outcome;
a review execution error is not a round.
One `review:candidate` invocation that splits a mixed-family range into runs counts as one round (#291).
Rounds count per allocated task
(eng lead → developer), not per issue. A new lineage,
changed approach, new model or successor lane keeps the count; only Jon
re-scoping resets it.

- The eng lead counts each lane's rounds from `review start`; the developer
  tracks its allocated task's count.
- Round 5 is the last. A task without a clean approval after round 5 stops. A
  developer reports the trip to the
  eng lead with each round's range, findings and repair changes.
- The three-consecutive-P0/P1 breaker in reviewed-main-workflow stays the faster
  trip.
- The eng lead resolves a trip once per task: narrow the scope, split the
  task, drop the failing ambition, park it for Jon, or grant one more 5-round
  budget for a changed approach. The note names what changed; another patch on
  the same mechanism is no change. Record the decision and reason on the issue.
- A second trip goes to Jon. Finding acceptance stays Jon's.

## Publication

For publication, record the remote base, full frozen tip, required suites, and
authority source. Create a clean detached worktree at that tip. Run final suites,
collect evidence, inspect review status, and push from that checkout. Evidence
lives in the Git common directory; WRSP's pre-push hook checks that checkout's
HEAD and requires outgoing commits and peeled tags to match it.

Reviews and landings keep advancing main. There is no admission freeze. Use an
explicit `<frozen-tip>:refs/heads/main` push from the detached checkout. Verify
the remote result and append the pushed-tip event to `lead-activity.md`.
[Operations](operations.md#lead-files) owns these file semantics. Do not replace the frozen checkout's
HEAD with main's newer tip or add a newer commit without its evidence.

The eng lead owns final publication-suite submission and collection. Reuse
matching evidence and resume known jobs after transport failure. Developers
may run suites for repair or a repository's landing requirement; share job handles
to avoid duplicate submissions. A focused check is not a full suite. Every full
suite, the eng lead's included, runs on the Test Mini through
`wrsp-runner test <tip>`; a local full run on Agent Mini refuses (#256).

A changed frozen tip needs a new evidence and authority check. Split pushes only
at recorded permitted segment boundaries. Older acceptance never covers added
work. A remote race needs reconciliation and fresh checks, never an automatic
force push. Queue go grants admission, not acceptance or publication authority.
