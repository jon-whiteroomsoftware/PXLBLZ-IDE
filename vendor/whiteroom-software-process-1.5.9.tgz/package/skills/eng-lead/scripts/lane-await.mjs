import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { setTimeout } from 'node:timers/promises';
import { assistantMessages, optionalBytes } from './lane-messages.mjs';

export function validateAwait(pattern, timeout) {
  if (typeof pattern !== 'string' || !pattern.length || !/^[1-9][0-9]{0,4}$/.test(String(timeout)) || Number(timeout) > 86400) throw new Error('expected --await PATTERN --timeout SECONDS (1..86400)');
  try { return new RegExp(pattern); }
  catch { throw new Error('invalid --await regular expression'); }
}

/** One admitted turn, observed read-only; deadlines neither cancel nor replay work. */
export async function waitForReply(options, dependencies = {}) {
  const { cli, log, turn, pattern, timeout } = options;
  const expression = validateAwait(pattern, timeout);
  const { now = () => performance.now(), wait = setTimeout, read = optionalBytes } = dependencies;
  const deadline = now() + Number(timeout) * 1000;
  for (;;) {
    // Read exit first, then its completed log; a missing marker remains live.
    const exit = read(log + '.exit');
    if (exit !== null && (!/^\d+\s*$/.test(exit.toString()) || Number(exit.toString()) > 255)) throw new Error(`${log}.exit: invalid turn exit`);
    const bytes = read(log);
    for (const message of assistantMessages(cli, bytes ?? Buffer.alloc(0))) {
      if (expression.test(message)) return { code: 0, message: `AWAIT MATCH: turn ${turn}\n${message}\n` };
    }
    if (exit !== null) return { code: 3, message: `AWAIT EXIT: turn ${turn} exit ${Number(exit.toString())} (no reply match)\n` };
    const remaining = deadline - now();
    if (remaining <= 0) return { code: 124, message: `AWAIT TIMEOUT: turn ${turn} after ${timeout}s\n` };
    await wait(Math.min(250, remaining));
  }
}

async function main(args) {
  try {
    if (args[0] === 'validate' && args.length === 3) { validateAwait(args[1], args[2]); return 0; }
    const [cli, log, turn, pattern, timeout] = args;
    if (args.length !== 5 || !['claude', 'codex'].includes(cli) || !/^[1-9][0-9]*$/.test(turn)) throw new Error('invalid await arguments');
    const result = await waitForReply({ cli, log, turn: Number(turn), pattern, timeout });
    process[result.code === 0 ? 'stdout' : 'stderr'].write(result.message);
    return result.code;
  } catch (error) { process.stderr.write(`REFUSED: ${error.message}\n`); return args[0] === 'validate' ? 64 : 65; }
}

if (process.argv[1] && fs.existsSync(process.argv[1]) && fs.realpathSync(process.argv[1]) === fileURLToPath(import.meta.url)) process.exitCode = await main(process.argv.slice(2));
