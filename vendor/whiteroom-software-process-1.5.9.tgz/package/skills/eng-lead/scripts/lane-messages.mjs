import fs from 'node:fs';

// Provider stdout only; tool results, subagents and incomplete JSONL are not replies.
export function assistantMessages(cli, bytes) {
  const messages = [];
  const lines = bytes.toString('utf8').split('\n');
  lines.pop();
  for (const line of lines) {
    let row;
    try { row = JSON.parse(line); } catch { continue; }
    if (cli === 'codex' && row?.type === 'item.completed' && row.item?.type === 'agent_message' && typeof row.item.text === 'string') messages.push(row.item.text);
    if (cli === 'claude' && !row?.parent_tool_use_id && !row?.parentToolUseID && !row?.isSidechain) {
      if (row?.type === 'result' && typeof row.result === 'string') messages.push(row.result);
      if (row?.type === 'assistant' && row.message?.role === 'assistant' && Array.isArray(row.message.content)) {
        messages.push(row.message.content.filter(block => block?.type === 'text' && typeof block.text === 'string').map(block => block.text).join('\n'));
      }
    }
  }
  return messages;
}

// Nonblocking open also makes unexpected FIFOs/devices refuse instead of hanging.
export function optionalBytes(file) {
  let fd;
  try {
    fd = fs.openSync(file, fs.constants.O_RDONLY | fs.constants.O_NONBLOCK);
    if (!fs.fstatSync(fd).isFile()) throw new Error('expected readable regular file');
    return fs.readFileSync(fd);
  } catch (error) {
    if (error.code === 'ENOENT') return null;
    throw new Error(`${file}: ${error.message}`);
  } finally { if (fd !== undefined) fs.closeSync(fd); }
}

export function pendingReview(cli, bytes) {
  let pending = null;
  for (const text of assistantMessages(cli, bytes)) {
    for (const line of text.split(/\r?\n/)) {
      if (/^\S+ review start\b/.test(line)) pending = line;
      if (/^\S+ review done\b/.test(line)) pending = null;
    }
  }
  return pending;
}
