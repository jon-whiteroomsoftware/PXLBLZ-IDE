---
name: git
description: Invoke before Git staging, commits, worktree/hook setup, pre-review rebase or push. Publication authority remains role-owned.
metadata:
  wrsp-min-version: "1.3.0"
---

# Git

## Commits

- Issue commit subjects start `#<n> `; no auto-close keywords. Small process/docs
  maintenance without an issue may use `no-issue:`. Normal product, architecture,
  implementation or multi-step process changes need an issue or plan reference.
- End agent commits with `X-Authored-Model: <exact model id>`; prepare-commit-msg
  fills missing attribution from the session transcript (#303). Leave it to
  the hook when the harness forbids typing model ids.
- Stage/commit by path, preserving unrelated and overlapping user work. Stage
  useful new project files; keep scratch unstaged.
- Never bypass hooks: `--no-verify`/`-n`, `HUSKY=0`, `core.hooksPath`
  overrides and hook edits are bypasses.
- Batch Git work into few calls. Run `git push` alone. Publication follows
  [eng-lead operations](../eng-lead/references/operations.md); this skill grants
  no authority.

## Worktrees

Keep source under `~/src`, isolated work in
`~/src/worktrees/<repo>-issue-<n>-<slug>`, and the shared checkout on `main`.
The issue segment enables usage attribution; preflight warns when absent.
Complete documented install/build and hooks before
`wrsp-preflight worktree` (`npm run preflight -- worktree` in source).

Offline, clone shared dependencies and build output:
`cp -Rc ~/src/<repo>/node_modules ~/src/<repo>/dist <worktree>/` on APFS;
use `cp -a` elsewhere, preserving symlinks. Build as tooling permits. Copying
these directories does not install generated hooks: run `npx husky` in each
worktree using husky. After landing, rebuild shared `dist/` before bin commands.

## Review freshness

Immediately before `review:candidate`, recheck local `main` and rebase unreviewed
work onto it if needed; refresh earlier on landing broadcasts. Keep the reviewed
checkout and exact range still during review. Rewriting approved ranges
requires eligible carry or fresh review through `reviewed-main-workflow`.
[Landing queue](../eng-lead/references/landing-queue.md) owns admission and
conflict-slot ownership.

For failures, apply global failure scope and `~/.agents/execution-policy.md`,
**Route failures**; this skill adds no recovery route.
