---
name: issue-workflow
description: GitHub issue writes, claims, implementation state, proof, closure, feature epics, typed children, specs, handoffs, and recording Jon's direct instructions.
metadata:
  wrsp-min-version: "1.3.0"
---

# Issue Workflow

Verify `gh auth status` before authenticated GitHub work. Failures follow global
failure scope and `~/.agents/execution-policy.md`, **Route failures**.
Invoke `git` for staging and commits.

## Issue role

Keep the body current: scope, done/remaining work, blockers, tests/proof and docs
impact. Keep durable product intent, architecture, technical design, domain
language and reference behavior in linked PRDs/plans, design docs, ADRs/reference docs,
`CONTEXT.md` and commits.

## Feature and typed work

Before feature work, reuse its epic (an existing PRD issue qualifies) and bounded
typed child; create only missing authorized work. Use UX children for UX,
definition children for PRD authorship. Epics group specs/children; preserve
reused labels/history. Attribute sessions/commits to the work child without a
second spend unit or new epic category. Shared/maintenance work may stand alone;
rollups remain future work.

Read the adopted work-type catalog and contract when creating or claiming work
(`docs/reference/contracts/work-types.md` in WRSP). Select/check one purpose label;
missing/multiple types are unknown diagnostics, not gates. Keep state labels
separate. Link corrections to their bugs/findings and follow contract history,
capture and effective-time rules. Use the adopted guide for native parent/child
attachment and read-back, or explicit reciprocal links when native grouping is
confirmed unavailable (`docs/reference/work-types.md` in WRSP). Preserve ambiguous
epics, conflicting parents and claims pending resolution; never silently replace
a parent. Connection failures follow Route failures above.

Prefer bounded sessions. A meaningful task/category change normally starts
another; incidental tests/docs stay with the feature, prototypes remain design.
Mixed sessions are allowed and unknown. Reuse provider-qualified session IDs,
issue worktrees and trailers; review activity and machine time remain separate
from issue purpose.

## Specs and template

Split plans into vertical slices. Use this template:

```text
## Parent
## What to build
## Limits
## Acceptance criteria
## Required proof
## Tests
## Docs impact
## Progress
## Blocked by
```

Describe the end-to-end slice without copying the PRD. Name limits/non-goals;
"decide with Jon" and other named points halt work. Acceptance criteria are
observable. At creation, Required proof names consumer surfaces/cases and Tests
names must-test cases/oracles; later record actual results and attach completion
evidence before close. Spec cases are the floor. Docs impact names contracts and
expected/actual updates; Progress holds meaningful milestones; blockers are issue
IDs or concrete dependencies. Link large designs.

- At assignment, the eng lead names the oracle and writes a test/proof sketch
  of at most 10 bullets into Required proof and Tests. Before code, the developer
  expands it with `systematic-test-design` into cases, partitions, setup and
  expected assertions in Tests; link large detail from the body. At spec time,
  invoke `systematic-test-design` for must-test cases and oracles.
  Name preserved/changed contract clauses;
  keep proposed guarantees out of current reference until accepted and implemented.
- Each criterion becomes a review invariant. Closed domains are our files,
  objects and config; open domains need enumerated forms, a fail-closed default
  with named residual, or explicit threat-model scope.
- Beyond trivial UI, link a mock-up/prototype; it and Limits bound the build,
  while Required proof carries interaction checks.
- Settle the approach with exact files, functions, call-stack/algorithm skeleton,
  refusal behavior and tests in the developer's plan before implementation.
  Unresolved design goes to Jon; execution-policy Test planning governs detail.
- Pin primary-source facts as cited issue artifacts; derive work from those
  bytes, not an agent's restatement. Record chat-settled decisions on the issue
  in the same turn.

## Updating issues

Record Jon's direct instructions verbatim with source in the same turn; forward
them verbatim to the eng lead within the assigned tree. Outside lanes, record
them on their own issue.

Comments are only short verbatim Jon quotes plus one source/context line,
decisions/scope changes, or proof the body cannot hold. Claims, releases, brief
pointers, ready-to-land, accepted/landed/returned states and handoffs are label
changes or body edits. Record owner, live jobs and next step; still deliver role
protocol messages. Developer/lander own the land-request protocol.

Reorganize for clarity; call out meaningful scope changes. Weakening scope or
acceptance needs Jon's confirmation. Update Progress, Tests and Docs impact on
commits/discoveries; cite commits when practical. Record completion after commit;
claims, blockers and scope/acceptance clarifications before commit. Separate
pending checks from passing proof.

For full body edits, use
`wrsp-issue-body --repo OWNER/REPO --issue N --body-file FILE`
(in WRSP source: `node bin/issue-body.mjs ...`). It checks the local draft's
existing size advisory, template headings and nonempty Required proof before
any GitHub call, then checks completed-issue proof markers using existing
comments. A passing draft gets one body-only PATCH; comments and labels stay
unchanged. Inspect an attempted-write failure before retrying.

Above the existing 800-word target, collapse Progress to current state and move
specs to a linked plan, preserving Jon's verbatim words. `--allow-advisories`
explicitly permits the size advisory and records the override in output;
mandatory template/proof failures still refuse. The standalone
`scripts/check-body-size.ts --body-file FILE` and claim-line editor retain their
advisory behavior. Arbitrary `gh` calls are not intercepted. The
[issue-body contract](~/src/whiteroom-software-process/docs/reference/contracts/issue-body.md) owns ordering,
proof lifecycle and failure semantics.

## Claiming And Coordination

- For an existing Owner or lane Progress line, use the Node 24+
  [claim-line editor](scripts/edit-claim.ts): `show --repo OWNER/REPO --issue N
  --prefix P` returns only the unique line, body SHA-256 and URL. Then `replace`
  with the same options plus `--expected LINE --replacement LINE --body-sha256 SHA`
  from that inspection. Run it as `node <skill-path>/scripts/edit-claim.ts`.
  Prefixes are literal and replacements retain them. Missing/duplicate lines,
  changed bodies or expected-line mismatches refuse; initialize a missing line
  through an explicit body edit first. The tool privately fetches/writes the
  body and verifies read-back, preserving surrounding bytes. Its digest detects
  changes since inspection; GitHub PATCH still has a last-writer-wins race.
  A failure with `writeAttempted: true` needs inspection before another write.
- Before substantial work, add `WIP` and record session/date in the body. Respect
  stale claims: ask before takeover unless explicitly assigned. Successors keep
  the claim. If work stops or is handed back, remove WIP and update the body.
- On Agent Mini, snapshot after claim, label changes and close:
  `wrsp-usage snapshot-issue --source claim|close OWNER/REPO N`; use claim for
  label changes. Failure warns but never blocks work.
- Only `WIP` and `📦 implemented` have Jon's standing creation approval (WIP:
  2026-10-18). Ask for any other missing label/status. If WIP cannot be created,
  put `Status: in progress`, identity and date in the body.

## Implemented

Use `📦 implemented` only when identified commits in the body claim the whole
implementation scope; partial/uncommitted work does not qualify. Replace WIP and
old `ready-for-review`. State the claim, proof, docs/contracts and remaining
review/landing/release/adoption work. The label signals available implementation,
not successful review, landing, release or Jon's acceptance; continue those gates.

Remove implemented when closing or when further implementation is needed; restore
it after replacement commits. Leave issues open for Jon unless explicitly asked
to close. The label grants no closure authority. Link affected contracts and the
evidence for changed/preserved obligations. Put a concrete `Proof:` line in the
body by default; comment only if the body cannot hold it. For
`wrsp-check-issue-proof`, keep `## Required proof` nonempty; bold text is not the
marker. The checker proves presence, not sufficiency.

## Follow-ups and splits

Feature work authorizes missing tracking issues within scope. Propose additional
splits/follow-ups; ask before creation unless project workflow authorizes it.
Create actionable, low-controversy work within an approved plan. Current
acceptance stays here; separable adjacent work becomes a proposal/follow-up section.
