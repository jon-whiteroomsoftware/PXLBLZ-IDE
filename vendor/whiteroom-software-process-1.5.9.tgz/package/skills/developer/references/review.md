# Review

Read
`~/.agents/skills/eng-lead/references/landing-queue.md` before requesting
review admission. Send publication needs and findings to the eng lead.
Read `review-packet` and `reviewed-main-workflow` on this branch.
The developer supplies requirement/source semantics, test-design invariants,
partitions, sequences, oracles and residual gaps, and proof obligations through
project policy and `--test-design`. The normal native candidate command owns
complete ephemeral review-input assembly and refusal diagnostics (`review-packet`,
exact-range review contract ER-7). Semantic judgment remains with the reviewer.

Review selections:

- WRSP candidate review ranks reviewers in the installed `reviewer` role's member order (`~/.agents/roles.yaml`; its `explicitPairs` are explicit only); select
  outside the author's family; native route, receipt provenance kept.
- Jon's explicit same-family direction for one exact candidate becomes the
  explicit pair, `--allow-same-family`, and a nonblank `--override-reason`;
  it changes reviewer eligibility for that candidate only.
- For normal mixed-family review, follow installed repository capability:
  current WRSP automatically splits into author-family runs when whole-range
  coverage/carry does not handle the range; older versions follow their
  documented supported path. `--carry-only` does not split.
- For authorization cases, follow
  `~/.agents/skills/eng-lead/references/operator-acceptance.md`.
  Send publication findings, exact range, and Jon's verbatim instruction/source
  to the eng lead. Record freshness, non-convergence, and supported mixed-range
  admission through that procedure. Admission recording requires an installed
  production interface; current WRSP exposes none.
- `gpt-6-astra` at `medium` is the planning model; review sessions may
  launch it, separate planning sessions need Jon to name it.
- Design and review selections grant no execution exception.

- Keep the worktree untouched and HEAD at the exact tip during review.
- Follow `git` for pre-review freshness and
  `~/.agents/skills/eng-lead/references/landing-queue.md` for admission and
  conflict-slot ownership.
- Read [Brief](launches.md#brief) for proportional proof and suite placement.
- Send required final suites/known job handles to the eng lead, who owns final
  publication-suite submission/collection at the frozen tip. Run repair or
  landing suites on the Test Mini.
- Pass `--issue <n>` to `review:candidate` so the review launch is recorded for the issue (#201).
