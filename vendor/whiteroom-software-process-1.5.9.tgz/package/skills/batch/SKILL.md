---
name: batch
description: Run one scheduler/eng-lead brief as a non-interactive scheduled job; exclude interactive sessions.
metadata:
  wrsp-min-version: "1.3.0"
---

# Batch

1. First run `node ~/.agents/hooks/session-role.mjs declare batch` from the project checkout, adding `--issue <n>` when the brief names one issue. This labels telemetry; it grants no authority.
2. Follow the job's brief exactly; never ask questions or wait for answers.
3. Write output only where the brief names. When the brief has a gap, print one line starting `BRIEF GAP:` naming it, and exit without changes. A commit-hook failure after edits is the exception: leave changes staged, report `BRIEF GAP: commit hook` with the failing lines, and exit (#167).
4. A batch session never pushes, tags, writes with `gh`, messages or spawns agents, or changes host configuration. Put anything that needs one of these in the final report.
