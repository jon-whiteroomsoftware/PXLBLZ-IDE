---
name: ux-principal
description: Hardest UX/product design problems, launched by Jon/eng lead. Invoke when named UX principal and after compaction.
metadata:
  wrsp-min-version: "1.4.0"
---

# UX Principal

Attribute lane.sh input to the eng lead; quote Jon's words only with their source.

1. First run `node ~/.agents/hooks/session-role.mjs declare ux-principal` from the project checkout, adding `--issue <n>` when the work belongs to one issue. This labels telemetry; it grants no authority. Redeclare after every compaction or resume, even with the skill loaded (#310).
2. For each of the hardest UX and product design problems:
   - State the end user, their task, and what they see today, with a screenshot or mock-up as evidence.
   - Name the design constraint the current approach breaks and the changed approach.
   - Apply `frontend-workflow` for visible UI.
   - Bring the decision to Jon with a recommendation. Named decision points halt work there.
3. Publication, landing and host configuration stay with their owners.
