---
name: writing-for-agents
description: Use when creating/editing skills, AGENTS.md, CLAUDE.md or documents agents reach through pointers, including briefs and references named in AGENTS.md.
metadata:
  wrsp-min-version: "1.3.0"
---

Reference for writing any agent-consumed document: skills, `AGENTS.md` / `CLAUDE.md`, and docs reached by pointers. The same levers make the agent's _process_ predictable across runs, not its output.

When writing a skill, read [`SKILL-MECHANICS.md`](SKILL-MECHANICS.md) for terseness, invocation choice and frontmatter, and router skills.

## Context pointers

A **context pointer** names out-of-context material and its read condition from within the agent's context: a skill description or an `AGENTS.md` doc pointer. Its _wording_, not its target, determines when and how reliably the agent reaches the material. For must-have material behind a weak pointer, sharpen the wording first; inline only if sharpening fails.

A pointer states what the material is and lists the **branches** that trigger reading it: distinct cases the document handles, taking different paths across runs. Prune always-loaded pointers harder than bodies; every word costs on every turn:

- **Front-load the leading word** — the pointer is where it does its triggering work.
- **One trigger per branch.** Collapse synonyms for one branch; keep distinct branches.
- **Cut identity the body already carries.**

Project instructions use the same rule for engineering contracts: point to a
contract by subsystem and name the behavior-change branch that requires reading
it, or point to a small contract index when several subsystems share one entry
path. Do not require every task to load every contract.

## The two loads

Every document and pointer you add spends one of two budgets:

- **Context load** — always-loaded material spends the agent's tokens and attention every turn whether it fires: an `AGENTS.md` line or skill description.
- **Cognitive load** — the human remembers which documents exist and when to reach them. The human is the index. Spend this cost of human agency where human judgement matters; remove it where it does not, rather than minimising it outright.

Material reached only through a pointer escapes context load at the price of the pointer's own line; material with no pointer at all rides entirely on cognitive load.

## Information hierarchy

A document mixes **steps** (ordered agent actions) and **reference** (definitions, rules, facts consulted on demand): all steps (a recipe), all reference (review rules, this skill), or both. Place each piece on the **information hierarchy**, ranked by how immediately the agent needs it:

1. **In-file step** — the primary tier: what the agent does, in order.
2. **In-file reference** — consulted on demand. A flat peer-set (every review rule on one rung) can be appropriate.
3. **Disclosed reference** — a separate file reached and loaded when a context pointer fires, from a sibling file to external reference anywhere, reachable by any document.

Push too little down and the top bloats; too much hides needed material.

**Progressive disclosure** moves material down the ladder, out of the main file behind a pointer, protecting hierarchy and legibility rather than primarily saving tokens. Inline what every branch needs; disclose what only some branches reach. In documents with steps, undisclosed branch-specific reference buries the steps and makes attention to them unreliable.

**Co-location** decides what sits together within a file; the ladder decides how far down it sits. Keep a concept's definition, rules, and caveats under one heading, so reading one brings its neighbours. The document should read like documentation grouped for the agent. Scattering fragments one meaning across locations; duplication repeats it.

**Sprawl** is excess length even when every line is live and unique: it thins attention and adds relevance maintenance. Disclose reference behind pointers; split by branch or sequence so each path carries only what it needs.

## Steps and completion criteria

Every step ends on a **completion criterion** — the condition that tells the agent the work is done. Two properties make it a lever:

- **Clarity** — can the agent tell done from not-done? A vague bound ("understanding reached") invites **premature completion**: ending the step before it is genuinely done, attention slipping to _being done_. The visible steps still ahead — the **post-completion steps** — supply the pull; the criterion's clarity is the resistance. Defend in order: **sharpen the bound first** (local and cheap); only if it is irreducibly fuzzy _and_ you observe the rush, hide the later steps by splitting the sequence — and hiding only works across a real context boundary (a hand-off or a subagent dispatch; an inline call leaves the later steps in context and clears nothing).
- **Demand** — how much it requires. "Every modified model accounted for" forces thorough work where "produce a change list" does not. Demand drives **legwork** — the digging the agent does within the work, latent in the wording rather than written as its own step — and it is not step-bound: "every rule applied" binds a body of flat reference just as "every step done" binds a sequence, which is how an all-reference document still carries an exhaustiveness bar.

The strongest criteria are both checkable and exhaustive.

## When to split

Splitting spends context or cognitive load; split only when the cut earns it:

- **By sequence** — split a run of steps where the post-completion steps tempt the agent to rush the one in front of it. Keeping them out of view drives more legwork on the current task. Beware the reverse: merging sequences exposes each step's later steps to what follows, inviting premature completion.
- **By invocation** — skill-specific: see [`SKILL-MECHANICS.md`](SKILL-MECHANICS.md).

## Leading words

A **leading word** recruits a compact pretrained concept the agent thinks with while running the document (_lesson_, _fog of war_, _tracer bullets_). Repeat the token, never a sentence, to accumulate a distributed definition and anchor behaviour with few tokens. A clearly defined coined word can work, but costs definition tokens without recruiting priors; reach for an existing word first.

It anchors _execution_ in the body: the same behaviour on each occurrence, focusing attention on a class of things in flat reference. It anchors _invocation_ in pointers: shared wording across prompts, docs and code links the language to the material, improving reach.

Refactor repeated triads and sentence-long pointers to one idea with leading words:

- "fast, deterministic, low-overhead" → _tight_ (a _tight_ loop).
- "a loop you believe in" → _red_ — a fuzzy gate becomes a binary observable state (the loop goes _red_ on the bug, or it doesn't).

Seek restatements in every document that leading words can replace, saving tokens and sharpening the agent's conceptual hook.

**Negation** is the failure mode beside this lever: steering by prohibition drags the forbidden behaviour into context and makes it _more_ available, not less. _Don't think of an elephant_, and the elephant is all there is; the negation is a weak modifier the strongly-activated concept overruns, so the ban half-reads as an instruction to do the thing. Prompt the **positive** — state the target behaviour ("write one-line comments") so the banned one is never spoken. A prohibition earns its place only as a hard guardrail you cannot phrase positively; even then, pair it with the positive target so attention lands on what to do.

## Pruning

- Keep each meaning in a **single source of truth**: one authoritative place, so changing the behaviour is a one-place edit. **Duplication** — the same meaning in more than one place — costs maintenance and tokens, and inflates a meaning's prominence on the ladder past its real rank. (The accidental inverse of a leading word, which repeats a token on purpose, never the meaning.)
- The **environment** is a source of truth too — `package.json` scripts, config files, the directory layout, `--help` output — and a document that restates it is a **cache**: a copy of a lookup, earning its load only when the lookup is expensive. Cache what the agent cannot find by looking: the unwritten convention, the reason behind a choice, the gotcha no config confesses. Leave the one-file, one-command lookups to the environment, where they cannot go stale.
- Check every line for **relevance**: does it still bear on what the document does? A line loses relevance by never bearing on the task (mere exposition, or a branch that should be disclosed) or by going stale as the behaviour or world it describes changes. Shorter documents are easier to keep relevant. Without a pruning discipline the default fate is **sediment**: stale layers that settle because adding feels safe and removing feels risky, until you must core down through them to find what is still live.
- Hunt **no-ops** sentence by sentence: an instruction the model already obeys by default pays load to say nothing. The test — does it change behaviour versus the default? — is model-relative, not reader-relative: two people disagreeing about a no-op disagree about the default, and settle it by running the document, not by debate. When a sentence fails, delete the whole sentence rather than trim words from it. The test also grades leading words: a word too weak to beat the default (_be thorough_ when the agent is already thorough-ish) is a no-op. Delete it, or replace it with a demand the default misses — an exhaustive completion criterion (see Steps and completion criteria).
