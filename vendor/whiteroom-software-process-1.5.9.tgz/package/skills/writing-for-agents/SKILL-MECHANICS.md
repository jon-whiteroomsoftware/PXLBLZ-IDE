# Skill mechanics

The skill-specific branch of [`writing-for-agents`](SKILL.md): terseness, invocation choice and frontmatter, and router skills. `SKILL.md` owns the universal writing reference.

## References

Keep skill references one level deep: link each required reference directly
from the owning `SKILL.md` with a when-to-read cue. Reference-to-reference
links may remain for orientation once that direct route exists.

Start each `references/*.md` file longer than 100 lines with `## Contents`
within its first ten lines, listing its `##` headings in order with links.

## Terseness

For skills, use terse operational wording: retain the trigger, action,
conditions, exceptions and completion criterion. Keep rationale or examples
only when they resolve an execution ambiguity; disclose branch-specific detail
through context pointers. On every edit, prune repetition and filler while
preserving every normative qualification.

## Invocation

Two choices, trading the two loads:

- A **model-invoked** skill keeps a `description`, so the agent can fire it autonomously — and other skills can reach it. You can still type its name: model-invocation always _includes_ user reach; a description only ever adds agent discovery, never removes the human's. The description is the skill's top-level context pointer, forced to stay loaded at all times — permanent context load in exchange for discoverability. A model-invoked skill whose content is all reference is also one home for shared reference: another skill can invoke it, so reference needed by several skills lives in one place. Mechanics: omit `disable-model-invocation`, and write a model-facing description carrying the trigger branches (the pointer-writing rules in `SKILL.md` apply in full).
- A **user-invoked** skill strips the description from the agent's reach: only the human typing its name can invoke it, and no other skill can. Zero context load, but it spends cognitive load — you are the index that must remember it exists. Mechanics: set `disable-model-invocation: true`; the `description` becomes human-facing — a one-line summary, trigger lists stripped.

Pick model-invocation only when the agent must reach the skill on its own, or another skill must. If it only ever fires by hand, make it user-invoked and pay no context load.

Shared reference that two user-invoked skills both need can live in neither — with no model-visible descriptions, neither can fire the other. Push it to a plain file outside the skill system: external reference any skill can point at.

## Splitting by invocation

Split off a model-invoked skill when a distinct leading word actually used in your prompts should trigger it independently, or another skill must reach it. That reach must justify the always-loaded description's context cost. Sequence splitting lives in `SKILL.md`.

## Router skills

When user-invoked skills multiply past what you can remember, that piled-up cognitive load is cured by a **router skill**: one user-invoked skill that names the others and when to reach for each, so the human has one skill to remember instead of many. It can only hint, never fire them: user-invoked skills have no model-visible description, so nothing but the human can reach them.
