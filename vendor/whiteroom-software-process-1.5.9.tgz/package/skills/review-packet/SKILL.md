---
name: review-packet
description: Use before exact-range candidate review or when native review-input assembly reports a gap.
metadata:
  wrsp-min-version: "1.4.0"
---

# Native review input

## Preparation

Developers supply requirements, source context, systematic test-design semantics
and proof obligations through project policy and `--test-design`.
Researchers remain factual and read-only.

Run the repository's normal candidate command:

```bash
npm run review:candidate -- <base> <tip> [--test-design <json>]
```

The native command owns complete ephemeral input assembly and validation;
[ER-7](~/src/whiteroom-software-process/docs/reference/contracts/exact-range-review.md#invariants)
owns completeness, identity, freshness and size refusals.

## Developer diagnostics

Bounded `Native review input v1` reports construction facts, never approval or
proof adequacy. Report native refusal's exact gap; stop the affected action.
Report installed command/version mismatches to the eng lead. Source changes
require separate installation and installed qualification before claiming deployment.
