---
name: doc-sweep
description: Synchronize docs after commits, issue/feature completion, or Jon's request for a doc/documentation/reference sweep, PRD cleanup or docs matching shipped behavior.
metadata:
  wrsp-min-version: "1.3.0"
---

# Documentation Sweep

Separate forward-looking plans from as-built reference; make current repo state easy for agents to consume.

## Inputs

Use Jon's requested scope; if absent, infer what shipped or changed from recent commits, the active issue and changed files.

Read repo-specific docs before editing:

- `AGENTS.md`
- `CONTEXT.md`
- `docs/agents/`
- active issue or relevant PRD
- relevant technical design documents
- relevant `docs/plans/` and `docs/reference/` files

## Document Roles

- `CONTEXT.md`: canonical domain language, concepts, boundaries and current conceptual model. Consider it every sweep; update it when shipped work introduces, renames, retires or meaningfully sharpens a domain term or boundary.
- `docs/plans/`: forward-looking PRDs, feature PRDs, technical design documents, milestones, sequencing, open questions, and intended future behavior.
- `docs/reference/product/`: as-built user-facing behavior.
- `docs/reference/technical/`: as-built architecture, algorithms, APIs, commands, data flow, and code organization.
- `docs/reference/contracts/` (or the project's established equivalent):
  current obligations at seams, including ownership, invariants, transitions,
  failure, compatibility, limits, and evidence.
- Issues: live implementation state and progress for active work.

Do not leak planning history into reference. Omit milestones, implementation sequencing, abandoned alternatives, temporary compromises and build history unless needed to understand the current system.

Avoid exhaustive prose mirrors of implementation. Preserve stable concepts,
contracts, boundaries, ownership, data flow and
surprising constraints that help humans reason about the system. Leave local
mechanics easier to inspect than explain in code/tests. Link detailed evidence
or specialist reports rather than copying them into central reference.

## Workflow

1. Determine what changed.
   - Review the active issue, recent commits, changed files, and user-provided scope.
   - Identify shipped behavior, conceptual changes, and remaining future work.

2. Classify documentation impact.
   - Update `CONTEXT.md` if domain language, boundaries, or the conceptual model changed.
   - Update product reference docs for user-facing behavior.
   - Update technical reference docs for implementation-relevant behavior.
   - Update applicable engineering contracts when shipped interface obligations
     changed. If code and contract disagree, expose the mismatch for a governing
     decision instead of silently weakening either claim.
   - Revise PRDs, feature PRDs and technical designs so completed work no longer reads as future scope.
   - Update the issue if progress, remaining work, or docs status changed.

3. Edit only current-truth docs with current truth.
   - Reference docs describe what exists now.
   - Planning docs describe what is still intended, undecided, or future.
   - If implementation differs from the plan, reference docs follow the implementation.

4. Archive completed plans when appropriate.
   - Move completed feature PRDs to `docs/plans/archive/` only when they are no longer useful for active planning.
   - Do not delete PRDs by default.
   - Retire or supersede obsolete contracts deliberately and leave a pointer to
     the current agreement. Remove duplicated normative detail from overview
     reference while preserving its conceptual explanation and entry point.

5. Report the sweep.
   - List docs updated.
   - List docs checked but left unchanged.
   - Note unresolved doc gaps, stale plans or decisions needing user input.
   - State whether reference docs now match the inspected shipped behavior.

## Cadence

- At commit boundaries: check whether technical reference docs need updates; if user-facing behavior changed, also check product reference docs.
- At issue completion: update reference only when shipped behavior changes a
  documented concept, contract, boundary, workflow or important constraint.
  Do not add feature-diary coverage merely to prove the issue was documented.
- At feature completion: update reference docs, update `CONTEXT.md` if concepts changed, revise PRDs, and archive completed feature PRDs when appropriate.

Do not perform a full documentation sweep on every commit unless requested or the change warrants it.
