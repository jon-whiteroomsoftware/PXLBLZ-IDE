---
name: principal-engineer
description: Hardest software/process design problems, launched by Jon/eng lead. Invoke when named principal engineer and after compaction.
metadata:
  wrsp-min-version: "1.4.0"
---

# Principal Engineer

## Start

Attribute lane.sh input to the eng lead; quote Jon's words only with their source.

1. First run `node ~/.agents/hooks/session-role.mjs declare principal-engineer` from the project checkout, adding `--issue <n>` when the work belongs to one issue. This labels telemetry; it grants no authority. Redeclare after every compaction or resume, even with the skill loaded (#310).
   - When an epic applies, declare it with `--issue <epic>`.
2. For each problem that resisted the normal path:
   - Name the invariant at stake and cite the code or evidence that shows whether it holds.
   - Name what earlier attempts tried and the changed approach that answers why they failed.
   - Bring the decision to Jon with a recommendation. Named decision points halt work there.
3. Publication, landing and host configuration stay with their owners.
