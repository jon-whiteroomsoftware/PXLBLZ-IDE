---
name: systematic-test-design
description: Use when planning/writing tests or planning issues/specs; record must-test cases, partitions and oracle surfaces in the spec. Design systemic preventative tests around invariants, sequences and fault-sensitive oracles, especially for state/coupling, transformations, recurring/review-discovered bugs or suite hardening.
metadata:
  wrsp-min-version: "1.3.0"
---

# Systematic Test Design

## Outcome

Produce the smallest test model giving convincing evidence for the behavior:

- the stable public or domain boundary under test;
- governing invariants;
- meaningful behavioral partitions;
- representative operation sequences;
- accepted, rejected, and preservation oracles;
- the testing forms that fit the risks;
- residual gaps that remain after implementation.

## Proportionality gate

Start every test-planning task here; scale work to risk.

One focused test suffices for an isolated change completely described by one
observable behavior. Use the full workflow for state/coupling, outputs consumed
by another operation, multiple result-changing dimensions, recurring defects in
one family, or review exposing missing systemic coverage.

Avoid decorative matrices for trivial changes.

## Planning-time use

When writing an issue/spec, invoke this skill and record must-test cases,
meaningful partitions, oracle surface and check location in the issue
(per [issue-workflow](../issue-workflow/SKILL.md)). Choose the spec's oracle
up front to prevent green-but-broken results. Implementers add to spec-named cases,
never silently drop them. Record contract clauses under **Docs impact**; separate
proven claims from residual gaps relying on review.

## Workflow

1. **Name the boundary.** Use the narrowest stable interface exposing real
   behavior; prefer domain/public interfaces to private helpers. Read applicable
   current engineering contracts before choosing cases.
2. **State the invariants.** Before examples, state what must always hold,
   including preservation and legal rejection. Report interface/contract
   mismatches; never silently redefine the invariant.
3. **Partition the state space.** Identify result-changing dimensions; select
   boundary, representative and adversarial values. Prefer risk-based/pairwise
   coverage to an exhaustive Cartesian product.
4. **Select sequences.** Use outputs as later inputs when edit order, retries,
   round trips or operation interactions can expose defects.
5. **Define the oracles.** Specify whole success, rejection and preservation
   evidence through [Oracle surface](#oracle-surface); avoid partial assertions
   permitting invalid surrounding state.
6. **Choose the test form.** Prefer reusable contracts for shared invariants,
   tables for partitions, model or property tests for broad state spaces, and
   mutation testing when fault sensitivity remains uncertain. Keep the form fast:
   follow ~/src/whiteroom-software-process/docs/reference/test-speed.md (no real sleeps,
   condition waits, deliberate timeouts, shape-compatible mocks).
7. **Execute incrementally.** Run one red-green-refactor cycle at a time; show
   each new behavior/regression failing against incomplete/buggy implementation
   before making it pass.
8. **Sweep the defect class.** Inspect sibling operations, ownership scopes,
   boundary values and sequences governed by a discovered bug's rule.
9. **Report evidence.** At handoff, name invariants, partitions, sequences,
   initial failures and residual gaps. Counts/coverage support, never replace,
   the conclusion.

## Oracle surface

Assert against the consumer's artifact: the exported file a slicer loads, clicked route,
rendered frame or published page; never generator internals. Source constants,
jsdom projections, prototype routes and pixel counts are adjacent properties.
Green suites prove nothing about unexercised consumer surfaces. Put one
acceptance check at an expensive consumer surface; cheap adjacent tests remain
diagnostics, never completion evidence.

### Transformation contract

For pure state transformations, accepted edits should normally prove:

- the input was not mutated;
- the complete output validates;
- observable projection is correct;
- dependent identities and references remain valid.

Rejected edits should normally prove:

- the complete prior state is unchanged;
- no partial side effect escaped;
- the rejection reason is observable when the API exposes one.

## Escalation

Repeated findings in one behavior family trigger stabilization: pause adjacent
feature expansion, strengthen the shared contract or model, sweep the defect
class, and resume only after the systemic evidence passes.

## Examples

- A copy change needs one focused rendering assertion, not a state matrix.
- A timeline move spanning owners needs invariants, boundary partitions,
  reference-preservation checks, and at least one move-then-edit sequence.
- A review-discovered parser bug needs a failing regression plus a sweep of
  sibling syntax forms governed by the same parsing rule.
