- Files: before sharing an artifact, read the [Files-view contract](~/src/whiteroom-software-process/docs/reference/contracts/runner-dashboard.md#files-view-199)
  for the current repository's configured artifact root/URL. Share its Files link.
- Issue folders: `<issue>-<slug>/` in that root. The top level holds current
  deliverables; move superseded files to `history/`, keeping their names and
  moving HTML with its referenced images. Logs, prompts and `.exit`, `.live`
  and `.pid` sidecars go in `work/`. Use only `history/` and `work/` as
  subfolders. `wrsp-agents check` reports working files at the top level and
  other subfolders with `layout:` lines.
- Bind previews to all interfaces; no SSH tunnels.
- Give Jon preview links as `http://Agent-Mini.local:<port>/...`, never `localhost`.
- Run `wrsp-preflight preview <port>` before giving Jon a preview link.
- Declare project standard preview port and port set in `wrsp.config.mjs` or
  `AGENTS.md`; no project ports hard-coded in WRSP.
- Serve latest `main` on the project's standard preview port; serve other
  work on other declared ports on the same host.
- Developers/eng leads may run concurrent previews.
- Jon sends screenshots to `~/inbox/screenshots/` on Agent Mini; ask them to
  send missing ones.
