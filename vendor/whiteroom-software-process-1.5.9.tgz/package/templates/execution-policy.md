# Execution policy

Read before implementation, research launches or scheduled
execution work, and when choosing a fallback, handling Git/GitHub failures, or
responding to non-convergence.
This authoritative policy's canonical install path is `~/.agents/execution-policy.md`;
this tracked file is its adoption source.
`wrsp-agents install` renders the role table from WRSP `templates/roles.yaml`; edit the template, never the installed copy (#287). Roles name models registered in WRSP `templates/models.yaml`; no role may list `gpt-6-astra` at `high` or `xhigh`. Other docs reference role names, never restate membership. Launchers take role ids with `--role-id` (#243).

## Roles

At launch, walk each role's ordered preference list top-down, skipping unavailable
models. An exhausted role stops: the operator names a specific model for any
further attempt. No cross-role fallback or urgency inference.

<!-- roles:begin (rendered from roles.yaml by wrsp-agents; edit the YAML, never the table) -->
| Role | Ordered members (model / effort) |
| --- | --- |
| `batch` | `gpt-6.1-sol` / `low` -> `claude-haiku-5-5` / `high` |
| `locator` | `claude-haiku-5-5` / `med` -> `gpt-6-luna` / `high` |
| `researcher` | `gpt-6.1-sol` / `med` -> `claude-opus-5-5` / `low` |
| `developer` | `gpt-6.1-sol` / `xhigh` -> `claude-opus-5-5` / `med` |
| `eng-lead` | `claude-opus-5-5` / `high` -> `gpt-6-astra` / `med` |
| `reviewer` | `gpt-6-astra` / `low` -> `claude-opus-5-5` / `high`; explicit pairs: `claude-opus-5-5` / `xhigh`, `gpt-6.1-sol` / `xhigh` (legacy `principal`) |
| `ux-principal` | `claude-fable-5-1` / `high` -> `claude-opus-5-5` / `high` |
| `principal-engineer` | `gpt-6-astra` / `med` -> `claude-opus-5-5` / `xhigh` |
<!-- roles:end -->

The `builder` role is retired (#441); confined execution launches use `batch`.
Ordinary implementation belongs to the developer at its current effort.

## Function map

| Function | Role |
| --- | --- |
| eng lead | `eng-lead` by default; `principal-engineer`, launched with an explicit pair (`--model claude-opus-5-5 --effort xhigh` or `--model gpt-6-astra --effort med`) when Jon names it |
| implementation | `developer`, implementing and testing its own slice |
| code review | `reviewer`; its explicit pairs for review selection only |
| design | `ux-principal` |
| ux design | `ux-principal` |
| research | `researcher`: native `researcher` agent in interactive Claude; `launch-worker.sh --research --cli codex` in Codex and headless Claude |
| bulk | `batch` |
| hardest escalation | `principal-engineer`, launched with an explicit pair (`--model claude-opus-5-5 --effort xhigh` or `--model gpt-6-astra --effort med`) |

No role named -> `developer`. Role word -> role id with aliases
(`supervisor` -> `eng-lead` unless Jon names `principal-engineer`,
`engineer` -> `developer`,
`hourly worker` -> `batch`). Function word -> role with the map above.
Unknown word -> ask; never guess. Name the role in the launch line as
`role:<id>` (for example `role:developer`); walk it, skipping unavailable;
exhausted stops.
`launch-worker.sh` refuses a `--model`/`--effort` pair that is not a member of the `--role-id` role in `~/.agents/roles.members`.
Model ids are exact `--model` strings. Codex: `--model <id>` with
`--config 'model_reasoning_effort="<effort>"'`; `-p <profile>` layers a config
selecting the model connection. Claude: `--model <claude-*>` with
`--effort <effort>`. GPT-family ids run only on the Codex default connection;
Claude-family ids only on the Claude CLI; the OpenRouter connection (today
`-p muse`) never carries GPT or Claude ids: subscription versus PAYG
multiples, and OpenRouter guardrails fail it closed. New profiles are named
here when added; never guess a profile. Model confirmation status lives in the
[model catalog](~/src/whiteroom-software-process/templates/models.yaml); unproven ids are skipped as unavailable, never
invented. Each launch still names the exact model and
effort explicitly; inheritance, aliases and configured defaults do not
establish the pair. Authorization, scope, concurrency, security and review
gates remain. Model choice grants no additional session launches.

Unavailability, exhausted quota, or provider failure advances to the next
eligible member within the named role only. Record the reason and selected pair
in the handoff. Skip models on a provider known to be exhausted or
unavailable; a model-specific failure does not establish provider-wide failure.
Keep independent work moving. If the role is exhausted, report the
unavailable choices and stop that launch; do not fall through to another role.
Authority failures follow the global failure-scope rule and **Route failures**
below; they are not provider unavailability.

## Route failures

Global `AGENTS.md` owns failure scope. Before changing a Git/GitHub connection:

1. Preserve the original operation, route and exact failure evidence. Identify
   the refusing authority and its scope from explicit evidence; a status such as
   403 or EPERM alone cannot do that. Unresolved provenance holds the uncertain
   action. A sandbox refusal supplies no host verdict or host retry authority;
   use only an already-authorized diagnostic or role handoff.
2. For a connection-only credential/capability failure, verify the existing
   alternative is independently authenticated as a permitted principal on the
   intended repository, supports the same already-authorized operation, and
   respects current session/tool/role/sandbox restrictions and Git gates
   (hooks, review, receipts, evidence, protection, signing and landing).
   Tool existence or urgency supplies no authority. Authority for
   push does not grant other mutations, installation, trust or release.
   A route change grants no credential, permission or configuration changes.
3. Check response fidelity: required fields, identity and history must remain
   available; after an authorized mutation, verify the same operation's result
   through normal read-back. Missing fidelity leaves that result unproved.
   Retain the failed-route evidence and report the replacement and its limits.
4. Syntax/usage, commit-subject, lint or test failures use the role's
   existing repair/handoff procedure. Before a normal gated retry, state the
   diagnosed cause, changed input and remaining proof. Developer repair and
   lander return duties remain in their skills. A gate refusal stays in force
   until its normal prerequisite is satisfied; never substitute raw Git, skip
   hooks, alter protection or force push.

Service/transport failures use existing bounded diagnostic and availability
guidance; they grant no retry-policy or provider-selection exception.

## Diagnose non-convergence

A developer's unsolved problem concerns reasoning or approach, not provider
unavailability. Preserve evidence and diagnose the invariant,
approach, or enforcement layer before another attempt. Escalation means the
operator names a specific role or model/effort pair with a concrete
changed approach, for example `role:principal-engineer` with an explicit pair or a fresh developer attempt
with a new hypothesis. State why that attempt should help; do not cycle models
indefinitely. A harder role is an explicit escalation, never an automatic
fallback or an inference from urgency.

Model changes preserve candidate lineage and the existing review breaker.
Three consecutive P0/P1-blocking reviews still require discussion with Jon
before a fourth review; a new lane, model, task, or fresh context cannot reset
that count. Repeated failure without a new hypothesis requires discussion,
not another automatic attempt. Review outcomes and availability failures remain
distinct.

## Use a capable launch interface

Codex collaboration, task or scheduled-work tools must expose both exact fields.
When supported, use `model` and `reasoning_effort` (or the tool's named equivalent)
explicitly, plus `role:<id>` in the launch line. If a chosen tool cannot express
a role plus pair, use an authorized capable CLI route or report the limitation.
Never translate an unsupported member launch into a different model.

For CLI execution, use normal input/workspace options for the prompt and
authorized workspace, and explicitly set:

- Codex: `--model <exact-model>` and `--config 'model_reasoning_effort="<effort>"'`.
- Claude: `--model <exact-model>` and `--effort <effort>`.

`launch-worker.sh` runs Claude confined executions with `--permission-mode auto`
(#151). It is not an implementation route for developer lanes.

Keep normal permission and sandbox controls. Selection flags neither prove
availability nor authorize permission changes. Preserve actual launch arguments
and returned outcome; never claim an unobserved model ran.
This policy does not supply a new dispatcher or automatic retry loop.

Headless Claude developer lanes route research through `launch-worker.sh --research --role-id researcher --cli codex --detach`, selecting a Codex researcher member; their `Agent`/`Task` deny remains.
Interactive Claude research uses the native `researcher` agent. The installed `Agent|Task` hook allows only that agent, whose definition pins the first Claude member of the `researcher` role, provides read-only web tools (`WebFetch`, `WebSearch`), and refuses a per-call model override. Every other native launch is refused; execution uses the CLI routes above.
Codex research uses `launch-worker.sh --research --role-id researcher`, which runs read-only with `web_search="live"` and needs no git repository (#133).

## Role tool limits

Batch and other confined execution launches require the installed neutral
`restricted` profile; `launch-worker.sh` applies it or refuses launch
(#178, #441). Developers implement directly with shared machine settings. WebFetch,
WebSearch and read-only `gh` stay allowed (Jon, 2026-10-18). The `role-gate`
hook backs the `gh`, push, tag and settings denies.

- Claude: `~/.agents/roles/restricted.claude.json` denies session, scheduling and subagent tools, `gh` issue, PR, release and label writes, `git push`, `wrsp-agents install` and `wrsp-agents roles apply`, and edits under `~/.claude`, `~/.codex`, `~/.agents` and `~/.claude.json`.
- Codex: `~/.agents/roles/restricted.codex.args` applies apps, browser, computer-use, image-generation and multi-agent feature overrides to execution and research launches. Collaboration-tool exclusion relies on the trusted `role-gate` hook for batch and every other restricted session; it matches tool names beginning `^collaboration` (#186). Feature overrides alone do not establish that exclusion. Read the [runtime qualification](~/src/whiteroom-software-process/docs/reference/evidence/issue504-codex-restricted-tools.md) when verifying tool visibility or hook enforcement.
- Codex skills: every Codex launch lists the skills in `~/.agents/skills`. `-c 'skills.config=[{name="<skill>", enabled=false}]'`, or `path=` the skill's `SKILL.md`, hides that skill from the launch (#183). The restricted profile hides `developer` and `eng-lead` this way; `launch-worker.sh` accepts that one `skills.config` disable-list shape besides `key=true|false` lines (#186).
- Claude skills: WRSP links each `~/.claude/skills/<name>` to `~/.agents/skills/<name>` for Claude Code discovery.
- Reviewers: the Codex reviewer launch passes the same five feature overrides from code, without the restricted profile's `skills.config` line (`CODEX_REVIEW_FEATURE_LIMITS` in `src/push-review.ts`), and the Claude reviewer stays limited to Read, Grep and Glob. Researchers: Codex research launches take the same overrides, and the Claude `researcher` agent keeps its Read, Grep, Glob, WebFetch and WebSearch tool list. Codex researchers can't run scripts: their read-only sandbox refuses heredocs, temp files and every write (Jon, 2026-10-27, #424). The developer runs needed scripts directly.

## Test planning

At assignment, the eng lead names the oracle and writes a test/proof sketch of
at most 10 bullets into the issue's Required proof and Tests, using
`~/.agents/skills/eng-lead/references/lane-brief-template.md`.
Before code, the developer expands it with `systematic-test-design` into the
detailed issue plan. The developer skill's
`~/.agents/skills/developer/references/responsibilities.md`, **Design and briefs**,
owns the plan's change locations, cases, partitions, setup/assertions,
preservation and proof detail. The developer implements, tests and repairs
directly. Invoke `git` for Git hygiene and `issue-workflow` before issue writes.

## Execution launcher

`launch-worker.sh` prepends the `batch` skill to execution briefs, validates
them, sets `WRSP_ROLE=batch`, logs output and uses launchd for detached
execution. It refuses retired builder before dispatch (#441). These confinement
mechanics do not delegate developer work.

The `~/.agents/skills/developer/references/execution-brief-template.md`
defines its seven required level-two slots. The phrase check ignores
inline code and fenced blocks and matches stems `establish`, `decid`, `choos`,
`choic`, `investigat`, `explor`, the verb forms
determine/determines/determined/determining, "decision on/about/between", and
find or figure followed by "out", including across a line break. Bare "find"
is allowed. The eval parent removes or explicitly justifies every hit before
using `--allow-phrase-hits`. This reference serves the retained harness only.

## Separate review and design

WRSP candidate review follows its ranked, cross-family policy and records
native receipt provenance. Read-only review and design workflows retain their
explicit model/effort selections. They grant no
implementation exception. Use their capable CLI or API routes; native Claude subagents other than `researcher` remain refused. Separate planning sessions retain
their existing explicit authorization requirement.
