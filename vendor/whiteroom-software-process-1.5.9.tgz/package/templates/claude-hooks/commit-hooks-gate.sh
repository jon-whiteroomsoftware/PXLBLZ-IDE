#!/bin/sh
# WRSP #137: deny a git commit in a worktree whose core.hooksPath directory is
# missing, because commits there run no hooks and git reports nothing. Best
# effort against a cooperative agent: the command forms enumerated below are
# the gate's whole domain, and every other shape is allowed.
# WRSP #167: workers also cannot override core.hooksPath with git -c,
# set core.hooksPath with git config, or set HUSKY=0.

command -v jq >/dev/null 2>&1 || exit 0

segments_def='
  def segments:
    (explode | map([.] | implode)) as $chars
    | reduce ($chars[]) as $c
        ({stack: [], cur: "", segs: [], esc: false, lastesc: false, comment: false, pend: [], body: false,
          line: "", i: -1, skip: 0, hd: null};
          .i += 1
          | ($chars[.i + 1] // "") as $next
          | (if .i > 0 then $chars[.i - 1] else "" end) as $prev
          | if .body then
              if $c == "\n" then
                (if .pend[0].strip then .line | sub("^\t+"; "") else .line end) as $line
                | if $line == .pend[0].d then .pend = .pend[1:] else . end
                | .body = (.pend | length > 0) | .line = ""
              else .line += $c end
            elif .skip > 0 then .skip -= 1
            elif .comment and $c != "\n" then .
            else
              (.lastesc) as $wasesc | .comment = false | .lastesc = false
              |
              # Finish the delimiter before processing its terminating operator.
              if .hd != null and .hd.q == "" and (.hd.esc | not)
                 and (($c | test("[\n;&|<>()]"))
                      or (.hd.phase == "word" and ($c | test("[[:space:]]")))) then
                if .hd.d != "" then .pend += [{d: .hd.d, strip: .hd.strip}] else . end
                | .hd = null
              else . end
              | if .hd != null then
                  .cur += $c
                  | if .hd.phase == "start" and $c == "-" then
                      .hd.strip = true | .hd.phase = "blanks"
                    elif (.hd.phase == "start" or .hd.phase == "blanks") and ($c == " " or $c == "\t") then
                      .hd.phase = "blanks"
                    else
                      .hd.phase = "word"
                      | if .hd.esc then .hd.d += $c | .hd.esc = false
                        elif $c == "\\" and .hd.q != "\u0027" then .hd.esc = true
                        elif .hd.q != "" then
                          if $c == .hd.q then .hd.q = "" else .hd.d += $c end
                        elif $c == "\u0027" or $c == "\"" then .hd.q = $c
                        else .hd.d += $c end
                    end
                elif .esc then .cur += $c | .esc = false | .lastesc = true
                elif .stack[-1] == "\u0027" then
                  .cur += $c | if $c == "\u0027" then .stack = .stack[:-1] else . end
                elif .stack[-1] == "$\u0027" then
                  .cur += $c
                  | if $c == "\\" then .esc = true
                    elif $c == "\u0027" then .stack = .stack[:-1]
                    else . end
                elif .stack[-1] == "\"" then
                  .cur += $c
                  | if $c == "\\" then .esc = true
                    elif $c == "\"" then .stack = .stack[:-1]
                    elif $c == "$" and $next == "(" and $chars[.i + 2] == "(" then .cur += "((" | .stack += ["(("] | .skip = 2
                    elif $c == "$" and $next == "(" then .cur += $next | .stack += ["$("] | .skip = 1
                    else . end
                elif .stack[-1] == "((" or .stack[-1] == "a(" then
                  .cur += $c
                  | if $c == "\\" then .esc = true
                    elif $c == "\u0027" or $c == "\"" then .stack += [$c]
                    elif $c == "(" then .stack += ["a("]
                    elif $c == ")" and .stack[-1] == "a(" then .stack = .stack[:-1]
                    elif $c == ")" and $next == ")" and .stack[-1] == "((" then .cur += $next | .stack = .stack[:-1] | .skip = 1
                    else . end
                else
                  if $c == "#" and ($wasesc | not) and (.cur == "" or (.cur | test("[ \t]$")) or ($prev | test("[;&|(<>\n]"))) then
                    .comment = true
                  elif $c == "\n" and (.pend | length > 0) then
                    .body = true | .line = ""
                    | if (.stack | length) == 0 then .segs += [.cur] | .cur = "" else .cur += $c end
                  elif (.stack | length) == 0 and ($c == ";" or $c == "|" or $c == "\n" or ($c == "&" and $next == "&")) then
                    .segs += [.cur] | .cur = ""
                    | if ($c == "&" or $c == "|") and $next == $c then .skip = 1 else . end
                  else
                    .cur += $c
                    | if $c == "\\" then .esc = true
                      elif $c == "$" and $next == "\u0027" then .cur += $next | .stack += ["$\u0027"] | .skip = 1
                      elif $c == "\u0027" or $c == "\"" then .stack += [$c]
                      elif $c == "$" and $next == "(" and $chars[.i + 2] == "(" then .cur += "((" | .stack += ["(("] | .skip = 2
                      elif $c == "$" and $next == "(" then .cur += $next | .stack += ["$("] | .skip = 1
                      elif $c == "(" and $next == "(" then .cur += $next | .stack += ["(("] | .skip = 1
                      elif (.stack[-1] == "$(" or .stack[-1] == "(") and $c == "(" then .stack += ["("]
                      elif (.stack[-1] == "$(" or .stack[-1] == "(") and $c == ")" then .stack = .stack[:-1]
                      elif $c == "<" and $next == "<" then
                        if $chars[.i + 2] == "<" then .cur += "<<" | .skip = 2
                        else .cur += $next | .skip = 1 | .hd = {phase: "start", d: "", strip: false, q: "", esc: false} end
                      else . end
                  end
                end
            end)
    | .segs[], .cur;
'

input=$(cat)
if [ "${WRSP_ROLE:-}" = batch ]; then
  bypass=$(printf '%s\n' "$input" | jq -r "$segments_def"'
    def token: "\"[^\"]*\"|\u0027[^\u0027]*\u0027|[^[:space:]\"\u0027]+";
    def trim: gsub("^[[:space:]]+|[[:space:]]+$"; "");
    if (.tool_input.command? | type) != "string" then empty
    else
      first(.tool_input.command | segments | trim
        | (gsub("[[:space:]]+[0-9]*(>>|>&|<&|>|<)[[:space:]]*[^[:space:]]*"; "")) as $plain
        | if test("^([^[:space:]]*/)?git([[:space:]]+(-C[[:space:]]+(" + token + ")|-c[[:space:]]*(" + token + ")))*[[:space:]]+-c[[:space:]]*[\"\u0027]?core\\.hookspath="; "i") then
            "-c core.hooksPath=…"
          elif ($plain | test("^([^[:space:]]*/)?git[[:space:]]+(-C[[:space:]]+(" + token + ")[[:space:]]+)?config([[:space:]]|$)"))
             and test("core\\.hookspath"; "i")
             and ($plain | test("(^|[[:space:]])(--unset|--unset-all|--replace-all|--add|set|unset)([[:space:]]|$)")
                  or test("core\\.hookspath[\"\u0027]?[[:space:]]+[^[:space:]-]"; "i"))
             and ($plain | test("(^|[[:space:]])(--get|--get-all|--get-regexp|--list|-l|get|list)([[:space:]]|$)") | not) then
            "git config core.hooksPath"
          elif test("^((export|env)[[:space:]]+)?([A-Za-z_][A-Za-z0-9_]*=[^[:space:]]*[[:space:]]+)*HUSKY=(0|\"0\"|\u00270\u0027)([[:space:]]|$)") then
            "HUSKY=0"
          else empty end)
    end
  ' 2>/dev/null) || bypass=
  if [ -n "$bypass" ]; then
    reason="Workers never disable git hooks; this command uses $bypass. If a commit hook fails, stop and report \`BRIEF GAP: commit hook\` with the failing lines, leaving the changes staged. (WRSP issue #167)"
    jq -cn --arg reason "$reason" '{hookSpecificOutput: {hookEventName: "PreToolUse", permissionDecision: "deny", permissionDecisionReason: $reason}}' 2>/dev/null
    exit 0
  fi
fi

targets=$(printf '%s\n' "$input" | jq -r --arg base "$PWD" --arg home "$HOME" "$segments_def"'
  def token: "\"[^\"]*\"|\u0027[^\u0027]*\u0027|[^[:space:]\"\u0027]+";
  def trim: gsub("^[[:space:]]+|[[:space:]]+$"; "");
  def resolve($base; $home):
    (if startswith("\"") or startswith("\u0027") then .[1:-1] else . end)
    | if . == "~" then $home
      elif startswith("~/") then $home + .[1:]
      elif startswith("/") then .
      else $base + "/" + . end;
  if (.tool_input.command? | type) != "string" then empty
  else
    (if (.cwd? | type) == "string" and (.cwd | length) > 0 then .cwd else $base end) as $start
    | reduce (.tool_input.command | segments | trim) as $segment
        ({base: $start, targets: []};
          ([$segment | capture("^cd[[:space:]]+(?<path>" + token + ")$")][0] // null) as $cd
          | ([$segment | capture("^([^[:space:]]*/)?git[[:space:]]+-C[[:space:]]+(?<path>" + token + ")[[:space:]]+commit([[:space:]]|$)")][0] // null) as $git_c
          | if $cd != null then
              (.base) as $current | .base = ($cd.path | resolve($current; $home))
            elif $segment | test("^([^[:space:]]*/)?git[[:space:]]+commit([[:space:]]|$)") then
              .targets += [.base]
            elif $git_c != null then
              (.base) as $current | .targets += [($git_c.path | resolve($current; $home))]
            else . end)
    | .targets[]
  end
' 2>/dev/null) || exit 0

printf '%s\n' "$targets" | while IFS= read -r target; do
  [ -d "$target" ] || continue
  configured=$(git -C "$target" config --type=path --get core.hooksPath 2>/dev/null) || continue
  [ -n "$configured" ] || continue
  top=$(git -C "$target" rev-parse --show-toplevel 2>/dev/null) || continue
  case "$configured" in
    /*) resolved=$configured ;;
    *) resolved=$top/$configured ;;
  esac
  [ -d "$resolved" ] && continue
  case "$configured" in
    .husky/_|.husky/_/|*/.husky/_|*/.husky/_/)
      remedy="Run \`npx husky\` in $top (it needs no network), or copy \`.husky/_\` from the shared checkout." ;;
    *)
      remedy="Install the repository's hooks in $top so the configured hooks directory exists." ;;
  esac
  reason="Git hooks are not installed in this worktree: core.hooksPath is \"$configured\", which resolves to $resolved, and that directory does not exist, so this commit would run no hooks. $remedy Then retry the commit. (WRSP issue #137)"
  jq -cn --arg reason "$reason" '{hookSpecificOutput: {hookEventName: "PreToolUse", permissionDecision: "deny", permissionDecisionReason: $reason}}' 2>/dev/null
  exit 0
done

exit 0
