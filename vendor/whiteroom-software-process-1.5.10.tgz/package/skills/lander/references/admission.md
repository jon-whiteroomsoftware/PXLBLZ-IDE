# Admission and repair

The eng lead assigns one queue owner: itself, or the lander for the delegated
scope. The lander handles developers directly from unreviewed intake through
proof and landing; a clean-reviewed `land request` can enter at Acknowledge.
The landing queue, reached through the owning skill's [Start](../SKILL.md#start),
owns admission, round limits and broadcast rules. This delegation changes their
operator only.

## Intake and slots

1. Read the issue's scope, acceptance criteria, oracle, Required proof and Tests.
   Obtain the developer's full range, worktree, session, test-design input,
   targeted-check evidence, current round count and any live review handles.
   Missing inputs go back to the developer; elapsed time proves nothing.
2. Reconcile existing holders and waiting lanes before issuing go. Track each
   holder separately up to `review.concurrency`; never start a second queue or
   duplicate a live review. A queued `review start` is a request, not go.
3. For unreviewed intake, admit the lane/issue under the existing queue protocol.
   Run native exact-range review in a clean detached checkout owned by the
   lander, following `git`, `reviewed-main-workflow` and `review-packet`. Never
   operate in the developer's worktree. Capture the final IDs after freshness
   checks; do not mutate that checkout/range during review. Reuse known handles
   after interruption. Preserve native cross-family selection and receipt rules.
4. On `review done`, acknowledge and release only the recovered terminal holder.
   Keep other holders intact. A clean candidate proceeds to proof verification
   and the developer's `land request` for Acknowledge; advisory coverage stays
   on the developer's advisory path.
   Native approval and contiguous coverage remain necessary for landing.

## Rounds and repairs

Track rounds per allocated task, including every predecessor's rounds. Apply the
queue's five-round limit and `reviewed-main-workflow`'s
three-consecutive-P0/P1 breaker; a successor or changed approach inherits the
round count. An execution error is not a round. Fresh lander review solely to
place already approved content on a train keeps the existing exception: it is
not a developer round; review of a developer repair is.

Return findings, conflicts and failed checks to the developer with exact range,
native outcome/receipt, failing oracle and next required proof. The developer
owns every content repair. Coordinate the replacement range directly, preserve
round history, and rejoin admission; never self-grant a slot or clear a finding.
Use the skill's Return procedure for an accepted train member.

At a round trip, send the lead a bounded escalation naming the decision needed
under the queue's Round limit. Record the answer and reason on the issue before
continuing. A second trip goes to Jon. No finding acceptance is inferred from
queue go, an approval, a role grant or a repair.

## Durable state

Keep admission holders, waiting lanes, allocated task/round count, exact ranges,
live handles, repair owner and next action in the lander's standing issue. Keep
candidate implementation and proof on its own issue. `train.json` retains its
existing schema and starts at clean-reviewed acceptance; it is not a substitute
for admission state. On resume, reconcile issue state and real processes before
releasing slots, restarting reviews or issuing go.

Report each landing's tip and touched files in the lead verdict so the existing
landing broadcast reaches every affected lane. When the lander owns the queue,
it forwards the broadcast to its holders and waiting lanes, records pending
delivery, and gives itself the current second-candidate list. The lead relays
to lanes outside that delegation. Preserve the queue's one-minute and pending
delivery rules.
