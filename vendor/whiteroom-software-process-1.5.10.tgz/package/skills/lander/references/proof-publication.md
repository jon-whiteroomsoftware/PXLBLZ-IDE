# Proof, publication and verdict

The lander opens proof artifacts and images, checks them against the issue
oracle, and prepares the publication packet. The eng lead receives only the
verdict and never opens a proof artifact or image. The eng lead runs the one push;
publication authorization, deployment, installation, tags and releases stay
with that role.

## Verify proof

Before accepting a candidate into a train, map every acceptance criterion and
named must-test case to observed evidence at the consumer's surface. Read the
issue's Required proof and Tests; inspect the running route, exported artifact,
image or other named oracle yourself. Agent reports and green suites alone do
not establish unexercised behavior.

Record the tested identity, case, observation and proof link on the candidate's
issue. Return missing, failing or stale proof to the developer with the exact
gap and required rerun. A proof verdict creates no review receipt or test
evidence. After rebase/repair, recheck evidence applicability and rerun affected
consumer cases before calling the candidate ready. Preserve all native gates.

## Prepare publication

Follow the landing queue's Publication section, linked from the owning skill's
[Start](../SKILL.md#start).
The lander prepares; the lead independently checks authority and pushes.

1. Freeze the full landed tip and remote base; record repository, outgoing
   range, issue/commit membership, required suites and authority source. Create
   a clean detached worktree at the frozen tip. Main may continue advancing.
2. Own final publication-suite submission and collection on the Test Mini.
   Reuse matching exact-tip evidence and known job handles, sharing them with
   the lead to prevent duplicate submissions. Collect only terminal jobs from
   that checkout; preserve the runner's transport, failure and retry rules.
3. Inspect contiguous review coverage, exact-tip suite evidence and the issue
   oracle at the frozen identity. Record passes and residual gaps separately;
   missing evidence, waived suites and accepted findings never become passes.
4. Prepare release notes and consumer bump issues as drafts, with per-version
   tarball and `.sha256` references when a release is intended. Record owners
   and outstanding release/adoption actions; the lead tags/releases and files
   the bump issues under the existing consumer policy. Use `issue-workflow`
   for authorized issue updates; preparation supplies no publication grant.
5. Keep the packet on the standing issue or in its Files folder. Include remote
   base, frozen tip, detached checkout, suites/results/job handles/evidence,
   review coverage, proof links/verdicts, authority source and pending recorder
   actions, release notes, bump drafts, residual gaps and the lead's next step.
   Send only its bounded verdict to the lead. The packet is a handoff, not an
   authorization record; the lead uses structured inspection for the exact
   scope and records any required Jon authorization itself.

A changed frozen tip needs new evidence, proof applicability and authority
checks. A remote race holds publication for reconciliation; never force-push
or silently advance the packet to newer main. The lead reinspects the frozen
scope and all independent gates, pushes explicitly from the prepared checkout,
verifies the remote result and performs the existing pushed-tip/closure duties.

## Verdict protocol

Every lead-bound message is at most 2000 tokens, including forwarded material.
Keep evidence detail, logs, screenshots and artifact contents in the lander
lane and issues. Summarize the observation and identity; a link is a locator,
not a request for the lead to open proof. Use this template, omitting fields
that do not apply:

```text
Verdict: ready | returned | blocked | escalation
Range: #issue full-base..full-tip; landed main and touched files if applicable
Proof: observed oracle cases, pass/fail and tested identity; evidence locators
Packet: remote base, frozen tip, checkout, suite/job/evidence and authority status
Residual: concrete gaps, next action and owner; release/bump draft locators
Decision: named question, options, recommendation and decision owner (escalation)
```

Check the complete message's token count before sending; condense to fit.
The receiver applies the same admission rule: Refuse an over-cap verdict and
return it to the lander for condensation. Refuse an escalation without a named decision
and return it for completion. Neither refusal releases a slot, authorizes a
push, accepts a finding or loses live-job state. Routine developer questions,
raw review output and proof contents go directly to the lander. Only the named
decision crosses to the lead; decisions reserved to Jon retain that owner.
