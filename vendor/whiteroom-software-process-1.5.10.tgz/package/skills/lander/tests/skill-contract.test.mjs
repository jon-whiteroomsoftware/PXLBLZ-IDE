import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '../../..');
const paths = [
  'skills/lander/SKILL.md',
  'skills/lander/references/admission.md',
  'skills/lander/references/proof-publication.md',
  'skills/eng-lead/SKILL.md',
  'skills/eng-lead/references/landing-queue.md',
  'skills/eng-lead/references/operator-acceptance.md',
];
const read = (path) => readFileSync(resolve(root, path), 'utf8');
const contains = (text, phrases) => {
  for (const phrase of phrases) assert.ok(text.includes(phrase), `missing: ${phrase}`);
};

test('lander routes admission, proof and packet work while preserving train gates', () => {
  const skill = read(paths[0]);
  const required = ['references/admission.md', 'references/proof-publication.md',
    'No pushes; the eng lead publishes', 'every repair is a return',
    '--carry-only', 'advisory-terminal', 'Land without invalidating approval',
    'No full suite outside the Test Mini'];
  contains(skill, required);
  for (const phrase of required.slice(0, 4)) {
    assert.throws(() => contains(skill.replaceAll(phrase, ''), required));
  }
});

test('admission owns independent holders, inherited rounds and developer repairs', () => {
  const admission = read(paths[1]);
  contains(admission, ['review.concurrency', 'review start', 'review done',
    'unreviewed', 'clean-reviewed', 'five-round', 'three-consecutive-P0/P1',
    'developer', 'No finding acceptance', 'oracle', 'round count']);
});

test('proof and publication packet bind the oracle and exact frozen identities', () => {
  const proof = read(paths[2]);
  contains(proof, ['every acceptance criterion', 'missing, failing or stale',
    'remote base', 'frozen tip', 'detached worktree', 'Test Mini',
    'job handles', 'release notes', 'bump issues', 'authority source',
    'changed frozen tip', 'remote race', 'eng lead runs the one push']);
});

test('verdict protocol refuses oversized messages and unnamed decisions', () => {
  const proof = read(paths[2]);
  const required = ['at most 2000 tokens', 'Refuse an over-cap verdict',
    'Refuse an escalation without a named decision',
    'Verdict:', 'Range:', 'Proof:', 'Packet:', 'Residual:', 'Decision:',
    'never opens a proof artifact or image'];
  contains(proof, required);
  // Each omitted guard must make the text check fail; these are instruction
  // regressions, not evidence that an agent followed the live protocol.
  for (const phrase of required.slice(0, 3)) {
    assert.throws(() => contains(proof.replace(phrase, ''), required));
  }
});

test('lead delegates preparation and retains publication authorization and push', () => {
  const authority = read(paths[3]).split('## Authority\n')[1].split('\n## ')[0];
  contains(authority, ['lander', 'verdict', 'never opens a proof artifact or image',
    'Own push', 'publication-acceptance recording']);
  const queue = read(paths[4]);
  contains(queue, ['queue owner', 'final publication-suite', 'lander',
    'eng lead runs the one push', 'Queue go grants admission, not acceptance']);
  contains(read(paths[5]), ['lander', 'responsible recorder', 'Eng lead']);
});

test('local Markdown paths and anchors resolve from the deployable skills', () => {
  for (const path of paths) {
    const text = read(path);
    for (const match of text.matchAll(/\[[^\]]*\]\(([^)]+)\)/g)) {
      const target = match[1];
      if (/^(?:[a-z]+:|~\/)/i.test(target)) continue;
      const [file, fragment] = target.split('#');
      const targetText = file ? readFileSync(resolve(root, dirname(path), file), 'utf8') : text;
      if (!fragment) continue;
      const anchors = [...targetText.matchAll(/^#{1,6}\s+(.+)$/gm)].map((heading) =>
        heading[1].toLowerCase().replace(/[^\p{L}\p{N}_\-\s]/gu, '').replace(/\s/g, '-'));
      assert.ok(anchors.includes(fragment), `${path}: unresolved ${target}`);
    }
  }
});
