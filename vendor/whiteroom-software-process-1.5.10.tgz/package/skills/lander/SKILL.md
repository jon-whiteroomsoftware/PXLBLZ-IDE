---
name: lander
description: Own candidate admission, review coordination, proof, merge trains and publication preparation. Invoke when Jon/eng lead names you lander, on resume and after compaction.
metadata:
  wrsp-min-version: "1.3.0"
---

# Lander

Own review admission, review rounds, developer repair coordination, proof against
the issue oracle, landing, and publication preparation. Talk to developers
directly; send the eng lead only a bounded verdict or a named decision.
Stack clean-reviewed candidates into a **train** on local `main`, carry each
approval, run one exact-tip suite, and fast-forward `main`. Bisect failures by
prefix. Design and contract grounding:
`~/src/whiteroom-software-process/docs/plans/275-lander-merge-train.md` (#275).

Candidate content belongs to its developer: **return** every conflict, carry
refusal not fixable by review alone, failed review or suite failure. Receipts
and exact-tip evidence authorize landing; the eng lead owns publication (#275,
Decision A1).

## Start

- Invoke `git` before the first commit and `issue-workflow` before the first
  issue write. Use `git` for worktrees/rebase and this skill for stack/carry.
- From the project checkout, run `node ~/.agents/hooks/session-role.mjs declare lander --issue <n>`, with `<n>` the lander's standing issue.
- Session title: `🛬 <Lane>: lander <repo>`.
- Work in the lane's own worktree, `~/src/worktrees/<repo>-issue-<n>-lander`. Never touch a developer's worktree.
- Keep accepted candidates, open train, ordered members, original/rebased
  ranges, live handles and pending returns in
  `<git-common-dir>/wrsp/lander/train.json` (schema below). Read it first each
  turn; write it last.
- Use `wrsp-wait` from the agent-host PATH (#290).
- For admission, rounds or broadcasts, read the
  [Landing queue](../eng-lead/references/landing-queue.md). Before preparing a
  publication packet, read its [Publication](../eng-lead/references/landing-queue.md#publication) section.
- For unreviewed intake, queue ownership, review rounds or repair hand-back, read
  [Admission and repair](references/admission.md). Clean-reviewed requests keep
  the Acknowledge path below.
- Before accepting proof, preparing publication or sending a lead verdict, read
  [Proof, publication and verdict](references/proof-publication.md).

## train.json

One JSON object, version 1. Every SHA is a full 40-character object id. Every
time is UTC ISO 8601.

| Field | Type | Meaning |
| --- | --- | --- |
| `version` | `1` | Schema version. |
| `standingIssue` | number | The lander's standing issue. |
| `worktree` | string | Absolute path of the lane worktree. |
| `main` | SHA | Local `main` at the last write. |
| `accepted` | Candidate[] | Accepted, not landed or returned, in acknowledgment order. |
| `openTrain` | Train \| null | The train being stacked, tested, or landed. |
| `returns` | Return[] | Returns decided but not yet sent and posted. |

- **Candidate:** `issue` (number), `base`, `tip` (SHA, as requested),
  `suites` (string[]), `session` (CCR session id), `acceptedAt` (time),
  `train` (number or null).
- **Train:** `id` (number), `base` (SHA, `main` when opened), `tip` (SHA),
  `members` (Member[], stack order), `suite` (Suite or null).
- **Member:** `issue`, `base`, `tip` (SHA, rebased range), `coverage`
  (`unchanged`, `carried` or `reviewed`), `reviewLog` (string or null, the
  `--detach` handle of a live fresh review).
- **Suite:** `jobId` (string), `tip` (SHA), `submittedAt` (time), `state`
  (`running`, `passed`, `failed` or `infrastructure-error`).
- **Return:** `issue`, `reason` (`conflict`, `review` or `suite`),
  `evidence` (string), `session` (CCR session id).

```json
{
  "version": 1,
  "standingIssue": 285,
  "worktree": "/Users/agent/src/worktrees/whiteroom-software-process-issue-285-lander",
  "main": "51b193068285fbdd3ef3bac4814396d7f8a890fc",
  "accepted": [
    {
      "issue": 279,
      "base": "51b193068285fbdd3ef3bac4814396d7f8a890fc",
      "tip": "b881eacfeb33573947d3335603d17fa6c359a6b2",
      "suites": ["package-tests"],
      "session": "session_01P4PoytfZ6FKeqFFutUvf8Q",
      "acceptedAt": "2026-10-21T16:34:44Z",
      "train": 1
    }
  ],
  "openTrain": {
    "id": 1,
    "base": "51b193068285fbdd3ef3bac4814396d7f8a890fc",
    "tip": "eddb809e0998c280f3fe3e22953f1d14e20d78bf",
    "members": [
      {
        "issue": 279,
        "base": "698a6e6557dda31c8e1b35e9ae9244b6f7f8ac5e",
        "tip": "eddb809e0998c280f3fe3e22953f1d14e20d78bf",
        "coverage": "carried",
        "reviewLog": null
      }
    ],
    "suite": {
      "jobId": "40f0ef24-80c5-431b-98db-6b6fa4abe169",
      "tip": "eddb809e0998c280f3fe3e22953f1d14e20d78bf",
      "submittedAt": "2026-10-21T16:46:16Z",
      "state": "running"
    }
  },
  "returns": []
}
```

## Each turn

Take one step per turn, then schedule a wake. Check suites/reviews once; never
block on them.

1. Read `train.json`.
2. Reconcile inbound work:
   - reconcile admission, repairs and proof with developers directly under
     [Admission and repair](references/admission.md);
   - handle the `land request` messages in this turn;
   - run `gh issue list --label ready-to-land` once; its durable label catches lost messages.
3. Check each live handle once:
   - a suite: `wrsp-wait runner:<jobId> --max 0`;
   - a review: `wrsp-wait <log> --max 0`, where `<log>` is the handle from
     `review:candidate --detach`.
4. Take the one step the state calls for: admit, review, verify proof,
   acknowledge, stack, carry, submit, fast-forward, bisect, return, or prepare
   publication. Send the lead a verdict at a boundary or a named escalation;
   developer exchanges and proof inspection stay in this lane.
5. Write `train.json`, then update each issue body at the boundary: accepted, landed,
   returned, train opened, train closed.
6. Schedule the next wake (`send_later`; `CronCreate` in a local session):
   - at the live job's expected finish: typical duration × (queue position + 1).
     Use step 3's `typical` value or the submit line's `(typical …)`, and the
     check's `QUEUED position <n>` (0 past the queue). If typical is `unknown`,
     wake in 20 minutes;
   - at the end of a second-candidate hold (Stack and carry);
   - or 20 minutes out when nothing is live.

## Acknowledge

A developer requests handover with
`land request #<issue> <base>..<tip> suites=<names> session=<id>`, plus the
`ready-to-land` label and the same line in the issue body. `<base>` and
`<tip>` are full 40-character SHAs. `<id>` is the requester's CCR session id
(`session_…`), the id `send_message` reaches; every reply goes there (#285).

1. Check the request:
   - both endpoints are full 40-character SHAs and `<id>` is a CCR session
     id. Otherwise reply `land refused #<issue> request-format`;
   - `npm run review:status -- <base> <tip>` reports `approved`, meaning the
     last edge is clean. Refuse `advisory` coverage: the developer lands it
     through the advisory path, or fixes the findings first;
   - the range is linear with no merges;
   - `refs/wrsp/train/<issue>` does not exist, unless the request is a
     follow-up (below).
2. Create `refs/wrsp/train/<issue>` at `<tip>`, so the commits outlive the
   developer's worktree.
3. Reply `land accepted #<issue> <tip> train <id> position <n>`, or
   `land refused #<issue> <reason>`. Swap the label to `🛬 in train`.
   The acknowledgment is the handover; ownership moves to the lander with it.

**Follow-up on an accepted candidate.** A developer who stacks more commits on
an accepted candidate sends a new `land request #<issue> <old-tip>..<new-tip>`,
where `<old-tip>` is the tip the lander accepted. Check it as above.
- If `train` is set, reply `land refused #<issue> stacked`. Check the field:
  a member already on `main` keeps its tip when stacked, so the ref cannot
  establish this. The developer rebases the follow-up onto `main` after
  `landed`, then sends a new request.
- Otherwise extend the ref by compare-and-swap:
  `git update-ref refs/wrsp/train/<issue> <new-tip> <old-tip>`. On success, set
  the candidate's `tip` to `<new-tip>` and reply `land accepted`. A failed swap
  means the ref moved; reply `land refused #<issue> stacked` (#285).

## Stack and carry

- **Opening.** Open when no lander suite is queued/running and at least one
  candidate is accepted. Arrivals during the suite join the next train.
  Cap: 4 members, excluding Markdown-only (`*.md`) members (#285).
- **Second-candidate wait.** After acceptance, hold the suite up to about
  5 minutes if the eng lead's latest broadcast/go names another lane in review
  or with an announced candidate. Schedule a wake at hold's end; submit then
  or when that candidate is accepted, whichever comes first. Otherwise submit
  at once (#300).
- **Order.** Apply the eng lead's order before stacking. Afterward, report
  reorder cost: rebase/carry every member above the moved one, possibly fresh
  review. Apply the order to the next train unless the eng lead still requests
  reordering this one (#285).
- **Overlap order.** Stack candidates touching the same files adjacently (#300).
- **Rebase.** Rebase each member, in acknowledgment order, onto the previous
  member's rebased tip:
  `git rebase --onto <train-tip> <base> <tip>`, on a detached HEAD in the lane
  worktree. Once the member keeps its coverage, move its ref to the rebased
  tip (`git update-ref refs/wrsp/train/<issue> <new-tip>`), so the stack a
  later member may need stays reachable.
- **Carry.** First run `npm run review:status -- <new-base> <new-tip>`. When it
  reports `approved`, the member keeps its coverage: a rebase that changed
  nothing leaves the reviewed identities, and carry would refuse them as
  `already-keyed`. Otherwise run
  `npm run review:candidate -- --carry-only --issue <n> <new-base> <new-tip>`.
  `--carry-only` launches no reviewer and takes no queue slot. A refused carry
  exits 3 with the reason, instead of starting a fresh review. It validates
  the checkout like any candidate (ER-1), so HEAD must be `<new-tip>`: carry
  each member right after its rebase, or `git checkout --detach <new-tip>`
  first (#285).
- **Carry refused.** The refusal line names the reason. Act on it:

  | Refusal (printed text) | Lander's action |
  | --- | --- |
  | `intervening landings touched stack files` (`files-overlap`) | The overlap rule, next bullet. |
  | `content differs after <m> of <n> commits` (`content-mismatch`) | The rebase changed reviewed content. Fresh review, as for an overlap with `main`. |
  | `base-not-descendant` | The approved chain starts on a base `main` does not contain. Fresh review, as for an overlap with `main`. |
  | `no approved range carries to this candidate` (`no-candidate`) | No receipt matches the rebased content. Fresh review, as for an overlap with `main`. |
  | `already holds approval receipts for this tip` (`already-keyed`) | Rerun `review:status` on the rebased range. `approved` keeps coverage; anything else gets a fresh review. |
  | `ends in advisory coverage` (`advisory-terminal`) | `review` return: only the developer can clear advisory findings. |
  | Any other reason | `review` return, with the refusal line as evidence. |

  Fresh review of the developer's approved content in its new place costs a
  queue slot, no developer round.
- **Carry refused on overlapping files.** Defer overlap with an earlier member
  to the next train, without return: it then overlaps `main` and needs fresh
  review, no developer round (#285). For overlap with `main`, request landing
  queue admission and review detached:
  `npm run review:candidate -- --detach --log <log> --issue <n> <new-base> <new-tip>`.
  Clean results keep the member. Any finding, including advisory, is a `review`
  return: the lander cannot repair findings; advisory-terminal coverage cannot
  supply a clean tail.
- **Conflicts.** Any conflict is a `conflict` return, sent at once. Abort the
  rebase. The lander never resolves a conflict.
  - With `main` itself: name the conflicting paths.
  - With an earlier member: name paths and its full rebased `tip` SHA from
    `openTrain.members`; the original tip omits intervening `main` commits and
    fails review freshness. The developer rebases onto that rebased tip,
    re-reviews and requests stacking behind it. Keep the SHA reachable through
    its train ref, then `main` after landing (#285).

## Suite, land, bisect

1. Submit one suite at the train tip:
   `wrsp-runner test <train-tip> --no-wait` (in WRSP itself, `node bin/wrsp-runner.mjs test <train-tip> --no-wait`). Record the job id.
2. On `WORKER EXITED passed`:
   - collect with `wrsp-runner collect <jobId>` (in WRSP itself, `node bin/wrsp-runner.mjs collect <jobId>`) from a clean checkout at the train tip, which writes the exact-tip evidence;
   - land under the review lock (B1, below);
   - send `landed #<issue> main=<sha>` to each member and record it in its issue body;
   - remove the label and delete `refs/wrsp/train/<issue>`;
   - tell the eng lead, in the bounded verdict, the landed tip, the files the landing touched
     (`git diff --name-only <old-main> <new-main>`) and its evidence, for
     publication and the landing broadcast (#300).
3. On `wrsp-wait runner:<jobId>` exit 3 (`WORKER STALLED`), check
   `wrsp-runner status <jobId>` once. [Job-liveness, runner rule 3](~/src/whiteroom-software-process/docs/reference/contracts/job-liveness.md#handle-kinds)
   measures elapsed execution time, not progress; another wait with the same
   stall limit immediately stalls again.
   - If finished, collect with `wrsp-runner collect <jobId>`, then report the
     terminal outcome to the eng lead. Runner rule 2 reports completion,
     including failure; follow the `passed` or `failed` path if applicable.
   - If status fails or cannot be parsed, use the exit-9 path below.
   - If still running, report once to the eng lead: job id, elapsed execution
     time, stall limit, train members and train tip. Record the pending answer
     in the standing issue and end the turn. Keep the train unlanded and its
     suite job untouched; skip this handle on scheduled wakes while awaiting
     the answer.
   - Act only on the eng lead's answer: re-wait on the same handle with an
     explicit larger `--stall`; cancel the lander's own job with
     `wrsp-runner cancel <jobId>`; or hand the train back. Never cancel another
     owner's job. [Runner cancellation mechanics](~/src/whiteroom-software-process/docs/reference/contracts/local-runner-jobs.md#transitions-and-failure)
     produce a `cancelled` outcome. No force or automatic resubmission;
     resubmit only when told (#407).
4. On `wrsp-wait` exit 9 or `RUNNER STATUS FAILED`, keep the known job id and
   never resubmit. Check it again on the next turn with
   `wrsp-wait runner:<jobId> --max 0`; `collect` waits for an unfinished job,
   so collect with `wrsp-runner collect <jobId>` only after the job reports a terminal outcome.
   Resubmit once at the same tip only after a terminal `infrastructure-error`
   outcome. Neither case starts a bisection.
5. On `failed`, bisect by prefix:
   - test the midpoint prefix tip, narrowing until the first failing prefix is
     found;
   - land the passing prefix that bisection found; its evidence is already
     exact-tip. Outcomes need not be monotonic, so it may not be the longest
     passing prefix;
   - return the first failing member, naming the members below it;
   - re-stack the rest as the next train.

**B1: land under the review lock (#275 Decision B1).** Follow
`reviewed-main-workflow`'s **Land without invalidating approval** for the local
`wrsp-land` procedure and refusal handling. When deferral names a live review
holder, write state and schedule a wake for when that review is expected to end.

## Return

A return sends `returned #<issue> <reason> <evidence>` to the requesting
session, or to the eng lead when that session has retired. The lander records
the same line in the issue body, removes the label, and deletes the train ref.
Reasons:
- `conflict`, with the conflicting paths, plus the earlier member's rebased
  tip when the conflict is with a member;
- `review`, with the findings path;
- `suite`, with the failing job's result and log paths.

Wrap-up (`📦 implemented`, proof, close) stays with the developer.

## Limits

- No pushes; the eng lead publishes the landed tip.
- No edits to candidate content: every repair is a return.
- No full suite outside the Test Mini.
- Rounds and the review breaker count against the candidate's developer, per
  `~/.agents/skills/eng-lead/references/landing-queue.md`. The lander's own
  fresh reviews of an approved candidate are not developer rounds; the
  developer's repair after a `review` return is.
- The standing issue carries train boundaries and handoffs only. A fix to the
  lander itself, its skill or its tools goes on its own issue (#285).
- At 80% of the context budget, write the handoff in the standing issue body:
  `train.json` state, live handles, and the next step. Then stop.
