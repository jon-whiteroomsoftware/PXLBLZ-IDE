# Durable times

Bind timestamps while preparing the local artifact. Put `{{time:now}}` where
the write needs current UTC time and `{{time:event:NAME}}` where it needs a
cited event time. Keep the event's source link and attribution in the draft.
For lead stamps, use `{{time:now:minute}}`: it projects that same observation
to `YYYY-MM-DD HH:MMZ`, retaining the date for lead rendering and age checks.

Run the binder with a new output path:

```sh
node ~/.agents/skills/issue-workflow/scripts/bind-durable-times.mjs \
  --draft draft.md --out bound.md \
  --event approval source-event.json /createdAt
```

The binder samples the clock once and reuses it for all `now` slots. Each event
binding reads a timestamp string from the saved source JSON using a JSON pointer
and copies it exactly, including offset and fractional seconds. Repeat `--event`
for distinct names; use `''` for a root string, `/events/0/createdAt` for an array,
`~1` for a slash in a key and `~0` for a tilde. Copy the source event's timestamp
field, rather than an observation or fetch time. The helper validates calendar
dates and requires an RFC3339 date-time with seconds and an explicit offset.

Open the output and check its times against the clock/source and its attribution
against the draft. Submit that artifact through the existing writer. For issue
bodies, pass it to `wrsp-issue-body --body-file`; for lead rewrites, replace the
intended Markdown and run `wrsp-lead render`. Lead additions keep using
`wrsp-lead log` or `append`, which already bind their clock.

The helper binds only marked slots. Replace a guessed literal in a draft with
the appropriate slot before binding. Unmarked historical times and quoted source
text stay unchanged; review their provenance. For sources outside JSON, copy the
observed event time verbatim with its citation; omit an unavailable time or mark
it unknown. Regenerate current-time slots for a later write from the slot draft,
keeping event times tied to the original source.

Missing slots, unbound events, malformed sources and invalid clocks refuse
before output creation. Usage errors exit 64; data/filesystem errors exit 65
with `DURABLE TIME REFUSED:`. The output must be a new file; an existing file is
preserved. The helper makes no remote writes and changes no publication checks.
