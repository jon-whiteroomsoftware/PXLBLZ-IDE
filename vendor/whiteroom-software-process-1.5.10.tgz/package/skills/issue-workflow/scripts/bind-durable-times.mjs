import { readFileSync, realpathSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

class TimeError extends Error {
  constructor(message, status = 65) { super(message); this.status = status }
}

/** Only marked slots are bound; all other draft bytes retain their provenance. */
export function bindDurableTimes(draft, events, clock = () => new Date()) {
  let current
  let slots = 0
  const bound = draft.replace(/\{\{time:([^{}]*)\}\}/g, (_, slot) => {
    slots++
    if (slot === 'now' || slot === 'now:minute') {
      if (current === undefined) {
        const observed = clock()
        if (!(observed instanceof Date) || !Number.isFinite(observed.getTime())) throw new TimeError('clock: invalid Date')
        current = observed.toISOString()
      }
      return slot === 'now' ? current : current.slice(0, 16).replace('T', ' ') + 'Z'
    }
    if (/^event:[A-Za-z][A-Za-z0-9_-]*$/.test(slot)) {
      const name = slot.slice('event:'.length)
      if (!events.has(name)) throw new TimeError(`unbound event: ${name}`)
      return events.get(name)
    }
    throw new TimeError('unknown time slot')
  })
  if (bound.includes('{{time:')) throw new TimeError('malformed time slot')
  if (!slots) throw new TimeError('draft has no time slots')
  return bound
}

function sourceValue(source, pointer, name) {
  if (pointer !== '' && (!pointer.startsWith('/') || /~(?:[^01]|$)/.test(pointer))) throw new TimeError(`event ${name}: invalid JSON pointer`)
  let value = source
  for (const token of pointer === '' ? [] : pointer.slice(1).split('/')) {
    const key = token.replace(/~1/g, '/').replace(/~0/g, '~')
    if (value === null || typeof value !== 'object' || !Object.hasOwn(value, key)) throw new TimeError(`event ${name}: missing source field ${pointer}`)
    value = value[key]
  }
  // Validate the local calendar separately: Date parsing alone normalizes Feb 30.
  const stamp = typeof value === 'string' && /^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:\.\d{1,9})?(?:Z|[+-]\d{2}:\d{2})$/.exec(value)
  const local = stamp && new Date(`${stamp[1]}Z`)
  if (!stamp || !Number.isFinite(local.getTime()) || local.toISOString().slice(0, 19) !== stamp[1] || !Number.isFinite(new Date(value).getTime())) {
    throw new TimeError(`event ${name}: expected an RFC3339 timestamp`)
  }
  return value
}

function argumentsFor(argv) {
  let draft
  let out
  const events = new Map()
  const take = (i, count) => {
    const values = argv.slice(i + 1, i + 1 + count)
    if (values.length !== count || values.some(value => value.startsWith('--'))) throw new TimeError(`missing arguments for ${argv[i]}`, 64)
    return values
  }
  for (let i = 0; i < argv.length; i++) {
    const flag = argv[i]
    if (flag === '--draft' || flag === '--out') {
      const [value] = take(i, 1)
      if (!value || (flag === '--draft' ? draft !== undefined : out !== undefined)) throw new TimeError(`invalid or duplicate ${flag}`, 64)
      if (flag === '--draft') draft = value
      else out = value
      i++
    } else if (flag === '--event') {
      const [name, file, pointer] = take(i, 3)
      if (!/^[A-Za-z][A-Za-z0-9_-]*$/.test(name) || !file) throw new TimeError('invalid event binding', 64)
      if (events.has(name)) throw new TimeError(`duplicate event: ${name}`, 64)
      events.set(name, { file, pointer })
      i += 3
    } else throw new TimeError(`unknown argument: ${flag}`, 64)
  }
  if (draft === undefined || out === undefined) throw new TimeError('required: --draft FILE --out NEW_FILE [--event NAME SOURCE_JSON JSON_POINTER]', 64)
  return { draft, out, events }
}

export function run(argv) {
  try {
    const args = argumentsFor(argv)
    const draft = readFileSync(args.draft, 'utf8')
    const sources = new Map()
    const events = new Map()
    for (const [name, { file, pointer }] of args.events) {
      const path = resolve(file)
      if (!sources.has(path)) sources.set(path, JSON.parse(readFileSync(path, 'utf8')))
      events.set(name, sourceValue(sources.get(path), pointer, name))
    }
    const bound = bindDurableTimes(draft, events)
    writeFileSync(args.out, bound, { flag: 'wx' })
    process.stdout.write(`wrote ${args.out}\n`)
    return 0
  } catch (error) {
    process.stderr.write(`DURABLE TIME REFUSED: ${error.message}\n`)
    return error instanceof TimeError ? error.status : 65
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === realpathSync(process.argv[1])) process.exitCode = run(process.argv.slice(2))
