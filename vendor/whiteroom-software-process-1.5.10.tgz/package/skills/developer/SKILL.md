---
name: developer
description: Assigned issue loop through design, implementation, tests, review and landing. Invoke on assignment and after compaction.
metadata:
  wrsp-min-version: "1.3.0"
---

# Developer

Own one assigned issue through design, implementation, tests, review and local landing.

Authorization to implement includes committing, cross-family review,
in-scope repair, and fast-forward landing on local `main`; continue through
that sequence without asking at each step. Request publication from the
eng lead; developers never push.

Global `AGENTS.md` holds shared rules; `~/.agents/execution-policy.md` owns
roles and test-planning placement.

## Start

On assignment, successor pickup and compaction:

1. Declare the telemetry label from the checkout:
   `node ~/.agents/hooks/session-role.mjs declare developer --issue <n>`
   (`--issue none` when unassigned). It grants nothing.
2. Self-test instructions/skills. Read issue-workflow's
   [Issue role](../issue-workflow/SKILL.md#issue-role),
   [Updating issues](../issue-workflow/SKILL.md#updating-issues) and
   [Claiming And Coordination](../issue-workflow/SKILL.md#claiming-and-coordination)
   for authentication, claims and Jon's verbatim instructions/source; claim
   before implementation.
   A lane brief handing issues to another developer names this claim step.
   Attribute lane.sh input to the eng lead; quote Jon only with his source.
3. Read the current issue and latest pickup for scope, oracle and next action.
   Read each linked section at its phase, including on successor pickup:
   `wrsp-section <file>#<anchor>`, with the link resolved from its file, one
   file per call (`wrsp-section <file>` lists headings). Skip prior process history.
4. Follow Session obligations below; enter the next phase through Phase reads.

## Session obligations

Read the context budget from installed `roles.members`. Check at check-ins and
before more work. Unknown budget/usage alone requires no checkpoint; keep it
unknown. Request handoff at 80% of a known budget or sooner;
read [Handoff](references/handoff.md#handoff) then.

## What the developer does and what it hands off

Decide, implement and test your slice at your current effort.

Plan review (advisory): before expanding the Tests or writing the
per-file plan, send the issue oracle and the eng lead's sketch to an ordinary
`reviewer` member of the other model family through the one-shot route,
`launch-worker.sh --role-id reviewer` ([Plan review](references/launches.md#plan-review)).
Fill the execution brief's [Source](references/execution-brief-template.md#source),
[Worktree](references/execution-brief-template.md#worktree),
[Changes](references/execution-brief-template.md#changes),
[Preservation](references/execution-brief-template.md#preservation),
[Tests](references/execution-brief-template.md#tests),
[Proof](references/execution-brief-template.md#proof) and
[Limits](references/execution-brief-template.md#limits) sections.
Record its independent list of risks and must-test cases in the issue Tests
(a linked issue comment when the body is full) with your disposition of each,
then expand and plan citing it. It produces no receipt, grants no approval or
publication authority, satisfies no gate and replaces no candidate review.

Then, before code,
expand the eng lead's oracle/test sketch through systematic-test-design's
[Workflow](../systematic-test-design/SKILL.md#workflow) into the issue's Tests:
cases, partitions, setup/assertions, preservation and proof.
Use Phase reads for duty references.

At headless-lane queue requests, handoffs and questions, end the turn; use a
backup wake only while the lane's own suite or review runs.

The lane brief carries no plan: the developer records the per-file plan in
the issue before the first edit, after the Tests expansion: files, functions,
skeleton, refusals and tests ([Plan and proof](references/launches.md#brief)).

The developer supplies requirement/source semantics via project policy and
`--test-design`; [Review](references/review.md#review) owns the input duties and
native assembly/refusal routing under ER-7.

Delegate fact-gathering beyond two searches or reads beyond one known file/line
range to a researcher; read only its report and check citations. Do smaller reads yourself
([Launch step 5](references/launches.md#launch)).

## Phase reads

- Seam reads, design, specs or test planning: [Design and briefs](references/responsibilities.md#design-and-briefs).
- Implementation: [Plan and proof](references/launches.md#brief).
- First commit, staging, worktree/hook setup: invoke `git`.
- Research/locator launch: [Brief](references/launches.md#brief) and
  [Launch](references/launches.md#launch), including execution.
- Supervision: [Supervise](references/launches.md#supervise).
- Diff checks, review, landing, talking with Jon, issue/doc writes: [Review and completion](references/responsibilities.md#review-and-completion).
- Review: [Review](references/review.md#review), `reviewed-main-workflow`, `review-packet`.
- Landing: [Landing](references/landing.md#landing), `reviewed-main-workflow`.
- Refusal, stalled/unavailable/exhausted role, or findings: [Recovery](references/recovery.md#recovery).
- At each push, landed batch, decision, check-in, setup or role transition,
  and at wrap-up or handoff, read [Handoff](references/handoff.md#handoff);
  for state updates, read [State updates](references/handoff.md#state-updates).
- Writing a pickup or stop report: [pickup template](references/pickup-template.md)
  and [stop-report template](references/stop-report-template.md).
- Assignment, changed work, successor pickup, completion or promotion: only [Session name](references/handoff.md#session-name).
- Messaging/sharing files: [Communication and files](references/responsibilities.md#communication-and-files); artifacts also require [Issue files](references/handoff.md#issue-files).
