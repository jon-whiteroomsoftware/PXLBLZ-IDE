#!/usr/bin/env bash
# Wait for a worker's <log>.exit completion file; exit 6 for live children, exit 7 for a refused launch.
# A live launch-worker handle that shows no model output within the produce grace exits 8;
# one whose session record stops growing for --stall seconds exits 3 (WRSP #248).
set -euo pipefail
script_dir=$(cd "$(dirname "$0")" && pwd -P)
source "$script_dir/worker-progress.sh"

usage() {
  echo 'Usage: wrsp-wait.sh <log> [--max <seconds>] [--stall <seconds>] (completion: <log>.exit)' >&2
  echo '       wrsp-wait.sh runner:<jobId> [--max <seconds>] [--stall <seconds>]' >&2
  echo 'Chained output uses NEXT: JSON with action, cwd and argv. Pass argv as separate arguments from cwd.' >&2
  echo 'Running prints wait; finished runner prints collect. Keep full returned handles.' >&2
  exit "${1:-64}"
}
[[ $# -ge 1 ]] || usage
if [[ $# -eq 1 && ( $1 == --help || $1 == -h ) ]]; then usage 0; fi
log=$1
shift
max=540
stall=${WRSP_WAIT_STALL:-600}
seen_max=0 seen_stall=0
while [[ $# -gt 0 ]]; do
  [[ $# -ge 2 && $2 =~ ^[0-9]+$ ]] || usage
  case "$1" in
    --max) [[ $seen_max -eq 0 ]] || usage; seen_max=1; max=$2 ;;
    --stall) [[ $seen_stall -eq 0 ]] || usage; seen_stall=1; stall=$2 ;;
    *) usage ;;
  esac
  shift 2
done
[[ $stall =~ ^[0-9]+$ ]] || usage
next_wait() {
  local full_log=$log
  case $full_log in /*|runner:*) ;; *) full_log=$PWD/$full_log ;; esac
  local args=("$full_log" --max "$max")
  local command=("$(command -v bash)" "$script_dir/wrsp-wait.sh")
  if [[ $log == runner:* ]]; then
    command=("$(command -v env)" "WRSP_RUNNER_BIN=$(command -v "${WRSP_RUNNER_BIN:-wrsp-runner}")" "${command[@]}")
  fi
  if [[ $seen_stall -eq 1 || -n ${WRSP_WAIT_STALL:-} ]]; then args+=(--stall "$stall"); fi
  node "$script_dir/next-invocation.mjs" wait "$PWD" "${command[@]}" "${args[@]}"
}
if [[ $log == runner:* ]]; then
  job=${log#runner:}
  [[ $job =~ ^([A-Za-z0-9][A-Za-z0-9._@-]*~)?[A-Za-z0-9._-]+$ ]] || usage
  runner_stderr=$(mktemp)
  trap 'rm -f "$runner_stderr"' EXIT
  interval=${WRSP_WAIT_RUNNER_INTERVAL:-15}
  start=$(date +%s)
  while :; do
    code=0
    status=$("${WRSP_RUNNER_BIN:-wrsp-runner}" status "$job" 2> "$runner_stderr") || code=$?
    if (( code == 0 )); then
      parsed=$(printf '%s' "$status" | node -e '
        function runnerStallLimit(typicalDurationMs) {
          return typicalDurationMs == null ? 600 : Math.max(600, 1.5 * typicalDurationMs / 1000);
        }
        let input = "";
        process.stdin.setEncoding("utf8");
        process.stdin.on("data", chunk => { input += chunk; });
        process.stdin.on("end", () => {
          try {
            const s = JSON.parse(input);
            const epoch = x => x == null ? "-" : Math.floor(Date.parse(x) / 1000);
            const seconds = Math.round(s.typicalDurationMs / 1000);
            const typical = s.typicalDurationMs == null ? "unknown" : seconds < 60
              ? `${seconds}s` : `${Math.floor(seconds / 60)}m${String(seconds % 60).padStart(2, "0")}s`;
            console.log([s.phase, s.outcome ?? "-", s.queuePosition ?? "-",
              epoch(s.timestamps.queuedAt), epoch(s.timestamps.executionStartedAt),
              s.timestamps.executionStartedAt ?? "-", typical, runnerStallLimit(s.typicalDurationMs)].join(" "));
          } catch { process.exitCode = 1; }
        });
      ') || code=$?
    fi
    if (( code != 0 )); then
      echo "RUNNER STATUS FAILED: exit $code"
      tail -n 20 "$runner_stderr"
      exit 9
    fi
    read -r phase outcome queue_position queued_at execution_started_at execution_started_iso typical runner_stall_limit <<< "$parsed"
    if [[ $seen_stall -eq 1 || -n ${WRSP_WAIT_STALL:-} ]]; then
      runner_stall_limit=$stall
    fi
    runner_stall_threshold=${runner_stall_limit%.*}
    now=$(date +%s)
    elapsed=$(( now - start ))
    if [[ $phase == finished ]]; then
      [[ $outcome != - ]] || outcome=unknown
      echo "WORKER EXITED $outcome"
      echo "COLLECT: wrsp-runner collect $job"
      node "$script_dir/next-invocation.mjs" collect "$PWD" "$(command -v "${WRSP_RUNNER_BIN:-wrsp-runner}")" collect "$job"
      exit 0
    fi
    if [[ $phase == running && $execution_started_at != - ]] && (( now - execution_started_at > runner_stall_threshold )); then
      echo "WORKER STALLED: running $(( now - execution_started_at ))s since execution start (limit ${runner_stall_limit}s)"
      exit 3
    fi
    if (( elapsed >= max )); then
      case "$phase" in
        queued) detail=QUEUED; [[ $queue_position == - ]] || detail="QUEUED position $queue_position" ;;
        running) detail="RUNNING since $execution_started_iso" ;;
        *) detail=$(printf '%s' "$phase" | tr '[:lower:]' '[:upper:]') ;;
      esac
      echo "WORKER RUNNING ${elapsed}s $detail typical $typical"
      next_wait
      exit 2
    fi
    sleep "$interval"
  done
fi
produce_grace=${WRSP_WAIT_PRODUCE_GRACE:-90}
progress=${log}.progress-seen
interval=${WRSP_WAIT_INTERVAL:-5}
start_grace=${WRSP_WAIT_START_GRACE:-60}
start=$(date +%s)

if [[ ! -e $log && ! -e ${log}.pid && ! -e ${log%.log}.prompt.md && ! -e ${log}.refused ]]; then
  echo "WAIT REFUSED: no worker log, pid or prompt at $log"
  exit 1
fi

while :; do
  if [[ -e ${log}.exit ]]; then
    code=$(cat "${log}.exit")
    if [[ -s ${log}.live ]]; then
      live_pids=()
      unverified=0
      # Preserve the marker as evidence; only its identity-matched survivors block collection.
      while IFS= read -r record || [[ -n $record ]]; do
        if [[ $record != *$'\t'* ]]; then
          unverified=1
          continue
        fi
        pid=${record%%$'\t'*}
        child_start=${record#*$'\t'}
        if [[ ! $pid =~ ^[1-9][0-9]*$ || -z ${child_start// /} || $child_start == *$'\t'* ]]; then
          unverified=1
          continue
        fi
        live_start=$(LC_ALL=C TZ=UTC ps -o lstart= -p "$pid" 2>/dev/null) || continue
        if [[ $live_start == "$child_start" ]]; then
          live_pids+=("$pid")
        fi
      done < "${log}.live"
      if (( ${#live_pids[@]} > 0 )); then
        echo "WORKER EXITED $code WITH LIVE CHILDREN: ${live_pids[*]}"
        if (( unverified )); then echo "UNVERIFIED CHILDREN: invalid records in ${log}.live"; fi
        tail -n 60 "$log"
        exit 6
      fi
      if (( unverified )); then
        echo "WORKER EXITED $code WITH UNVERIFIED CHILDREN: invalid records in ${log}.live"
        tail -n 60 "$log"
        exit 6
      fi
    fi
    if [[ $code == 10 && -s ${log}.availability ]]; then
      echo 'WORKER EXITED availability (10)'
      printf 'AVAILABILITY: %s\n' "$(cat "${log}.availability")"
      tail -n 60 "$log"
      exit 10
    fi
    echo "WORKER EXITED $code"
    tail -n 60 "$log"
    exit 0
  fi
  if [[ -e ${log}.refused ]]; then
    echo 'LAUNCH REFUSED'
    cat "${log}.refused"
    exit 7
  fi
  if [[ -s ${log}.pid ]] && ! kill -0 "$(cat "${log}.pid")" 2>/dev/null; then
    if [[ -e ${log}.exit ]]; then continue; fi
    echo 'WORKER EXITED unknown: no EXIT line, report missing'
    if [[ -f $log ]]; then tail -n 20 "$log"; fi
    exit 4
  fi
  elapsed=$(( $(date +%s) - start ))
  if [[ ! -e ${log}.pid ]] && (( elapsed >= start_grace )); then
    echo "WORKER NOT STARTED: no pid after ${elapsed}s; check launchctl list for the job label"
    exit 5
  fi
  # #248: a launch-worker handle (<log>.started) must show model output, then keep its session record growing; lane.sh turn handles have no .started and only report running or exited.
  if [[ -s ${log}.pid && -e ${log}.started ]]; then
    now=$(date +%s)
    seen_size= seen_at= seen_flag=
    if [[ -f $progress ]]; then read -r seen_size seen_at seen_flag < "$progress" || true; fi
    [[ $seen_size =~ ^[0-9]+$ && $seen_at =~ ^[0-9]+$ && $seen_flag == produced ]] || seen_size= seen_at=
    produced=worker_produced
    progress_label='session record'
    if [[ -e ${log}.progress ]]; then
      rec=$(worker_progress_path "$log") || rec=
      produced=worker_progress_produced
      progress_label='progress file'
    else
      rec=$(worker_record_path "$log") || rec=
    fi
    if [[ -z $seen_at ]]; then
      if [[ -n $rec ]] && "$produced" "$rec"; then
        seen_size=$(worker_record_size "$rec") seen_at=$now
        printf '%s %s produced\n' "$seen_size" "$seen_at" > "$progress.tmp.$$" && mv -f "$progress.tmp.$$" "$progress"
      else
        started_at=$(stat -f %m "${log}.started" 2>/dev/null) || started_at=$now
        since=$(( now - started_at ))
        if (( since >= produce_grace )); then
          echo "WORKER NOT PRODUCING: no model output ${since}s after start; check the worker's session"
          exit 8
        fi
      fi
    else
      size=$(worker_record_size "$rec")
      if [[ $size != "$seen_size" ]]; then
        printf '%s %s produced\n' "$size" "$now" > "$progress.tmp.$$" && mv -f "$progress.tmp.$$" "$progress"
      # Whole-second clocks: strictly greater guarantees at least --stall real seconds unchanged.
      elif (( now - seen_at > stall )); then
        echo "WORKER STALLED: $progress_label unchanged for $(( now - seen_at ))s"
        exit 3
      fi
    fi
  fi
  if (( elapsed >= max )); then
    echo "WORKER RUNNING ${elapsed}s"
    next_wait
    exit 2
  fi
  sleep "$interval"
done
