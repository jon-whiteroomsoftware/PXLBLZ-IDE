export function nextInvocation(action: string, argv: readonly string[], cwd?: string): string
