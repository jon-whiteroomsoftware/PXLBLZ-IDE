import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

// Argument vectors are data, including whitespace and shell metacharacters.
export function nextInvocation(action, argv, cwd = process.cwd()) {
  return `NEXT: ${JSON.stringify({ action, cwd, argv })}\n`
}

if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) {
  const [action, cwd, ...argv] = process.argv.slice(2)
  process.stdout.write(nextInvocation(action, argv, cwd))
}
