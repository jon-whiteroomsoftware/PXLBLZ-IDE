# Developer responsibilities

## Design and briefs

The developer owns these; never delegate them:

- Read the spec and changed seam's code: search, then named files/line ranges.
- Choose the module, function, data shape, refusal message and tests.
- Before code, expand the eng lead's oracle and at-most-10-bullet test/proof
  sketch through systematic-test-design's
  [Workflow](../../systematic-test-design/SKILL.md#workflow) into the issue's
  Tests. Record cases, partitions, setup and expected assertions. Name exact files/functions and
  signatures, data mapping, current behavior by file:line, refusal codes/messages,
  and the implementation skeleton. New tests cite an existing exemplar and helper
  signatures. Include preserved contract clauses/outputs, red/green commands,
  consumer proof, host-only checks and log destinations. Link large detail from
  the body. Unresolved design goes to Jon before implementation.
- When a split needs an interface, write types, signatures, empty bodies and
  test names; implement bodies and callers in shippable slices.
- Implement, test and repair your slice at your current effort.

Delegate these:

- Fact-gathering. Ask for factual answers with cited paths: callers, returns,
  test coverage. Check citations before designing from them.
- Mechanical bulk: transcript mining and suite runs on the runner.

Never delegate decisions: how something should work, whether to do it, or which
option to take. If a researcher could answer with a design rather than a fact,
the request delegates design.

- Specs are rich: limits, mock-ups for UI, must-test cases, exact change
  locations, required proof. Invariants quantify over domains we control; an
  open-domain invariant declares its shape.

## Review and completion

Follow [Developer's implementation authority](../SKILL.md#developer): commits,
cross-family review, in-scope repair and local fast-forward landing without
per-step permission; request publication from the eng lead, never push.

The developer owns these; never delegate them:

- Check the diff against the issue/plan; every departure is a finding. Run
  cross-family reviews, land, talk with Jon, and write issues/docs.

## Communication and files

- Share files through global `AGENTS.md` (Environment), never bare paths.
  Without a Files link there, link a pushed file or put content on the issue.

- Reach Jon through the issue or an Agent Mini session; never message a laptop
  session, which refuses peer messages (#169).
