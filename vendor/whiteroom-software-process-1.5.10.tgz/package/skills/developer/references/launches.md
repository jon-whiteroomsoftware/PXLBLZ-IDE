# Plan, proof and research launches

## Contents

- [Brief](#brief)
- [Launch](#launch)
- [Plan review](#plan-review)
- [Supervise](#supervise)

## Brief

Before code, record [Design and briefs](responsibilities.md#design-and-briefs)'
detailed issue plan. Size slices for about 70% context and approval within the
round limit. Land each part separately: interface, bodies, then callers when needed.

Research/bulk requests produce reports, not edits. Supply factual questions and
context for cited answers. `wrsp-wait` exits 3 when session-record size stays
unchanged beyond `--stall` seconds (default 600).

For chained calls, decode the command's `NEXT:` JSON and pass its `argv` elements
separately from its `cwd`. Retain full lane/log/job handles. Keep argument lists
as arrays and quote shell glob patterns. Inspect returned JSON keys/types before
extracting fields; resolve modules from the repository's package or use its
existing runner. A failed setup call is retried only after its diagnostic changes
the invocation data. Ordinary red tests keep their own meaning.

- **Hot files.** The lane brief names yours. Before editing another lane's,
  coordinate with its owner through the eng lead (which may connect you
  directly), or wait (landing-queue, Hot files).

  Follow the landing queue's Lander section
  (`~/.agents/skills/eng-lead/references/landing-queue.md`).

- Proportional proof: revert proof plus lint, typecheck and build for gate or
  CLI behaviour changes; the affected test file for doc and text changes.
  Host-side checks are the developer's, once, before commit.
- Every full suite runs on the Test Mini as `node bin/wrsp-runner.mjs test <tip>`
  (consumers: `wrsp-runner test <tip>`), never as a local `npm test` or
  `vitest run`; on Agent Mini those refuse (#256). Lint, typecheck, build and
  targeted test files stay local. Briefs say the same.

## Launch

1. Resolve role and pair through the execution policy: role or function
   word -> role id -> exact model/effort. Unknown word: ask. Exhausted role:
   stop; never fall through.
2. Write the factual request; record its pointer in the issue body through `issue-workflow`.
3. Codex and headless Claude research use
   `scripts/launch-worker.sh --research --role-id researcher --cli <claude|codex>`.
   Select a researcher member and the CLI for its model family. Claude runs
   `claude -p` with only the policy's read/search tools and strict empty MCP
   configuration; Codex uses its read-only research sandbox.
   It refuses a model/effort pair outside the named role or a missing `--issue <N>`.
   It records the launch and snapshots the issue (#196). Launch with `--detach`;
   it returns a handle once the researcher has started and refuses with exit 69
   when it does not start (#228). In
   Codex, run the launch as an escalated command. Then wait with
   `wrsp-wait <handle>` and call it
   again on `WORKER RUNNING`. The same two commands serve Claude and Codex.

   ```bash
   ~/.agents/skills/developer/scripts/launch-worker.sh --cli <claude|codex> \
     --research --role-id researcher --issue <N> --model <role-member> --effort <effort> \
     --worktree <dir> --brief <file> --log <file> --detach
   ```

4. Up to 2 concurrent researchers without asking (Jon, 2026-09-23).
   More needs Jon's opt-in with count and budget.
5. Interactive Claude research goes to the native `researcher` agent; other native Claude Agent|Task launches are hook-refused. Headless Claude lanes and Codex use step 3, which selects the exact researcher member through its CLI family.
6. A "where is X / who calls Y / which file defines Z" question goes to a locator in either harness: `launch-worker.sh --locate --role-id locator`, selecting the exact `--model` and `--effort` from the installed `locator` role and `--cli` by model family, with the question as `--brief`, the repository as `--worktree`, a `--log`, and `--issue <n>` so the run is attributed to that issue as role locator (#240). It runs synchronously and prints `REPOSITORY/REVISION/DIRTY` and the answer: a status, the scope searched and at most ten `path:start-end` hits. `PARTIAL` means narrow the question and launch again. "How does X work" stays with the researcher.

## Plan review

Plan review (#532, #556) is advisory: the developer records and disposes of its
list. It produces no receipt, grants no approval or publication authority,
satisfies no gate and replaces no candidate review.

1. Pair: an ordinary `reviewer` member in installed `roles.members`, never
   `explicitPairs`, whose family differs from yours. A Claude developer selects
   a GPT member with `--cli codex`; a Codex developer selects a Claude member
   with `--cli claude`. An unavailable member advances to the next such member;
   with none left, record `Plan review: unavailable (<reason>)` in the Tests.
2. Brief: the seven execution-brief slots. Source carries the oracle and the eng lead's
   sketch verbatim and is the only source: an issue link lets the worker
   recover an omitted oracle and hides the gap. Changes: none; print the list
   as the final report. Tests: at most 10 risks and 10 must-test cases, each
   citing `path:line` or `UNCITED`. Limits: no edits, `gh` writes or child
   agents. The banned-phrase check applies.
3. Launch detached, then `wrsp-wait <handle>`. Detaching also gives the child a
   clean environment; a foreground Codex child launched from Claude inherits
   `CLAUDE_CODE_SESSION_ID` and fails its declaration.

   ```bash
   ~/.agents/skills/developer/scripts/launch-worker.sh --cli <cli> \
     --role-id reviewer --issue <N> --model <reviewer-member> --effort <effort> \
     --worktree <dir> --brief <brief> --log <log> --detach
   ```

4. Read the final report from the log. A `BRIEF GAP:` line means the brief
   lacks the oracle or sketch: complete Source and relaunch.

## Supervise

- Stop processes only by exact PID after `ps -p <pid>`. Never use `pkill`,
  `killall`, `kill $(pgrep …)` or `pgrep … | xargs kill`
  ([incident](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/blob/49e548111b54bc7bbf60a861ae174accfc960aac/skills/developer/references/launches.md#L64)).
- Never read a running research worker's log/output or loop on `sleep`;
  wait only with `wrsp-wait.sh` (peeks reload the whole session context).
- Codex kills background processes at turn end; a backgrounded hooked commit
  dies mid-hook (#540). Run hooked commits, targeted suites and builds in the
  foreground with `wrsp-log <command>`. Work that must outlive the turn goes
  detached (`launch-worker.sh --detach`, `review:candidate --detach`, runner
  jobs); record its handle on the issue and name it at turn end.
- Never wait on a task notification alone: one can be lost (#245). Claude:
  before ending a turn while your own background job is alive, record its pid
  or log handle and its expected finish, and schedule a wake shortly after that
  (`send_later` in Claude remote, `CronCreate` in Claude local). Each later turn
  checks the job once, with `ps -p`, its `.exit` marker, or
  `wrsp-wait.sh <log> --max 0`. Read the log tail only after exit.
- Every background start names its product signal before it starts and is
  checked within 60 s: the launcher's `PRODUCING:` line for a research worker, a
  growing log for a suite or review, `wrsp-telemetry.sh verify` after a
  `launchctl` load or restart. Missing or empty output at that check is a
  failed start. A command that prints nothing until it exits (`tsc`,
  `npm run build`) has no product signal; a live pid stands in for one only
  up to a stated expected duration or the brief's cap, and passing that cap
  is a failure, never more waiting. For an ad-hoc wait on a condition, use
  `wrsp-poll`
  ([job-liveness](../../../docs/reference/contracts/job-liveness.md)).
- Report on four events only: exit, a `BRIEF GAP:` line, `WORKER NOT
  PRODUCING` (`wrsp-wait.sh` exit 8) and `WORKER STALLED` (exit 3: the
  session record unchanged for `--stall` seconds, default 600). Exits 8
  and 3 are failures to act on, never states to wait out. Exit 10 is provider
  availability: inspect retained worktree changes before relaunch; relaunch
  only by developer selection under the existing execution policy. See
  [job-liveness](../../../docs/reference/contracts/job-liveness.md#provider-availability-outcomes-332)
  for the outcome and wait contract.
- Liveness comes from the process table, never from the log's last line.
- Task names: `#<issue> <short task> [<actual port>]`; omit the port when
  none is allocated.

For other failures, read [Recovery](recovery.md#recovery).
