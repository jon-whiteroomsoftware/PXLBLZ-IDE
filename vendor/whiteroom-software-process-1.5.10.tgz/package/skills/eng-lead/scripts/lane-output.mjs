import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { optionalBytes } from './lane-messages.mjs';

export const MESSAGE_BYTES = 4096;
export const CHECK_BYTES = 8192;

// Keep the next UTF-8 character for a later read instead of splitting it.
function prefixEnd(bytes, limit) {
  let end = Math.min(bytes.length, Math.max(0, limit));
  while (end > 0 && end < bytes.length && (bytes[end] & 0xc0) === 0x80) end--;
  return end;
}

export function preview(bytes, limit, file, { total = false, suffix = '' } = {}) {
  if (bytes.length <= limit) return { output: bytes, exposed: bytes.length, truncated: false };
  let end = prefixEnd(bytes, limit);
  for (;;) {
    const footer = Buffer.from(`\nFULL: ${file}\nOMITTED: ${bytes.length - end} bytes\n${suffix}`);
    if (!total || end + footer.length <= limit) {
      return { output: Buffer.concat([bytes.subarray(0, end), footer]), exposed: end, truncated: true };
    }
    if (footer.length > limit) throw new Error('full-output pointer exceeds output cap');
    end = prefixEnd(bytes, limit - footer.length);
  }
}

// Oversized checks retain each event kind/lane, coalescing historical bursts.
export function checkSummary(bytes, file) {
  const groups = new Map();
  for (const line of bytes.toString('utf8').trimEnd().split('\n')) {
    const fields = line.split('\t');
    const key = JSON.stringify(fields.slice(0, 2));
    const group = groups.get(key);
    if (group) group.count++;
    else groups.set(key, { bytes: Buffer.from(line), count: 1 });
  }
  const footerSize = Buffer.byteLength(`\nFULL: ${file}\nOMITTED: ${bytes.length} bytes\n`);
  const perLine = Math.floor((CHECK_BYTES - footerSize) / groups.size);
  if (perLine < 64) return preview(bytes, CHECK_BYTES, file, { total: true }).output;
  let exposed = 0;
  const lines = [];
  for (const group of groups.values()) {
    const suffix = group.count > 1 ? ` [${group.count} events; details in FULL]` : '';
    const end = prefixEnd(group.bytes, Math.min(512, perLine - Buffer.byteLength(suffix) - 4));
    exposed += end + 1;
    lines.push(group.bytes.subarray(0, end).toString('utf8') + (end < group.bytes.length ? '…' : '') + suffix);
  }
  return Buffer.from(lines.join('\n') + `\n\nFULL: ${file}\nOMITTED: ${bytes.length - exposed} bytes\n`);
}

function rawRead(file, cursor, full) {
  const bytes = optionalBytes(file) ?? Buffer.alloc(0);
  const remaining = bytes.subarray(cursor);
  const result = full ? { output: remaining, exposed: remaining.length } : preview(remaining, MESSAGE_BYTES, path.resolve(file));
  const output = Buffer.concat([result.output, Buffer.from(`\nCURSOR: ${cursor + result.exposed}\n`)]);
  for (let offset = 0; offset < output.length;) {
    const written = fs.writeSync(1, output, offset, output.length - offset);
    if (written <= 0) throw new Error('incomplete output write');
    offset += written;
  }
}

function isEntry() {
  try { return process.argv[1] && fs.realpathSync(process.argv[1]) === fileURLToPath(import.meta.url); }
  catch { return false; }
}

if (isEntry()) {
  try { rawRead(process.argv[2], Number(process.argv[3]), process.argv[4] === 'yes'); }
  catch (error) { fs.writeSync(2, `REFUSED: ${error.message}\n`); process.exitCode = 65; }
}
