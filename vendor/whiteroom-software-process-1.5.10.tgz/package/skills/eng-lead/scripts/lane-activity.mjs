import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const count = value => Number.isSafeInteger(value) && value >= 0;
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const unknown = () => ({ state: 'unknown', key: '' });

// O_NONBLOCK prevents opening a FIFO from waiting for a writer.
export function readRegular(file) {
  const fd = fs.openSync(file, fs.constants.O_RDONLY | fs.constants.O_NONBLOCK);
  try {
    if (!fs.fstatSync(fd).isFile()) throw new Error('not a regular file');
    return fs.readFileSync(fd);
  } finally { fs.closeSync(fd); }
}

/** Native work events only; the key identifies a completed boundary, not prose. */
export function nativeActivity(handle, bytes) {
  const source = handle.verification?.source;
  if (!['claude', 'codex'].includes(handle.cli) || !handle.thread || handle.verification?.phase !== 'work' ||
      source?.provider !== handle.cli || source.session !== handle.thread || !count(source.start) ||
      source.start > bytes.length || (source.start > 0 && bytes[source.start - 1] !== 10)) return unknown();
  const current = bytes.subarray(source.start);
  if (!current.length || current.at(-1) !== 10) return unknown();
  let text;
  try { text = new TextDecoder('utf-8', { fatal: true }).decode(current); } catch { return unknown(); }
  const pending = new Set();
  let state = 'unknown', key = '', offset = source.start;
  const active = () => { state = 'live'; key = ''; };
  const finish = () => { state = pending.size ? 'live' : 'waiting-on-lead'; key = state === 'live' ? '' : String(offset); };
  for (const line of text.slice(0, -1).split('\n')) {
    offset += Buffer.byteLength(line) + 1;
    let row;
    try { row = JSON.parse(line); } catch { return unknown(); }
    if (!object(row)) return unknown();
    if (handle.cli === 'claude') {
      if (row.isSidechain || row.parentToolUseID || row.parent_tool_use_id) continue;
      if (row.sessionId !== undefined && row.sessionId !== handle.thread) return unknown();
      if (row.type === 'assistant' || row.type === 'user') {
        const message = row.message;
        if (!object(message) || message.role !== row.type) return unknown();
        if (row.type === 'user' && typeof message.content === 'string') { active(); continue; }
        if (!Array.isArray(message.content)) return unknown();
        for (const block of message.content) {
          if (!object(block)) return unknown();
          if (block.type === 'tool_use') {
            if (typeof block.id !== 'string' || !block.id) return unknown();
            pending.add(block.id);
          } else if (block.type === 'tool_result') {
            if (typeof block.tool_use_id !== 'string' || !block.tool_use_id) return unknown();
            pending.delete(block.tool_use_id);
          }
        }
        active();
        if (row.type === 'assistant' && message.stop_reason === 'end_turn') finish();
      } else if (['progress', 'api-request', 'attachment', 'queue-operation'].includes(row.type)) active();
      else if (row.type === 'system' && ['turn_duration', 'stop_hook_summary'].includes(row.subtype)) continue;
      else if (['file-history-snapshot', 'summary', 'custom-title', 'agent-name', 'cost-state', 'last-prompt', 'tools-used', 'mode', 'session-owner', 'atis-latch', 'api-request-blob'].includes(row.type)) continue;
      else return unknown();
    } else if (row.type === 'session_meta') {
      if (row.payload?.id !== handle.thread) return unknown();
    } else if (row.type === 'event_msg') {
      const type = row.payload?.type;
      if (type === 'task_complete') finish();
      else if (['token_count', 'token_usage_record', 'thread_settings_applied'].includes(type)) continue;
      else if (['task_started', 'agent_message', 'agent_reasoning', 'item_started', 'item_completed', 'user_message'].includes(type)) active();
      else return unknown();
    } else if (row.type === 'response_item') {
      const item = row.payload;
      if (!object(item)) return unknown();
      if (['function_call', 'custom_tool_call'].includes(item.type)) {
        if (typeof item.call_id !== 'string' || !item.call_id) return unknown();
        pending.add(item.call_id);
      } else if (['function_call_output', 'custom_tool_call_output'].includes(item.type)) {
        if (typeof item.call_id !== 'string' || !item.call_id) return unknown();
        pending.delete(item.call_id);
      } else if (!['message', 'reasoning'].includes(item.type)) return unknown();
      active();
    } else if (row.type === 'token_usage_record') continue;
    else if (['turn_context', 'compacted'].includes(row.type)) active();
    else return unknown();
  }
  return { state, key };
}

function providerTree(cli, pid) {
  const result = spawnSync('ps', ['-axo', 'pid=,ppid=,stat=,comm='], { encoding: 'utf8', timeout: 5000, maxBuffer: 8 * 1024 * 1024 });
  if (result.error || result.status !== 0) throw new Error('process snapshot unavailable');
  const rows = new Map();
  for (const line of result.stdout.trim().split('\n')) {
    const fields = /^\s*(\d+)\s+(\d+)\s+(\S+)\s+(.+?)\s*$/.exec(line);
    if (!fields) throw new Error('invalid process row');
    const [, id, parent, stat, comm] = fields;
    if (rows.has(Number(id))) throw new Error('duplicate process');
    rows.set(Number(id), { pid: Number(id), parent: Number(parent), live: !/^[ZX]/.test(stat), comm });
  }
  const wrapper = rows.get(pid);
  if (!wrapper?.live) return null;
  if (path.basename(wrapper.comm) !== 'bash') throw new Error('unknown turn wrapper');
  const children = id => [...rows.values()].filter(row => row.parent === id && row.live);
  let resolved;
  for (const directory of (process.env.PATH ?? '').split(path.delimiter)) {
    try { resolved = fs.realpathSync(path.join(directory, cli)); break; } catch { /* next PATH entry */ }
  }
  const isProvider = row => path.basename(row.comm) === cli || row.comm === resolved;
  const chain = new Set([pid]);
  let parent = wrapper;
  // Only known CLI launcher layers may precede the native provider.
  for (;;) {
    const next = children(parent.pid);
    const providers = next.filter(isProvider);
    if (providers.length === 1) {
      const provider = providers[0]; chain.add(provider.pid);
      // The Node Codex launcher can have the same comm as its native child.
      const nested = children(provider.pid).filter(isProvider);
      if (cli === 'codex' && nested.length === 1 && children(provider.pid).length === 1) { parent = provider; continue; }
      const extras = [...chain].some(id => children(id).some(row => !chain.has(row.pid)));
      return { ownJob: extras };
    }
    if (providers.length || next.length !== 1 || !['node', 'env'].includes(path.basename(next[0].comm)) || chain.has(next[0].pid)) throw new Error('provider not identified');
    parent = next[0]; chain.add(parent.pid);
  }
}

/** A missing/dead turn stays with the caller's ordinary exited/idle handling. */
export function observeLaneActivity(handle) {
  try {
    if (fs.existsSync(handle.contact + '.exit')) return null;
    let text;
    try { text = readRegular(handle.contact + '.pid').toString('utf8').trim(); }
    catch (error) { if (error.code === 'ENOENT') return null; throw error; }
    if (!/^[1-9]\d*$/.test(text) || !Number.isSafeInteger(Number(text))) return unknown();
    const tree = providerTree(handle.cli, Number(text));
    if (tree === null) return null;
    const activity = nativeActivity(handle, readRegular(handle.verification?.source?.path));
    if (activity.state === 'waiting-on-lead' && tree.ownJob) return { state: 'live', key: '' };
    return activity;
  } catch { return unknown(); }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try { console.log(observeLaneActivity(JSON.parse(readRegular(process.argv[2])))?.state ?? 'inactive'); }
  catch { console.log('unknown'); }
}
