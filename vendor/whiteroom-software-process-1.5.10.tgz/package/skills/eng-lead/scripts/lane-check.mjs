import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import { optionalBytes, pendingReview } from './lane-messages.mjs';
import { CHECK_BYTES, checkSummary } from './lane-output.mjs';
import { observeLaneActivity } from './lane-activity.mjs';

const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const count = value => Number.isSafeInteger(value) && value >= 0;
const identity = value => typeof value === 'string' && /^[A-Za-z0-9.-]+$/.test(value);
const filename = value => typeof value === 'string' && value.length > 0 && !value.includes('\0');
const sha = value => typeof value === 'string' && /^(?:[a-f0-9]{40}|[a-f0-9]{64})$/.test(value);
const percent = value => typeof value === 'number' && Number.isFinite(value) && value > 0 && value <= 100;
const clean = value => String(value).replace(/[\t\r\n]/g, ' ');
const unique = values => new Set(values).size === values.length;

function validateState(state) {
  if (!object(state) || state.version !== 1 || !filename(state.repo) || !filename(state.directory) ||
      !percent(state.threshold) || !sha(state.local) || !sha(state.origin) || !Array.isArray(state.lanes) ||
      !state.lanes.every(lane => object(lane) && identity(lane.identity) && typeof lane.retired === 'boolean' &&
        (lane.above === null || typeof lane.above === 'boolean') && Array.isArray(lane.finished) &&
        lane.finished.every(count) && unique(lane.finished) &&
        (lane.review === undefined || (object(lane.review) && count(lane.review.turn) &&
          typeof lane.review.message === 'string' && lane.review.message.length > 0)) &&
        (lane.activity === undefined || (object(lane.activity) && count(lane.activity.turn) &&
          ['waiting-on-lead', 'unknown'].includes(lane.activity.state) && typeof lane.activity.key === 'string')) &&
        (lane.waiting === undefined || (object(lane.waiting) && count(lane.waiting.turn) &&
          typeof lane.waiting.key === 'string'))) || !unique(state.lanes.map(lane => lane.identity))) {
    throw new Error('invalid version 1 state');
  }
}

/** Pure projection: context side survives unknown readings, and tombstones retain history. */
export function projectCheck(snapshot, previous, threshold) {
  if (!percent(threshold)) throw new Error('invalid threshold');
  if (previous !== null) {
    validateState(previous);
    for (const key of ['repo', 'directory']) {
      if (previous[key] !== snapshot[key]) throw new Error(`${key} configuration mismatch`);
    }
    if (previous.threshold !== threshold) throw new Error('threshold configuration mismatch');
  }
  const identities = new Set();
  for (const lane of snapshot.lanes) {
    if (identities.has(lane.identity)) throw new Error(`duplicate lane identity ${lane.identity}`);
    identities.add(lane.identity);
  }
  const lines = [];
  for (const [key, label] of [['local', 'local'], ['origin', 'origin']]) {
    if (!previous || previous[key] !== snapshot[key]) lines.push(`main\t${label}\t${snapshot[key]}`);
  }
  const old = new Map((previous?.lanes ?? []).map(lane => [lane.identity, lane]));
  const current = new Map(snapshot.lanes.map(lane => [lane.identity, lane]));
  const lanes = [];
  for (const name of [...new Set([...old.keys(), ...current.keys()])].sort()) {
    const lane = current.get(name), prior = old.get(name);
    if (!lane) {
      if (!prior.retired) lines.push(`retired\t${clean(name)}`);
      lanes.push({ ...prior, finished: [...prior.finished], retired: true });
      continue;
    }
    // Keep notification identity independently of transient observation state.
    let waiting = prior?.waiting ?? (prior?.activity?.state === 'waiting-on-lead'
      ? { turn: prior.activity.turn, key: prior.activity.key } : undefined);
    if (waiting?.turn !== lane.turn) waiting = undefined;
    const known = lane.context !== null;
    const above = known ? lane.context >= threshold : prior?.above ?? null;
    const finished = [...lane.finished].sort((a, b) => a.turn - b.turn);
    const seen = new Set(prior?.finished ?? []);
    const context = known ? `${lane.context}%` : 'unknown';
    const currentExit = finished.find(turn => turn.turn === lane.turn)?.exit ?? 'unfinished';
    const added = !prior || prior.retired;
    if (lane.retired) {
      if (prior && !prior.retired) lines.push(`retired\t${clean(lane.identity)}`);
    } else {
      if (added) lines.push(['lane', lane.identity, lane.slot ?? lane.identity, 'turn', lane.turn, 'exit', currentExit, 'context', context].map(clean).join('\t'));
      for (const turn of finished) {
        if (!seen.has(turn.turn) && !(added && turn.turn === lane.turn)) {
          lines.push(['finished', lane.identity, 'turn', turn.turn, 'exit', turn.exit, 'context', context].map(clean).join('\t'));
        }
      }
      if (!added && known && above && prior.above === false) lines.push(['context', lane.identity, 'turn', lane.turn, context].map(clean).join('\t'));
      if (lane.review && (lane.review !== prior?.review?.message || lane.turn !== prior?.review?.turn)) lines.push(['review-request', lane.identity, 'turn', lane.turn, lane.review].map(clean).join('\t'));
      if (lane.activity?.state === 'waiting-on-lead') {
        if (waiting?.key !== lane.activity.key) lines.push(['waiting-on-lead', lane.identity, 'turn', lane.turn, 'needs lead action'].map(clean).join('\t'));
        waiting = { turn: lane.turn, key: lane.activity.key };
      } else if (lane.activity && (lane.activity.state !== prior?.activity?.state || lane.turn !== prior?.activity?.turn)) {
        lines.push(['activity-unknown', lane.identity, 'turn', lane.turn].map(clean).join('\t'));
      }
    }
    for (const turn of finished) seen.add(turn.turn);
    lanes.push({ identity: lane.identity, retired: lane.retired, finished: [...seen].sort((a, b) => a - b), above,
      ...(lane.review ? { review: { turn: lane.turn, message: lane.review } } : {}),
      ...(lane.activity ? { activity: { turn: lane.turn, ...lane.activity } } : {}),
      ...(waiting ? { waiting } : {}) });
  }
  return {
    output: (lines.length ? lines.join('\n') : 'no changes') + '\n',
    state: { version: 1, repo: snapshot.repo, directory: snapshot.directory, threshold, local: snapshot.local, origin: snapshot.origin, lanes },
  };
}

function source(file, action) {
  try { return action(); } catch (error) { throw new Error(`${file}: ${error.message}`); }
}
function refillSuppression() {
  const scripts = path.dirname(fileURLToPath(import.meta.url));
  const built = path.resolve(scripts, '../../../dist/launch-retry-runtime.mjs');
  const runtime = fs.existsSync(built) ? built : path.resolve(scripts, '../../developer/scripts/launch-retry-runtime.mjs');
  try {
    const result = spawnSync(process.execPath, [runtime, 'marker-status'], { encoding: 'utf8', timeout: 5000 });
    if (result.stderr) fs.writeSync(2, result.stderr);
    if (result.error || result.status !== 0) throw new Error('marker status unavailable');
    const marker = JSON.parse(result.stdout);
    return marker.throttled === true && marker.overridden !== true && typeof marker.throttledUntil === 'string'
      ? `refill skipped until ${clean(marker.throttledUntil)}\n` : '';
  } catch {
    fs.writeSync(2, 'WARNING: launch backoff status unavailable; refill suppression skipped\n');
    return '';
  }
}
function optional(file) {
  try { return fs.readFileSync(file, 'utf8'); }
  catch (error) { if (error.code === 'ENOENT') return null; throw error; }
}
function validEvent(row, lane) {
  return object(row) && typeof row.at === 'string' && /^\d{4}-\d\d-\d\dT.*Z$/.test(row.at) &&
    Number.isFinite(Date.parse(row.at)) && row.lane === lane && typeof row.slot === 'string' &&
    count(row.turn) && count(row.issue) && (row.reason === null || typeof row.reason === 'string') &&
    ['started', 'work-sent', 'assigned', 'released', 'blocked', 'retired'].includes(row.event) &&
    (row.event !== 'work-sent' || (typeof row.sha256 === 'string' && /^[a-f0-9]{64}$/.test(row.sha256) && typeof row.firstLine === 'string'));
}
function readLane(directory, name) {
  const file = path.join(directory, name);
  const handle = source(file, () => {
    const row = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (!object(row) || !identity(row.lane) || !count(row.turn) ||
        !filename(row.contact) || (row.slot !== undefined && typeof row.slot !== 'string') ||
        (row.turns !== undefined && (!Array.isArray(row.turns) || !row.turns.every(turn =>
          object(turn) && count(turn.n) && turn.n <= row.turn && filename(turn.log)) ||
          !unique(row.turns.map(turn => turn.n)) || row.turns.some(turn => turn.n === row.turn && turn.log !== row.contact)))) {
      throw new Error('invalid handle identity/turn/contact/turns');
    }
    return row;
  });
  const eventsFile = path.join(directory, handle.lane + '.events.jsonl');
  const retired = source(eventsFile, () => {
    const text = optional(eventsFile);
    if (text === null) return false;
    let last;
    // A final unterminated fragment belongs to an in-flight append.
    for (const line of text.slice(0, text.lastIndexOf('\n') + 1).split('\n').slice(0, -1)) {
      const row = JSON.parse(line);
      if (!validEvent(row, handle.lane)) throw new Error('invalid lifecycle event');
      last = row;
    }
    return last?.event === 'retired';
  });
  const turns = [...(handle.turns ?? [])];
  if (!turns.some(turn => turn.n === handle.turn)) turns.push({ n: handle.turn, log: handle.contact });
  const finished = [];
  for (const turn of turns) {
    const exitFile = turn.log + '.exit';
    const exit = source(exitFile, () => {
      const text = optional(exitFile);
      if (text === null) return null;
      if (!/^\d+\s*$/.test(text) || !Number.isSafeInteger(Number(text)) || Number(text) > 255) throw new Error('invalid turn exit');
      return Number(text);
    });
    if (exit !== null) finished.push({ turn: turn.n, exit });
  }
  const value = handle.context;
  const context = object(value) && value.turn === handle.turn && count(value.inputTokens) &&
    count(value.budget) && value.budget > 0 ? value.inputTokens / value.budget * 100 : null;
  // Read only this turn: an admitted follow-up supersedes any prior request.
  const bytes = !retired && ['claude', 'codex'].includes(handle.cli) ? optionalBytes(handle.contact) : null;
  const review = bytes === null ? null : pendingReview(handle.cli, bytes);
  const observed = !retired && !finished.some(turn => turn.turn === handle.turn) ? observeLaneActivity(handle) : null;
  const activity = observed && observed.state !== 'live' ? observed : null;
  return { identity: handle.lane, slot: handle.slot ?? handle.lane, turn: handle.turn, retired, context, finished, review, activity };
}

function parseArgs(args) {
  const [directory, ...flags] = args;
  const full = flags.includes('--full');
  if (full) flags.splice(flags.indexOf('--full'), 1);
  if (!directory || directory.startsWith('--') || flags.length !== 6) throw new Error('expected DIR --repo ROOT --state FILE --threshold P');
  const values = {};
  for (let index = 0; index < flags.length; index += 2) {
    const key = flags[index], value = flags[index + 1];
    if (!['--repo', '--state', '--threshold'].includes(key) || key in values || !value || value.startsWith('--')) throw new Error('invalid or duplicate argument ' + key);
    values[key] = value;
  }
  const threshold = Number(values['--threshold']);
  if (!percent(threshold)) throw new Error('invalid threshold');
  return { directory, repo: values['--repo'], stateFile: path.resolve(values['--state']), threshold, full };
}

/** CLI only; importing the module never reads sources, writes state, or emits output. */
export function main(args) {
  let options;
  try { options = parseArgs(args); }
  catch (error) { fs.writeSync(2, `REFUSED: ${error.message}\n`); return 64; }
  const { stateFile, threshold } = options;
  const lock = stateFile + '.lock';
  let ownedLock = false, temp;
  try {
    source(lock, () => fs.mkdirSync(lock));
    ownedLock = true;
    const previous = source(stateFile, () => {
      const text = optional(stateFile);
      if (text === null) return null;
      const value = JSON.parse(text);
      validateState(value);
      return value;
    });
    const repo = source(options.repo, () => fs.realpathSync(options.repo));
    const directory = source(options.directory, () => fs.realpathSync(options.directory));
    if (previous) source(stateFile, () => {
      if (previous.repo !== repo) throw new Error('repo configuration mismatch');
      if (previous.directory !== directory) throw new Error('directory configuration mismatch');
      if (previous.threshold !== threshold) throw new Error('threshold configuration mismatch');
    });
    const ref = name => source(repo, () => {
      const result = spawnSync('git', ['-C', repo, 'rev-parse', '--verify', name], { encoding: 'utf8' });
      const value = result.stdout?.trim();
      if (result.error || result.status !== 0 || !sha(value)) throw new Error('invalid repository ref ' + name);
      return value;
    });
    const identities = new Set();
    const snapshot = { repo, directory, local: ref('refs/heads/main'), origin: ref('refs/remotes/origin/main'),
      lanes: source(directory, () => fs.readdirSync(directory)).filter(name => name.endsWith('.lane.json')).sort().map(name => {
        const lane = readLane(directory, name);
        if (identities.has(lane.identity)) throw new Error(`${path.join(directory, name)}: duplicate lane identity ${lane.identity}`);
        identities.add(lane.identity);
        return lane;
      }) };
    const result = projectCheck(snapshot, previous, threshold);
    result.output += refillSuppression();
    let output = Buffer.from(result.output);
    if (!options.full && output.length > CHECK_BYTES) {
      const report = `${stateFile}.report.${randomUUID()}.txt`;
      source(report, () => {
        const fd = fs.openSync(report, 'wx', 0o600);
        try { fs.writeFileSync(fd, output); }
        finally { fs.closeSync(fd); }
      });
      output = checkSummary(output, report);
    }
    const candidate = `${stateFile}.tmp.${randomUUID()}`;
    // Claim ownership only after exclusive creation; never clean someone else's file.
    source(candidate, () => { const fd = fs.openSync(candidate, 'wx', 0o600); temp = candidate; fs.closeSync(fd); });
    source(candidate, () => fs.writeFileSync(candidate, JSON.stringify(result.state) + '\n'));
    source('stdout', () => {
      const bytes = output;
      let offset = 0;
      while (offset < bytes.length) {
        const written = fs.writeSync(1, bytes, offset, bytes.length - offset);
        if (written <= 0) throw new Error('incomplete output');
        offset += written;
      }
    });
    source(stateFile, () => fs.renameSync(temp, stateFile));
    temp = undefined;
    return 0;
  } catch (error) {
    fs.writeSync(2, `REFUSED: ${error.message}\n`);
    return 65;
  } finally {
    if (temp) fs.unlinkSync(temp);
    if (ownedLock) fs.rmdirSync(lock);
  }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) process.exitCode = main(process.argv.slice(2));
