# Eng lead operations

## Contents

- [Lead files](#lead-files)
- [Check in](#check-in)
- [Claude eng-lead handover](#claude-eng-lead-handover)
- [Claude eng lead](#claude-eng-lead)
- [Codex eng lead](#codex-eng-lead)
- [Lane turns](#lane-turns)
- [Lane check](#lane-check)
- [Names and instructions](#names-and-instructions)
- [Pushes while Jon is away](#pushes-while-jon-is-away)
- [Visibility](#visibility)

Operate one project and only the lane tree you started, under eng-lead skill
ownership. Claude is the unattended eng-lead default, with mixed
Claude and Codex developers. A Codex eng lead runs only while Jon drives the
session, with Codex and headless Claude developers.

Invoke `git` before the first commit and `issue-workflow` before the first issue write.

## Lead files

Keep lead files in the project's leads Files root, a `leads/` directory beside its
artifacts root (Files root `<project>-leads`), in one folder per lead assignment:
`<issue>-<slug>/`, or `<slug>/` without an issue. Each file exists once: a
successor keeps the folder; a move leaves a one-line pointer stub at the old
path. Only lead files and their archives live there; lane briefs and lane
records stay in the issue's briefs folder (Jon, 2026-10-31, #484). No
dashboard page.

- `lead-activity.md` is append-only history. Each notable event is one line of
  at most 20 words. Append nudges, starts and publications here; link issue
  dispositions rather than duplicating them.
  Use `wrsp-lead log "<text>"` from the lead directory, or
  `wrsp-lead log <dir> "<text>"`; the command stamps the entry from the UTC clock.
- Keep `lead-decisions.md` current with exactly these sections, in order:
  - **Needs your answer**: blocked on Jon.
  - **Judgment calls**: the lead's own decisions only, what and why; leaves after it lands or about a day unredirected; no work items.
  - **Work queue**: approved work that runs if Jon walks away; one in-flight line per live lane linking its handoff, then approved queued work in order, each naming its approval.
  - **Proposed next**: ranked suggestions with why and size; Jon's go moves an item to Work queue.
  Link governing issues; do not duplicate transcripts.
  For a stamped addition, use `wrsp-lead append <dir> --text TEXT --section SECTION`
  with the exact section name; appends preserve existing bytes and dates.
  Use targeted edits to remove completed items or replace stale current state;
  obtain only the needed section through `wrsp-lead read` below.
  For timestamped rewrites, bind the local draft through
  `~/.agents/skills/issue-workflow/references/durable-times.md` before replacing
  the file; keep cited event times and attribution.
- `lead-handoff.md` is current state only, updated on each lane/queue change,
  at most about 800 words. Hold live lanes, review holders, pending timers and
  background jobs, ready list, findings no issue holds yet, and links to issues
  recording Jon's decisions. Preserve exact frozen/publication tips, checkout,
  research/review/runner identities and handles, next owners, recovery commands
  and steps, pending requests, broadcasts and held pushes.

Run `wrsp-lead render <dir>` after every decisions or handoff edit. It writes
the complete decisions HTML and previews handoff then decisions. Stdout is capped
at 8192 UTF-8 bytes including diagnostics and truncation pointers: 3072 bytes per
file, 1024 diagnostics, 1024 result. A truncated preview names omitted bytes and
the inclusive line range to recover with `wrsp-lead read . --file FILE --lines START:END`
from the lead directory. Explicit reads return the complete selected range;
`wrsp-lead read <dir> --file FILE --section NAME` returns one unique top-level H2
section. Both reads are read-only; use them for omitted or needed state.
Truncated diagnostics point to `wrsp-lead check .`. Resolve
section errors and caps: Judgment calls allows 8 items and 800 words;
Work queue allows 12 items; Proposed next allows 8 items; handoff allows 800
words. Old three-section files are refused naming the four expected sections.
Check flagged stale or unstamped Judgment calls for completion
or supersession; remove them only on that basis. Before writing HTML, render
refuses future `HH:MMZ` stamps anywhere in activity, decisions or handoff,
naming the file and line. Approximate `~HH:MMZ` stamps follow the same rule.
Use an adjacent ISO date, MM-DD, or English month/day (optional year) for a dated
stamp. An undated stamp inherits the nearest preceding valid calendar date in the same file,
including a heading, prose date or dated stamp on that line or an earlier line.
Section changes keep that context; only no preceding date means today UTC.
Yearless dates up to 24 h
ahead (inclusive) retain the current year; farther ahead means the previous
year. Historical lines stay unchanged. `check` retains its nonfatal Judgment
calls age and future-stamp warnings.

For issue status, use `wrsp-issue-read --repo OWNER/REPO N...`; select fields
with `--fields owner,progress,blocked-by`. Read whole specs and needed
omitted/truncated content with explicit `--full-body`.
A successor, resumed or compacted lead first runs `wrsp-lead render <dir>` and
consumes the complete handoff before action: a complete preview suffices;
otherwise consume every omitted handoff range through the named read command
(or every named section plus explicit preamble lines). The 800-word handoff
cap still applies; long words can exceed the byte preview cap. Reconcile issue,
job, queue, native grant state and current queue permission before action.
Consult activity/history only when relevant through explicit ranges or sections.
Resolve command failures before proceeding. Update
the appropriate files before risky steps; give Jon their Files links and point
to them instead of repeating their content in chat.

## Check in

1. On resume and after every compaction, follow [Lead files](#lead-files) to
   reload and reconcile current state before the next real action.
   Saved wakes and review go messages prompt this check; they never authorize
   replay. Unanswered questions remain pending through every compaction.
   Compaction preserves this session's native identity and grant. If the grant
   is no longer this session's, stop leading: actual supersession ends its role.
2. Run `wrsp-agents check`. Read version and warning lines for both CLIs; a
   version warning alone does not fail the command. Report a behind CLI to Jon;
   never update one (#249). Jon trusts changed hooks in the desktop app.
3. Claude updates itself. Report which sessions and Remote Control servers
   started before the installed version. Schedule their handoffs normally.
4. Inspect this session's grant with `wrsp-session-role inspect`. At setup,
   record Jon's assignment through [Record the grant](succession.md#record-the-grant).
5. Read context and status for each developer lane and apply the skill's Lanes
   budget rule, with each model's budget from installed `roles.members`.
6. In Claude remote, read this session's lineage headroom. Near 70% context
   use, at headroom 3 or less, or with unknown lineage, follow
   [Choose a successor](succession.md#choose-a-successor).
7. Confirm priorities, queue requests, publication needs, and Jon's instructions.
   Record decisions through `issue-workflow`; link from lead files.
8. Open the runner dashboard's Telemetry → A · Budget (`/telemetry/a-budget`).
   Read the Session coverage panel's counts for the selected window and report
   each nonzero gap class to Jon. Report an unavailable panel as unavailable.

## Claude eng-lead handover

Claude grant transfer needs no new Jon grant. Follow the
[session-grant transfer contract](../../../docs/reference/contracts/supervisor-session.md#transfer)
for authority, refusal and failure semantics.

1. Create a successor at the quiet point and within the lineage limits of
   [Choose a successor](succession.md#choose-a-successor).
2. Have the successor read the Lead files and acknowledge readiness.
3. Run `wrsp-session-role offer` in the predecessor's own shell. Pass the offer
   id to the successor. From its own shell in the shared checkout, the successor
   runs `wrsp-session-role accept <offer>` as one plain command (no
   `cd … &&`, `;` or pipes) so the installed
   `Bash(wrsp-session-role accept:*)` allow rule matches. That rule is Jon's
   standing approval. Only successful accept changes authority. Failed offer
   or accept leaves the predecessor leading while it holds its grant; check the
   contract's zero-holder failure case before continuing after a write failure.
4. After successful accept, the predecessor cancels its own timers and watcher,
   replaces its role emoji with 💀, and stops.

## Claude eng lead

Developer lanes use the headless `lane.sh` routes from either eng-lead home.
The Remote capability column below is reference for other sessions.

| Capability | Claude lane | Codex lane |
| --- | --- | --- |
| Start | Remote session create with title, model, permission mode, and tags. Select the Agent Mini Remote Control environment. A cloud environment skips the host hooks. | Detached `codex exec --json`; record the thread id. |
| Message | Remote send-message with priority now, next, or later. | Next turn: `codex exec resume <id>`. |
| Receive | The lane sends a message to `@parent`. | Read the turn's output. |
| Context use | Remote get-session → `context_usage`. | Latest `token_count.last_token_usage` in the rollout, under `payload.info`; use input tokens, not cumulative totals. |
| Rename | Remote set-title, including the eng lead's own session. | `thread/name/set` only for app-server threads; otherwise update the roster title. |
| Transcript | Remote list-events / get-event. | Rollout matched by `session_meta.id`. |
| Status / retire | Remote get-session status bucket; archive after handoff acknowledgment. | Recorded handle and exit state; retire after handoff acknowledgment. |

## Codex eng lead

| Capability | Claude lane | Codex lane |
| --- | --- | --- |
| Start | Escalated, detached `claude -p --session-id <uuid> --name "<thread name>" --output-format json`. | Detached `codex exec --json`; record the thread id. |
| Message | `claude -p --resume <uuid>`, one turn at a time. | `codex exec resume <id>`, one turn at a time. |
| Receive | Read the turn's JSON output. | Read the turn's output. |
| Context use | `usage` in the turn's JSON. | Latest `token_count.last_token_usage` in the rollout, under `payload.info`. |
| Rename | `--name` on start or resume; qualify resume naming on the host. | `thread/name/set` only for app-server threads; otherwise update the roster title. |
| Transcript | `~/.claude/projects/<slug>/<uuid>.jsonl`. | Rollout matched by `session_meta.id`. |
| Status / retire | Recorded handle and exit state; retire after handoff acknowledgment. | Recorded handle and exit state; retire after handoff acknowledgment. |

Start with exact role, model, effort, and budget. A route unable to select
the required pair cannot start that lane. Native bootstrap verification precedes
initial issue input; later turns revalidate native qualification offline before
dispatch. Unknown or off-policy pairs refuse. Remote cannot
select developer effort, so its developer route is refused. Non-preferred
developer starts record `--selection-reason` for earlier-member unavailability
or Jon's explicit model request. Permission profiles and handle format remain owned by
`scripts/lane.sh`; it supplies start, send, read, and status.
OpenRouter-backed Codex follows the Codex routes and provider limits.

## Lane turns

Start developer lanes through `lane.sh` in the installed `developer` role's
member order, selecting the CLI by model family. Use a later member only
when earlier members are unavailable or Jon explicitly requests it. In Claude
remote, check [lineage headroom](succession.md#choose-a-successor) first.

- The Codex harness kills background processes when a call ends. A Codex
  eng lead cannot keep an app-server alive between turns. Each headless lane
  turn runs detached under launchd and is waited on with
  `wrsp-wait`.
- Every lane turn runs from its worktree (#258). `lane.sh` passes `-C` on
  turn 1 only; `codex exec resume <id>` has no `-C`.
- Hold one lock per lane from turn admission through its exit record. Provider
  turns never overlap. A failed submission releases only its own lock. Recover an
  interrupted turn from its handle and exit record, not elapsed time.
- A headless lane cannot receive mid-turn. It ends its turn at a queue request,
  handoff, or question for Jon. A queue “go” arrives as its next turn.
  A plain send during a live turn reports busy. `send --when-idle` waits in the
  client until the observed turn finishes, then attempts one ordinary send.
  After exit, run `lane.sh read <handle> --finished`, reconcile the complete
  handoff against grants and queue state, then send. Waiting clients need that
  read before admission too; waiting acknowledges nothing.
- After final reconciliation and turn exit, retire the lane from the shared
  checkout with `lane.sh event <handle> retired`. Inspect its targeted worktree
  cleanup output; a non-retired sibling holder keeps the shared worktree and
  branch. Resolve any refusal before claiming cleanup complete. The
  [retirement contract](../../../docs/reference/contracts/supervisor-session.md#lane-retirement)
  owns eligibility and retry behavior. `wrsp-preflight worktrees` reports leftovers.
- Never resume a headless lane interactively while its eng lead may send turns.
  Transfer ownership explicitly first. A fresh successor gets a fresh identity.
- A headless Claude lane has no Remote tools. Its tree is whatever it launches
  through `~/.agents/skills/developer/scripts/launch-worker.sh`.
- Persist lane identity, title, family, provider, host, project, issue, worktree,
  role id, requested and reported model/effort, native source, selection reason,
  budget, contact route, launch handle, and next exchange.
  Match #196 launch attribution; a resume is a turn of the same lane.
### Acknowledgment

- Require acknowledgment for queue ownership, scope changes, and handoffs.
  If contact fails, inspect the handle and process table, read output only after
  exit, and recover that lane.
  An issue body records intent but does not wake an idle headless process.
  Independent lanes continue. Missing delivery never supplies queue permission.

### Lead reads

The lead reads its [Lead files](#lead-files), issues through `wrsp-issue-read`,
lane messages through `lane.sh read`, and [Lane check](#lane-check) metadata
(#531). Any other question about a developer worktree, plan, pickup or brief
goes to a delegate; never Read, search or shell-read those paths yourself.
Ask the lane instead when it can answer at its next exchange.

- Where-questions ("which file defines X", "where does the pickup name Y") go
  to a locator, run synchronously:
  `~/.agents/skills/developer/scripts/launch-worker.sh --locate --role-id locator --cli <family> --model <member> --effort <effort> --worktree <lane worktree> --brief <question file> --log <briefs folder>/work/locate-<slug>.log --issue <N>`.
  Select model and effort from the installed `locator` role. The answer is a
  status, the scope searched and at most ten `path:start-end` hits, printed in
  at most 8192 bytes; `PARTIAL` means narrow the question and relaunch.
- Content questions ("what does the plan settle about X") go to a researcher:
  the native `researcher` agent in an interactive Claude lead, otherwise
  `launch-worker.sh --research --role-id researcher --cli codex --detach`
  per the `developer` skill's Launch step 3. The report
  stays under 500 words with cited ranges; read only the report and check its
  citations.

### Brief rules

Use [lane-brief-template.md](lane-brief-template.md) for the issue and scope,
limits, oracle plus sketch, bounded reads and operating rules. At assignment,
name the oracle and put a test/proof sketch of at most 10 bullets into the
issue's Required proof and Tests. The developer implements and tests its own
slice and expands that sketch with `systematic-test-design` into the issue's
Tests; the developer records the per-file plan in the issue before the first
edit. The brief carries no plan slot.

Every developer-lane brief carries these rules:

- Invoke `git` for commits and review freshness; invoke `issue-workflow` for issue writes.
- A non-fast-forward land refusal means rebase and carry under the lane's go,
  following `reviewed-main-workflow` (#300).
- A question to the eng lead ends the turn; the eng lead reads only end-of-turn
  messages.
- The eng lead creates the issue worktree before `lane.sh start` (#386).
- A successor brief is the handoff link plus named reads; find them through
  [Lead reads](#lead-reads), not by reading the pickup. Name sections, not
  whole skills, in its read-first list. Name a whole skill only when the
  successor needs all of it. Name a line range for every read of a file over
  200 lines.

Candidate repairs follow
[Candidate repairs](../../developer/references/recovery.md#candidate-repairs).

### Lane script

Installed path: `~/.agents/skills/eng-lead/scripts/lane.sh`.

```text
lane.sh start --role developer|ux-principal|principal-engineer --cli claude|codex --role-id <role> --model <model> --effort <effort> --worktree <dir> --issue <N> --brief <file> --title <text> --log <file> [--selection-reason <text>]
lane.sh send [--when-idle] <handle> <message-file> [--await <pattern> --timeout <seconds>]
lane.sh read <handle> [--cursor <bytes>]
lane.sh read <handle> --finished
lane.sh status <handle>
lane.sh recover <handle>
lane.sh check <handle-directory> --repo <repository> --state <state-file> --threshold <percent>
lane.sh title --role <role> [--lane <name>] --task <text> [--issues "#1 #2"] [--state done]
lane.sh verify-pair --cli claude|codex --role-id <id> --model <requested> --effort <requested> --session <native-id> --transcript <path> [--offset <nonnegative-byte-offset>]
```

Developer and principal-engineer lanes require the matching `--role-id`.

`start` refuses the repository main worktree (exit 66) before creating a handle,
lock or launch; create an issue worktree first. Linked worktrees, including
detached checkouts, remain accepted.

Every provider input starts with the fixed line `From: eng lead, not Jon. Jon's words appear only as quoted text with their source.`,
then a blank line. Work inputs prepend the headless browser preamble to the
original input; metadata-only bootstrap prompts retain their original input
directly after the stamp. Handles and launch records retain source attribution. Ordinary turn
history and `next_exchange` retain the original absolute message path. The message
file must remain readable until dispatched, when its bytes are read and stamped.

Headless `codex exec` and `claude -p` lanes record
`browser: {"runner":"repo-playwright","iab":"unavailable"}` in the lane handle.
Every work input carries the same fact and directs UI verification to the
repository's Playwright runner, skipping the in-app-browser probe and fallback
announcement. `launch-worker.sh` carries the same preamble and records the object
as `LANE_FACTS: {"browser":...}` in its existing log-path handle. The
[frontend browser rule](../../frontend-workflow/SKILL.md#browser-verification)
consumes this fact; interactive sessions retain their default and all paths
retain the existing UI proof requirements.

The handle is `<log without .log>.lane.json`; turn logs are
`<log without .log>.turn-<n>.log`. A `<handle>.lock` directory admits one
turn and remains held through turn completion. A live turn refuses plain sends;
an interrupted turn needs `recover`, which checks the pid and exit record.
Failed submission releases the lock and preserves the previous handle.
Every turn removes its launchd job on exit, including refusals and aborts; an aborted turn is recorded as exit 70 with its launch-record exit fact.
A launchd respawn of a killed turn is refused (exit 79) and leaves the turn interrupted for `recover`; no input is replayed.

One lane, one issue, one worktree: start a new lane for a new issue. Recreate a
missing lane worktree only to continue the same issue.

A missing lane worktree is refused with exit 80 and `lane <name>: worktree <path> is missing; recreate it for this issue or start a new lane for a new issue`:
`send` (including `--when-idle`) refuses before admitting a turn, and a turn whose
worktree vanished after admission writes the refusal and `EXIT:80` to its turn log
(#261, #457).
Wait on a turn with
`wrsp-wait <turn-log>`.

Use `read <handle> --finished` after completion and before the next send. It
exposes the full final message and records the current-turn read receipt. Cursor
reads remain available for inspection and confer no receipt. Unread sends refuse
77 with the finished-read remedy; missing or changed evidence refuses 65. A
successful full reread repairs a stale or malformed receipt. Recovery alone
does not acknowledge output; a recovered turn without a final message fails
closed. Receipt identity, byte preservation and lock ordering belong to
[Lane turns](../../../docs/reference/contracts/supervisor-session.md#lane-turns).

`--when-idle` polls in the client until the observed turn finishes, then attempts
the ordinary turn lock once. Background the client and track that client job's
exit; read its output only after exit:

```sh
lane.sh send --when-idle "$handle" "$message" > "$send_log" 2>&1 &
send_pid=$!
wait "$send_pid"
```

`HANDLE:` means submitted, not provider completion. Competing clients targeting
the same observed turn yield one send and refusal 75 for a loser, even if the
winning turn finishes before the loser resumes. Interruption refuses 76 with the
`recover` remedy. Keep the message file on interruption or refusal and retry
explicitly when appropriate. Recovery records exit 70 and releases an interrupted
turn's lock without submitting input.

Use `send <handle> <message-file> --await <pattern> --timeout <seconds>` to
submit once and wait for a reply. The pattern is a JavaScript regular expression;
the timeout is an integer from 1 to 86400 seconds, measured after submission.
The ordinary send guard runs first: unread finished turns still require an explicit
`read --finished`, and refused sends return their original code and text immediately.
No refused input is retried. After acceptance, `AWAIT MATCH` exits 0 on a complete
assistant message, `AWAIT EXIT` exits 3 when the admitted turn ends without a
match, and `AWAIT TIMEOUT` exits 124 at the deadline. The wait follows that turn
even if the handle later advances. A match may arrive while the turn continues;
timeout leaves admitted work running. Keep a bounded backup wake for the client.

Only turn 1 performs the metadata-only bootstrap, bounded at 90 seconds;
`WRSP_LANE_BOOTSTRAP_TIMEOUT=<seconds>` on `lane.sh start` waits longer. Later
turns rediscover the same native source and verify its bytes from the accepted
qualification's start against the requested pair and current role membership.
The `resume` phase reuses native evidence; it does not claim fresh provider
execution. Old handles may use only the immediately preceding accepted report.
Missing qualification, source changes or invalid native metadata refuse 81
before dispatch. Every work turn then verifies fresh records after the offline
check's end offset. Native refusal clears qualification; a process interruption
while verification is pending retains the previous accepted qualification.

Verification may remain pending until the turn exits; pending grants no acceptance.
Status and logs show accepted or refused (exit 81), the phase, and native source.
Status adds `context: <tokens> / <budget> (<pct>%)`, with one decimal place,
using the stored budget and native-source session record: Codex's latest
token-count input usage or Claude's latest parent assistant input and cache usage.
Missing or invalid native usage, source, provider or budget yields `context: unknown`.
A work-phase refusal reports drift after dispatch. Relative send handle and
message paths resolve from the sender's cwd.

## Lane check

Run `lane.sh check <handle-directory> --repo <repository> --state <state-file> --threshold <percent>`
at each check. Keep the state file across checks; its parent directory must exist.
Use default summaries for every periodic check; open the named full report when a
check is truncated. Status/read accept `--full`; a truncated finished preview
requires `read <handle> --finished --full` before sending.
Reconcile `review-request` lines with actual grant and queue state as soon as
they appear, including while the lane's turn continues. Each lane is observed
independently; the line is a request, not a review go or receipt. Reconcile
`waiting-on-lead` lines as needing lead action; inspect `activity-unknown` evidence
before treating a live lane as working. Detection never interrupts a lane.
Then reconcile newly finished turns. Read
each finished handoff with `read <handle> --finished` before sending; check itself
consumes no handoff and authorizes no send. Retain
timer checks while any lane is live or the ready list is non-empty. Use
`lane.sh board <handle-directory>` for an explicit full snapshot. Check's change
and failure semantics, including completed-work context snapshots, belong to
[Lane turns](../../../docs/reference/contracts/supervisor-session.md#lane-check).

- Claude: arm a background Bash `sleep <seconds>` with `run_in_background`,
  at most 1200 s out. Its exit re-invokes the idle session. Re-arm after every
  check while any lane is live or the ready list is non-empty. Optionally add
  `send_later` (remote) or `CronCreate` (local) as a backup; whichever fires
  first runs the check (#469).
- Each wake prompts one check: recheck current issue, grant and queue state,
  then status, nudges, refill. A stale wake or saved go requires that
  reconciliation; never replay an old review go or wait in a loop inside a turn.
- Codex: a foreground `sleep` is the only in-session timer; the session cannot
  receive messages while it runs. Codex leads run only while Jon drives, so
  check at the start of each turn.
- Reserve external launchd/cron with headless resume for a wake that must
  survive a session restart (#469).
- Read metadata only: each lane's session status, including `quiet`; `ps -p`
  on its recorded review, research and runner pids; `.exit` markers and file
  mtimes newer than the lane's last message; `git -C <worktree> status --short`;
  and one `wrsp-wait <log> --max 0` per launch handle. Inspect a live turn
  quiet for more than 600 seconds; a rate-limited resume can hang without exiting.
  `quiet: unknown` means the live log is unavailable.
- Reconcile waiting send clients' exits before nudging. Read output only
  after exit; `HANDLE:` proves submission. Establish completion from turn history
  and exit evidence. Keep refused input and explicitly decide whether to retry.
- Use check's complete-message observation for live review requests and
  `send --await` for bounded reply waits. Do not manually tail live output or
  loop on `sleep`; read a log's tail once after the process exits.
- Nudge a lane that is idle on finished work, meaning an `.exit` marker or a
  dead pid newer than its last message. Name the finished job and its exit code.
- For a lane blocked on another lane, confirm the blocker has moved since the
  last check: its session is working, or its HEAD or status has changed. If
  it hasn't, nudge the blocker.
- Append nudges to `lead-activity.md`.
- Before refill, consult `node ~/.agents/skills/developer/scripts/launch-retry-runtime.mjs marker-status`
  once. While `throttled` is true, defer fresh refill and record `throttledUntil`
  in `lead-activity.md`; retain the normal check timer, reconciliation, nudges
  and queue actions. Missing, unreadable, corrupt or overflow state leaves
  refill eligible. `WRSP_LAUNCH_BACKOFF_OVERRIDE=1` bypasses this advisory and
  fresh-launch waiting. See [lane bootstrap backoff](../../../docs/reference/contracts/job-liveness.md#first-turn-lane-bootstrap-retry-357).
- End every check by reconciling the authorized inventory and, when eligible, refilling
  executable ready-list work within the lane cap; append starts to `lead-activity.md`. Keep parked
  issues and explicit exclusions parked. Report and reconcile missing or stale issue state; it is
  uncertainty, never proof that no work remains.
- Before retiring the last lane, record concrete blocked actions and remaining
  authorized work in the existing issues and lead files, and refill executable
  work within the cap. When the authorized inventory is exhausted or every
  remaining action is blocked, retire idle lanes and stop checks. Keep no empty
  polling lanes.
- `wrsp-wait` on a `lane.sh` turn handle reports only running or exited; exits 8 (not producing) and 3 (stalled) come only from `launch-worker.sh` handles.

## Names and instructions

| Role | Emoji |
|---|---|
| Eng lead | 👽 |
| Developer | 👩‍💻 |
| Reviewer | 👀 |
| Researcher | 🔬 |
| Locator | 🔍 |
| Lander | 🛬 |
| UX principal | 👩‍🎤 |
| Principal engineer | 🧙 |
| Batch | 🤖 |
| Done | 💀 (replaces the role emoji when the thread is finished) |

Jon set these emoji (#197, #240, #275, #298).

The developer skill carries the same table. Shape:
`<emoji>[ <Lane>]: <task>[ #issues]`. Follow these examples:

- `👽 Agent Mini migration #174 #196 #197`
- `👩‍💻 G: event capture #196`
- `💀 F: laptop ledger #192`

The colon appears only after a lane letter. Rename on assignment, changed work,
successor pickup, and completion. Replace the role emoji with 💀 at completion
and keep task text. Promotion changes 👩‍💻 to 👽. Titles grant no authority.

Jon names a Codex eng lead's thread at start. Tell them the new name when its
scope changes. Use Remote titles for Remote lanes, `--name` for Claude headless
lanes, and `thread/name/set` for Codex app-server threads. Other Codex CLI lanes
keep their desired title in the roster. Never edit app databases to rename.
Name descendant launch records with 🤖, 👩‍🎤, 👀, 🔬, or 🔍 as appropriate.
Keep #196 launch identities intact.

Follow `issue-workflow` for Jon's direct instructions and their source.

Never hand Jon a bare file path. Follow global `AGENTS.md` (Environment);
where it names no Files link, link a pushed file or publish content on the issue.
This includes drafts, handoffs, logs, proof, decisions and finished documents.

## Pushes while Jon is away

Jon approved this rule; “you” refers to Jon:

> a push proceeds without you when it has full review coverage or recorded acceptance and passing evidence at the exact commit. It waits for you only when it does one of these:
>
> - changes review, receipt, evidence or gate semantics, or a contract consumers see;
> - installs hooks that need re-trust;
> - tags or releases;
> - force-pushes or deletes a remote ref.

Reuse Jon's existing approval only for the risky action and exact scope it covers.
A new material release fact holds remaining release actions: a promised installed
operation fails, consumer impact changes, or release proof is invalidated. Resume
under the original go only after verified correction within that scope. Unresolved
material defects or uncovered scope wait for Jon; shipping a defect as a known
limitation requires their explicit acceptance. Unchanged limitations already
disclosed and accepted, and advisories unrelated to release promises, consumer
impact or proof, do not reopen the go. Record the new fact, scope, correction proof
or accepted limitation, and Jon's approval source on the release issue; link that
disposition from `lead-activity.md` before resuming. Disclose accepted limitations
in release notes and consumer handoffs. Otherwise hold the push. An eng lead
assignment is role authority, not findings acceptance or approval of every risky action.
Use the landing-queue and operator-acceptance references for the actual checks.
Create a detached worktree pinned to the exact publication tip; run the
publication suite, collect its evidence and push from that worktree.
Keep it pinned through push so reviews and landings can continue on main.

Route Progress/body edits, label changes, snapshots, close-on-push and consumer
bump issues through a `batch` bookkeeping job, using its
[instruction reference](../../batch/references/issue-bookkeeping.md) and
[reusable brief](../../batch/references/issue-bookkeeping-brief.md). Give one
instruction with repository, issue, action and attributed source, plus the named
work directory; the job returns at most ten report lines and retains the issue
diff there. Inspect that report; use `wrsp-issue-read` for subsequent status.
The lead still authorizes each close by repository, issue and pushed tip after
checking complete scope, recorded commits and no open decision. The job performs
#418's body Proof, implemented removal, close and snapshot in order. Keep issues
with unpushed commits, remaining increments or an open decision open. A wrapper
refusal holds that action; inspect uncertain writes before any new instruction,
and keep generic batch `gh` writes denied. Publication, release and operator
approval remain the lead's existing responsibilities.

A step needing Jon blocks only that step. Within the assigned goal, continue
authorized preparation, analysis and independent issues while it waits; keep
parked issues and explicit exclusions parked. Report and reconcile missing or
stale issue state rather than treating it as proof that no work remains.
Group prepared sudo installs, laptop actions, hook re-trust and product questions
into one operator window; each still waits for its own required instruction.
Keep unanswered requests in `lead-decisions.md` and `lead-handoff.md` through compaction.

## Visibility

See only the tree you started. Jon accepts missing visibility into their threads
in other apps; discovering every chat is not a completion requirement.
Do not send peer messages to laptop sessions; their inbound refusal still applies.

Remote events expose the connected conversation, subject to pagination and tool
availability. They do not expose private reasoning or promise every local tool
byte. Same-host Claude transcripts and Codex rollouts expose persisted events
and usage. Match identity and read only relevant, bounded ranges for this project.
Missing files, truncation, persistence settings, and provider differences limit
that view. OpenRouter adds no Remote or cross-session capability. Missing usage
stays unknown and does not by itself require a checkpoint. The usage ledger is
counters, not a transcript.
