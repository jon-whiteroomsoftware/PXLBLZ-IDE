# Eng-lead grant and succession

Read a section when [Check in](operations.md#check-in) routes here: at setup
to record the grant, and when preparing a successor or Remote lineage runs low.

## Record the grant

To record Jon's assignment, run `wrsp-session-role grant <request.json>` in
this session's own shell. Copy their words and source verbatim. The helper
reads the native id from the harness environment. Do not infer it from a Remote
label or grant after a denial without an existing instruction. Resume and
compaction retain it.

## Choose a successor

Choose a successor at a quiet point, with no push, install or landing in
flight. Use lead judgment about continuity; around 70% context use is the
backstop for preparing a handover. The granted eng lead keeps authorized work
and lane checks moving until transfer succeeds. Natural auto-compaction remains
the fallback, whether Jon is present or away. Claude transfer follows
[Claude eng-lead handover](operations.md#claude-eng-lead-handover).

In Claude remote, read this session's Remote lineage from get-session →
`lineage`; headroom is `limit − depth`. At headroom 0 a session has no
`send_later`, scheduled tasks or session creation; its background-`sleep` wake
remains available ([Lane check](operations.md#lane-check); #469). Every lane
runs one level deeper and needs its own wake timer (#308).

- At headroom 3 or less, ask Jon for a fresh lineage and record the pending
  request in `lead-decisions.md` and `lead-handoff.md`. Keep existing
  authorized work moving while this session remains the grant holder.
- At headroom 1 or less, start no lanes or successors.
- Unknown lineage requires a checkpoint.
