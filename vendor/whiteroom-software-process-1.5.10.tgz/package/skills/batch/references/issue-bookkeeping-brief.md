# Issue bookkeeping job

Fill the named values; retain all seven sections. The lead supplies one JSON
instruction line with issue/action/source and any exact close authorization.

## Source

Issue: ISSUE_URL. Instruction file: ABSOLUTE_INSTRUCTION_JSON, one JSON line
supplied by LEAD_ID with its source. Brief recorded at ISSUE_BRIEF_POINTER.

## Worktree

Checkout: ABSOLUTE_WORKTREE. Branch/tip: BRANCH_AND_TIP. Retained paths: NAMED_PATHS
or none. Work directory: ABSOLUTE_WORK_DIR. Expected duration: under two minutes.
No source edits or commits.

## Changes

Read the instruction and batch bookkeeping reference. Execute only the installed
wrapper with --work-dir ABSOLUTE_WORK_DIR and --instruction-file
ABSOLUTE_INSTRUCTION_JSON. Capture stdout at ABSOLUTE_REPORT. Keep the instruction
unchanged; use no additional actions or generic gh writes.

## Preservation

Preserve unnamed body fields/labels and Jon's sourced quotes verbatim. Compare a
named full draft with the current body before execution. Close only the exact
repository/issue/tip authorized by the lead. Existing issue-body, #418,
publication and generic-gh restrictions apply.

## Tests

No suite or implementation work. Inspect wrapper exit and report. Failure or
uncertainty stops this action without retry. Report snapshot warnings separately
from successful issue writes.

## Proof

Keep before/after/diff and body-check artifacts in the named work directory.
Return the wrapper report verbatim, at most ten lines, without added narrative.
The lead handles real-close proof and status reads.

## Limits

Only the named instruction, report and work paths are authorized. No pushes,
tags, releases, source edits, agents, messages or host configuration. A brief
gap produces one BRIEF GAP line and no issue changes. No automatic retries.
