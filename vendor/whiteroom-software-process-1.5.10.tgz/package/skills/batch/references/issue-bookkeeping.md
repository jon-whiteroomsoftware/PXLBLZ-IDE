# Issue bookkeeping (#535)

A lead supplies one sourced instruction line and a named work directory. The
batch job runs the installed wrapper; it alone may make the named issue writes.
Generic `gh` writes, pushes, releases and host changes retain their restrictions.
Jon approved this boundary in [the sourced issue comment](https://github.com/jon-whiteroomsoftware/whiteroom-software-process/issues/535#issuecomment-6691695961).

## Run the job

Use the [reusable brief](issue-bookkeeping-brief.md) with the existing batch
launcher and the batch member resolved through execution policy. Record its
brief pointer on the issue before launch. The lead fills the instruction file
with one JSON line and names the existing work directory and report destination.
The worker runs:

```sh
node ~/.agents/skills/batch/scripts/issue-bookkeeping.mjs --work-dir /named/issue/work --instruction-file /named/issue/work/instruction.json
```

The wrapper also accepts `--instruction` followed by JSON as one argv value.
Use the file form in shell commands so sourced quotes need no shell escaping.
It requires `WRSP_ROLE=batch`; the declaration is telemetry, not a grant.
Operations use fixed argv, with no shell or arbitrary endpoint.

## Instruction

Every object names `repository` (`OWNER/REPO`), positive integer `issue`,
`action`, and nonempty attributed `source`. Unknown fields, malformed values
and contradictory labels refuse with `BRIEF GAP:` before mutations. Parsing
preserves source strings and quote bytes.

| Action | Named fields |
| --- | --- |
| `update` | One logical `progress` line or full `bodyFile`; optional `addLabels`/`removeLabels`. Labels alone qualify. Arrays have unique nonempty names and no overlap. |
| `close-on-push` | `closeAuthorization`, `pushedTip`, complete recorded `commits`, `proof` containing `Proof:`. Tip/commits are full commit SHAs. |
| `snapshot` | `snapshotSource`: `claim` or `close`. |
| `bump` | `targetRepository`, `title`, `bodyFile`, optional `addLabels`. Base repository/issue identifies the authorizing release issue; target is the consumer. Use the existing pinned release URL/checksum and issue template. |

Example lead instruction:

```json
{"repository":"jon-whiteroomsoftware/whiteroom-software-process","issue":535,"action":"update","source":"eng lead 23544594, named brief","progress":"Proof: targeted checks pass.","addLabels":["WIP"]}
```

The brief names every requested change and preserves Jon's quotes verbatim. A
full draft is an explicitly named replacement; the job compares sourced quotes
and unrelated content before submitting it. Progress append preserves surrounding
bytes and requires one literal unfenced `## Progress` heading. Body edits use
`wrsp-issue-body`; bump creation first uses its unchanged local checks with
`--check-only`, then submits those exact bytes. Before any issue mutation, each
added label must be confirmed by name in the update repository or bump consumer;
a missing or unconfirmed lookup refuses with `BRIEF GAP:`. Label definitions are
never created.
Requested removals absent from the initial issue snapshot are no-ops; only
applied names receive DELETE requests. A removal-only label no-op reports
`LABELS: unchanged` and still retains read-back, diff and snapshot evidence.
For body actions, `allowAdvisories:true` explicitly carries the existing size
advisory override; mandatory template/proof checks still refuse.

## Close authorization

The lead authorizes each close using `lead`, `repository`, `issue`, `pushedTip`,
attributed `source`, `scopeComplete:true` and `noOpenDecision:true` in the
`closeAuthorization` object. Repository/issue/tip must match the instruction.
The lead checks remaining increments, decisions and completeness of recorded
commits before issuing it. The sourced brief is the trust boundary; text fields
do not authenticate a person or replace those lead judgments.

The wrapper checks OPEN + implemented, matching origin, live remote main tip,
local commit ancestry and references to each named commit in the body. Missing
objects refuse; the lead fetches and inspects before a new instruction. The job
adds pushed tip + Proof, removes implemented, closes, then snapshots with source
`close`. Unpushed commits, unfinished scope or an open decision stay open under
unchanged #418. The wrapper grants no publication authority.

## Report and recovery

Eight report lines give status, source issue, action, source, body, labels,
lifecycle and snapshot. Optional result URL and detail make ten maximum. Free
text is JSON quoted with line separators escaped. `complete`, `refused` and
`partial` describe execution; `prepared` remains available to pure callers.
`uncertain` marks an unconfirmed effect. A bump URL names the consumer issue;
the source issue stays the release issue.

The named work directory receives unique before/after JSON, checked draft,
body-check output and issue diff. Stop on refusal or ambiguity; inspect current
state and artifacts before a new instruction. A bump retains its source issue
separately and diffs the created issue against an absent prior target.
The wrapper never retries.
Snapshot failure warns after confirmed writes; request a separate snapshot job
after diagnosis. Read the report for routine completion and `wrsp-issue-read`
for status; load artifacts on failure.

[CLI tests](../../../src/batch-bookkeeping.test.ts) cover installed execution,
preservation, ordering, failures and the pure grammar/report contract.
[Both hook registrations](../../../src/role-gate.test.ts) still reject generic
`gh` writes. The lead owns the final runner suite, push and real-close report/diff.
