// Pure data boundary; the fixed-operation executor lives in scripts/.
function refuse(reason) {
  throw new Error(`BRIEF GAP: ${reason}`)
}

function text(value, field) {
  if (typeof value !== 'string' || !value.trim()) refuse(`${field} must be nonempty text`)
}

function repository(value, field) {
  text(value, field)
  if (!/^[a-z\d](?:[a-z\d-]*[a-z\d])?\/[a-z\d_.-]+$/i.test(value) || ['.', '..'].includes(value.split('/')[1])) {
    refuse(`${field} must name OWNER/REPO`)
  }
}

function labels(value, field) {
  if (!Array.isArray(value)) refuse(`${field} must be an array`)
  for (const label of value) text(label, field)
  if (new Set(value).size !== value.length) refuse(`${field} contains duplicate labels`)
  return value
}

/** Checks instruction shape only; source and close claims still need verification. */
export function parseBookkeepingInstruction(line) {
  if (/[\r\n\u0085\u2028\u2029]/.test(line)) refuse('instruction must occupy one line')
  let parsed
  try { parsed = JSON.parse(line) } catch { refuse('instruction must be JSON') }
  if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) refuse('instruction must be an object')
  const value = parsed
  repository(value.repository, 'repository')
  if (!Number.isSafeInteger(value.issue) || value.issue < 1) refuse('issue must be a positive safe integer')
  text(value.source, 'source')

  const fields = {
    update: ['progress', 'bodyFile', 'addLabels', 'removeLabels'],
    'close-on-push': ['closeAuthorization', 'pushedTip', 'commits', 'proof'],
    snapshot: ['snapshotSource'],
    bump: ['targetRepository', 'title', 'bodyFile', 'addLabels'],
  }
  if (typeof value.action !== 'string' || !Object.hasOwn(fields, value.action)) refuse('action is unsupported')
  const allowed = new Set(['repository', 'issue', 'source', 'action', ...fields[value.action]])
  if (value.action !== 'snapshot') allowed.add('allowAdvisories')
  for (const key of Object.keys(value)) if (!allowed.has(key)) refuse(`unnamed field ${key}`)
  if ('allowAdvisories' in value && value.allowAdvisories !== true) refuse('allowAdvisories must explicitly be true')

  switch (value.action) {
    case 'update': {
      if ('progress' in value) text(value.progress, 'progress')
      if ('bodyFile' in value) text(value.bodyFile, 'bodyFile')
      if ('progress' in value && 'bodyFile' in value) refuse('update must name progress or bodyFile, not both')
      const add = 'addLabels' in value ? labels(value.addLabels, 'addLabels') : []
      const remove = 'removeLabels' in value ? labels(value.removeLabels, 'removeLabels') : []
      if (add.some(label => remove.includes(label))) refuse('a label cannot be both added and removed')
      if (!('progress' in value) && !('bodyFile' in value) && add.length + remove.length === 0) refuse('update names no change')
      break
    }
    case 'close-on-push': {
      text(value.proof, 'proof')
      if (!value.proof.includes('Proof:')) refuse('proof must include Proof:')
      const isCommit = (commit) => typeof commit === 'string' && /^[a-f\d]{40}$/i.test(commit)
      if (!isCommit(value.pushedTip)) refuse('pushedTip must be a full commit SHA')
      if (!Array.isArray(value.commits) || value.commits.length === 0 || !value.commits.every(isCommit)) {
        refuse('commits must be a nonempty array of full commit SHAs')
      }
      const auth = value.closeAuthorization
      if (!auth || typeof auth !== 'object' || Array.isArray(auth)) refuse('closeAuthorization must name the lead and exact issue/tip')
      const authKeys = ['lead', 'repository', 'issue', 'pushedTip', 'source', 'scopeComplete', 'noOpenDecision']
      if (Object.keys(auth).some(key => !authKeys.includes(key))) refuse('closeAuthorization contains an unnamed field')
      text(auth.lead, 'closeAuthorization.lead')
      text(auth.source, 'closeAuthorization.source')
      if (auth.repository !== value.repository || auth.issue !== value.issue || auth.pushedTip !== value.pushedTip
        || auth.scopeComplete !== true || auth.noOpenDecision !== true) refuse('closeAuthorization must match issue/tip with complete scope and no open decision')
      break
    }
    case 'snapshot':
      if (value.snapshotSource !== 'claim' && value.snapshotSource !== 'close') refuse('snapshotSource must be claim or close')
      break
    case 'bump':
      repository(value.targetRepository, 'targetRepository')
      text(value.title, 'title')
      text(value.bodyFile, 'bodyFile')
      if ('addLabels' in value) labels(value.addLabels, 'addLabels')
      break
  }
  return value
}

function quote(value) {
  return JSON.stringify(value).replace(/[\u0085\u2028\u2029]/g, character => `\\u${character.charCodeAt(0).toString(16).padStart(4, '0')}`)
}

/** Formats caller-supplied outcomes; it does not establish that effects occurred. */
export function formatBookkeepingReport(instruction, outcome) {
  const lines = [
    `STATUS: ${outcome.status}`,
    `ISSUE: ${instruction.repository}#${instruction.issue}`,
    `ACTION: ${instruction.action}`,
    `SOURCE: ${quote(instruction.source)}`,
    `BODY: ${outcome.body}`,
    `LABELS: ${outcome.labels}`,
    `LIFECYCLE: ${outcome.lifecycle}`,
    `SNAPSHOT: ${outcome.snapshot}`,
  ]
  if (outcome.issueUrl !== undefined) lines.push(`URL: ${quote(outcome.issueUrl)}`)
  if (outcome.detail !== undefined) lines.push(`DETAIL: ${quote(outcome.detail)}`)
  return lines.join('\n')
}
