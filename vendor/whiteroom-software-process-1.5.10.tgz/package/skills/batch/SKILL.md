---
name: batch
description: Run one scheduler/eng-lead brief as a non-interactive scheduled job; exclude interactive sessions.
metadata:
  wrsp-min-version: "1.3.0"
---

# Batch

1. First run `node ~/.agents/hooks/session-role.mjs declare batch` from the project checkout, adding `--issue <n>` when the brief names one issue. This labels telemetry; it grants no authority.
2. Follow the job's brief exactly; never ask questions or wait for answers.
3. Write output only where the brief names. When the brief has a gap, print one line starting `BRIEF GAP:` naming it, and exit without changes. A commit-hook failure after edits is the exception: leave changes staged, report `BRIEF GAP: commit hook` with the failing lines, and exit (#167).
4. For lead issue bookkeeping, read [Issue bookkeeping](references/issue-bookkeeping.md); when preparing its job, use the [reusable brief](references/issue-bookkeeping-brief.md). Run only the installed wrapper with the named instruction and work directory. It permits checked body edits, named labels, snapshots, bump issues and explicitly authorized closes (#535). A refusal stops that action; report it without substituting direct writes.
5. A batch session never pushes, tags, writes directly with `gh`, messages or spawns agents, or changes host configuration. Put anything needing those actions in the final report. The bookkeeping wrapper is the sole GitHub-write exception.
