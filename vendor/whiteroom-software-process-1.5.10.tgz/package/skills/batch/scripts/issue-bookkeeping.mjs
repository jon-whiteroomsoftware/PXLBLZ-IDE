#!/usr/bin/env node
import { spawnSync } from 'node:child_process'
import console from 'node:console'
import { randomUUID } from 'node:crypto'
import { readFileSync, statSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import process from 'node:process'
import { parseBookkeepingInstruction, formatBookkeepingReport } from '../issue-bookkeeping.mjs'

let instruction, prefix, before, attempted = false
const outcome = { status: 'refused', body: 'not-run', labels: 'not-run', lifecycle: 'not-run', snapshot: 'not-run' }
const fail = message => { throw new Error(message) }
const save = (suffix, value) => writeFileSync(`${prefix}.${suffix}`, value, { flag: 'wx' })
const run = (command, args, input) => spawnSync(command, args, {
  input, encoding: 'utf8', timeout: 30_000, maxBuffer: 16 * 1024 * 1024, windowsHide: true,
})
function read(command, args) {
  const r = run(command, args)
  if (r.status !== 0) fail(`${command} read failed; no automatic retry`)
  return r.stdout
}
function gh(args, input, effect) {
  if (effect) { attempted = true; outcome[effect] = 'uncertain' }
  const r = run('gh', args, input === undefined ? undefined : JSON.stringify(input))
  if (r.status !== 0) fail('GitHub request failed; inspect the issue before retrying')
  try { return JSON.parse(r.stdout) } catch { fail('GitHub response is unconfirmed; inspect before retrying') }
}
function issue(repository, number) {
  const value = gh(['issue', 'view', String(number), '--repo', repository, '--json', 'number,url,body,title,state,labels'])
  if (value?.number !== number || typeof value.body !== 'string' || typeof value.title !== 'string'
    || !['OPEN', 'CLOSED'].includes(value.state) || !Array.isArray(value.labels)
    || !value.labels.every(label => typeof label?.name === 'string')) fail('GitHub issue identity/state is unconfirmed')
  return value
}
function appendProgress(body, progress) {
  if (/[\r\n]/.test(progress)) fail('BRIEF GAP: progress must be one logical line; use a checked bodyFile for multiline edits')
  let fence, offset = 0, end = body.length
  const starts = []
  for (const chunk of body.match(/[^\n]*(?:\n|$)/g) ?? []) {
    const line = chunk.replace(/\r?\n$/, '')
    const marker = /^ {0,3}(`{3,}|~{3,})(.*)$/.exec(line)
    if (marker) {
      if (fence && marker[1][0] === fence[0] && marker[1].length >= fence.length && !marker[2].trim()) fence = undefined
      else if (!fence && (marker[1][0] === '~' || !marker[2].includes('`'))) fence = marker[1]
    } else if (!fence) {
      if (/^## Progress[ \t]*$/.test(line)) starts.push(offset)
      if (starts.length === 1 && offset > starts[0] && /^#{1,2} /.test(line) && end === body.length) end = offset
    }
    offset += chunk.length
  }
  if (starts.length !== 1) fail('BRIEF GAP: body needs one literal unfenced ## Progress heading')
  const head = body.slice(0, end)
  return head + (head.endsWith('\n') ? '' : '\n') + `- ${progress}\n` + body.slice(end)
}
function bodyWrite(repository, number, body, checkOnly = false) {
  const path = `${prefix}.draft.md`
  save('draft.md', body)
  const priorAttempted = attempted, priorBody = outcome.body
  if (!checkOnly) { attempted = true; outcome.body = 'uncertain' }
  const r = run('wrsp-issue-body', ['--repo', repository, '--issue', String(number), '--body-file', path,
    ...(instruction.allowAdvisories ? ['--allow-advisories'] : []), ...(checkOnly ? ['--check-only'] : [])])
  save('body-check.txt', r.stdout + r.stderr)
  if (r.status !== 0) {
    let diagnostic
    try { diagnostic = JSON.parse(r.stderr.trim().split('\n').at(-1)) } catch { /* Unconfirmed child failure. */ }
    if (!checkOnly && diagnostic?.writeAttempted === false) { attempted = priorAttempted; outcome.body = priorBody }
    fail('wrsp-issue-body refused or failed; inspect retained body-check output before retrying')
  }
  let receipt
  try { receipt = JSON.parse(r.stdout) } catch { fail('wrsp-issue-body result is unconfirmed') }
  if (checkOnly) {
    if (receipt.checked !== true || receipt.writeAttempted !== false) fail('wrsp-issue-body check-only support is required')
  } else { attempted = true; outcome.body = 'updated' }
}
function requireLabels(repository, names = []) {
  for (const name of names) {
    const r = run('gh', ['api', `repos/${repository}/labels/${encodeURIComponent(name)}`])
    let label
    try { label = JSON.parse(r.stdout) } catch { /* Unconfirmed lookup refuses below. */ }
    if (r.status !== 0 || label?.name !== name) fail(`BRIEF GAP: label ${JSON.stringify(name)} is not confirmed in ${repository}; inspect before a new instruction`)
  }
}
function editLabels(repository, number, add = [], remove = []) {
  const endpoint = `repos/${repository}/issues/${number}/labels`
  if (add.length) gh(['api', '--method', 'POST', endpoint, '--input', '-'], { labels: add }, 'labels')
  for (const label of remove) gh(['api', '--method', 'DELETE', `${endpoint}/${encodeURIComponent(label)}`], undefined, 'labels')
  if (add.length + remove.length) outcome.labels = 'updated'
}
function snapshot(repository, number, source) {
  const r = run('wrsp-usage', ['snapshot-issue', '--source', source, repository, String(number)])
  outcome.snapshot = r.status === 0 ? 'written' : 'warning'
  save('snapshot.txt', r.stdout + r.stderr)
}
function closeEligibility(i, current) {
  if (current.state !== 'OPEN' || !current.labels.some(label => label.name === '📦 implemented')) fail('BRIEF GAP: close needs an open implemented issue')
  const origin = read('git', ['remote', 'get-url', 'origin']).trim()
  if (![ `https://github.com/${i.repository}`, `https://github.com/${i.repository}.git`, `git@github.com:${i.repository}.git`, `git@github.com:${i.repository}` ].includes(origin)) fail('BRIEF GAP: origin does not match the named repository')
  const remote = read('git', ['ls-remote', '--exit-code', 'origin', 'refs/heads/main']).trim().split(/\s+/)
  if (!/^[a-f\d]{40}$/i.test(remote[0]) || remote[1] !== 'refs/heads/main') fail('GitHub main tip is unconfirmed')
  for (const [ancestor, descendant] of [[i.pushedTip, remote[0]], ...i.commits.map(commit => [commit, i.pushedTip])]) {
    if (run('git', ['merge-base', '--is-ancestor', ancestor, descendant]).status !== 0) fail('BRIEF GAP: named commits/tip are not proved reachable from pushed main; fetch missing objects before a new instruction')
  }
  const recorded = current.body.match(/\b[a-f\d]{7,40}\b/gi) ?? []
  if (!i.commits.every(commit => recorded.some(token => commit.toLowerCase().startsWith(token.toLowerCase())))) fail('BRIEF GAP: named commits must be recorded in the issue body')
}
function verify(current, expected) {
  const actualLabels = current.labels.map(label => label.name).sort()
  if (current.body !== expected.body || current.title !== expected.title || current.state !== expected.state
    || JSON.stringify(actualLabels) !== JSON.stringify([...expected.labels].sort())) fail('Issue read-back differs from the named changes; inspect before retrying')
}
function artifacts(after) {
  save('after.json', JSON.stringify(after, null, 2) + '\n')
  const r = run('diff', ['-u', `${prefix}.before.json`, `${prefix}.after.json`])
  if (r.status !== 0 && r.status !== 1) fail('Issue diff could not be produced; inspect retained before/after artifacts')
  save('diff', r.stdout)
}

try {
  const args = process.argv.slice(2)
  if (args.length !== 4 || args[0] !== '--work-dir' || !['--instruction', '--instruction-file'].includes(args[2])) fail('BRIEF GAP: use --work-dir DIR --instruction ONE_LINE_JSON or --instruction-file FILE')
  instruction = parseBookkeepingInstruction(args[2] === '--instruction-file' ? readFileSync(args[3], 'utf8').replace(/\r?\n$/, '') : args[3])
  if (process.env.WRSP_ROLE !== 'batch') fail('BRIEF GAP: this wrapper runs only as a batch job from the lead brief')
  const work = resolve(args[1])
  if (!statSync(work).isDirectory()) fail('BRIEF GAP: named work directory must exist')
  const i = instruction
  // Read named drafts once; all later checks and writes use these same bytes.
  const draft = 'bodyFile' in i ? readFileSync(i.bodyFile, 'utf8') : undefined
  prefix = join(work, `bookkeeping-${randomUUID()}`)
  read('gh', ['auth', 'status'])
  before = issue(i.repository, i.issue)
  outcome.issueUrl = before.url
  save('before.json', JSON.stringify(i.action === 'bump' ? null : before, null, 2) + '\n')
  if (i.action === 'bump') save('source.json', JSON.stringify(before, null, 2) + '\n')
  requireLabels(i.action === 'bump' ? i.targetRepository : i.repository, i.addLabels)
  let targetRepository = i.repository, targetNumber = i.issue
  const expected = { body: before.body, title: before.title, state: before.state, labels: before.labels.map(label => label.name) }
  if (i.action === 'update') {
    const removeLabels = (i.removeLabels ?? []).filter(label => expected.labels.includes(label))
    if ('progress' in i || draft !== undefined) {
      expected.body = draft ?? appendProgress(before.body, i.progress)
      bodyWrite(i.repository, i.issue, expected.body)
    }
    editLabels(i.repository, i.issue, i.addLabels, removeLabels)
    if (i.removeLabels?.length && outcome.labels === 'not-run') outcome.labels = 'unchanged'
    expected.labels = [...new Set(expected.labels.filter(label => !(i.removeLabels ?? []).includes(label)).concat(i.addLabels ?? []))]
  } else if (i.action === 'close-on-push') {
    closeEligibility(i, before)
    expected.body = appendProgress(before.body, `Pushed ${i.pushedTip}. ${i.proof}`)
    bodyWrite(i.repository, i.issue, expected.body)
    editLabels(i.repository, i.issue, [], ['📦 implemented'])
    expected.labels = expected.labels.filter(label => label !== '📦 implemented')
    gh(['api', '--method', 'PATCH', `repos/${i.repository}/issues/${i.issue}`, '--input', '-'], { state: 'closed', state_reason: 'completed' }, 'lifecycle')
    outcome.lifecycle = 'closed'; expected.state = 'CLOSED'
  } else if (i.action === 'bump') {
    bodyWrite(i.targetRepository, i.issue, draft, true)
    const result = gh(['api', '--method', 'POST', `repos/${i.targetRepository}/issues`, '--input', '-'], { title: i.title, body: draft, labels: i.addLabels ?? [] }, 'lifecycle')
    if (!Number.isSafeInteger(result.number) || result.number < 1) fail('Created issue identity is unconfirmed; inspect before retrying')
    targetRepository = i.targetRepository; targetNumber = result.number
    outcome.lifecycle = 'created'; outcome.body = 'updated'
    if (i.addLabels?.length) outcome.labels = 'updated'
    Object.assign(expected, { body: draft, title: i.title, state: 'OPEN', labels: i.addLabels ?? [] })
  }
  const after = issue(targetRepository, targetNumber)
  verify(after, expected)
  outcome.issueUrl = after.url
  artifacts(after)
  snapshot(targetRepository, targetNumber, i.action === 'close-on-push' ? 'close' : i.action === 'snapshot' ? i.snapshotSource : 'claim')
  outcome.status = 'complete'
  outcome.detail = `Proof: ${prefix}.diff${outcome.snapshot === 'warning' ? '; snapshot warning: inspect and recapture separately' : ''}`
} catch (error) {
  outcome.status = attempted ? 'partial' : 'refused'
  outcome.detail = error instanceof Error ? error.message : 'Bookkeeping failed; inspect current issue before retrying'
  if (prefix) outcome.detail += `; artifacts: ${prefix}`
  if (!instruction) {
    console.log(`BRIEF GAP: ${outcome.detail.replace(/^BRIEF GAP: /, '').replace(/[\r\n\u0085\u2028\u2029]/g, ' ').slice(0, 1000)}`)
    process.exit(1)
  }
  process.exitCode = 1
}
console.log(formatBookkeepingReport(instruction, outcome))
