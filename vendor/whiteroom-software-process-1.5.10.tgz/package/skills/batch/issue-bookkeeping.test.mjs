import assert from 'node:assert/strict'
import { test } from 'node:test'
import { formatBookkeepingReport, parseBookkeepingInstruction } from './issue-bookkeeping.mjs'

const identity = {
  repository: 'jon-whiteroomsoftware/whiteroom-software-process',
  issue: 535,
  source: 'eng lead 23544594, lane A362 instruction',
}
const update = { ...identity, action: 'update', progress: 'Proof: targeted checks pass.' }
const close = {
  ...identity,
  action: 'close-on-push',
  closeAuthorization: {
    lead: '23544594', repository: identity.repository, issue: 535, pushedTip: 'a'.repeat(40),
    source: 'eng lead brief', scopeComplete: true, noOpenDecision: true,
  },
  pushedTip: 'a'.repeat(40),
  commits: ['b'.repeat(40)],
  proof: 'Proof: publication evidence linked from the issue.',
}
const bump = {
  ...identity,
  action: 'bump',
  targetRepository: 'jon-whiteroomsoftware/PXLBLZ-IDE',
  title: 'Bump WRSP to the named release',
  bodyFile: '/named/consumer-bump.md',
}
const parse = (value) => parseBookkeepingInstruction(JSON.stringify(value)
  .replace(/[\u0085\u2028\u2029]/g, character => `\\u${character.charCodeAt(0).toString(16).padStart(4, '0')}`))

test('preserves every named field for each instruction action', () => {
  for (const value of [
    update,
    { ...identity, action: 'update', bodyFile: '/named/body.md', addLabels: ['WIP'], removeLabels: ['📦 implemented'] },
    { ...identity, action: 'update', addLabels: ['📦 implemented'] },
    close,
    bump,
    { ...identity, action: 'snapshot', snapshotSource: 'claim' },
    { ...identity, action: 'snapshot', snapshotSource: 'close' },
  ]) assert.deepEqual(parse(value), value)
})

test('preserves sourced quotes and escaped whitespace byte for byte', () => {
  const value = {
    ...update,
    source: 'eng lead, source: "Jon, issue #525"',
    progress: 'Jon, #525: "Yes, go ahead and create the child issues, please".\n🦋\r\n',
  }
  assert.deepEqual(parse(value), value)
})

test('refuses missing or malformed identity and source fields', () => {
  for (const key of ['repository', 'issue', 'source']) {
    const missing = { ...update }
    delete missing[key]
    assert.throws(() => parse(missing), /BRIEF GAP:/)
  }
  for (const issue of [0, -1, 1.5, Number.MAX_SAFE_INTEGER + 1, '535', null]) {
    assert.throws(() => parse({ ...update, issue }), /BRIEF GAP: issue/)
  }
  for (const source of ['', ' \t ', null, 12]) {
    assert.throws(() => parse({ ...update, source }), /BRIEF GAP: source/)
  }
  for (const repository of ['owner', '../repo', 'owner/..', '-owner/repo', 'owner/repo/extra', '']) {
    assert.throws(() => parse({ ...update, repository }), /BRIEF GAP: repository/)
  }
})

test('refuses malformed JSON, multiline envelopes and non-object instructions', () => {
  for (const line of ['', '{', 'null', '[]', '535', 'true', JSON.stringify(update) + '\n', '\u2028' + JSON.stringify(update)]) {
    assert.throws(() => parseBookkeepingInstruction(line), /BRIEF GAP:/)
  }
})

test('refuses unknown actions, unnamed fields and fields belonging to another action', () => {
  for (const value of [
    { ...update, action: 'shell', command: 'anything' },
    { ...update, arbitrary: true },
    { ...update, closeAuthorization: close.closeAuthorization },
    { ...close, addLabels: ['WIP'] },
    { ...bump, progress: 'extra' },
    { ...identity, action: 'snapshot', snapshotSource: 'other' },
  ]) assert.throws(() => parse(value), /BRIEF GAP:/)
})

test('requires one unambiguous update and explicit noncontradictory label changes', () => {
  for (const fields of [
    {}, { progress: '' }, { bodyFile: '' }, { progress: 'x', bodyFile: '/body.md' },
    { addLabels: [] }, { addLabels: [''] }, { removeLabels: 'WIP' },
    { addLabels: ['WIP', 'WIP'] }, { addLabels: ['WIP'], removeLabels: ['WIP'] },
  ]) assert.throws(() => parse({ ...identity, action: 'update', ...fields }), /BRIEF GAP:/)
})

test('requires close-specific authorization and publication inputs without treating them as verified', () => {
  for (const key of ['closeAuthorization', 'pushedTip', 'commits', 'proof']) {
    const missing = { ...close }
    delete missing[key]
    assert.throws(() => parse(missing), /BRIEF GAP:/)
  }
  for (const fields of [
    { closeAuthorization: '' }, { pushedTip: 'HEAD' }, { pushedTip: 'a'.repeat(39) },
    { commits: [] }, { commits: ['HEAD'] }, { proof: ' ' },
  ]) assert.throws(() => parse({ ...close, ...fields }), /BRIEF GAP:/)
})

test('requires bump destination and draft while retaining the authorizing release issue identity', () => {
  for (const key of ['targetRepository', 'title', 'bodyFile']) {
    const missing = { ...bump }
    delete missing[key]
    assert.throws(() => parse(missing), /BRIEF GAP:/)
  }
  assert.throws(() => parse({ ...bump, targetRepository: 'wrong' }), /BRIEF GAP:/)
})

test('formats complete result states into at most ten physical lines with lossless escaped source/detail', () => {
  const instruction = parse({ ...update, source: 'lead\nquote\r\n🦋\u0085\u2028\u2029' })
  const detail = 'verbatim "quote"\nnext\rline\u0085\u2028\u2029'
  for (const status of ['prepared', 'complete', 'refused', 'partial']) {
    const report = formatBookkeepingReport(instruction, {
      status,
      body: 'not-run',
      labels: 'not-run',
      lifecycle: 'not-run',
      snapshot: 'not-run',
      issueUrl: 'https://github.com/jon-whiteroomsoftware/whiteroom-software-process/issues/535',
      detail,
    })
    const lines = report.split(/[\n\r\u0085\u2028\u2029]/)
    assert.equal(lines.length, 10)
    assert.equal(lines[0], `STATUS: ${status}`)
    assert.equal(lines[1], `ISSUE: ${identity.repository}#535`)
    assert.equal(lines[2], 'ACTION: update')
    assert.equal(JSON.parse(lines[3].slice('SOURCE: '.length)), 'lead\nquote\r\n🦋\u0085\u2028\u2029')
    assert.deepEqual(lines.slice(4, 8), ['BODY: not-run', 'LABELS: not-run', 'LIFECYCLE: not-run', 'SNAPSHOT: not-run'])
    assert.equal(lines[8], 'URL: "https://github.com/jon-whiteroomsoftware/whiteroom-software-process/issues/535"')
    assert.equal(JSON.parse(lines[9].slice('DETAIL: '.length)), detail)
  }
})

test('formats minimal results in eight lines and represents partial effects explicitly', () => {
  const report = formatBookkeepingReport(parse(close), {
    status: 'partial', body: 'updated', labels: 'updated', lifecycle: 'unchanged', snapshot: 'warning',
  })
  assert.deepEqual(report.split('\n').slice(4), [
    'BODY: updated', 'LABELS: updated', 'LIFECYCLE: unchanged', 'SNAPSHOT: warning',
  ])
  assert.equal(report.split('\n').length, 8)
})
