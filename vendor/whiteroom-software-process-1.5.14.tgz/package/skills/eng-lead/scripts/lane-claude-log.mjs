import { execFileSync } from 'node:child_process';
import { realpathSync, statSync } from 'node:fs';
import { dirname, join } from 'node:path';

const readRights = new Set(['list', 'search', 'read', 'execute', 'readattr', 'readextattr',
  'readsecurity', 'inherited', 'file_inherit', 'directory_inherit', 'limit_inherit', 'only_inherit']);
const within = (dir, root) => dir === root || dir.startsWith(root + '/');

function checkDirectory(dir) {
  const stat = statSync(dir);
  if (!stat.isDirectory() || stat.uid !== process.getuid() || (stat.mode & 0o022)) throw new Error('unsafe mode or owner');
  const listing = execFileSync('/bin/ls', ['-lde', dir], { encoding: 'utf8', env: { LC_ALL: 'C' }, stdio: ['ignore', 'pipe', 'pipe'] });
  for (const line of listing.trimEnd().split('\n').slice(1)) {
    const entry = /^\s*\d+:\s+.+\s(allow|deny)\s+([a-z_,]+)$/.exec(line);
    if (!entry || (entry[1] === 'allow' && entry[2].split(',').some(right => !readRights.has(right)))) {
      throw new Error('unsafe directory ACL');
    }
  }
}

try {
  const [homeArg, file, worktree, commonDir] = process.argv.slice(2);
  const home = realpathSync.native(homeArg);
  const dir = realpathSync.native(dirname(file));
  let temp;
  try { temp = realpathSync.native(process.env.TMPDIR || '/tmp'); } catch { /* No temporary directory at this path. */ }
  const writable = [worktree, commonDir, temp, join(home, 'src/worktrees'), join(home, '.local/state/wrsp/claude-github')];
  if (!within(dir, home) || writable.some(root => root && within(dir, root))) throw new Error('lane writable directory');
  for (let parent = dir; ; parent = dirname(parent)) {
    checkDirectory(parent);
    if (parent === home) break;
  }
  console.log(dir);
} catch {
  console.error('Claude developer lanes require --log in an agent-owned directory outside the lane writable roots');
  process.exitCode = 64;
}
