import fs from 'node:fs'
import path from 'node:path'
import { createHash } from 'node:crypto'
import { nextInvocation } from '../../developer/scripts/next-invocation.mjs'

export function writeEvent(target, eventArgs) {
  const handle = JSON.parse(fs.readFileSync(target, 'utf8'))
  const [event, ...options] = eventArgs
  if (typeof handle.lane !== 'string' || !/^[A-Za-z0-9.-]+$/.test(handle.lane) ||
      !Number.isSafeInteger(handle.turn) || handle.turn < 0 ||
      !['started', 'work-sent', 'assigned', 'released', 'blocked', 'retired'].includes(event)) {
    throw new Error('invalid event metadata')
  }
  let issue = Number(handle.issue), reason = null, input
  const seen = new Set()
  for (let index = 0; index < options.length; index += 2) {
    const key = options[index], value = options[index + 1]
    if (seen.has(key) || value === undefined) throw new Error('invalid event arguments')
    seen.add(key)
    if (key === '--issue' && /^[0-9]+$/.test(value)) issue = Number(value)
    else if (key === '--reason') reason = value
    else if (key === '--input' && event === 'work-sent') input = value
    else throw new Error('invalid event arguments')
  }
  if (!Number.isSafeInteger(issue) || issue < 0) throw new Error('invalid event issue')
  const row = { at: new Date().toISOString(), event, lane: handle.lane, slot: handle.slot ?? handle.lane, turn: handle.turn, issue, reason }
  if (event === 'work-sent') {
    const bytes = fs.readFileSync(input)
    row.sha256 = createHash('sha256').update(bytes).digest('hex')
    row.firstLine = bytes.toString('utf8').split('\n')[0]
  }
  fs.appendFileSync(path.join(path.dirname(target), handle.lane + '.events.jsonl'), JSON.stringify(row) + '\n')
}

export function announce(target, cwd, bash, wrapper, stateFile, eventArgs) {
  try { writeEvent(target, eventArgs) }
  catch (error) {
    console.error('REFUSED: event not written: ' + error.message)
    console.error('WARNING: event append failed after successful submission; admitted work was not replayed or rolled back.')
  }
  process.stdout.write('HANDLE: ' + target + '\n' +
    nextInvocation('watch', [bash, wrapper, 'watch', target, '--state', stateFile, '--timeout', '600'], cwd) +
    nextInvocation('status', [bash, wrapper, 'status', target], cwd))
}
