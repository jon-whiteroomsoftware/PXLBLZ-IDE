import { spawn } from 'node:child_process';
import { appendFileSync, closeSync, constants, fstatSync, lstatSync, openSync, readSync } from 'node:fs';
import { constants as os } from 'node:os';
import { StringDecoder } from 'node:string_decoder';
import { pathToFileURL } from 'node:url';

const resultGraceMs = 2_000;
const logPollMs = 100;

function watchResult(log, thread, onIdle) {
  let fd;
  let initial;
  try {
    fd = openSync(log, constants.O_RDONLY | constants.O_NONBLOCK | constants.O_NOFOLLOW);
    initial = fstatSync(fd);
    if (!initial.isFile()) throw new Error('turn log is not a regular file');
  } catch {
    if (fd !== undefined) closeSync(fd);
    return () => {};
  }

  const buffer = Buffer.allocUnsafe(64 * 1024);
  const decoder = new StringDecoder('utf8');
  let position = initial.size;
  let partial = '';
  let result;
  let lastOutput = 0;

  const timer = setInterval(() => {
    let size;
    try {
      const current = lstatSync(log);
      if (current.dev !== initial.dev || current.ino !== initial.ino || current.size < position) {
        stop();
        return;
      }
      size = current.size;
      const end = Math.min(size, position + 1024 * 1024);
      while (position < end) {
        const count = readSync(fd, buffer, 0, Math.min(buffer.length, end - position), position);
        if (count === 0) break;
        position += count;
        lastOutput = performance.now();
        const lines = (partial + decoder.write(buffer.subarray(0, count))).split('\n');
        partial = lines.pop();
        for (const line of lines) {
          if (!line.includes('"result"')) continue;
          let row;
          try { row = JSON.parse(line); } catch { continue; }
          if (row?.type === 'result' && typeof row.result === 'string' &&
              (row.session_id === undefined || row.session_id === thread)) {
            result = { success: row.is_error !== true && (row.subtype === undefined || row.subtype === 'success') };
          }
        }
      }
    } catch {
      stop();
      return;
    }
    if (result && position === size && performance.now() - lastOutput >= resultGraceMs) {
      stop();
      onIdle(result);
    }
  }, logPollMs);

  function stop() {
    if (fd === undefined) return;
    clearInterval(timer);
    closeSync(fd);
    fd = undefined;
  }
  return stop;
}

export function dispatchClaudeWork({ command, args, log, thread, cwd, env, crossAccount = false, signal }) {
  return new Promise(resolve => {
    if (signal?.aborted) return resolve(70);
    let child;
    let reapedResult;
    let deadline;
    let settled = false;
    const reapSignal = crossAccount ? 'SIGTERM' : 'SIGKILL';
    const complete = code => {
      if (settled) return;
      settled = true;
      clearTimeout(deadline);
      signal?.removeEventListener('abort', abort);
      stop();
      resolve(code);
    };
    const refuse = reason => {
      if (settled) return;
      process.stderr.write(`REFUSED: Claude lane cleanup unconfirmed (#575): ${reason}\n`);
      child.unref();
      complete(74);
    };
    const requestStop = (kind, result) => {
      if (settled || deadline || child.exitCode !== null || child.signalCode !== null) return;
      try {
        if (!child.kill(kind)) return;
        reapedResult = result;
        if (crossAccount && !settled) deadline = setTimeout(() => refuse('host relay did not close'), 7500);
      } catch (error) {
        if (crossAccount) refuse(error.code ?? error.message);
        else throw error;
      }
    };
    const abort = () => requestStop('SIGTERM');
    const stop = watchResult(log, thread, result => requestStop(reapSignal, result));
    try {
      child = spawn(command, args, { cwd, env, stdio: 'inherit' });
    } catch (error) {
      stop();
      throw error;
    }
    child.once('exit', stop);
    child.once('error', error => {
      if (crossAccount) return refuse(error.code ?? error.message);
      stop();
      process.stderr.write(String(error) + '\n');
      if (child.pid === undefined) complete(70);
    });
    signal?.addEventListener('abort', abort, { once: true });
    child.once('close', (code, stopped) => {
      if (settled) return;
      if (crossAccount && (code === 74 || stopped)) {
        if (stopped) return refuse(`host relay exited on ${stopped}`);
        return complete(74);
      }
      if (signal?.aborted) return complete(70);
      if (reapedResult && (crossAccount ? code === 143 : stopped === reapSignal)) {
        try {
          appendFileSync(log, `CLAUDE WORK: reaped child PID ${child.pid} after result grace\n`);
        } catch (error) {
          process.stderr.write(String(error) + '\n');
        }
        if (reapedResult.success) return complete(0);
      }
      complete(code ?? (stopped ? 128 + os.signals[stopped] : 70));
    });
  });
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const [log, thread, command, ...args] = process.argv.slice(2);
  process.exitCode = await dispatchClaudeWork({ command, args, log, thread, cwd: process.cwd(), env: process.env });
}
