import fs from 'node:fs';

export const isLaneCli = cli => cli === 'claude' || cli === 'codex' || cli === 'agy';
export const isAgyConversation = id => typeof id === 'string' && /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(id);

export function agyResultMessage(row) {
  if (row?.type === 'agy.result' && isAgyConversation(row.conversation_id) &&
      typeof row.response === 'string' && row.response.trim()) return row.response;
  return undefined;
}

// Provider stdout only; tool results, subagents and incomplete JSONL are not replies.
export function assistantMessages(cli, bytes, { finalOnly = false } = {}) {
  const messages = [];
  const lines = bytes.toString('utf8').split('\n');
  lines.pop();
  for (const line of lines) {
    let row;
    try { row = JSON.parse(line); } catch { continue; }
    if (cli === 'codex' && row?.type === 'item.completed' && row.item?.type === 'agent_message' && typeof row.item.text === 'string') messages.push(row.item.text);
    if (cli === 'agy') {
      const message = agyResultMessage(row);
      if (message !== undefined) messages.push(message);
    }
    if (cli === 'claude' && !row?.parent_tool_use_id && !row?.parentToolUseID && !row?.isSidechain) {
      if (row?.type === 'result' && typeof row.result === 'string') messages.push(row.result);
      if (!finalOnly && row?.type === 'assistant' && row.message?.role === 'assistant' && Array.isArray(row.message.content)) {
        messages.push(row.message.content.filter(block => block?.type === 'text' && typeof block.text === 'string').map(block => block.text).join('\n'));
      }
    }
  }
  return messages;
}

// A finished handoff is actionable only from the final provider reply.
export function finishedLandRequest(cli, bytes, lane) {
  const text = assistantMessages(cli, bytes, { finalOnly: true }).at(-1);
  for (const line of (text ?? '').split(/\r?\n/)) {
    if (/^land request\b/.test(line)) return line;
    const request = line.startsWith(`${lane} `) ? line.slice(lane.length + 1) : line;
    if (/^land request\b/.test(request)) return line;
  }
  return null;
}

// Nonblocking open also makes unexpected FIFOs/devices refuse instead of hanging.
export function optionalBytes(file) {
  let fd;
  try {
    fd = fs.openSync(file, fs.constants.O_RDONLY | fs.constants.O_NONBLOCK);
    if (!fs.fstatSync(fd).isFile()) throw new Error('expected readable regular file');
    return fs.readFileSync(fd);
  } catch (error) {
    if (error.code === 'ENOENT') return null;
    throw new Error(`${file}: ${error.message}`);
  } finally { if (fd !== undefined) fs.closeSync(fd); }
}

export function pendingReview(cli, bytes) {
  let pending = null;
  for (const text of assistantMessages(cli, bytes)) {
    for (const line of text.split(/\r?\n/)) {
      if (/^\S+ review start\b/.test(line)) pending = line;
      if (/^\S+ review done\b/.test(line)) pending = null;
    }
  }
  return pending;
}
