import { existsSync, realpathSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { pathToFileURL } from 'node:url'

const [invoked, cwd, bash, ...argv] = process.argv.slice(2)
const scripts = realpathSync(dirname(invoked))
const installed = join(scripts, 'lane-runtime')
const runtime = existsSync(installed) ? installed : join(scripts, '../../../dist/lane')
const { runLane } = await import(pathToFileURL(join(runtime, 'cli.mjs')).href)

async function statusContext() {
  const { nextInvocation } = await import('../../developer/scripts/next-invocation.mjs')
  const { contextStatus, observeLaneActivity, readRegular } = await import('./lane-activity.mjs')
  return {
    cwd, bash, wrapper: join(scripts, 'lane.sh'),
    env: process.env, stdout: process.stdout, stderr: process.stderr, now: Date.now,
    nextInvocation, contextStatus, observeLaneActivity, readRegular,
  }
}

// Keep the status context compatible with a previous build. Defer opening the
// Node streams to statusContext; check uses blocking fd writes.
const context = argv[0] === 'status' ? await statusContext() : { scripts, invoked, cwd, bash, env: process.env }
process.exitCode = await runLane(argv, context)
