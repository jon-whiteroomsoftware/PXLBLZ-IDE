import { execFileSync } from 'node:child_process'
import { lstatSync, readFileSync, realpathSync } from 'node:fs'
import { basename, dirname, join, resolve } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const agentHome = '/Users/agent';
const laneHome = '/Users/wrsp-lane';
const entry = '/Library/WRSP/bin/wrsp-claude-lane';
const supervisor = '/Library/WRSP/bin/wrsp-claude-lane-process.mjs';
const quote = value => "'" + value.replaceAll("'", "'\\''") + "'";
const search = 'search,readattr';
const read = 'read,readattr,readextattr,readsecurity';
const readDir = 'list,search,readattr,readextattr,readsecurity';
const edit = 'write,append,delete,writeattr,writeextattr';
const editDir = 'add_file,add_subdirectory,delete_child,delete,writeattr,writeextattr';
const privateRights = 'read,write,append,execute,delete,delete_child,readattr,writeattr,readextattr,writeextattr,readsecurity,writesecurity,chown';

function canonical(path, kind) {
  const stat = lstatSync(path);
  if (realpathSync.native(path) !== path || (kind === 'dir' ? !stat.isDirectory() : !stat.isFile() || stat.nlink !== 1)) {
    throw new Error(`unexpected ${kind} at ${path}`);
  }
  return path;
}

function record(path) {
  canonical(path, 'file');
  if (lstatSync(path).size > 4096) throw new Error(`oversize Git record at ${path}`);
  return readFileSync(path, 'utf8').replace(/[\r\n]+$/, '');
}

function linkedPaths(home, worktree) {
  const name = basename(worktree);
  const match = /^([A-Za-z0-9_.-]+)-issue-[1-9][0-9]*-[A-Za-z0-9_.-]+$/.exec(name);
  if (!match || !/^[A-Za-z0-9]/.test(match[1]) || worktree !== join(home, 'src/worktrees', name)) {
    throw new Error('unknown Claude lane worktree');
  }
  try {
    canonical(home, 'dir');
    canonical(worktree, 'dir');
    const common = canonical(join(home, 'src', match[1], '.git'), 'dir');
    const admin = canonical(join(common, 'worktrees', name), 'dir');
    const pointer = join(worktree, '.git');
    if (record(pointer) !== `gitdir: ${admin}` || resolve(admin, record(join(admin, 'commondir'))) !== common ||
        resolve(admin, record(join(admin, 'gitdir'))) !== pointer) throw new Error('mismatched Git registration');
    canonical(join(common, 'config'), 'file');
    for (const path of ['objects', 'refs', 'logs']) canonical(join(common, path), 'dir');
    const usageParent = join(common, 'wrsp');
    if (lstatSync(usageParent, { throwIfNoEntry: false })) canonical(usageParent, 'dir');
    const usage = join(usageParent, 'usage');
    if (lstatSync(usage, { throwIfNoEntry: false })) canonical(usage, 'dir');
    return { common, admin, usage };
  } catch (error) {
    throw new Error(`unknown Claude lane worktree: ${error.message}`);
  }
}

const acl = (path, user, rights) => `sudo /bin/chmod +a '${user} allow ${rights}' ${quote(path)}`;

function shieldSiblings(parent, ...sharedNames) {
  const exceptions = sharedNames.map(name => `! -name ${quote(name)}`).join(' ');
  return [
    `sudo /usr/bin/find -P ${quote(parent)} -mindepth 1 -maxdepth 1 ${exceptions} \\( -type d -o -type f \\) -exec /bin/chmod +a# 0 'wrsp-lane deny ${privateRights}' '{}' +`,
    `sudo /bin/chmod +a# 0 'wrsp-lane deny ${privateRights},file_inherit,directory_inherit,only_inherit' ${quote(parent)}`,
  ];
}

function treeAcl(path, user, writable) {
  const fileRights = writable ? `${read},${edit}` : read;
  const dirRights = writable ? `${readDir},${editDir}` : readDir;
  const entries = [
    ['d', `${dirRights},directory_inherit`],
    ['d', `${fileRights},file_inherit,directory_inherit,only_inherit`],
    ['f', fileRights],
  ];
  return entries.map(([type, rights]) => `sudo /usr/bin/find -P ${quote(path)} -type ${type} -exec /bin/chmod +a '${user} allow ${rights}' '{}' +`);
}

export function planClaudeLaneSetup(home, worktree) {
  const { common, admin, usage } = linkedPaths(home, worktree);
  const broker = join(home, '.local/state/wrsp/claude-github');
  const source = join(home, 'src/whiteroom-software-process/templates/claude-lane/wrsp-claude-lane');
  const processSource = join(home, 'src/whiteroom-software-process/skills/developer/scripts/claude-lane-process.mjs');
  const state = [join(home, '.local'), join(home, '.local/state'), dirname(broker), dirname(usage), broker, usage];
  const paths = [worktree, admin, join(common, 'objects'), join(common, 'refs'), join(common, 'logs'), usage];
  const ancestors = [home, join(home, 'src'), dirname(worktree), dirname(common), common, dirname(admin), dirname(usage),
    join(home, '.local'), join(home, '.local/state'), dirname(broker), broker];
  for (const path of ancestors) if (lstatSync(path, { throwIfNoEntry: false })) canonical(path, 'dir');
  const readGit = ['config', 'packed-refs', 'shallow'].map(name => join(common, name)).filter(path => lstatSync(path, { throwIfNoEntry: false }));
  readGit.forEach(path => canonical(path, 'file'));
  return [
    '# Run from Jon’s administrator account after reviewing the landed launcher.',
    'sudo /usr/bin/install -d -o root -g wheel -m 0755 /Library/WRSP /Library/WRSP/bin',
    `sudo /usr/bin/install -o root -g wheel -m 0644 ${quote(processSource)} ${supervisor}`,
    `sudo /usr/bin/install -o root -g wheel -m 0755 ${quote(source)} ${entry}`,
    '# Open sudoers with visudo and enter the single line shown below.',
    'sudo /usr/sbin/visudo',
    `agent ALL=(wrsp-lane) NOPASSWD:NOSETENV: ${entry}`,
    `sudo /usr/bin/install -d -o agent -m 0700 ${state.map(quote).join(' ')}`,
    `sudo /bin/chmod go-rwx ${quote(home)}`,
    ...shieldSiblings(home, 'src', '.local'),
    ...shieldSiblings(join(home, '.local'), 'state'),
    ...shieldSiblings(join(home, '.local/state'), 'wrsp'),
    ...shieldSiblings(dirname(broker), 'claude-github'),
    ...ancestors.map(path => acl(path, 'wrsp-lane', search)),
    ...readGit.map(path => acl(path, 'wrsp-lane', read)),
    ...paths.flatMap(path => [...treeAcl(path, 'wrsp-lane', true), ...treeAcl(path, 'agent', true)]),
    acl(laneHome, 'agent', search),
    acl(join(laneHome, '.claude'), 'agent', search),
    ...treeAcl(join(laneHome, '.claude/projects'), 'agent', false),
  ];
}

function verify(worktree) {
  linkedPaths(agentHome, worktree);
  if (lstatSync(agentHome).mode & 0o077) throw new Error('agent home grants group or other access');
  for (const path of ['/Library/WRSP', '/Library/WRSP/bin', entry, supervisor]) {
    canonical(path, path === entry || path === supervisor ? 'file' : 'dir');
    const stat = lstatSync(path);
    if (stat.uid !== 0 || (stat.mode & 0o022) !== 0) throw new Error(`launcher path must be root-owned and protected: ${path}`);
  }
  canonical(join(laneHome, '.claude/projects'), 'dir');
  const host = fileURLToPath(new URL('../../developer/scripts/claude-lane-host.sh', import.meta.url));
  for (const args of [['check'], ['run', '--verify']]) {
    execFileSync('/bin/bash', [host, ...args], { cwd: worktree, stdio: ['ignore', 'inherit', 'inherit'] });
  }
  console.log('Claude developer lane setup verified (#575).');
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  try {
    const [mode, worktree, ...extra] = process.argv.slice(2);
    if (!['plan', 'verify'].includes(mode) || !worktree || extra.length) {
      throw new Error('usage: node claude-lane-setup.mjs plan|verify <absolute-registered-worktree>');
    }
    if (mode === 'verify') verify(worktree);
    else console.log(planClaudeLaneSetup(agentHome, worktree).join('\n'));
  } catch (error) {
    console.error(`REFUSED: ${error.message}`);
    process.exitCode = 66;
  }
}
