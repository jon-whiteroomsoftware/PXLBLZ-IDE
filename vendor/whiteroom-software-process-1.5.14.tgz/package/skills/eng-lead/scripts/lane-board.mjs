import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { agyResultMessage } from './lane-messages.mjs';
import { contextStatus } from './lane-activity.mjs';

const count = value => Number.isSafeInteger(value) && value >= 0;
const safeLane = value => typeof value === 'string' && /^[A-Za-z0-9.-]+$/.test(value);
const read = file => { try { return fs.readFileSync(file, 'utf8'); } catch { return null; } };
const records = file => {
  const text = read(file) ?? '';
  return text.slice(0, text.lastIndexOf('\n') + 1).split('\n').flatMap(line => {
    try { const row = JSON.parse(line); return row && typeof row === 'object' && !Array.isArray(row) ? [row] : []; } catch { return []; }
  });
};

export function main(args) {
  const target = args[0] || '.';
  const clean = value => String(value ?? 'unknown').replace(/[\t\r\n]/g, ' ');
  const processIsLive = pid => {
    if (!/^[0-9]+$/.test(pid)) return false;
    const listed = spawnSync('ps', ['-p', pid], { stdio: 'ignore' });
    if (listed.error?.code !== 'EPERM') return listed.status === 0;
    // The commit profile denies ps and allows signal zero within the sandbox.
    const id = Number(pid);
    if (id < 1 || id > 0x7fffffff) return false;
    try { return process.kill(id, 0); } catch { return false; }
  };
  const validEvent = (row, lane) => typeof row.at === 'string' && /^\d{4}-\d\d-\d\dT.*Z$/.test(row.at) &&
    Number.isFinite(Date.parse(row.at)) && row.lane === lane && typeof row.slot === 'string' &&
    count(row.turn) && count(row.issue) && (row.reason === null || typeof row.reason === 'string') &&
    ['started', 'work-sent', 'assigned', 'released', 'blocked', 'retired'].includes(row.event) &&
    (row.event !== 'work-sent' || (typeof row.sha256 === 'string' && /^[a-f0-9]{64}$/.test(row.sha256) && typeof row.firstLine === 'string'));
  const rows = [];
  let files;
  try { files = fs.readdirSync(target).filter(name => name.endsWith('.lane.json')); }
  catch (error) { console.error('REFUSED: board directory unreadable: ' + error.message); return 65; }
  for (const file of files) {
    const filename = path.join(target, file), fallback = file.slice(0, -10);
    let handle;
    try {
      handle = JSON.parse(fs.readFileSync(filename, 'utf8'));
      if (!handle || !safeLane(handle.lane) || !count(handle.turn) || typeof handle.contact !== 'string') throw new Error('invalid handle');
    } catch { rows.push([fallback, fallback, 'unknown', 'unknown', 'unknown', 'unknown', 'unknown']); continue; }
    const log = handle.contact;
    let state;
    if (fs.existsSync(log + '.exit')) state = 'exited ' + (read(log + '.exit') ?? 'unknown').trim();
    else {
      const pid = (read(log + '.pid') ?? '').trim();
      state = processIsLive(pid) ? 'live' : fs.existsSync(filename + '.lock') ? 'interrupted' : 'none';
    }
    const events = records(path.join(target, handle.lane + '.events.jsonl')).filter(row => validEvent(row, handle.lane));
    let message, messageTurn;
    if (state.startsWith('exited ')) {
      const turns = Array.isArray(handle.turns) ? handle.turns.filter(turn => turn && count(turn.n) && typeof turn.log === 'string') : [];
      if (!turns.some(turn => turn.n === handle.turn)) turns.push({ n: handle.turn, log });
      turns.sort((a, b) => b.n - a.n);
      for (const turn of turns) {
        if (handle.cli === 'agy' && read(turn.log + '.exit')?.trim() !== '0') continue;
        for (const row of records(turn.log).reverse()) {
          let text;
          if (handle.cli === 'agy' && row.conversation_id === handle.thread) text = agyResultMessage(row);
          else if (handle.cli === 'codex' && row.type === 'item.completed' && row.item?.type === 'agent_message') text = row.item.text;
          else if (handle.cli === 'claude' && row.type === 'result') text = row.result;
          if (typeof text === 'string' && text.length) { message = text.split(/\r?\n/)[0]; messageTurn = turn.n; break; }
        }
        if (message !== undefined) break;
      }
      if (message !== undefined && (/^\S+ review (start|done)\b/.test(message) || /\b(handoff|handed off|milestone)\b/i.test(message)) && !events.some(row => row.event === 'work-sent' && row.turn > messageTurn)) state = 'needs-reply';
      if (events.at(-1)?.event === 'retired') state = 'retired';
    }
    rows.push([handle.lane, handle.slot ?? handle.lane, state, handle.turn, contextStatus(handle).percent, events.at(-1)?.event ?? 'unknown', message ?? 'unknown']);
  }
  rows.sort((a, b) => Number(a[2] === 'retired') - Number(b[2] === 'retired') || Number(b[2] === 'needs-reply') - Number(a[2] === 'needs-reply') || (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0));
  console.log('lane\tslot\tstate\tturn\tcontext\tlast-event\tlast-message');
  for (const row of rows) console.log(row.map(clean).join('\t'));
  return 0;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) process.exitCode = main(process.argv.slice(2));
