import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

// The observation is already on disk. Checking it never probes the runner.
function warnAboutDegradedRunners() {
  const read = file => { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return null; } };
  const config = read(path.join(os.homedir(), '.config/wrsp/runner.json'));
  const root = process.env.WRSP_LEDGER_HOME || config?.ledgerHome || path.join(os.homedir(), '.local/state/wrsp/runner-mirror');
  const index = read(path.join(root, 'mirror/runner-hosts.json'));
  const text = value => typeof value === 'string' ? value.replace(/[\u0000-\u001f\u007f]/g, ' ') : '(unknown)';
  const homes = index?.version === 1 && Array.isArray(index.hosts)
    ? index.hosts.flatMap(entry => typeof entry?.host === 'string' ? [entry.legacy ? root : path.join(root, 'mirror/hosts', createHash('sha256').update(entry.host).digest('hex'))] : [])
    : [root];
  const degraded = homes.map(home => read(path.join(home, 'mirror/pull.json')))
    .filter(pull => pull?.connection?.path === 'ethernet' && pull.connection.degraded === true)
    .map(pull => `${text(pull.host)}: ethernet (${text(pull.connection.address)}); observed ${text(pull.finishedAt)}`);
  if (!degraded.length) return;
  // Keep stdio blocking for check's checked writes, including when fd 1 and
  // fd 2 share a pipe. The legacy diagnostic ignored stderr write errors.
  try { fs.writeFileSync(2, `Runner SSH DEGRADED: ${degraded.join('; ')}; Thunderbolt bridge needs attention.\n`); } catch { /* diagnostic only */ }
}

export async function main(args) {
  warnAboutDegradedRunners();
  const { main: check } = await import('./lane-check.mjs');
  return check(args);
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) process.exitCode = await main(process.argv.slice(2));
