import fs from 'node:fs';
import path from 'node:path';
import { createHash, randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { MESSAGE_BYTES, preview } from './lane-output.mjs';
import { agyResultMessage, isAgyConversation, isLaneCli } from './lane-messages.mjs';
import { nextInvocation } from '../../developer/scripts/next-invocation.mjs';

const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
const nonempty = value => typeof value === 'string' && value.length > 0;
const positive = value => Number.isSafeInteger(value) && value > 0;
const fail = (file, reason) => { throw new Error(`${file}: ${reason}`); };
const missingAgyMessage = 'no complete final message for failed agy turn';
const missingCodexMessage = 'no complete final message for failed Codex turn';
const missingClaudeMessage = 'no complete final message for refused Claude developer turn';
const unconfirmedClaudeMessage = 'Claude lane cleanup unconfirmed (#575); the lead must verify closure';
const noMessageRequires = '--no-message requires a failed agy turn without a complete final message';

// Only complete JSONL events in this turn's log can supply its final message.
function findFinalMessage(cli, logBytes, thread) {
  if (!isLaneCli(cli) || !Buffer.isBuffer(logBytes)) throw new Error('invalid final-message input');
  const lines = logBytes.toString('utf8').split('\n');
  lines.pop();
  let final;
  for (const line of lines) {
    let event;
    try { event = JSON.parse(line); } catch { continue; }
    if (cli === 'codex' && event?.type === 'item.completed' && event.item?.type === 'agent_message' && typeof event.item.text === 'string') final = event.item.text;
    if (cli === 'claude' && event?.type === 'result' && typeof event.result === 'string') final = event.result;
    if (cli === 'agy' && event?.conversation_id === thread) final = agyResultMessage(event) ?? final;
  }
  return final;
}

export function finalMessage(cli, logBytes, thread) {
  const final = findFinalMessage(cli, logBytes, thread);
  if (final === undefined) throw new Error('no complete final message');
  return final;
}

function identity(handle) {
  const { lane, cli, thread, turn, handlePath, logPath } = handle;
  if (!nonempty(lane) || !isLaneCli(cli) || !(cli === 'agy' ? isAgyConversation(thread) : nonempty(thread)) || !positive(turn)
      || !nonempty(handlePath) || !path.isAbsolute(handlePath) || !nonempty(logPath) || !path.isAbsolute(logPath)) throw new Error('invalid finished-turn identity');
  return { version: 1, lane, cli, thread, turn, handlePath, logPath };
}

function exitCodeFor(bytes) {
  const marker = bytes.toString('utf8');
  const code = Number(marker);
  if (!/^[+-]?\d+\s*$/.test(marker) || !Number.isSafeInteger(code)) throw new Error('invalid integer exit marker');
  return code;
}

function failedAgyMessage(handle, code, bytes) {
  if (bytes === undefined) return undefined;
  const result = JSON.parse(bytes.toString('utf8'));
  if (result?.id !== handle.thread || result.code !== code) throw new Error(missingAgyMessage);
  if (result.providerStatus === 'SUCCESS' && result.produced === true
      && typeof result.response === 'string' && result.response.trim()) return result.response;
  return undefined;
}

function finishedEvidence(handle, logBytes, exitBytes, exitCode, resultBytes, allowNoMessage = false) {
  const id = identity(handle);
  const failedAgy = id.cli === 'agy' && exitCode !== 0;
  const failedCodex = id.cli === 'codex' && exitCode !== 0;
  const report = handle.verification;
  const failedClaude = id.cli === 'claude' && handle.role === 'developer' &&
    handle.qualification?.state === 'accepted' && report?.phase === 'work' && report.state === 'refused' &&
    ((exitCode === 66 && report.hostRefusal === 'routing') || (exitCode === 70 && report.hostRefusal === 'cancelled'));
  const unconfirmedClaude = id.cli === 'claude' && handle.role === 'developer' && exitCode === 74;
  const missing = unconfirmedClaude ? unconfirmedClaudeMessage
    : failedAgy ? missingAgyMessage : failedCodex ? missingCodexMessage : failedClaude ? missingClaudeMessage : 'no complete final message';
  const text = failedAgy ? failedAgyMessage(id, exitCode, resultBytes) : findFinalMessage(id.cli, logBytes, id.thread);
  const noMessage = text === undefined;
  if (noMessage) {
    if (!allowNoMessage || (!failedAgy && !failedCodex && !failedClaude)) throw new Error(missing);
    if (failedAgy && findFinalMessage(id.cli, logBytes, id.thread) !== undefined) throw new Error(noMessageRequires);
  }
  const output = noMessage ? Buffer.alloc(0) : Buffer.from(text.endsWith('\n') ? text : `${text}\n`, 'utf8');
  const receipt = { ...id, outputSha256: sha256(output), logSha256: sha256(logBytes), exitSha256: sha256(exitBytes),
    ...(resultBytes !== undefined ? { resultSha256: sha256(resultBytes) } : {}) };
  return { output, receipt, noMessage, failedCodex, failedClaude, missing, unconfirmedClaude };
}

export function receiptFor(handle, logBytes, exitBytes) {
  if (!Buffer.isBuffer(exitBytes)) throw new Error('invalid integer exit marker');
  return finishedEvidence(handle, logBytes, exitBytes, exitCodeFor(exitBytes)).receipt;
}

function source(file, action) {
  try { return action(); } catch (error) { fail(file, error.message); }
}

const canonicalHandle = file => source(file, () => fs.realpathSync(file));

function writeOutput(bytes) {
  source('stdout', () => {
    for (let offset = 0; offset < bytes.length;) {
      const written = fs.writeSync(1, bytes, offset, bytes.length - offset);
      if (written <= 0) throw new Error('incomplete output write');
      offset += written;
    }
  });
}

function regularBytes(file, flags = 0, optional = false) {
  return source(file, () => {
    let fd;
    try { fd = fs.openSync(file, fs.constants.O_RDONLY | fs.constants.O_NONBLOCK | flags); }
    catch (error) {
      if (optional && error.code === 'ENOENT') return undefined;
      throw error;
    }
    try {
      if (!fs.fstatSync(fd).isFile()) throw new Error('expected readable regular file');
      return fs.readFileSync(fd);
    } finally { fs.closeSync(fd); }
  });
}

function snapshot(file, allowNoMessage) {
  const handlePath = canonicalHandle(file);
  const handleBytes = regularBytes(handlePath);
  const handle = source(handlePath, () => JSON.parse(handleBytes.toString('utf8')));
  source(handlePath, () => {
    if (!handle || !positive(handle.turn) || !nonempty(handle.contact)) throw new Error('invalid handle/current contact');
    const current = Array.isArray(handle.turns) ? handle.turns.at(-1) : null;
    const expected = `${handlePath.replace(/\.lane\.json$/, '')}.turn-${handle.turn}.log`;
    const contact = path.join(fs.realpathSync(path.dirname(handle.contact)), path.basename(handle.contact));
    if (contact !== expected || current?.n !== handle.turn || current?.log !== handle.contact) throw new Error('invalid current-turn contact');
  });
  // Exit evidence is validated before opening or resolving the log.
  const exitPath = `${handle.contact}.exit`;
  const exitBytes = regularBytes(exitPath);
  const exitCode = source(exitPath, () => exitCodeFor(exitBytes));
  const logPath = source(handle.contact, () => fs.realpathSync(handle.contact));
  if (logPath !== `${handlePath.replace(/\.lane\.json$/, '')}.turn-${handle.turn}.log`) fail(handle.contact, 'current log resolves outside this turn');
  const logBytes = regularBytes(logPath);
  const resultPath = handle.cli === 'agy' && exitCode !== 0 ? `${logPath}.agy.result.json` : null;
  const resultBytes = resultPath ? regularBytes(resultPath, fs.constants.O_NOFOLLOW, allowNoMessage) : undefined;
  const evidence = source(resultPath ?? logPath, () => finishedEvidence(
    { ...handle, handlePath, logPath }, logBytes, exitBytes, exitCode, resultBytes, allowNoMessage,
  ));
  return { handlePath, handleBytes, logPath, logBytes, exitBytes, exitCode, resultPath, ...evidence };
}

function validReceipt(value) {
  try { identity(value); } catch { return false; }
  const keys = ['outputSha256', 'logSha256', 'exitSha256'];
  if ('resultSha256' in value) keys.push('resultSha256');
  return value.version === 1 && keys.every(key => typeof value[key] === 'string' && /^[a-f0-9]{64}$/.test(value[key]));
}

function readReceipt(file) {
  const bytes = regularBytes(file, 0, true);
  if (bytes === undefined) return undefined;
  const receipt = source(file, () => JSON.parse(bytes.toString('utf8')));
  if (!validReceipt(receipt)) fail(file, 'malformed receipt');
  return receipt;
}

export function run(mode, file, full = false, ackFailed = false, noMessage = false) {
  let temp, ownedTemp = false;
  try {
    if (!['guard', 'read', 'canonical-handle'].includes(mode) || !nonempty(file)) throw new Error('expected guard HANDLE, read HANDLE or canonical-handle HANDLE');
    if (mode === 'canonical-handle') {
      writeOutput(Buffer.from(`${canonicalHandle(file)}\n`, 'utf8'));
      return 0;
    }
    if (mode === 'read' && noMessage && !ackFailed) throw new Error('--no-message requires --ack-failed');
    const allowNoMessage = mode === 'guard' || noMessage;
    const before = snapshot(file, allowNoMessage);
    const receiptFile = `${before.handlePath}.read.json`;
    if (mode === 'guard') {
      if (before.unconfirmedClaude) fail(before.logPath, unconfirmedClaudeMessage);
      const prior = readReceipt(receiptFile);
      if (prior === undefined || prior.turn !== before.receipt.turn) {
        if (before.noMessage) {
          fail(before.resultPath ?? before.logPath, `${before.missing}; run lane.sh read ${before.handlePath} --finished --ack-failed --no-message`);
        }
        const ack = before.resultPath ? ' --ack-failed' : '';
        fs.writeSync(2, `REFUSED: unread finished turn ${before.receipt.turn}; run lane.sh read ${before.handlePath} --finished${ack}\n`);
        return 77;
      }
      const evidenceFiles = { logSha256: before.logPath, outputSha256: before.resultPath ?? before.logPath,
        exitSha256: `${before.logPath}.exit`, resultSha256: before.resultPath };
      // Compare the optional digest even when the current snapshot omits it.
      const expected = before.resultPath ? { ...before.receipt, resultSha256: before.receipt.resultSha256 } : before.receipt;
      for (const [key, value] of Object.entries(expected)) {
        if (prior[key] !== value) fail(evidenceFiles[key] ?? receiptFile, 'finished-turn receipt mismatch');
      }
      return 0;
    }
    if (noMessage && !before.noMessage) {
      fail(before.resultPath ?? before.logPath, before.failedCodex
        ? '--no-message requires a failed Codex turn without a complete final message'
        : before.failedClaude ? '--no-message requires a refused Claude developer turn without a complete final message' : noMessageRequires);
    }
    const ackCodex = before.failedCodex && before.noMessage;
    const ackClaude = before.failedClaude && before.noMessage;
    if (ackFailed && !before.resultPath && !ackCodex && !ackClaude) fail(before.logPath, '--ack-failed requires a failed agy turn or a failed Codex turn with --no-message');
    if (ackCodex && readReceipt(receiptFile)?.turn === before.receipt.turn) fail(receiptFile, 'finished Codex turn already acknowledged');
    if (ackClaude && readReceipt(receiptFile)?.turn === before.receipt.turn) fail(receiptFile, 'finished Claude turn already acknowledged');
    const fullRead = ['bash', path.join(path.dirname(fileURLToPath(import.meta.url)), 'lane.sh'), 'read', before.handlePath, '--finished', '--full'];
    if (ackFailed) fullRead.push('--ack-failed');
    const display = full ? { output: before.output, truncated: false } : preview(before.output, MESSAGE_BYTES, before.resultPath ?? before.logPath, {
      suffix: `Preview does not acknowledge this turn. Read --finished --full${before.resultPath ? ' --ack-failed' : ''} before sending.\n` + nextInvocation('read', fullRead),
    });
    if (!display.truncated && (!before.resultPath || ackFailed)) {
      temp = `${receiptFile}.tmp.${process.pid}.${randomUUID()}`;
      source(temp, () => {
        const fd = fs.openSync(temp, 'wx', 0o600);
        ownedTemp = true;
        try { fs.writeFileSync(fd, `${JSON.stringify(before.receipt)}\n`); }
        finally { fs.closeSync(fd); }
      });
    }
    if (ackClaude) fs.writeSync(2, `REFUSED TURN ${before.receipt.turn}: exit ${before.exitCode}\n`);
    else if (before.resultPath || ackCodex) {
      fs.writeSync(2, `FAILED TURN ${before.receipt.turn}: native exit ${before.exitCode}\n`);
      if (!ackFailed) fs.writeSync(2, 'Read with --finished --ack-failed before sending again.\n');
    }
    writeOutput(display.output);
    const after = snapshot(file, allowNoMessage);
    if (before.handlePath !== after.handlePath || !before.handleBytes.equals(after.handleBytes)) fail(file, 'handle changed during exposure');
    if (before.logPath !== after.logPath || !before.logBytes.equals(after.logBytes)) fail(before.logPath, 'log changed during exposure');
    if (!before.exitBytes.equals(after.exitBytes)) fail(`${before.logPath}.exit`, 'exit marker changed during exposure');
    if (before.receipt.resultSha256 !== after.receipt.resultSha256) fail(before.resultPath, 'agy result changed during exposure');
    if (temp) {
      source(receiptFile, () => fs.renameSync(temp, receiptFile));
      temp = undefined;
      if (before.noMessage) fs.writeSync(2, 'No message was delivered. Acknowledged without a message.\n');
    }
    return 0;
  } catch (error) {
    fs.writeSync(2, `REFUSED: ${error.message}\n`);
    return 65;
  } finally {
    if (temp && ownedTemp) { try { fs.unlinkSync(temp); } catch { /* Only this invocation's temp is owned. */ } }
  }
}

function isEntry() {
  try { return process.argv[1] && fs.realpathSync(process.argv[1]) === fileURLToPath(import.meta.url); }
  catch { return false; }
}
if (isEntry()) {
  const [mode, file, ...flags] = process.argv.slice(2);
  process.exitCode = run(mode, file, flags.includes('--full'), flags.includes('--ack-failed'), flags.includes('--no-message'));
}
