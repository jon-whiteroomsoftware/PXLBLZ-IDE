import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { readRegular } from './lane-activity.mjs';
import { isAgyConversation, isLaneCli } from './lane-messages.mjs';

class NativeRefusal extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

export function runNative([mode, ...args]) {
  try { return collect(mode, args); }
  catch (error) {
    if (!(error instanceof NativeRefusal)) throw error;
    return { status: error.status, stderr: error.message };
  }
}

// Native metadata only. The caller's argv and assistant prose are never evidence.
function collect(mode, args) {
  const normalize = value => value === 'medium' ? 'med' : value;
  const separateClaude = cli => cli === 'claude' && process.env.WRSP_CLAUDE_LANE_RECORDS === '1';
  function find(cli, session) {
    function discoveryFailure(code, message) {
      throw new NativeRefusal(mode === 'bootstrap' ? 82 : code, message);
    }
    if (!session || /[/\\]/.test(session)) discoveryFailure(81);
    if (cli === 'agy') {
      if (!isAgyConversation(session)) discoveryFailure(81);
      try {
        const root = fs.realpathSync(process.env.HOME);
        const transcript = path.join(root, '.gemini/antigravity-cli/brain', session, '.system_generated/logs/transcript.jsonl');
        if (fs.realpathSync(transcript) !== transcript || !fs.lstatSync(transcript).isFile()) throw new Error('unverified native transcript path');
        return transcript;
      } catch (error) { discoveryFailure(error.code === 'ENOENT' ? 82 : 81, error.message); }
    }
    const root = cli === 'codex'
      ? path.join(process.env.CODEX_HOME || path.join(process.env.HOME, '.codex'), 'sessions')
      : path.join(process.env.CLAUDE_CONFIG_DIR || path.join(process.env.HOME, '.claude'), 'projects');
    const matches = [];
    function walk(dir, depth) {
      for (const entry of fs.readdirSync(dir, {withFileTypes:true})) {
        const file = path.join(dir, entry.name);
        if (entry.isDirectory() && (cli === 'codex' || depth === 0)) walk(file, depth + 1);
        else if (entry.isFile() && (cli === 'claude' ? entry.name === session + '.jsonl' : entry.name.startsWith('rollout-') && entry.name.endsWith('-' + session + '.jsonl'))) matches.push(file);
      }
    }
    try {
      if (separateClaude(cli) && fs.realpathSync.native(root) !== root) throw new Error('noncanonical Claude lane transcript directory');
      walk(root, 0);
    } catch (error) { if (error.code !== 'ENOENT') discoveryFailure(81, error.message); }
    if (matches.length !== 1) discoveryFailure(matches.length ? 81 : 82, 'native transcript ' + (matches.length ? 'ambiguous' : 'missing') + ' for ' + session);
    return path.resolve(matches[0]);
  }
  if (mode === 'find') return { status: 0, stdout: find(...args) };
  if (!['verify','bootstrap','resume','work'].includes(mode)) throw new NativeRefusal(64);
  const priorPath = mode === 'bootstrap' ? args.shift() : null;
  const options = {};
  const allowed = new Set(['--cli','--role-id','--model','--effort','--session','--transcript','--offset','--prefix-end','--prefix-sha256']);
  for (let i = 0; i < args.length; i += 2) {
    if (!allowed.has(args[i]) || options[args[i]] !== undefined || !args[i+1] || args[i+1].startsWith('--')) throw new NativeRefusal(64);
    options[args[i]] = args[i+1];
  }
  if (mode === 'bootstrap') {
    const discovered = find(options['--cli'], options['--session']);
    if (priorPath && priorPath !== discovered) throw new NativeRefusal(83);
    options['--transcript'] = discovered;
  }
  if (!isLaneCli(options['--cli']) || ['--role-id','--model','--effort','--session','--transcript'].some(key => !options[key]) || !/^\d+$/.test(options['--offset'] || '0')) throw new NativeRefusal(64);
  const start = Number(options['--offset'] || 0);
  if (!Number.isSafeInteger(start)) throw new NativeRefusal(64);
  const cli = options['--cli'];
  const session = options['--session'];
  const report = {
    state:'refused', phase:mode === 'verify' ? 'bootstrap' : mode,
    requested:{role:options['--role-id'],model:options['--model'],effort:normalize(options['--effort'])},
    reported:{model:null,effort:null,nativeEffort:null},
    source:{provider:cli,session,path:path.resolve(options['--transcript']),start,end:start}, reason:''
  };
  function fail(reason) { throw new Error(reason); }
  function field(values, label, norm = value => value) {
    const supplied = values.filter(value => value !== undefined);
    if (!supplied.length) return null;
    if (supplied.some(value => typeof value !== 'string' || !value.trim())) fail('unknown native ' + label);
    if (new Set(supplied.map(norm)).size !== 1) fail('conflicting native ' + label);
    return supplied[0];
  }
  try {
    const bytes = cli === 'agy' || separateClaude(cli) ? readRegular(report.source.path, separateClaude(cli)) : fs.readFileSync(report.source.path);
    report.source.end = bytes.length;
    if (start > bytes.length || (start > 0 && bytes[start-1] !== 10)) fail('invalid native offset or truncation');
    if (bytes.length && bytes[bytes.length-1] !== 10) fail('truncated native record');
    if (cli === 'agy') {
      if (!isAgyConversation(session)) fail('invalid native conversation');
      const digest = bytes => createHash('sha256').update(bytes).digest('hex');
      const prefixEnd = options['--prefix-end'];
      if (prefixEnd !== undefined) {
        const end = Number(prefixEnd);
        if (!/^\d+$/.test(prefixEnd) || !Number.isSafeInteger(end) || end < start || end > bytes.length ||
            digest(bytes.subarray(0, end)) !== options['--prefix-sha256']) fail('native transcript prefix changed');
      } else if (start > 0) fail('native qualification prefix missing');
      report.source.prefixSha256 = digest(bytes);
    }
    let position = 0;
    const rows = new TextDecoder('utf-8', {fatal:true}).decode(bytes).split('\n').slice(0,-1).map(line => {
      const at = position; position += Buffer.byteLength(line) + 1;
      try {
        const row = JSON.parse(line);
        if (!row || typeof row !== 'object' || Array.isArray(row)) fail('malformed native record');
        return {at,row};
      } catch { if (at < start) return {at,row:{}}; fail('malformed native record'); }
    });
    if (cli === 'codex') {
      const ids = rows.filter(({row}) => row.type === 'session_meta').map(({row}) => row.payload?.id);
      if (!ids.length || ids.some(id => id !== session)) fail('native session identity mismatch or missing');
    }
    if (cli === 'agy') {
      const planner = rows.filter(({at,row}) => at >= start && row.type === 'PLANNER_RESPONSE' && row.source === 'MODEL');
      if (!planner.some(({row}) => row.status === 'DONE')) fail('missing fresh native agy model step');
      if (planner.some(({row}) => typeof row.model !== 'string' || !/^gemini-4-neon-(low|medium|high|xhigh)$/.test(row.model))) fail('missing or unsupported native agy model slug');
      const slug = field(planner.map(({row}) => row.model), 'agy model slug');
      report.reported.model = 'gemini-4-neon';
      report.reported.nativeEffort = slug.slice('gemini-4-neon-'.length);
      report.reported.effort = normalize(report.reported.nativeEffort);
    } else {
      let context;
      let assistant;
      for (const {at,row} of rows) {
        if (at < start) continue;
        if (cli === 'codex' && row.type === 'turn_context') context = row.payload;
        if (cli === 'claude' ? row.type === 'assistant' && !row.isSidechain && !row.parentToolUseID && !row.parent_tool_use_id : row.type === 'response_item' && row.payload?.type === 'message' && row.payload.role === 'assistant') {
          assistant = row; break;
        }
      }
      if (!assistant) fail('missing fresh parent assistant metadata');
      if (cli === 'claude' && assistant.sessionId !== session) fail('native session identity mismatch');
      if (cli === 'claude' && assistant.message?.role !== 'assistant') fail('missing native assistant role');
      const value = cli === 'claude' ? assistant : context;
      if (!value) fail('missing fresh turn context before first assistant');
      const settings = cli === 'codex' ? value.collaboration_mode?.settings : undefined;
      report.reported.model = field(cli === 'claude' ? [value.message?.model] : [value.model], 'model');
      report.reported.nativeEffort = field(cli === 'claude' ? [value.perTurnEffort,value.effort] : [value.effort,value.reasoning_effort], 'effort', normalize);
      report.reported.effort = normalize(report.reported.nativeEffort);
      if (cli === 'codex') {
        field([value.model,settings?.model], 'model');
        field([value.effort,value.reasoning_effort,settings?.reasoning_effort], 'effort', normalize);
      }
      if (!report.reported.model || !report.reported.effort) fail('missing native model or effort');
    }
    let members;
    try { members = fs.readFileSync(process.env.WRSP_ROLES_MEMBERS || path.join(process.env.HOME,'.agents/roles.members'),'utf8').split('\n').map(line => line.split('\t')); }
    catch { fail('role membership source missing or unreadable'); }
    const member = (model,effort) => members.some(([role,m,e,budget]) => role === report.requested.role && m === model && normalize(e) === effort && /^\d+$/.test(budget) && Number(budget) > 0);
    if (!member(report.reported.model,report.reported.effort)) fail('native pair is not a current positive-budget role member');
    if (!member(report.requested.model,report.requested.effort)) fail('requested pair is not a current positive-budget role member');
    if (report.requested.model !== report.reported.model || report.requested.effort !== report.reported.effort) fail('native pair differs from requested pair');
    report.state = 'accepted';
  } catch (error) { report.reason = error.message; }
  return { status: report.state === 'accepted' ? 0 : 81, stdout: JSON.stringify(report) };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const result = runNative(process.argv.slice(2));
  if (result.stdout !== undefined) console.log(result.stdout);
  if (result.stderr) console.error(result.stderr);
  process.exitCode = result.status;
}
