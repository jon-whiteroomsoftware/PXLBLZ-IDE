import { spawn } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { constants } from 'node:os';
import { setTimeout as pause } from 'node:timers/promises';

// Both sides reserve this status for an unconfirmed stop, never a provider exit.
const uncertain = 74;
const cancelled = 143;
const stopDeadlineMs = 5000;
const report = reason => process.stderr.write(`REFUSED: Claude lane cleanup unconfirmed (#575): ${reason}\n`);

function host(command, args) {
  const owner = process.ppid;
  if (owner <= 1) return Promise.resolve(cancelled);
  const prompt = readFileSync(0);
  const header = Buffer.alloc(4);
  header.writeUInt32BE(prompt.length);
  // sudo has no terminal and is outside the host attempt group. EOF on this
  // pipe is the stop request, including when the host relay itself dies.
  const child = spawn(command, args, { detached: true, stdio: ['pipe', 'inherit', 'inherit'] });
  return new Promise(resolve => {
    let deadline;
    let done = false;
    const stdin = child.stdin;
    const finish = status => {
      if (done) return;
      done = true;
      clearInterval(watch);
      clearTimeout(deadline);
      process.off('SIGTERM', stop);
      process.off('SIGINT', stop);
      resolve(status);
    };
    const failed = reason => {
      if (done) return;
      report(reason);
      stdin.destroy();
      child.unref();
      finish(uncertain);
    };
    const stop = () => {
      if (deadline) return;
      stdin.destroy();
      deadline = setTimeout(() => failed('lane reaper did not close'), stopDeadlineMs);
    };
    const watch = setInterval(() => { if (process.ppid !== owner) stop(); }, 100);
    process.on('SIGTERM', stop);
    process.on('SIGINT', stop);
    child.once('error', error => failed(error.code ?? error.message));
    child.once('close', (code, signal) => {
      if (signal) failed(`sudo exited on ${signal}`);
      else finish(code ?? uncertain);
    });
    stdin.on('error', stop);
    stdin.write(header);
    stdin.write(prompt);
  });
}

function lane(command, args) {
  return new Promise(resolve => {
    const input = process.stdin;
    let provider;
    let length;
    let stopping = false;
    let done = false;
    const finish = status => {
      if (done) return;
      done = true;
      input.off('readable', receive);
      input.destroy();
      process.off('SIGTERM', stop);
      process.off('SIGINT', stop);
      resolve(status);
    };
    const failed = reason => {
      report(reason);
      provider?.stdin.destroy();
      provider?.unref();
      finish(uncertain);
    };
    const groupExists = () => {
      try { process.kill(-provider.pid, 0); return true; }
      catch (error) {
        if (error.code === 'ESRCH') return false;
        throw error;
      }
    };
    const stop = () => {
      if (stopping || done) return;
      stopping = true;
      if (!provider) return finish(cancelled);
      if (provider.exitCode !== null || provider.signalCode !== null || !provider.pid) return;
      try { process.kill(-provider.pid, 'SIGKILL'); }
      catch (error) {
        if (error.code !== 'ESRCH') failed(`cannot stop lane process group (${error.code ?? error.message})`);
      }
    };
    const receive = () => {
      if (length === undefined) {
        const header = input.read(4);
        if (!header) return;
        length = header.readUInt32BE();
      }
      const prompt = length ? input.read(length) : Buffer.alloc(0);
      if (!prompt || done) return;
      if (prompt.length !== length) return finish(cancelled);
      input.off('readable', receive);
      input.resume();
      provider = spawn(command, args, { detached: true, stdio: ['pipe', 'inherit', 'inherit'] });
      provider.stdin.on('error', () => {}); // Claude may exit before reading the entire prompt.
      provider.stdin.end(prompt);
      provider.once('error', error => { console.error(String(error)); finish(66); });
      provider.once('close', async (code, signal) => {
        if (done) return;
        try {
          const deadline = performance.now() + 1000;
          while (groupExists()) {
            if (performance.now() >= deadline) return failed('lane process group remains live');
            await pause(20);
          }
        } catch (error) {
          return failed(`cannot verify lane process group (${error.code ?? error.message})`);
        }
        const status = code ?? (signal ? 128 + constants.signals[signal] : 70);
        finish(stopping ? cancelled : status === uncertain ? 70 : status);
      });
    };
    process.on('SIGTERM', stop);
    process.on('SIGINT', stop);
    input.on('readable', receive);
    input.once('end', stop);
    input.once('error', stop);
  });
}

const [mode, command, ...args] = process.argv.slice(2);
if (command && ['host', 'lane'].includes(mode)) {
  process.exitCode = await (mode === 'host' ? host : lane)(command, args);
} else {
  process.exitCode = 64;
}
