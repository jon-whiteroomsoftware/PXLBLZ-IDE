# Restore shim priority after the system login profile runs path_helper.
typeset -U path
path=("${ZDOTDIR:h}/lane-bin" "${path[@]}")
