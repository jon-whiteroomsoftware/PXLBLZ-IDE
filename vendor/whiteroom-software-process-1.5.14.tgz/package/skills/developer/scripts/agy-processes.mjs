import { spawnSync } from 'node:child_process'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'

const unavailable = () => new Error('agy owned process identity is unavailable')
const maxTracked = 1024

export function buildProcessIdentity(scratch) {
  const source = fileURLToPath(new URL('./agy-process-identity.c', import.meta.url))
  const identity = join(scratch, 'agy-process-identity')
  const compiled = spawnSync('/usr/bin/clang', ['-Wall', '-Wextra', '-Werror', '-O2', source, '-o', identity], {
    env: { PATH: '/usr/bin:/bin', TMPDIR: scratch },
    stdio: 'ignore',
    timeout: 10_000,
  })
  if (compiled.status !== 0) throw unavailable()
  return identity
}

export function createProcessTracker(identity, readRegistered) {
  const known = new Map()

  function read(args) {
    const result = spawnSync(identity, args.map(String), {
      env: {}, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'], timeout: 2000,
    })
    if (result.status !== 0) throw unavailable()
    return result.stdout.trimEnd().split('\n').filter(Boolean).map(line => {
      const match = /^(\d+) (\d+) (\d+) (\d+\.\d{6})$/.exec(line)
      if (!match) throw unavailable()
      const [, pid, parent, group, start] = match
      return { pid: Number(pid), parent: Number(parent), group: Number(group), start }
    })
  }

  const verify = (current, captured) => current?.start === captured.start
  function live(captured) {
    if (captured.length === 0) return []
    const expected = new Map(captured.map(row => [row.pid, row]))
    return read(['identity', ...expected.keys()]).filter(row => expected.has(row.pid) && verify(row, expected.get(row.pid)))
  }

  function register(pid, parent) {
    const [row] = read(['identity', pid])
    if (!row || row.parent !== parent) throw unavailable()
    known.set(pid, row)
    return row
  }

  function scan() {
    const current = live([...known.values()])
    const next = new Map(current.map(row => [row.pid, known.get(row.pid)]))
    if (readRegistered) {
      // Sandboxed fixtures supply spawn observations. Kernel identity still
      // supplies the current group and rules out dead or reused PIDs.
      const registered = readRegistered()
      if (registered.length > maxTracked) throw unavailable()
      const byPid = new Map(registered.map(row => [row.pid, row]))
      for (const row of live([...byPid.values()])) {
        if (!next.has(row.pid)) next.set(row.pid, { ...row, parent: byPid.get(row.pid).parent })
      }
      if (next.size > maxTracked) throw unavailable()
    } else {
      const pids = new Set(current.map(row => row.pid))
      // A formerly observed child may now be an orphan. Its enrolled start time
      // still authorizes walking only that process's own children.
      for (const root of current.filter(row => !pids.has(row.parent))) {
        for (const row of read(['tree', root.pid, root.start])) {
          if (!next.has(row.pid)) next.set(row.pid, row)
          if (next.size > maxTracked) throw unavailable()
        }
      }
    }
    known.clear()
    for (const row of next.values()) known.set(row.pid, row)
  }

  function signal(row, signalName) {
    if (live([row]).length === 0) return false
    try { return process.kill(row.pid, signalName) } catch (error) {
      if (error.code === 'ESRCH') return false
      throw error
    }
  }

  return { register, scan, live, signal, captured: () => [...known.values()] }
}
