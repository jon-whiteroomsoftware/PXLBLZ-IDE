#include <errno.h>
#include <libproc.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/proc.h>

enum { MAX_PROCESSES = 1024 };

// Only native identity fields leave this helper.
static int read_identity(pid_t pid, struct proc_bsdinfo *info) {
    errno = 0;
    int size = proc_pidinfo(pid, PROC_PIDTBSDINFO, 0, info, sizeof *info);
    if (size == 0 && errno == ESRCH) return 0;
    if (size != sizeof *info || info->pbi_pid != (unsigned int)pid) return -1;
    return info->pbi_status != SZOMB;
}

static void start_identity(const struct proc_bsdinfo *info, char *start, size_t size) {
    snprintf(start, size, "%llu.%06llu", info->pbi_start_tvsec, info->pbi_start_tvusec);
}

static int print_identity(const struct proc_bsdinfo *info) {
    char start[32];
    start_identity(info, start, sizeof start);
    return printf("%u %u %u %s\n", info->pbi_pid, info->pbi_ppid, info->pbi_pgid, start) < 0;
}

static pid_t parse_pid(const char *arg) {
    char *end;
    errno = 0;
    long value = strtol(arg, &end, 10);
    return errno || *end || value <= 0 || value > INT_MAX ? -1 : (pid_t)value;
}

static int read_tree(pid_t root, const char *expected_start) {
    struct proc_bsdinfo tree[MAX_PROCESSES];
    int result = read_identity(root, &tree[0]);
    if (result <= 0) return result < 0;
    char start[32];
    start_identity(&tree[0], start, sizeof start);
    if (strcmp(start, expected_start) != 0) return 0;

    int length = 1;
    for (int index = 0; index < length; index++) {
        const struct proc_bsdinfo *parent = &tree[index];
        pid_t children[MAX_PROCESSES];
        errno = 0;
        int count = proc_listchildpids(parent->pbi_pid, children, sizeof children);
        if (errno || count < 0 || count >= MAX_PROCESSES) return 1;
        struct proc_bsdinfo current;
        result = read_identity(parent->pbi_pid, &current);
        if (result < 0) return 1;
        if (result == 0 || current.pbi_start_tvsec != parent->pbi_start_tvsec ||
            current.pbi_start_tvusec != parent->pbi_start_tvusec) continue;
        for (int child = 0; child < count; child++) {
            result = read_identity(children[child], &current);
            if (result < 0) return 1;
            if (result == 0 || current.pbi_ppid != parent->pbi_pid) continue;
            if (length == MAX_PROCESSES) return 1;
            tree[length++] = current;
        }
    }

    for (int index = 0; index < length; index++) {
        if (print_identity(&tree[index])) return 1;
    }
    return 0;
}

int main(int argc, char **argv) {
    if (argc < 3) return 64;
    if (strcmp(argv[1], "tree") == 0 && argc == 4) {
        pid_t pid = parse_pid(argv[2]);
        return pid < 0 ? 64 : read_tree(pid, argv[3]);
    }
    if (strcmp(argv[1], "identity") != 0 || argc - 2 > MAX_PROCESSES) return 64;
    for (int i = 2; i < argc; i++) {
        pid_t pid = parse_pid(argv[i]);
        if (pid < 0) return 64;
        struct proc_bsdinfo info;
        int result = read_identity(pid, &info);
        if (result < 0 || (result != 0 && print_identity(&info))) return 1;
    }
    return 0;
}
