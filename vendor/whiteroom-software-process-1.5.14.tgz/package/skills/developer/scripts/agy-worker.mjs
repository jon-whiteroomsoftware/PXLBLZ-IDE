import { execFileSync, fork, spawn } from 'node:child_process'
import { createHash } from 'node:crypto'
import { closeSync, lstatSync, mkdirSync, mkdtempSync, openSync, readFileSync, readdirSync, readlinkSync, realpathSync, renameSync, rmSync, writeFileSync } from 'node:fs'
import { homedir, tmpdir, userInfo } from 'node:os'
import { basename, dirname, isAbsolute, join, resolve } from 'node:path'
import { setTimeout as delay } from 'node:timers/promises'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { buildProcessIdentity, createProcessTracker } from './agy-processes.mjs'
import { issueArtifactDirectory } from './retain-brief.mjs'

const self = fileURLToPath(import.meta.url)
const uuid = /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i
const waitForProcessRegistration = 'IFS= read -r ready <&3 && [ "$ready" = ready ] || exit 70\nexec 3<&-\nexec "$@"'

function entry(path) {
  try { return lstatSync(path) } catch (error) {
    if (error.code !== 'ENOENT') throw error
    return undefined
  }
}

function directory(path) {
  const found = entry(path)
  if (!found) return false
  if (!found.isDirectory()) throw new Error('unverified configuration directory ' + path)
  return true
}

function object(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
}

function refuseMcpServers(configDir) {
  const path = join(configDir, 'mcp_config.json')
  const found = entry(path)
  if (!found) return
  if (found.isFile()) {
    try {
      const config = JSON.parse(readFileSync(path, 'utf8').trim() || '{}')
      if (object(config) && Object.keys(config).every(key => key === 'mcpServers')) {
        const servers = config.mcpServers
        if (servers === undefined || (object(servers) && Object.values(servers).every(server => server?.disabled === true))) return
      }
    } catch { /* An unreadable or invalid registry cannot rule out server startup. */ }
  }
  throw new Error('read-only agy MCP servers are configured or cannot be ruled out in ' + path)
}

function refusePluginHooks(plugins, readOnly) {
  if (!directory(plugins)) return
  for (const plugin of readdirSync(plugins, { withFileTypes: true })) {
    const root = join(plugins, plugin.name)
    if (plugin.isSymbolicLink() || (plugin.isDirectory() && entry(join(root, 'hooks.json')))) {
      throw new Error('plugin hooks are present or cannot be ruled out in ' + root)
    }
    if (readOnly && plugin.isDirectory()) refuseMcpServers(root)
  }
}

function verifyUnaliasedGitMetadata(path) {
  const directories = [path]
  while (directories.length) {
    const parent = directories.pop()
    for (const name of readdirSync(parent)) {
      const child = join(parent, name)
      const stat = entry(child)
      if (!stat) continue // Another host Git process may remove a temporary lock.
      if (stat.isDirectory()) directories.push(child)
      else if (!stat.isFile() || stat.nlink !== 1) throw new Error('aliased Git metadata at ' + child)
    }
  }
}

function nativeWritableRoot(path) {
  if (!isAbsolute(path)) throw new Error('unverified agy writable directory')
  const parts = path.split('/').filter(part => part !== '' && part !== '.')
  let current = '/'
  let links = 0
  while (parts.length > 0) {
    const part = parts.shift()
    if (part === '..') {
      current = dirname(current)
      continue
    }
    const next = join(current, part)
    const stat = entry(next)
    if (!stat) {
      current = next
      continue
    }
    if (stat.isSymbolicLink()) {
      if (++links > 40) throw new Error('unverified agy writable directory')
      const target = readlinkSync(next)
      const targetParts = target.split('/').filter(segment => segment !== '' && segment !== '.')
      if (isAbsolute(target)) current = '/'
      parts.unshift(...targetParts)
      continue
    }
    current = realpathSync.native(next)
  }
  return current
}

function denialPaths(paths, resolvePath = nativeWritableRoot) {
  const denied = new Set()
  for (const path of paths) {
    denied.add(path)
    try {
      const canonical = resolvePath(path)
      if (canonical) denied.add(canonical)
    } catch (error) {
      if (!['EPERM', 'EACCES', 'ENOENT'].includes(error.code)) throw error
    }
  }
  return [...denied]
}

function verifyGitAnchor(common, writableRoots) {
  for (const path of writableRoots) {
    if (!isAbsolute(path)) throw new Error('unverified agy writable directory')
    for (const root of new Set([nativeWritableRoot(path), nativeWritableRoot(resolve(path))])) {
      if (common === root || common.startsWith(root === '/' ? root : root + '/') || root.startsWith(common + '/')) {
        throw new Error('agy linked Git metadata overlaps a model-writable directory')
      }
    }
  }
}

function implicitModelWritableRoots() {
  const homes = new Set([homedir(), userInfo().homedir])
  const roots = ['/tmp', '/var/tmp', tmpdir(),
    ...[...homes].flatMap(home => ['Library/Caches', '.cache', '.npm'].map(name => join(home, name))),
  ]
  if (process.env.XDG_CACHE_HOME) roots.push(process.env.XDG_CACHE_HOME)
  if (process.platform === 'darwin') {
    for (const name of ['DARWIN_USER_TEMP_DIR', 'DARWIN_USER_CACHE_DIR']) {
      const path = execFileSync('/usr/bin/getconf', [name], { encoding: 'utf8', timeout: 5000 }).trim()
      roots.push(path)
    }
  }
  return roots
}

function verifyNoNestedLinkedWorktrees(root) {
  const directories = [root]
  while (directories.length) {
    const path = directories.pop()
    if (path !== root) {
      const marker = join(path, '.git')
      const stat = entry(marker)
      if (stat?.isSymbolicLink()) throw new Error('agy developer launch cannot verify nested Git metadata at ' + path)
      if (stat?.isFile()) {
        const pointer = readFileSync(marker, 'utf8').replace(/[\r\n]+$/, '')
        if (pointer.startsWith('gitdir: ')) {
          const target = pointer.slice('gitdir: '.length)
          const gitDir = isAbsolute(target) ? target : path + '/' + target
          if (entry(gitDir + '/commondir')) throw new Error('agy developer launch refuses nested linked worktree at ' + path)
        }
      }
    }
    // Inspect physical descendants, including worktrees registered to a
    // different repository. Directory symlinks do not extend this boundary.
    for (const child of readdirSync(path, { withFileTypes: true })) {
      if (child.isDirectory()) directories.push(join(path, child.name))
    }
  }
}

function gitPermissions(cwd, root) {
  const output = execFileSync('git', ['rev-parse', '--path-format=absolute', '--git-dir', '--git-common-dir'], { cwd, encoding: 'utf8' })
  const paths = output.replace(/\n$/, '').split('\n')
  const invalid = () => new Error('unverified Git metadata for ' + root)
  if (paths.length !== 2 || paths.some(path => !path.startsWith('/'))) throw invalid()
  const [gitDir, common] = paths.map(path => realpathSync.native(path))
  const markerPath = join(root, '.git')
  const marker = entry(markerPath)
  if (marker?.isDirectory()) throw new Error('agy developer launch requires a linked worktree')
  if (!marker?.isFile() || marker.nlink !== 1 || basename(common) !== '.git' ||
    dirname(gitDir) !== join(common, 'worktrees')) throw invalid()
  const dotGit = realpathSync.native(markerPath)
  const backlink = join(gitDir, 'gitdir')
  const commonPointer = join(gitDir, 'commondir')
  try {
    if (!entry(backlink)?.isFile() || realpathSync.native(resolve(gitDir, readFileSync(backlink, 'utf8').trimEnd())) !== dotGit ||
      !entry(commonPointer)?.isFile() || realpathSync.native(resolve(gitDir, readFileSync(commonPointer, 'utf8').trimEnd())) !== common) {
      throw invalid()
    }
  } catch { throw invalid() }
  verifyGitAnchor(common, [root, ...implicitModelWritableRoots()])
  verifyNoNestedLinkedWorktrees(root)
  const metadata = [...new Set([common, gitDir, dotGit])]
  if (metadata.some(path => !permissionPath(path))) throw invalid()
  // A preexisting hard link can write the same inode under a permitted path.
  verifyUnaliasedGitMetadata(common)
  if (entry(join(common, 'objects', 'info', 'alternates'))) throw new Error('agy developer launch refuses external Git object stores')
  return { metadata, common }
}

function permissionPath(path) {
  return isAbsolute(path) && path !== '/' && !/[\x00-\x1f\\()*?\[\]]/.test(path)
}

function developerReadPaths(home) {
  const config = process.env.XDG_CONFIG_HOME || join(home, '.config')
  const paths = [join(home, '.agents'), join(home, '.local/bin'), join(home, '.local/share/wrsp/host'), join(config, 'wrsp')]
  return paths.filter(isAbsolute).filter(path => entry(path)).map(path => realpathSync(path))
}

function credentialDenials(home, laneKeychainDirectory) {
  const homes = [...new Set([home, userInfo().homedir])]
  const ghDirs = homes.map(path => join(path, '.config/gh'))
  if (process.env.XDG_CONFIG_HOME) ghDirs.push(join(process.env.XDG_CONFIG_HOME, 'gh'))
  if (process.env.GH_CONFIG_DIR) ghDirs.push(process.env.GH_CONFIG_DIR)
  const candidates = homes.flatMap(path => [
    join(path, 'Library/Keychains'), laneKeychainDirectory(path),
    ...['login.keychain', 'login.keychain-db'].map(name => join(path, 'Library/Keychains', name)),
    join(path, '.git-credentials'), join(path, '.config/git/credentials'), join(path, '.netrc'),
  ])
  candidates.push(...ghDirs.flatMap(dir => [dir, ...['config.yml', 'hosts.yml', 'state.yml'].map(name => join(dir, name))]))
  if (process.env.XDG_CONFIG_HOME) candidates.push(join(process.env.XDG_CONFIG_HOME, 'git/credentials'))
  if (candidates.some(path => !permissionPath(path))) throw new Error('invalid agy credential protection path')
  return denialPaths(candidates, path => {
    if (!entry(path)) return undefined
    const canonical = realpathSync.native(path)
    const found = entry(canonical)
    if (found?.isFile() && found.nlink !== 1) throw new Error('agy credential protection refuses hard-linked files')
    return canonical
  })
}

function laneModelEnvironment(developerEnv) {
  const env = { ...process.env }
  delete env.WRSP_LANE_DISPATCH
  delete env.WRSP_AGY_DISPATCH_PROTECTED_WRITES
  if (!developerEnv) return env
  const suppressed = /^(?:GH_|GITHUB_|GIT_CONFIG_|WRSP_AGY_GITHUB$|WRSP_LANE_COMMIT$|GIT_ASKPASS$|SSH_ASKPASS$|SSH_AUTH_SOCK$|GIT_SSH(?:_COMMAND)?$|NODE_USE_ENV_PROXY$|(?:HTTP|HTTPS|ALL|NO)_PROXY$)/i
  return { ...Object.fromEntries(Object.entries(env).filter(([name]) => !suppressed.test(name))), ...developerEnv }
}

function stateSwapPath(path) {
  return path + '.tmp'
}

function developerLogPaths(log) {
  const sidecars = ['.progress', '.started', '.live', '.pid', '.exit', '.agy.pid', '.agy.pgid',
    '.agy.conversation', '.agy.result.json'].map(suffix => log + suffix)
  const audits = ['.agy-hooks.jsonl', '.agy-commit.jsonl', '.lane-dispatch.jsonl'].map(suffix => log + suffix)
  // Bootstrap needs the same literal denials for the queued work log before
  // its worker exists and before either work-turn audit opens.
  return [log, ...sidecars, ...sidecars.map(stateSwapPath), ...audits]
}

function configuredPermissions(home) {
  const gemini = join(home, '.gemini')
  const config = join(gemini, 'antigravity-cli')
  if (!directory(gemini) || !directory(config)) return {}
  const settings = join(config, 'settings.json')
  const found = entry(settings)
  if (!found) return {}
  const invalid = () => new Error('unreadable or invalid agy permissions settings')
  if (!found.isFile()) throw invalid()
  let value
  try { value = JSON.parse(readFileSync(settings, 'utf8')) } catch { throw invalid() }
  if (!object(value)) throw invalid()
  const permissions = value.permissions
  if (permissions === undefined) return {}
  if (!object(permissions) || Object.entries(permissions).some(([key, rules]) =>
    !['allow', 'ask', 'deny'].includes(key) || !Array.isArray(rules) || rules.some(rule => typeof rule !== 'string'))) throw invalid()
  return permissions
}

async function preflight(worktree, cache) {
  const lane = process.env.WRSP_AGY_LANE
  const research = lane === 'researcher'
  const readOnly = research || lane === 'reviewer'
  if (!(readOnly ? process.env.WRSP_ROLE === lane : lane === '1' && process.env.WRSP_ROLE === 'developer')) {
    throw new Error('invalid agy lane role marker')
  }
  const dispatchGateDirectory = readOnly ? process.env.WRSP_AGY_DISPATCH_GATE_DIRECTORY : undefined
  if (dispatchGateDirectory !== undefined) {
    const common = dirname(dispatchGateDirectory)
    if (!permissionPath(dispatchGateDirectory) || dispatchGateDirectory !== join(common, 'wrsp')
      || !entry(common)?.isDirectory() || realpathSync.native(common) !== common) {
      throw new Error('invalid agy dispatch gate directory')
    }
  }
  const cwd = realpathSync.native(worktree)
  const gitRoot = realpathSync.native(execFileSync('git', ['rev-parse', '--show-toplevel'], { cwd, encoding: 'utf8' }).trim())
  for (let path = cwd; ; path = dirname(path)) {
    const config = join(path, '.agents')
    if (directory(config)) {
      for (const name of ['hooks.json', 'plugins.json']) {
        const target = join(config, name)
        if (entry(target)) throw new Error('workspace hook or plugin registry exists at ' + target)
      }
      if (readOnly) refuseMcpServers(config)
      refusePluginHooks(join(config, 'plugins'), readOnly)
    }
    if (path === gitRoot) break
    if (path === dirname(path)) throw new Error('could not establish the worktree root')
  }
  const home = homedir()
  const userConfig = join(home, '.gemini/config')
  if (readOnly) refuseMcpServers(userConfig)
  refusePluginHooks(join(userConfig, 'plugins'), readOnly)
  const installed = join(home, '.agents/hooks')
  const helper = await import(pathToFileURL(join(installed, 'session-role.mjs')).href)
  if (typeof helper.isAgyHookRegistration !== 'function') throw new Error('installed agy role gate is unavailable')
  const configPath = helper.agyHooksPath(home)
  let registry
  try { registry = JSON.parse(readFileSync(configPath, 'utf8')) } catch {
    throw new Error('unreadable or invalid agy hook registry at ' + configPath)
  }
  if (!registry || !helper.isAgyHookRegistration(registry[helper.agyHookName])) {
    throw new Error('missing or disabled agy hook in ' + configPath)
  }
  if (readOnly && Object.entries(registry).some(([name, hook]) => name !== helper.agyHookName && hook?.enabled !== false)) {
    throw new Error('additional active agy hooks are configured in ' + configPath)
  }
  const env = { ...process.env }
  delete env.WRSP_AGY_HOOK_LOG
  delete env.WRSP_AGY_WRITE_ROOTS
  let protectedCredentials = []
  let github
  let git
  if (!readOnly) {
    delete env.WRSP_AGY_GITHUB
    const scripts = join(home, '.agents/skills/developer/scripts')
    const { laneKeychain, laneKeychainDirectory, checkLaneKeychain } = await import(pathToFileURL(join(scripts, 'lane-keychain.mjs')).href)
    const { laneOrigin, startLaneGithub, nativeLaneTransport, laneGitEnvironment } = await import(pathToFileURL(join(scripts, 'lane-github.mjs')).href)
    const issue = process.env.WRSP_AGY_ISSUE
    if (cache && !/^[1-9][0-9]{0,9}$/.test(issue)) throw new Error('agy developer dispatch requires an issue number')
    git = gitPermissions(cwd, gitRoot)
    env.WRSP_AGY_GIT_METADATA = JSON.stringify(git.metadata)
    const { repository, origin } = laneOrigin(git.common)
    const config = laneKeychain(home, repository)
    checkLaneKeychain(config)
    const bin = realpathSync(join(scripts, 'lane-bin'))
    if (['gh', 'git-remote-wrsp-lane'].some(name => !entry(join(bin, name))?.isFile())) throw new Error('installed agy GitHub shims are unavailable')
    protectedCredentials = credentialDenials(home, laneKeychainDirectory)
    env.WRSP_AGY_CREDENTIAL_DENIES = JSON.stringify(protectedCredentials)
    const parent = dirname(realpathSync(laneKeychainDirectory(home)))
    github = { issue, bin, origin, laneGitEnvironment, parent, start(resume) {
      const recordDeclaration = uuid.test(resume)
        ? () => helper.recordAgyDeveloperDeclaration(resume, Number(issue), gitRoot)
        : undefined
      return startLaneGithub({ repository, issue, origin }, nativeLaneTransport(config), parent, recordDeclaration)
    } }
  }
  const probes = readOnly ? [
    ['read_file', 'allow', { Path: 'AGENTS.md' }],
    ...(dispatchGateDirectory === undefined ? [] : [
      ['read_file', 'deny', { Path: join(dispatchGateDirectory, 'wrsp-preflight-probe') }],
      ['read_file', 'deny', { Path: join(home, '.git-credentials') }],
      ['grep_search', 'deny', { SearchPath: dispatchGateDirectory, Query: 'fixture' }],
      ...(!research ? [
        ['list_dir', 'deny', { DirectoryPath: cwd }],
        ['find_by_name', 'deny', { SearchDirectory: cwd, Pattern: 'fixture' }],
        ['grep_search', 'deny', { SearchPath: cwd, Query: 'fixture' }],
      ] : []),
    ]),
    ['run_command', 'deny', { CommandLine: 'printf scratch' }],
    ['write_file', 'deny', { Path: 'scratch.txt' }],
    ['edit_file', 'deny', { Path: 'scratch.txt' }],
    ['read_file', 'deny', { Path: 'AGENTS.md', BypassSandbox: true }],
    ...(!research ? [
      ['read_url_content', 'deny', { Url: 'https://example.invalid' }],
      ['finish', 'allow', {}],
    ] : []),
  ] : [
    ['run_command', 'allow', { CommandLine: 'printf scratch' }],
    ['run_command', 'deny', { CommandLine: 'printf scratch', BypassSandbox: true }],
    ['run_command', 'allow', { CommandLine: 'git status' }],
    ['run_command', 'deny', { CommandLine: 'git commit -m fixture' }],
    ['edit_file', 'deny', { Path: join(gitRoot, '.git') }],
    ['write_file', 'deny', { Path: '/' }],
    ['read_file', 'deny', { Path: join(home, '.config/gh/hosts.yml') }],
    ['grep_search', 'deny', { SearchPath: join(home, 'Library/Keychains'), Query: 'fixture' }],
  ]
  for (const [name, decision, args] of [...probes, ['wrsp_unknown_tool', 'deny', {}]]) {
    const payload = { cwd, hookEventName: 'PreToolUse', toolCall: { name, args } }
    const output = execFileSync('/bin/sh', [join(installed, 'agy-role-gate.sh')], {
      input: JSON.stringify(payload), cwd, env, timeout: 6000, stdio: ['pipe', 'pipe', 'pipe'],
    })
    const verdict = JSON.parse(output.toString('utf8'))
    if (verdict.decision !== decision || typeof verdict.reason !== 'string') {
      throw new Error('installed agy role gate is unavailable for ' + process.env.WRSP_ROLE)
    }
  }
  const permissions = configuredPermissions(home)
  if (readOnly) {
    const dispatchReads = dispatchGateDirectory !== undefined && !research
      ? [dispatchGateDirectory, join(dispatchGateDirectory, 'review-approvals'), join(dispatchGateDirectory, 'test-evidence')]
        .flatMap(path => entry(path) ? [path, realpathSync(path)] : [path])
      : []
    if (dispatchReads.some(path => !permissionPath(path))) throw new Error('invalid agy dispatch read protection path')
    const settings = { permissions: {
      ...permissions,
      allow: (permissions.allow ?? []).filter(rule => rule.startsWith('read_file(') || (research && rule.startsWith('read_url('))),
      deny: [...new Set([...(permissions.deny ?? []), 'write_file(*)', 'command(*)', 'unsandboxed(*)', 'execute_url(*)', 'mcp(*)',
        ...dispatchReads.flatMap(path => [`read_file(${path})`, `read_file(${path}/*)`]),
        ...(!research ? ['read_url(*)'] : [])])],
    } }
    return { settings }
  }
  if (!cache) return {}
  const artifacts = await issueArtifactDirectory({ worktree: gitRoot, issue: github.issue })
  const nodeBin = dirname(realpathSync(process.execPath))
  const reads = [git.common, ...developerReadPaths(home), dirname(nodeBin)]
  const writes = [cache, ...(artifacts ? [artifacts] : [])]
  const writeRoots = [gitRoot, ...writes]
  verifyGitAnchor(git.common, writes)
  const homes = [home, userInfo().homedir]
  const providerSettings = denialPaths(homes.map(dir => join(dir, '.gemini')))
  const cloudSettings = denialPaths(homes.map(dir => join(dir, '.config/gcloud')))
  const protectedReads = [...protectedCredentials, ...providerSettings, ...cloudSettings]
  const protectedWrites = [...protectedCredentials, ...providerSettings]
  if ([...reads, ...writeRoots, ...protectedReads, ...protectedWrites].some(path => !permissionPath(path))) {
    throw new Error('invalid agy developer permission path')
  }
  return {
    settings: { permissions: {
      ...permissions,
      allow: [...new Set([...reads.map(path => `read_file(${path})`), ...writeRoots.map(path => `write_file(${path})`), 'read_url(*)'])],
      deny: [...new Set([...(permissions.deny ?? []), 'unsandboxed(*)', ...protectedReads.map(path => `read_file(${path})`),
        ...protectedWrites.map(path => `write_file(${path})`),
        ...git.metadata.map(path => `write_file(${path})`)])],
    } },
    developerEnv: { npm_config_cache: cache,
      WRSP_AGY_CREDENTIAL_DENIES: env.WRSP_AGY_CREDENTIAL_DENIES, WRSP_AGY_GIT_METADATA: env.WRSP_AGY_GIT_METADATA,
      PATH: `${github.bin}:${nodeBin}:${process.env.PATH ?? ''}` },
    github, git, protectedReads, writeRoots,
  }
}

function signalGroup(pid, signal) {
  try { process.kill(-pid, signal) } catch (error) { if (error.code !== 'ESRCH') throw error }
}

async function modelGroup(cwd, prompt, model, seconds, resume, raw, schema, cache, identity, log, handle, turn, owner, laneLog, workInput) {
  const dispatch = Promise.withResolvers()
  const tracked = createProcessTracker(identity)
  const qualifiedWork = Boolean(handle && resume)
  const commitTracked = qualifiedWork ? createProcessTracker(identity) : undefined
  let modelProcess
  let provider
  let inspectError
  let cancelled = false
  let commit
  let closingCommit
  let dispatchTurn
  let openingDispatch
  function scan() {
    try { tracked.scan(); commitTracked?.scan() } catch (error) { inspectError = error }
  }
  function stopTasks(tracker = tracked) {
    const detached = tracker.live(tracker.captured()).filter(row => row.group !== process.pid)
    const stoppedGroups = new Set()
    for (const row of detached) {
      if (row.pid !== row.group || tracker.live([row])[0]?.group !== row.pid) continue
      signalGroup(row.pid, 'SIGKILL')
      stoppedGroups.add(row.pid)
    }
    for (const row of detached.reverse()) {
      if (!stoppedGroups.has(row.group)) tracker.signal(row, 'SIGKILL')
    }
  }
  function closeCommit() {
    if (commit && !closingCommit) {
      scan()
      closingCommit = commit.close().catch(error => { inspectError = error })
    }
    return closingCommit
  }
  function closeTurns() {
    const closingDispatch = dispatchTurn
      ? dispatchTurn.close()
      : openingDispatch?.then(channel => channel.close(), () => {})
    return Promise.all([closeCommit(), closingDispatch?.catch(error => { inspectError = error })])
  }
  function cancel() {
    cancelled = true
    dispatch.resolve(false)
    void closeTurns()
    if (!provider) return
    // Keep the provider alive while reading ancestry, then stop the exact
    // observed background groups before the provider can orphan them.
    try { tracked.signal(provider, 'SIGSTOP') } catch (error) { inspectError = error }
    scan()
    try { stopTasks() } catch (error) { inspectError = error }
    try { tracked.signal(provider, 'SIGKILL') } catch (error) { inspectError = error }
  }
  process.on('message', message => {
    if (message === 'dispatch') dispatch.resolve(true)
    if (message === 'cancel') cancel()
  })
  process.on('disconnect', () => {
    cancel()
    void closeTurns().then(() => signalGroup(process.pid, 'SIGKILL'))
  })
  const { settings, developerEnv, github, git, protectedReads, writeRoots } = await preflight(cwd, cache)
  const protectedTurnPaths = writeRoots ? [raw, prompt, ...developerLogPaths(log), join(writeRoots[0], '.husky/_')] : []
  if (writeRoots && handle) {
    protectedTurnPaths.push(handle, stateSwapPath(handle), handle + '.lock', workInput, ...developerLogPaths(laneLog))
  }
  if (!process.connected) return
  // The supervisor may receive cancellation before this process starts
  // listening. Ask for permission after preflight so it can replay that state.
  process.send({ ready: true })
  const authorized = await dispatch.promise
  if (!process.connected) return
  if (!authorized || cancelled) {
    process.send({ exit: { code: null, signal: null }, known: [], cleanupUncertain: false })
    return
  }
  const out = openSync(join(raw, 'stdout'), 'wx', 0o600)
  const err = openSync(join(raw, 'stderr'), 'wx', 0o600)
  let input = 'ignore'
  let broker
  try {
    if (schema) {
      const request = join(raw, 'input')
      const message = { event: 'user', message: { role: 'user', content: [{ type: 'text', text: readFileSync(prompt, 'utf8') }] } }
      writeFileSync(request, JSON.stringify(message) + '\n', { flag: 'wx', mode: 0o600 })
      input = openSync(request, 'r')
    }
    broker = github?.start(resume)
    if (broker) {
      if (![broker.inbox, broker.outbox].every(permissionPath)) throw new Error('invalid agy GitHub channel path')
      verifyGitAnchor(git.common, [broker.inbox])
      settings.permissions.allow.push(`write_file(${broker.inbox})`, `read_file(${broker.outbox})`)
      protectedTurnPaths.push(broker.outbox)
    }
    const gitEnvironment = broker ? { ...github.laneGitEnvironment(github.origin), GIT_OPTIONAL_LOCKS: '0' } : {}
    const laneEnv = broker ? { WRSP_AGY_GITHUB: broker.path, ...gitEnvironment } : {}
    if (qualifiedWork) {
      const selectedModel = /^(.+)-(?:low|medium|high|xhigh)$/.exec(model)?.[1]
      if (!github || !uuid.test(resume) || !git || !commitTracked || !selectedModel) throw new Error('invalid commit turn')
      const scripts = dirname(github.bin)
      const { bindCommitRepository, readBoundedCommitFile, runSandboxedCommit } = await import(pathToFileURL(join(scripts, 'sandboxed-commit.mjs')).href)
      const { startCommitTurn } = await import(pathToFileURL(join(scripts, 'sandboxed-commit-turn.mjs')).href)
      const { runSandboxedStage } = await import(pathToFileURL(join(scripts, 'sandboxed-stage.mjs')).href)
      const { commonDir } = JSON.parse(readBoundedCommitFile(handle, 1024 * 1024).content.toString('utf8'))
      if (commonDir !== undefined && commonDir !== git.common) throw new Error('unverified agy dispatch Git anchor')
      const dispatchHost = commonDir === undefined
        ? undefined
        : await import(pathToFileURL(join(scripts, 'lane-dispatch-host.mjs')).href)
      if (cancelled || !process.connected) {
        if (process.connected) process.send({ exit: { code: null, signal: null }, known: [], cleanupUncertain: false })
        return
      }
      const worktree = realpathSync.native(cwd)
      const repository = bindCommitRepository(worktree, git.common)
      const executable = join(github.bin, 'wrsp-sandboxed-commit')
      if (!entry(executable)?.isFile()) throw new Error('installed fixed commit shim is unavailable')
      const binding = {
        handle, turn: Number(turn), log, owner: Number(owner), thread: resume, issue: Number(github.issue),
        worktree, parent: github.parent,
      }
      const processes = {
        register(pid) { commitTracked.register(pid, process.pid) },
        reap() {
          try {
            commitTracked.scan()
            stopTasks(commitTracked)
          } catch (error) {
            inspectError = error
            throw error
          }
        },
      }
      commit = startCommitTurn({
        ...binding, selectedModel, gitEnvironment, seconds: Number(seconds),
        execute: (message, signal, verifyTurn, attribution) => runSandboxedCommit(repository, message, {
          operatorIdentity: true, protectedPaths: protectedReads, signal, verifyTurn, attribution, processes,
        }),
        stage: (paths, signal, verifyTurn) => runSandboxedStage(repository, paths, {
          protectedPaths: protectedReads, signal, verifyTurn, processes,
        }),
      })
      verifyGitAnchor(git.common, [commit.inbox])
      if (!permissionPath(commit.inbox)) throw new Error('invalid commit turn permission path')
      settings.permissions.allow.push(`write_file(${commit.inbox})`, `read_file(${commit.outbox})`, `read_file(${commit.descriptor})`)
      protectedTurnPaths.push(commit.outbox, commit.descriptor, commit.auditPath)
      laneEnv.WRSP_LANE_COMMIT = commit.path
      if (dispatchHost) {
        if (!entry(join(github.bin, 'wrsp-lane-dispatch'))?.isFile()) throw new Error('installed lane dispatch shim is unavailable')
        const parent = join(github.parent, 'lane-dispatch-turns')
        mkdirSync(parent, { recursive: true, mode: 0o700 })
        const state = lstatSync(parent)
        if (!state.isDirectory() || (state.mode & 0o077) !== 0) throw new Error('agy dispatch requires a private channel parent')
        openingDispatch = dispatchHost.startDispatchHost({
          ...binding, family: 'agy', parent, commonDir, gitDir: repository.gitDirectory,
        })
        dispatchTurn = await openingDispatch
        if (cancelled || !process.connected) {
          await closeTurns()
          if (process.connected) process.send({ exit: { code: null, signal: null }, known: [], cleanupUncertain: Boolean(inspectError) })
          return
        }
        const { inbox, outbox, hostLogDirectory, auditPath } = dispatchTurn
        verifyGitAnchor(git.common, [inbox])
        if (!permissionPath(inbox)) throw new Error('invalid agy dispatch turn permission path')
        settings.permissions.allow.push(`write_file(${inbox})`, `read_file(${outbox})`, `read_file(${hostLogDirectory})`)
        protectedTurnPaths.push(outbox, hostLogDirectory, auditPath, join(commonDir, 'wrsp'))
        writeRoots.push(inbox)
        laneEnv.WRSP_LANE_DISPATCH = dispatchTurn.path
      }
    }
    if (writeRoots) {
      if (!protectedTurnPaths.every(permissionPath)) throw new Error('invalid agy turn permission path')
      const protectedWrites = denialPaths(protectedTurnPaths)
      if (!protectedWrites.every(permissionPath)) throw new Error('invalid native agy turn permission path')
      settings.permissions.deny.push(...protectedWrites.map(path => `write_file(${path})`))
      laneEnv.WRSP_AGY_DISPATCH_PROTECTED_WRITES = JSON.stringify(protectedWrites)
      laneEnv.WRSP_AGY_WRITE_ROOTS = JSON.stringify(writeRoots)
    }
    const argv = ['-p', schema ? '' : readFileSync(prompt, 'utf8'), '--model', model, '--output-format', schema ? 'stream-json' : 'json',
      '--print-timeout', seconds + 's', '--disable-slash-commands', '--sandbox', '--settings', JSON.stringify(settings),
      ...(schema ? ['--input-format', 'stream-json', '--json-schema', schema] : []),
      ...(resume ? ['--conversation', resume] : [])]
    // Use an extra pipe to hold the PID before exec. A fast provider can finish
    // before a post-exec probe sees it. The provider keeps its original stdin.
    modelProcess = spawn('/bin/sh', ['-c', waitForProcessRegistration, 'agy-provider', 'agy', ...argv], {
      cwd, env: { ...laneModelEnvironment(developerEnv), ...laneEnv }, stdio: [input, out, err, 'pipe'],
    })
    const ended = new Promise((resolve, reject) => {
      modelProcess.once('exit', (code, signal) => resolve({ code, signal }))
      modelProcess.once('error', reject)
    })
    const registration = modelProcess.stdio[3]
    try {
      if (modelProcess.pid) provider = tracked.register(modelProcess.pid, process.pid)
    } finally {
      registration.on('error', error => { inspectError = error })
      registration.end(provider ? 'ready\n' : undefined)
    }
    process.send({ pid: modelProcess.pid })
    scan()
    const sampler = setInterval(scan, 250)
    let exit
    try {
      exit = await ended
      await closeTurns()
    } finally { clearInterval(sampler) }
    scan()
    try { stopTasks() } catch (error) { inspectError = error }
    const known = [...tracked.captured(), ...(commitTracked?.captured() ?? [])]
    if (process.connected) process.send({ exit, known, cleanupUncertain: Boolean(inspectError) })
    // The connected IPC channel keeps this exact group leader alive until
    // the supervisor has killed the remaining inherited process group.
  } finally {
    await closeTurns()
    broker?.close()
    if (typeof input === 'number') closeSync(input)
    closeSync(out)
    closeSync(err)
  }
}

function transcript(id) {
  const path = join(homedir(), '.gemini/antigravity-cli/brain', id, '.system_generated/logs/transcript_full.jsonl')
  return readFileSync(path, 'utf8').split('\n').filter(Boolean).map(line => JSON.parse(line))
}

class StatePublicationError extends Error {}

function publishState(path, data) {
  const temp = stateSwapPath(path)
  let owned = false
  try {
    const fd = openSync(temp, 'wx', 0o600)
    owned = true
    try { writeFileSync(fd, data) } finally { closeSync(fd) }
    renameSync(temp, path)
  } catch (error) {
    if (owned) {
      try { rmSync(temp, { force: true }) } catch { /* Retain the publication failure. */ }
    }
    throw new StatePublicationError(`cannot publish agy state ${JSON.stringify(path)} via ${JSON.stringify(temp)} (${error.code})`)
  }
}

function failedStep(step) {
  if (step.status === 'ERROR' || (typeof step.error === 'string' && step.error.trim() !== '')) return true
  if (step.type !== 'GENERIC' || step.source !== 'MODEL' || typeof step.content !== 'string') return false
  // agy 1.5.14 marks a completed command step DONE even for a nonzero exit.
  // Read the generated header before command output, which is arbitrary text.
  const exit = /^(?:(?:Created At|Completed At):[^\n]+\n)+Command exited with code (-?\d+)\.(?:\r?\n|$)/.exec(step.content)
  return exit !== null && Number(exit[1]) !== 0
}

function readHookAudit(hookLog) {
  return readFileSync(hookLog, 'utf8').split('\n').filter(Boolean).map(line => JSON.parse(line))
}

function reviewerToolRefusal(audit) {
  const deniedEvents = audit.filter(event => event.decision === 'deny').map(event => ({
    type: 'agy-tool',
    conversationId: event.conversationId ?? null,
    stepIdx: event.stepIdx ?? null,
    name: typeof event.name === 'string' && /^[a-z][a-z0-9_.-]{0,99}$/i.test(event.name) ? event.name : null,
    decision: 'deny',
    reason: event.reason ?? '',
    category: event.category,
    argumentSummary: event.argumentSummary,
  }))
  if (deniedEvents.length === 0) return undefined
  const { name, argumentSummary } = deniedEvents[0]
  const reason = 'tool refused: ' + (name ?? 'unknown tool') + ' ' + (argumentSummary ?? '[arguments unavailable]')
  return { reason, deniedEvents }
}

function indexedReadArgs(calls, auditEvent) {
  const digest = auditEvent?.readRequestSha256
  // The pre-tool event and result share a trajectory index. A complete
  // single-call batch also proves the association without an indexed audit.
  if (digest === undefined) return calls.length === 1 ? calls[0].args : undefined
  const matches = calls.filter(({ args: { Path, StartLine, EndLine } }) => {
    if ([StartLine, EndLine].some(line => line !== undefined && (!Number.isSafeInteger(line) || line < 1))) return false
    return digest === createHash('sha256').update(JSON.stringify([Path, StartLine ?? null, EndLine ?? null])).digest('hex')
  })
  return matches.length === 1 ? matches[0].args : undefined
}

function reviewerReadEvidence(steps, auditedTools, duplicateSteps) {
  const batchSteps = new Set()
  const boundReads = new Map()
  const successfulReads = new Map()
  for (const [index, planner] of steps.entries()) {
    const calls = planner.tool_calls
    if (planner.type !== 'PLANNER_RESPONSE' || planner.source !== 'MODEL' || planner.status !== 'DONE'
      || duplicateSteps.has(planner.step_index) || !Array.isArray(calls) || calls.length === 0
      || !calls.every(call => call?.name === 'read_file' && typeof call.args?.Path === 'string' && call.args.Path.trim())) continue
    const results = steps.slice(index + 1, index + 1 + calls.length)
    // All results must belong to this delivery of a read-only batch.
    if (results.length !== calls.length || !results.every((result, offset) => {
      const step = result.step_index
      return step === planner.step_index + offset + 1 && result.type === 'GENERIC' && result.source === 'MODEL'
        && !duplicateSteps.has(step) && (!auditedTools.has(step) || auditedTools.get(step)?.name === 'read_file')
    })) continue
    const resultByArgs = new Map()
    for (const result of results) {
      batchSteps.add(result.step_index)
      const args = indexedReadArgs(calls, auditedTools.get(result.step_index))
      if (args) resultByArgs.set(args, resultByArgs.has(args) ? null : result)
    }
    // A planner call cannot establish which result it produced if two
    // trajectory indexes claim the same request.
    for (const [args, result] of resultByArgs) {
      if (result === null) continue
      boundReads.set(result.step_index, args)
      if (result.status !== 'DONE' || failedStep(result) || typeof result.content !== 'string') continue
      // File contents may contain the same text. Use only the provider header.
      const header = /^(?:(?:Created At|Completed At):[^\n]+\n)+Showing lines ([1-9]\d*)-([1-9]\d*) of ([1-9]\d*)(?:\r?\n|$)/.exec(result.content)
      if (!header) continue
      const [start, end, total] = header.slice(1).map(Number)
      if (![start, end, total].every(Number.isSafeInteger) || start > end || end > total) continue
      if (args.StartLine === start && Number.isSafeInteger(args.EndLine) && Math.min(args.EndLine, total) === end) {
        successfulReads.set(args.Path, planner.step_index)
      }
    }
  }
  return { batchSteps, boundReads, successfulReads }
}

function recoveredReadRange(step, { boundReads, successfulReads }) {
  const args = boundReads.get(step.step_index)
  if (!args || typeof step.error !== 'string') return false
  const range = /^invalid line range: StartLine ([1-9]\d*) is greater than EndLine ([1-9]\d*)$/.exec(step.error)
  if (!range || range[0] !== step.error) return false
  const [start, end] = range.slice(1).map(Number)
  if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start <= end) return false
  return args.StartLine === start && args.EndLine === end && successfulReads.get(args.Path) > step.step_index
}

function completion(raw, resume, previousStep, hookLog, provider, reviewerModel) {
  const stdout = readFileSync(join(raw, 'stdout'), 'utf8')
  const stderr = readFileSync(join(raw, 'stderr'), 'utf8')
  if (/Authentication required/i.test(stderr)) throw new Error('authentication required')
  let result
  let init
  try {
    if (reviewerModel) {
      const events = stdout.trim().split('\n').map(line => JSON.parse(line))
      const starts = events.filter(event => event.event === 'init')
      const results = events.filter(event => event.event === 'result')
      if (starts.length !== 1 || results.length !== 1 || events.at(-1) !== results[0]) throw new Error('expected one turn')
      init = starts[0]
      result = results[0].result
    } else {
      result = JSON.parse(stdout)
    }
  } catch { throw new Error('invalid agy completion JSON') }
  if (!result || typeof result !== 'object' || Array.isArray(result)) throw new Error('invalid agy completion JSON')
  const id = result.conversation_id
  if (typeof id !== 'string' || !uuid.test(id) || (resume && id !== resume)) {
    throw new Error('invalid agy conversation identity')
  }
  if (init && init.conversation_id !== id) throw new Error('invalid agy conversation identity')
  const timedOut = result.finished_reason === 'print_timeout' && (reviewerModel || (provider.code === 3 && result.status === 'ERROR'))
  if (timedOut || result.status !== 'SUCCESS' || provider.code !== 0) {
    const refusal = reviewerModel ? reviewerToolRefusal(readHookAudit(hookLog)) : undefined
    if (refusal) return { id, code: 1, produced: false, ...refusal }
    const model = init?.init?.model
    if (reviewerModel && model != null && model !== reviewerModel) {
      return { id, code: 1, reason: 'reviewer identity mismatch', model, produced: false }
    }
    const timeoutEnvelope = reviewerModel && timedOut && provider.code === 3 && provider.signal === null
      && result.status === 'ERROR' && result.structured_output === undefined
    if (timeoutEnvelope) {
      let steps
      try { steps = transcript(id) } catch (error) { if (error.code !== 'ENOENT') throw error; steps = [] }
      const observed = steps.filter(step => step.type === 'PLANNER_RESPONSE' && step.source === 'MODEL')
      if (observed.some(step => step.model != null && step.model !== reviewerModel)) {
        return { id, code: 1, reason: 'reviewer identity mismatch', produced: false }
      }
      return { id, code: 3, reason: 'print timeout', model: model ?? null, providerStatus: 'ERROR',
        availability: 'timeout', produced: false }
    }
    return { id, code: timedOut ? 3 : 1, reason: timedOut ? 'print timeout' : 'provider error', produced: false }
  }
  const audit = readHookAudit(hookLog)
  const refusal = reviewerModel ? reviewerToolRefusal(audit) : undefined
  let steps
  try {
    steps = transcript(id).filter(step => Number.isSafeInteger(step.step_index) && step.step_index > previousStep)
  } catch (error) {
    if (!refusal) throw error
    steps = []
  }
  const produced = steps.some(step => step.type === 'PLANNER_RESPONSE' && step.source === 'MODEL')
  if (refusal) return { id, code: 1, ...refusal, produced, providerStatus: result.status }
  if (reviewerModel) {
    // The gate records request evidence against the provider's trajectory
    // index. GENERIC transcript results omit the tool name and arguments.
    const auditedTools = new Map()
    for (const event of audit) {
      if (event.type !== 'agy-tool' || event.conversationId !== id || event.decision !== 'allow'
        || !Number.isSafeInteger(event.stepIdx)) continue
      auditedTools.set(event.stepIdx, auditedTools.has(event.stepIdx) ? null : event)
    }
    const seenSteps = new Set()
    const duplicateSteps = new Set()
    for (const step of steps) {
      if (seenSteps.has(step.step_index)) duplicateSteps.add(step.step_index)
      seenSteps.add(step.step_index)
    }
    const readEvidence = reviewerReadEvidence(steps, auditedTools, duplicateSteps)
    let failed = false
    let toleratedAbsentReads = 0
    let toleratedTranscriptAbsentReads = 0
    let toleratedRecoveredReadRanges = 0
    for (const step of steps) {
      if (!failedStep(step)) continue
      const index = step.step_index
      const candidate = step.type === 'GENERIC' && step.source === 'MODEL' && step.status === 'ERROR'
        && !duplicateSteps.has(index)
      const transcriptRead = !auditedTools.has(index) && readEvidence.batchSteps.has(index)
      if (candidate && step.error === 'file does not exist' && (auditedTools.get(index)?.name === 'read_file' || transcriptRead)) {
        toleratedAbsentReads++
        if (transcriptRead) toleratedTranscriptAbsentReads++
      } else if (candidate && recoveredReadRange(step, readEvidence)) {
        toleratedRecoveredReadRanges++
      } else {
        failed = true
      }
    }
    const planner = steps.filter(step => step.type === 'PLANNER_RESPONSE' && step.source === 'MODEL')
    const models = [init?.init?.model, ...planner.map(step => step.model)].filter(model => typeof model === 'string' && model)
    const finalized = audit.some(event => event.type === 'agy-tool' && event.conversationId === id
      && event.name === 'finish' && event.decision === 'allow')
    let reason = 'completed'
    if (failed) reason = 'transcript contains a failed step'
    else if (planner.at(-1)?.status !== 'DONE') reason = 'missing completed model transcript evidence'
    else if (models.some(model => model !== reviewerModel)) reason = 'reviewer identity mismatch'
    else if (!object(result.structured_output)) reason = 'missing structured review output'
    else if (!finalized) reason = 'missing reviewer completion audit'
    return { id, code: reason === 'completed' ? 0 : 1, reason, produced, providerStatus: result.status, toleratedAbsentReads,
      toleratedTranscriptAbsentReads, toleratedRecoveredReadRanges,
      ...(reason === 'completed' ? { review: result.structured_output, model: models[0] ?? null } : {}) }
  }
  const failed = steps.some(failedStep)
  const refused = audit.some(event => event.decision === 'deny')
  const response = typeof result.response === 'string' ? result.response.trim() : ''
  const reportsFailure = /denied by pre-tool hook|blocked by a pre-tool hook|the (?:requested )?(?:task|turn) failed\b|\bi (?:cannot|can't|could not|couldn't) (?:complete|comply)/i.test(response)
  const reason = refused ? 'tool refused' : failed ? 'transcript contains a failed step' : reportsFailure ? 'response reports failure'
    : !response ? 'empty response' : !produced ? 'missing model transcript evidence' : 'completed'
  const usage = Object.fromEntries(['input_tokens', 'cache_read_tokens', 'output_tokens', 'thinking_tokens', 'total_tokens']
    .flatMap(key => Number.isSafeInteger(result.usage?.[key]) && result.usage[key] >= 0 ? [[key, result.usage[key]]] : []))
  return { id, code: reason === 'completed' ? 0 : 1, reason, produced, response, providerStatus: result.status,
    ...(Object.keys(usage).length ? { usage } : {}) }
}

async function supervise(cwd, prompt, log, model, seconds, resume, schema, handle, turn, laneLog, workInput) {
  const research = process.env.WRSP_AGY_LANE === 'researcher'
  const review = process.env.WRSP_AGY_LANE === 'reviewer'
  if ((research || review) && resume) throw new Error('agy ' + process.env.WRSP_AGY_LANE + ' mode requires a fresh conversation')
  if (review !== Boolean(schema)) throw new Error('agy reviewer mode requires a review schema')
  if (Boolean(handle) !== Boolean(turn) || Boolean(laneLog) !== Boolean(workInput) || (laneLog && !handle)
    || (handle && (research || review || (!resume && (!laneLog || turn !== '1'))))) throw new Error('invalid agy lane turn')
  const audit = log + '.agy-hooks.jsonl'
  const previousStep = resume
    ? transcript(resume).reduce((last, step) => Number.isSafeInteger(step.step_index) ? Math.max(last, step.step_index) : last, -1)
    : -1
  const raw = mkdtempSync(join(tmpdir(), 'wrsp-agy-output-'))
  let cache = ''
  let group
  let finished
  let cancelled = 0
  function cancel(code) {
    if (cancelled !== 0) return
    cancelled = code
    if (group?.connected) group.send('cancel', () => {})
  }
  const term = () => cancel(143)
  const interrupt = () => cancel(130)
  process.on('SIGTERM', term)
  process.on('SIGINT', interrupt)
  let watchdog
  try {
    closeSync(openSync(audit, 'wx', 0o600))
    publishState(log + '.progress', audit + '\n')
    publishState(log + '.started', process.ppid + '\n')
    if (process.env.WRSP_AGY_LANE === '1') cache = realpathSync(mkdtempSync(join(tmpdir(), 'wrsp-agy-npm-')))
    const identity = buildProcessIdentity(realpathSync(raw))
    const tracked = createProcessTracker(identity)
    const laneContext = handle ? [handle, turn, String(process.ppid), laneLog ?? log, workInput ?? prompt] : []
    group = fork(self, ['group', cwd, prompt, model, seconds, resume, raw, schema ?? '', cache, identity, log, ...laneContext], {
      cwd, detached: true, stdio: ['ignore', 'ignore', 'inherit', 'ipc'],
      env: { ...process.env, WRSP_AGY_HOOK_LOG: audit },
    })
    const ended = new Promise((resolve, reject) => {
      group.once('exit', resolve)
      group.once('error', reject)
    })
    finished = ended.catch(() => {})
    if (group.pid) publishState(log + '.agy.pgid', group.pid + '\n')
    const result = new Promise((resolve, reject) => {
      group.on('message', event => {
        try {
          if (event.ready && group.connected) group.send(cancelled ? 'cancel' : 'dispatch', () => {})
          if (event.pid) publishState(log + '.agy.pid', event.pid + '\n')
          if (event.exit) resolve(event)
        } catch (error) { reject(error) }
      })
    })
    watchdog = setTimeout(() => cancel(3), (Number(seconds) + 60) * 1000)
    const observed = await Promise.race([result, ended.then(() => { throw new Error('agy process group exited before reporting completion') })])
    signalGroup(group.pid, 'SIGKILL')
    await finished
    let live = []
    for (let attempt = 0; attempt < 20; attempt++) {
      live = tracked.live(observed.known)
      if (live.length === 0) break
      await delay(25)
    }
    if (live.length !== 0) publishState(log + '.live', live.map(row => row.pid + '\t' + row.start + '\n').join(''))
    if (observed.cleanupUncertain || live.length !== 0) throw new Error('agy process cleanup could not be verified')
    if (cancelled) {
      console.log(cancelled === 3 ? 'AGY FAILED: supervisor deadline expired' : 'CANCELLED: agy process group stopped')
      return cancelled
    }
    const outcomeRecord = completion(raw, resume, previousStep, audit, observed.exit, review ? model : undefined)
    publishState(log + '.agy.conversation', outcomeRecord.id + '\n')
    publishState(log + '.agy.result.json', JSON.stringify(outcomeRecord) + '\n')
    if (outcomeRecord.produced) {
      const fd = openSync(audit, 'a')
      try { writeFileSync(fd, '{"type":"agy-completion"}\n') } finally { closeSync(fd) }
    }
    console.log('AGY ' + (outcomeRecord.code === 0 ? 'COMPLETED: ' : 'FAILED: ') + outcomeRecord.reason)
    if (research && outcomeRecord.code === 0) console.log(outcomeRecord.response)
    return outcomeRecord.code
  } finally {
    clearTimeout(watchdog)
    if (group?.pid && group.exitCode === null && group.signalCode === null) {
      signalGroup(group.pid, 'SIGKILL')
      await finished
    }
    process.removeListener('SIGTERM', term)
    process.removeListener('SIGINT', interrupt)
    rmSync(raw, { recursive: true, force: true })
    if (cache) rmSync(cache, { recursive: true, force: true })
  }
}

const [command, ...args] = process.argv.slice(2)
try {
  if (command === 'preflight') await preflight(args[0])
  else if (command === 'group') await modelGroup(...args)
  else if (command === 'run') process.exitCode = await supervise(...args)
  else if (command === 'publish-state' && args.length === 1) publishState(args[0], readFileSync(0))
  else throw new Error('unknown agy worker operation')
} catch (error) {
  console.error('AGY FAILED: ' + error.message.split('\n')[0])
  process.exitCode = command === 'preflight' ? 66 : (error instanceof StatePublicationError ? 73 : 1)
  if (command === 'group' && process.connected) process.disconnect()
}
