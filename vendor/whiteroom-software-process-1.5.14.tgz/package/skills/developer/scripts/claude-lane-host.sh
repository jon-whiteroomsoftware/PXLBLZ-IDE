#!/bin/bash
# The operator's sudoers entry names only this installed, root-owned program.
set -euo pipefail
readonly account=wrsp-lane
readonly entry=/Library/WRSP/bin/wrsp-claude-lane

case ${1:-} in
  check)
    uid=$(/usr/bin/id -u "$account" 2>/dev/null) || uid=
    groups=$(/usr/bin/id -G "$account" 2>/dev/null) || groups=
    if [[ ! $uid =~ ^[1-9][0-9]*$ || -z $groups || " $groups " == *' 80 '* || " $groups " == *' 0 '* ]]; then
      printf '%s\n' 'Claude developer lane account wrsp-lane is missing or invalid (#575).' >&2
      exit 66
    fi
    # Ignore cached authentication. Test the same executable through sudo.
    if ! protocol=$(/usr/bin/sudo -n -k -u "$account" -- "$entry" --check </dev/null 2>/dev/null); then
      printf 'Claude developer lane sudo rule is unavailable for %s (#575).\n' "$entry" >&2
      exit 66
    fi
    if [[ $protocol != WRSP_CLAUDE_LANE_PIPE_V1 ]]; then
      printf '%s\n' 'Claude developer lane launcher requires the updated process supervisor setup (#575).' >&2
      exit 66
    fi
    printf '%s\t%s\n' "$uid" /Users/wrsp-lane/.claude
    ;;
  run)
    shift
    if [[ ${1:-} == --version || ${1:-} == --verify ]]; then
      exec /usr/bin/env -i /usr/bin/sudo -n -u "$account" -- "$entry" "$@"
    fi
    [[ $# -ge 5 ]] || exit 64
    role=$1 budget=$2 origin=$3 channel=$4
    shift 4
    relay=$(dirname "$0")/claude-lane-process.mjs
    exec node "$relay" host /usr/bin/env -i /usr/bin/sudo -n -u "$account" -- "$entry" "$role" "$budget" \
      "${OTEL_RESOURCE_ATTRIBUTES:-}" "$origin" "$channel" "$@"
    ;;
  *) exit 64 ;;
esac
