# Durable times

Bind timestamps while preparing the local artifact. Human-facing stamps
(lead files, issue Progress lines, proof docs and handoffs) default to
`{{time:now:local}}`. It writes `YYYY-MM-DD HH:MM ±HH:MM`: the host's local
wall-clock minute with its numeric offset, for example `2026-11-23 13:16 -07:00`.
A historical offset with seconds is written as the nearest minute, half-minute
ties toward +∞ (#610).
Lead rendering and age checks read the date and offset. Put `{{time:event:NAME}}`
where the write needs a cited event time, and keep the event's source link and
attribution in the draft. `{{time:now}}` (RFC3339 UTC with milliseconds) and
`{{time:now:minute}}` (`YYYY-MM-DD HH:MMZ`) remain for UTC-precise text.
Machine records (ledgers, receipts, evidence and other JSON) stay UTC (#610).

Write the offset, never a zone abbreviation alone. An abbreviation does not
resolve to an offset: on Agent Mini, macOS `date` prints `MST` where Node
prints `PDT` for the same −07:00 instant. Lead checks therefore skip `13:16 MST`.

Run the binder with a new output path:

```sh
node ~/.agents/skills/issue-workflow/scripts/bind-durable-times.mjs \
  --draft draft.md --out bound.md \
  --event approval source-event.json /createdAt
```

The binder samples the clock once and reuses it for all `now` slots, local and UTC. Each event
binding reads a timestamp string from the saved source JSON using a JSON pointer
and copies it exactly, including offset and fractional seconds. Repeat `--event`
for distinct names; use `''` for a root string, `/events/0/createdAt` for an array,
`~1` for a slash in a key and `~0` for a tilde. Copy the source event's timestamp
field, rather than an observation or fetch time. The helper validates calendar
dates and requires an RFC3339 date-time with seconds and an explicit offset.

Open the output and check its times against the clock/source and its attribution
against the draft. Submit that artifact through the existing writer. For issue
bodies, pass it to `wrsp-issue-body --body-file`; for lead rewrites, replace the
intended Markdown and run `wrsp-lead render`. Lead additions keep using
`wrsp-lead log` or `append`, which bind their clock and stamp local time with its offset.

The helper binds only marked slots. Replace a guessed literal in a draft with
the appropriate slot before binding. Unmarked historical times and quoted source
text stay unchanged; review their provenance. For sources outside JSON, copy the
observed event time verbatim with its citation; omit an unavailable time or mark
it unknown. Regenerate current-time slots for a later write from the slot draft,
keeping event times tied to the original source.

Missing slots, unbound events, malformed sources and invalid clocks refuse
before output creation. Usage errors exit 64; data/filesystem errors exit 65
with `DURABLE TIME REFUSED:`. The output must be a new file; an existing file is
preserved. The helper makes no remote writes and changes no publication checks.
