# frozen_string_literal: true

# The AppleSMC read ABI follows the Stats reference pinned in NOTICE.
# Exit 2 identifies a system Ruby without Fiddle to the caller.
begin
  require 'fiddle'
rescue LoadError
  exit 2
end
require 'json'

class AppleSmc
  SELECTOR = 2
  READ_KEY = 5
  READ_KEY_INFO = 9
  STRUCT_SIZE = 80
  DATA_SIZE = 28
  DATA_TYPE = 32
  RESULT = 40
  COMMAND = 42
  BYTES = 48
  FLOAT_TYPE = 'flt '.unpack1('N')

  def initialize
    @iokit = Fiddle.dlopen('/System/Library/Frameworks/IOKit.framework/IOKit')
    @call = bind('IOConnectCallStructMethod', [int, int, pointer, Fiddle::TYPE_SIZE_T, pointer, pointer])
  end

  def read(keys)
    task = Fiddle::Pointer.new(Fiddle.dlopen(nil)['mach_task_self_'])[0, 4].unpack1('L<')
    match = bind('IOServiceMatching', [pointer], pointer).call('AppleSMC')
    raise 'AppleSMC match unavailable' if match.null?

    service = bind('IOServiceGetMatchingService', [int, pointer]).call(0, match)
    raise 'AppleSMC service unavailable' if service.zero?

    connection_out = [0].pack('L<')
    begin
      status = bind('IOServiceOpen', [int, int, int, pointer]).call(service, task, 0, connection_out)
    ensure
      bind('IOObjectRelease', [int]).call(service)
    end
    raise 'AppleSMC connection unavailable' unless status.zero?

    connection = connection_out.unpack1('L<')
    begin
      keys.each_with_object([]) do |key, readings|
        value = temperature(connection, key)
        readings << { name: key, celsius: value } if value&.finite?
      end
    ensure
      bind('IOServiceClose', [int]).call(connection)
    end
  end

  private

  def int
    Fiddle::TYPE_INT
  end

  def pointer
    Fiddle::TYPE_VOIDP
  end

  def bind(name, args, returns = int)
    Fiddle::Function.new(@iokit[name], args, returns)
  end

  def temperature(connection, key)
    info = request(connection, key, READ_KEY_INFO, 0)
    return unless info && info[DATA_SIZE, 4].unpack1('L<') == 4 && info[DATA_TYPE, 4].unpack1('L<') == FLOAT_TYPE

    value = request(connection, key, READ_KEY, 4)
    value&.byteslice(BYTES, 4)&.unpack1('e')
  end

  def request(connection, key, command, size)
    input = "\x00" * STRUCT_SIZE
    input[0, 4] = [key.unpack1('N')].pack('L<')
    input[DATA_SIZE, 4] = [size].pack('L<')
    input.setbyte(COMMAND, command)
    output = "\x00" * STRUCT_SIZE
    output_size = [STRUCT_SIZE].pack('Q<')
    status = @call.call(connection, SELECTOR, input, STRUCT_SIZE, output, output_size)
    output if status.zero? && output_size.unpack1('Q<') == STRUCT_SIZE && output.getbyte(RESULT).zero?
  end
end

abort 'Invalid AppleSMC key list' unless ARGV.size.between?(1, 64) && ARGV.all? { |key| /\A[A-Za-z0-9]{4}\z/.match?(key) }
puts JSON.generate(AppleSmc.new.read(ARGV))
