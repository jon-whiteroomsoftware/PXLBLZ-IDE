#!/bin/sh
# Finish before agy's outer command-hook timeout so dependency errors can deny.
helper="$HOME/.agents/hooks/session-role.mjs"
if verdict=$(/usr/bin/perl -e 'alarm 5; exec @ARGV' node "$helper" gate agy 2>/dev/null); then
  if [ "$verdict" = '{"decision":"allow","reason":""}' ] ||
    printf '%s\n' "$verdict" | /usr/bin/perl -MJSON::PP -0777 -ne '
      my $reply = eval { decode_json($_) };
      exit !(ref($reply) eq "HASH" && ($reply->{decision} // "") eq "deny"
        && defined($reply->{reason}) && !ref($reply->{reason}) && length($reply->{reason}));
    '; then
    printf '%s\n' "$verdict"
    exit 0
  fi
fi
printf '%s\n' '{"decision":"deny","reason":"WRSP agy gate helper is unavailable"}'
