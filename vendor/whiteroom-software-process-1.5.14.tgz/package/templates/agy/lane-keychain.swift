import Darwin
import Foundation
import Security

private let service = "wrsp-lane-github"
private let account = "github.com"
private let maximumBody = 16 * 1024 * 1024

private func openKeychain(_ path: String) -> SecKeychain? {
    var keychain: SecKeychain?
    guard SecKeychainOpen(path, &keychain) == errSecSuccess, let keychain else { return nil }
    var status: SecKeychainStatus = 0
    guard SecKeychainGetStatus(keychain, &status) == errSecSuccess,
          status & SecKeychainStatus(kSecUnlockStateStatus) != 0 else { return nil }
    return keychain
}

private func findItem(_ keychain: SecKeychain, data: Bool) -> CFTypeRef? {
    let query: [String: Any] = [
        kSecClass as String: kSecClassGenericPassword,
        kSecAttrService as String: service,
        kSecAttrAccount as String: account,
        kSecMatchSearchList as String: [keychain],
        kSecMatchLimit as String: kSecMatchLimitOne,
        (data ? kSecReturnData : kSecReturnAttributes) as String: true
    ]
    var result: CFTypeRef?
    guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess else { return nil }
    return result
}

private final class Response: NSObject, URLSessionDataDelegate, @unchecked Sendable {
    let done = DispatchSemaphore(value: 0)
    private let output = FileHandle.standardOutput
    private var accepted = false
    private(set) var complete = false

    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(nil)
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse,
                    completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
            completionHandler(.cancel)
            return
        }
        let mime = http.mimeType ?? "-"
        guard mime.range(of: #"^[A-Za-z0-9./+-]{1,100}$"#, options: .regularExpression) != nil else {
            completionHandler(.cancel)
            return
        }
        output.write(Data("\(http.statusCode) \(mime)\n".utf8))
        accepted = true
        completionHandler(.allow)
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        output.write(data)
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        complete = accepted && error == nil
        done.signal()
    }
}

private func forward(_ args: [String], keychain: SecKeychain) -> Bool {
    guard args.count == 6 else { return false }
    let kind = args[2], method = args[3], endpoint = args[4], gitProtocol = args[5]
    let host: String
    switch kind {
    case "api":
        guard ["GET", "POST", "DELETE", "PATCH"].contains(method), gitProtocol.isEmpty else { return false }
        host = "api.github.com"
    case "git":
        let info = method == "GET" && endpoint.hasSuffix(".git/info/refs?service=git-upload-pack")
        let upload = method == "POST" && endpoint.hasSuffix(".git/git-upload-pack")
        guard info || upload, ["", "version=2"].contains(gitProtocol) else { return false }
        host = "github.com"
    default: return false
    }
    guard endpoint.hasPrefix("/"), !endpoint.hasPrefix("//"),
          let url = URL(string: "https://" + host + endpoint), url.host == host, url.fragment == nil,
          let item = findItem(keychain, data: true) as? Data, item.count <= 1024,
          let token = String(data: item, encoding: .ascii),
          token.range(of: #"^[A-Za-z0-9_]+$"#, options: .regularExpression) != nil else { return false }
    var request = URLRequest(url: url)
    request.httpMethod = method
    request.setValue("WRSP-lane-github", forHTTPHeaderField: "User-Agent")
    if kind == "api" {
        request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization")
        request.setValue("application/vnd.github+json", forHTTPHeaderField: "Accept")
    } else {
        let authorization = Data(("x-access-token:" + token).utf8).base64EncodedString()
        request.setValue("Basic " + authorization, forHTTPHeaderField: "Authorization")
        if !gitProtocol.isEmpty { request.setValue(gitProtocol, forHTTPHeaderField: "Git-Protocol") }
    }
    let body = FileHandle.standardInput.readDataToEndOfFile()
    guard body.count <= maximumBody else { return false }
    if !body.isEmpty {
        request.httpBody = body
        request.setValue(kind == "api" ? "application/json" : "application/x-git-upload-pack-request",
                         forHTTPHeaderField: "Content-Type")
    }
    let config = URLSessionConfiguration.ephemeral
    config.httpShouldSetCookies = false
    config.urlCredentialStorage = nil
    config.urlCache = nil
    config.timeoutIntervalForRequest = 30
    config.timeoutIntervalForResource = 120
    let response = Response()
    let session = URLSession(configuration: config, delegate: response, delegateQueue: nil)
    session.dataTask(with: request).resume()
    response.done.wait()
    session.finishTasksAndInvalidate()
    return response.complete
}

private func run(_ args: [String]) -> Bool {
    guard args.count >= 2 else { return false }
    let operation = args[0], path = args[1]
    if operation == "setup" {
        guard args.count == 2 else { return false }
        umask(0o077)
        var keychain: SecKeychain?
        return SecKeychainCreate(path, 0, nil, true, nil, &keychain) == errSecSuccess
    }
    guard SecKeychainSetUserInteractionAllowed(false) == errSecSuccess, let keychain = openKeychain(path) else { return false }
    switch operation {
    case "ready": return args.count == 2 && findItem(keychain, data: false) != nil
    case "request": return forward(args, keychain: keychain)
    default: return false
    }
}

var noCore = rlimit(rlim_cur: 0, rlim_max: 0)
exit(setrlimit(RLIMIT_CORE, &noCore) == 0 && run(Array(CommandLine.arguments.dropFirst())) ? 0 : 66)
