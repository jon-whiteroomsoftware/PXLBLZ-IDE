#!/usr/bin/env bash
set -euo pipefail

usage() {
  echo "Usage: $(basename "$0") <claude|codex> <workspace> <prompt-file> <output-file>" >&2
  exit 64
}

[[ $# -eq 4 ]] || usage
worker=$1
workspace_input=$2
prompt_input=$3
output=$4

case "$worker" in
  claude|codex) ;;
  *) usage ;;
esac
[[ -d "$workspace_input" ]] \
  || { echo "Workspace directory not found: $workspace_input" >&2; exit 66; }
[[ -s "$prompt_input" ]] \
  || { echo "Prompt file missing or empty: $prompt_input" >&2; exit 66; }
[[ ! -e "$output" ]] \
  || { echo "Refusing to overwrite worker output: $output" >&2; exit 73; }
[[ -d "$(dirname "$output")" ]] \
  || { echo "Output directory not found: $(dirname "$output")" >&2; exit 66; }

workspace=$(cd "$workspace_input" && pwd -P)
prompt=$(cd "$(dirname "$prompt_input")" && pwd -P)/$(basename "$prompt_input")
output=$(cd "$(dirname "$output")" && pwd -P)/$(basename "$output")

if [[ "$worker" == claude ]]; then
  command -v claude >/dev/null \
    || { echo "Claude Code is not on PATH." >&2; exit 69; }
  (
    cd "$workspace"
    claude --print --no-session-persistence --output-format text \
      --model fable --effort xhigh \
      --permission-mode dontAsk \
      --tools "Read,Glob,Grep" \
      --allowedTools "Read,Glob,Grep" < "$prompt"
  ) > "$output"
else
  command -v codex >/dev/null \
    || { echo "Codex CLI is not on PATH." >&2; exit 69; }
  codex exec --ephemeral \
    --model gpt-6-sol \
    --config 'model_reasoning_effort="high"' \
    --config 'approval_policy="never"' \
    --sandbox read-only \
    --cd "$workspace" \
    --output-last-message "$output" \
    - < "$prompt"
fi

[[ -s "$output" ]] \
  || { echo "$worker exited without a final response." >&2; exit 70; }
printf '%s worker output: %s\n' "$worker" "$output"
