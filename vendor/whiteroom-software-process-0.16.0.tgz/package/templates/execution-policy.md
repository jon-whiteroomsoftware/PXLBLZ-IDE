# Execution worker policy

Read before launching implementation workers, new execution tasks, or scheduled
execution work, and when choosing a fallback or responding to non-convergence.
This is the authoritative execution policy. Its canonical installed location is
`~/.agents/execution-policy.md`; this tracked file is its adoption source.
This file defines tiers once; all other docs reference tier names, never
restate membership.

## Tiers

Each tier is an ordered preference list. At launch, walk the tier top-down and
skip unavailable models. An exhausted tier STOPS: the operator names a specific
model for any further attempt. No cross-tier fallback, no urgency inference.

| Tier | Aliases | Ordered members (model / effort) |
| --- | --- | --- |
| `batch` | hourly worker | `gpt-6-luna` / `high` -> `meta/muse-spark-1.3-contributor` / `low` -> `claude-sonnet-5` / `high` |
| `junior` | junior dev, junior engineer, researcher | `gpt-6-sol` / `low` -> `meta/muse-spark-1.3-contributor` / `high` |
| `developer` | engineer; THE DEFAULT | `gpt-6-sol` / `high` -> `claude-opus-5-5` / `med` -> `meta/muse-spark-1.3-contributor` / `xhigh` |
| `eng-lead` | -- | `claude-opus-5-5` / `high` -> `gpt-6-sol` / `high` -> `gpt-6-astra` / `low` -> `claude-fable-5-1` / `med` |
| `principal` | -- | `claude-fable-5-1` / `high` -> `gpt-6-astra` / `med` -> `gpt-6-sol` / `high` -> `claude-opus-5-5` / `xhigh` |
| `designer` | -- | `claude-fable-5-1` / `med` -> `claude-opus-5-5` / `high` -> `gpt-6-astra` / `low` -> `meta/muse-spark-1.3-contributor` / `xhigh` |

## Function map

| Function | Tier |
| --- | --- |
| implementation | `developer` |
| code review | `eng-lead` |
| design | `designer` |
| ux design | `designer` |
| research | `junior` |
| bulk | `batch` |
| hardest escalation | `principal` |

No role named -> `developer`. Role word -> tier with aliases
(`researcher` -> `junior`, `engineer` -> `developer`,
`hourly worker` -> `batch`). Function word -> tier with the map above.
Unknown word -> ask; never guess. Name the tier in the launch line as
`tier:<name>` (for example `tier:eng-lead`). Then walk the tier,
skipping unavailable; exhausted stops.
Model ids are exact `--model` strings. Codex: `--model <id>` with
`--config 'model_reasoning_effort="<effort>"'`; `-p <profile>` layers a config
selecting the model connection. Claude: `--model <claude-*>` with
`--effort <effort>`. GPT-family ids run only on the Codex default connection;
Claude-family ids only on the Claude CLI; the OpenRouter connection (today
`-p muse`) never carries GPT or Claude ids: subscription versus PAYG
multiples, and OpenRouter guardrails fail it closed. New profiles are named
here when added; never guess a profile. `gpt-6-sol`, `gpt-6-luna`, and
`claude-sonnet-5` confirm on first launch; unproven ids are skipped as
unavailable, never invented. Each launch still names the exact model and
effort explicitly; inheritance, aliases, and configured defaults do not
establish the pair. Existing authorization, scope, concurrency, security, and
review gates remain in force. A model choice supplies no permission to launch
additional workers.

Unavailability, exhausted quota, or provider failure advances to the next
eligible member within the named tier only. Record the reason and selected pair
in the handoff. Skip models on a provider already known to be exhausted or
unavailable; a model-specific failure does not establish provider-wide failure.
Keep independent work moving. If the named tier is exhausted, report the
unavailable choices and stop that launch; do not fall through to another tier.
Permission/security refusals stop the affected action; they are not availability
failures and never justify a different provider or tool as a bypass.

## Diagnose non-convergence

A worker failing to solve a problem is a reasoning or approach problem, not
provider unavailability. Preserve its evidence and diagnose the invariant,
approach, or enforcement layer before another attempt. Escalation means the
operator names a specific tier or a specific model/effort pair with a concrete
changed approach, for example `tier:principal` or a fresh `developer` attempt
with a new hypothesis. State why that attempt should help; do not cycle models
indefinitely. A harder tier is an explicit escalation, never an automatic
fallback or an inference from urgency.

Model changes preserve candidate lineage and the existing review breaker.
Three consecutive P0/P1-blocking reviews still require discussion with Jon
before a fourth review; a new worker, model, task, or fresh context cannot reset
that count. Repeated failure without a new hypothesis requires discussion,
not another automatic attempt. Review outcomes and availability failures remain
distinct.

## Use a capable launch interface

Codex collaboration, task, or scheduled-work tools must expose both exact fields.
When supported, use `model` and `reasoning_effort` (or the tool's named equivalent)
explicitly, plus `tier:<name>` in the launch line. If a chosen tool cannot express
a tier plus pair, use an authorized capable CLI route or report the limitation.
Never translate an unsupported member launch into a different model.

For CLI execution, provide the prompt and authorized workspace through the
CLI's normal input/workspace options, and explicitly set:

- Codex: `--model <exact-model>` and `--config 'model_reasoning_effort="<effort>"'`.
- Claude: `--model claude-fable-5-1 --effort high`.

Keep normal permission and sandbox controls. These flags express selection;
they do not prove availability or authorize changing permissions. Preserve the
actual launch arguments and returned outcome rather than claiming an unobserved
model ran. TBD launch IDs must be resolved before launch, never invented.
This policy does not supply a new dispatcher or automatic retry loop.

The installed Claude native `Agent|Task` hook refuses that interface because it
cannot bind the exact approved model/effort pair. Its refusal points to this
policy and the capable CLI routes above. The hook neither parses prompt prose
to infer a role nor intercepts arbitrary shell commands. Codex/API and direct
CLI launches rely on explicit caller compliance; there is no claimed universal
host enforcement.

## Brief workers through the worker skill

Every worker brief starts with the body of the `worker` skill
(`~/.agents/skills/worker/SKILL.md`, tracked in WRSP `skills/`). It carries the
worker role, the reporting format, and the Codex harness-fault rules for WRSP
#69 and #70 in one place. The coordinator skill's
`scripts/launch-worker.sh` prepends it, runs the banned-phrase check below,
sets `WRSP_ROLE=worker`, and writes the worker's output to a log. The
coordinator backgrounds that launch and waits for its exit notification; the
worker itself never backgrounds anything.

## Brief content

The coordinator settles design before launching an execution worker. A worker
implements a settled design; it never decides one.

1. A brief names the files and functions to change, with signatures; the data
   mapping; the behaviour to match, with file:line citations; refusal codes or
   messages; and each test's setup and expected assertion.
2. A brief that asks for a new test cites an existing test to copy by
   file:line range and gives the helper signatures it uses.
3. A brief never asks the worker to establish, decide, choose, find out, figure
   out, determine, investigate or explore anything the coordinator could read.
   Before launch run
   `grep -niE 'establish|decid|decis|choos|choic|determin|investigat|explor|(find|figur)[a-z]* +out' <brief>`
   (stems catch inflections such as "deciding", "decision", "choice", "figured
   out"; write each brief instruction on one line so no phrase is split)
   and remove or explicitly justify every hit. Bare "find" is allowed
   ("grep to find callers").
4. Questions the coordinator cannot answer go to Jon before launch, never to
   the worker.
5. Worker discretion is local implementation only. When the brief looks wrong
   or incomplete, the worker prints one line starting `BRIEF GAP:` naming the
   missing decision and exits without edits.
6. The brief is posted to the issue before launch. Before candidate review the
   coordinator checks the diff against the brief; any departure is a finding.

## Separate review and design

WRSP candidate review follows its own ranked, cross-family policy and records
native receipt provenance. Read-only review and design workflows retain their
explicit model/effort selections, including `dual-model-design`. They grant no
implementation exception. Use their capable CLI or API routes; the native
Claude `Agent|Task` limitation still applies. Separate planning sessions retain
their existing explicit authorization requirement.
