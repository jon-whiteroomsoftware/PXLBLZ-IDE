#!/usr/bin/env bash
# WRSP #197: one detached process per lane turn; identity survives process exit.
set -euo pipefail
case $0 in
  */*) lane_script_dir=${0%/*}; lane_script_dir=${lane_script_dir:-/} ;;
  *) lane_script_dir=. ;;
esac
refuse() { printf 'REFUSED: %s\n' "$2" >&2; exit "$1"; }
# A source-only checkout can still observe lanes from its Git hooks.
if [[ ${1:-} == status && -r $lane_script_dir/lane-cli.mjs ]] &&
   [[ -d $lane_script_dir/lane-runtime || -r $lane_script_dir/../../../dist/lane/cli.mjs ]]; then
  exec node "$lane_script_dir/lane-cli.mjs" "$0" "$PWD" "$(command -v bash)" "$@"
fi
if [[ ${1:-} == board && $# -gt 2 ]]; then refuse 64 'invalid board arguments'; fi
if [[ ${1:-} == board || ${1:-} == watch || ${1:-} == check ]]; then
  # Older builds only dispatch status. Use the standalone helpers until rebuilt.
  observation_runtime=$lane_script_dir/../../../dist/lane
  if [[ -d $lane_script_dir/lane-runtime ]]; then observation_runtime=$lane_script_dir/lane-runtime; fi
  if [[ -r $lane_script_dir/lane-cli.mjs && -r $observation_runtime/observation.mjs ]]; then
    exec node "$lane_script_dir/lane-cli.mjs" "$0" "$PWD" '' "$@"
  fi
fi
lane_script_dir=$(cd -- "$lane_script_dir" && pwd -P)
announce_turn() {
  local bash_bin state_file="${WRSP_LANE_CHECK_STATE:-${handle%/*}/.lane-check.json}"
  bash_bin=$(command -v bash)
  [[ $state_file == /* ]] || state_file=$PWD/$state_file
  view announce "$handle" "$PWD" "$bash_bin" "$state_file" "$@"
}
readonly sender="From: eng lead, not Jon. Jon's words appear only as quoted text with their source."
readonly browser_facts='{"runner":"repo-playwright","iab":"unavailable"}'
readonly browser_preamble="Headless browser capability: browser=$browser_facts. Use the repository's Playwright runner directly for UI verification; skip the in-app-browser probe and fallback announcement."
readonly bootstrap_prompt='Startup metadata verification only. Reply exactly LANE_READY. Do not use tools, claim an issue, edit files, launch children, or perform issue work. The issue brief arrives in a later message.'
readonly default_lane_reply_timeout=2700

absolute() { case $1 in /*) printf '%s\n' "$1";; *) printf '%s/%s\n' "$PWD" "$1";; esac; }
# Shell variables retain empty fields and embedded whitespace. Match the
# trailing-newline handling of the individual command substitutions.
json_fields() {
  local projection=$1; shift
  jq -j "($projection)[] | (tostring | gsub(\"\u0000\"; \"\") | sub(\"\n+\\\\z\"; \"\")), \"\u0000\"" "$@"
}
# Command substitution cannot carry NULs. Escape backslashes and tabs so a
# tab-terminated stream survives capture without adding external commands.
pack_fields() {
  local field
  while IFS= read -r -d '' field; do
    field=${field//\\/\\\\}
    printf '%s\t' "${field//$'\t'/\\t}"
  done
}
read_fields() {
  local destination field
  for destination; do
    IFS= read -r -d $'\t' field || return
    # Bash 3.2 can reuse the previous output when %b receives an empty field.
    if [[ $field == *\\* ]]; then
      printf -v "$destination" '%b' "$field"
    else
      printf -v "$destination" '%s' "$field"
    fi
  done
}
handle_fields() {
  json_fields 'select(length == 1) | .[0] | select(type == "object" and (.turn | type == "number")) |
    [.turn, .contact, .cli, .role, (.role_id // ""), .worktree, .lane, (.thread // ""), .next_exchange]' -s "$@"
}
read_handle() {
  [[ -r $1 ]] &&
    read_fields n log cli role role_id worktree lane send_thread next_exchange <<< "$(handle_fields "$1" 2>/dev/null | pack_fields)" || return 65
  handle=$1
}
load() {
  if ! read_handle "$1"; then
    # Keep the original read diagnostic for a readable directory handle.
    if [[ -d $1 && -r $1 ]]; then cat "$1" >/dev/null || :; fi
    refuse 65 'handle missing or unreadable'
  fi
}
load_wait_snapshot() {
  local loaded
  [[ -r $1 ]] && loaded=$(cat "$1") || refuse 65 'handle missing or unreadable'
  # The idle client pins the turn and rechecks a complete snapshot on each poll.
  n=$(jq -r .turn <<< "$loaded" 2>/dev/null) || refuse 65 'handle missing or unreadable'
  read_fields n log cli role role_id worktree lane send_thread next_exchange <<< "$(handle_fields <<< "$loaded" 2>/dev/null | pack_fields)" ||
    refuse 65 'handle missing or unreadable'
  handle=$1
}
load_admission() {
  local canonical
  canonical=$(node "$lane_script_dir/lane-finished.mjs" canonical-handle "$1") || return $?
  if [[ ${2:-} == yes ]]; then load_wait_snapshot "$canonical"; else load "$canonical"; fi
}
# Both dispatchers use the same redirections. On success the shell becomes
# the original child. On a redirection failure Bash emits its diagnostic.
readonly redirect_output='output=$1; shift; exec "$@" > "$output"'
readonly dispatch_work='input=$1; output=$2; shift 2; exec "$@" < "$input" >> "$output" 2>&1'
readonly restore_handle='restore() { cat > "$2"; mv -f "$2" "$3"; }; restore "$@" < "$1"'
readonly remove_backup='before=$1; rm "$before"; exit $?'
atomic() { /bin/bash -c "$restore_handle" "$0" "$1" "$handle.tmp.$$" "$handle"; }
agy_write_state() {
  if printf '%s\n' "$2" | node "$lane_script_dir/../../developer/scripts/agy-worker.mjs" publish-state "$1" 2>> "$log"; then
    return 0
  fi
  agy_state_failed=1
  return 73
}
write_handle() {
  if [[ $cli == agy && $command == run-turn ]]; then
    local contents
    contents=$(jq "$@") || return
    agy_write_state "$handle" "$contents"
  else
    jq "$@" > "$handle.tmp.$$" && mv -f "$handle.tmp.$$" "$handle"
  fi
}
view() {
  node - "$lane_script_dir" "$@" <<'NODE'
const fs = require('node:fs');
const path = require('node:path');
const { contextStatus, readRegular, observeLaneActivity } = require(path.join(process.argv[2], 'lane-activity.mjs'));
const read = file => { try { return fs.readFileSync(file, 'utf8'); } catch { return null; } };
const [mode, target, ...args] = process.argv.slice(3);
function invocation(action, cwd, bash, ...argv) {
  const { nextInvocation } = require(path.join(process.argv[2], '../../developer/scripts/next-invocation.mjs'));
  return nextInvocation(action, [bash, path.join(process.argv[2], 'lane.sh'), action, ...argv], cwd);
}
if (mode === 'context-snapshot') {
  let handle; try { handle = JSON.parse(read(target)); } catch {}
  const { inputTokens, budget } = contextStatus(handle);
  console.log(JSON.stringify({ turn: handle?.turn ?? null, inputTokens, budget }));
} else if (mode === 'status') {
  let handle; try { handle = JSON.parse(read(target)); } catch {}
  const [cwd, bash, full, absolute, log, nextExchange, initialState] = args;
  console.log(contextStatus(handle).status);
  let state = initialState, quiet = 'none';
  if (state === 'live') {
    try { quiet = Math.max(0, Math.floor((Date.now() - fs.statSync(log).mtimeMs) / 1000)) + 's'; }
    catch { quiet = 'unknown'; }
    try { state = observeLaneActivity(JSON.parse(readRegular(target)))?.state ?? state; }
    catch { state = 'unknown'; }
  }
  console.log('state: %s\nquiet: %s', state, quiet);
  if (full === '--full') console.log('turn-log: %s\nnext-exchange: %s', log, nextExchange);
  else console.log('handle: %s\ndetails: --full', absolute);
  if (state.startsWith('exited')) process.stdout.write(invocation('read', cwd, bash, absolute, '--finished'));
} else if (mode === 'event' || mode === 'announce') {
  const { writeEvent, announce } = require(path.join(process.argv[2], 'lane-announce.mjs'));
  if (mode === 'announce') {
    const [cwd, bash, stateFile, ...eventArgs] = args;
    announce(target, cwd, bash, path.join(process.argv[2], 'lane.sh'), stateFile, eventArgs);
  } else {
    try { writeEvent(target, args); }
    catch (error) { console.error('REFUSED: event not written: ' + error.message); process.exit(65); }
  }
} else process.exit(64);
NODE
}
manual_event_options() {
  while [[ $# -gt 0 ]]; do
    [[ $# -ge 2 && $2 != --* ]] || refuse 64 'missing event argument'
    case $1 in --issue|--reason) ;; *) refuse 64 'invalid manual event argument';; esac
    shift 2
  done
}
# Native metadata only: never infer served configuration from argv or assistant prose.
native() { node "$lane_script_dir/lane-native.mjs" "$@"; }
readonly pending_verification='.verification={state:"pending",phase:(if .turn == 1 then "bootstrap" else "resume" end),requested:{role:.role_id,model:.model,effort:(if .effort == "medium" then "med" else .effort end)},reported:{model:null,effort:null,nativeEffort:null},source:{provider:.cli,session:.thread,path:null,start:0,end:0},reason:""} | .turns[-1].verification=.verification'
save_verification() {
  local preserve=$1 transform=$2 verified_handle pair_line pair_has_nul
  local render_pair='"PAIR \($report.state | ascii_upcase) phase=\($report.phase) requested=\($report.requested.model)/\($report.requested.effort) native=\($report.reported.model // "unknown")/\($report.reported.effort // "unknown") source=\($report.source | tojson) reason=\($report.reason) selection-reason=\($selection)"'
  local selection='((.selection_reason // "") | tostring | gsub("\u0000"; "") | sub("\n+\\z"; "")) as $selection'
  shift 2
  read_fields verified_handle recorded_path recorded_end pair_has_nul pair_line <<< "$(
    jq -j --arg preserve "$preserve" "$@" "($transform) as \$report | $selection | ($render_pair) as \$pair | "'
      .verification=$report | .turns[-1].verification=$report |
      if $report.state == "accepted" and ($report.phase == "bootstrap" or $report.phase == "work") then .qualification=$report
      elif $report.state == "refused" and $preserve != "yes" then .qualification=null else . end |
      ($pair | contains("\u0000")) as $raw |
      ., "\u0000", ($report.source.path // ""), "\u0000", $report.source.end, "\u0000", $raw, "\u0000",
      (if $raw then "" else $pair end), "\u0000"' "$handle" | pack_fields
  )" || return 1
  if [[ $cli == agy && $command == run-turn ]]; then
    agy_write_state "$handle" "$verified_handle" || return
  else
    printf '%s\n' "$verified_handle" > "$handle.tmp.$$" && mv -f "$handle.tmp.$$" "$handle" || return
  fi
  if [[ $pair_has_nul == true ]]; then
    # A native refusal can quote arbitrary input bytes. Keep those bytes out
    # of Bash variables, where NUL cannot be represented.
    jq -r ".verification as \$report | $selection | $render_pair" <<< "$verified_handle" >> "$log"
  else
    printf '%s\n' "$pair_line" >> "$log"
  fi
}
provider_command() {
  local fresh=$1 output_format=${2:-json} cli_effort=$effort override members reserve auto_compact_window settings
  [[ $cli_effort != med ]] || cli_effort=medium
  cmd=(env WRSP_ROLE=developer "WRSP_CONTEXT_BUDGET=$budget")
  if [[ $cli == claude ]]; then
    members=${WRSP_ROLES_MEMBERS:-$HOME/.agents/roles.members}
    if ! reserve=$(awk -F '\t' '/^# claude-auto-compact-reserve([[:space:]]|$)/ { count++; if (NF == 2 && $1 == "# claude-auto-compact-reserve" && $2 ~ /^[1-9][0-9]*$/) value=$2; else invalid=1 } END { if (count != 1 || invalid) exit 1; print value }' "$members"); then
      printf 'Refusing launch: %s has no valid Claude compaction reserve (WRSP #325). Run wrsp-agents install.\n' "$members" | tee -a "$log" >&2
      return 66
    fi
    auto_compact_window=$((budget + reserve))
    if [[ ${service_tier:-} == fast ]]; then
      settings=$(jq -c --argjson b "$auto_compact_window" '. + {autoCompactWindow: $b, fastMode: true}' "$roles/developer.claude.json") || return 66
    else
      settings=$(jq -c --argjson b "$auto_compact_window" '. + {autoCompactWindow: $b}' "$roles/developer.claude.json") || return 66
    fi
    cmd+=(claude -p --model "$model" --effort "$cli_effort" --settings "$settings" --permission-mode bypassPermissions)
    if [[ $fresh == yes ]]; then cmd+=(--session-id "$thread" --name "$title"); else cmd+=(--resume "$thread"); fi
    cmd+=(--output-format "$output_format")
    [[ $output_format != stream-json ]] || cmd+=(--verbose)
  else
    cmd+=(codex exec)
    [[ $fresh == yes ]] || cmd+=(resume "$thread")
    cmd+=(--json -m "$model" -c "model_reasoning_effort=$cli_effort" -c "model_auto_compact_token_limit=$budget")
    [[ ${service_tier:-} != fast ]] || cmd+=(-c "service_tier=fast")
    if ! [[ -f $roles/developer.codex.args && -r $roles/developer.codex.args ]] ||
      ! { while IFS= read -r override || [[ -n $override ]]; do
      [[ -z $override || $override == \#* ]] || cmd+=(-c "$override")
      done; } 2>/dev/null < "$roles/developer.codex.args"; then
      printf 'REFUSED: Codex role arguments missing or unreadable: %s\n' "$roles/developer.codex.args" >&2
      return 66
    fi
    [[ $fresh != yes ]] || cmd+=(-C "$worktree")
    cmd+=(-)
  fi
}
agy_selection() {
  [[ $role == developer && $role_id == developer && $model == gemini-4-neon ]] &&
    [[ $effort =~ ^(low|med|high|xhigh)$ ]]
}
agy_command() {
  cmd=(env -u CLAUDE_CODE_SESSION_ID -u CODEX_THREAD_ID -u CODEX_SESSION_ID
    -u GIT_DIR -u GIT_COMMON_DIR -u GIT_WORK_TREE
    -u ANTIGRAVITY_CONFIG_REL_DIR -u ANTIGRAVITY_EXECUTABLE_DATA_DIR -u ANTIGRAVITY_PLUGIN_SHIM_DIR -u ANTIGRAVITY_PROJECT_ID
    WRSP_ROLE=developer WRSP_AGY_LANE=1 node "$lane_script_dir/../../developer/scripts/agy-worker.mjs")
}
agy_dispatch() {
  local prompt=$1 output=$2 timeout=$3 resume=$4 suffix
  local runtime_pid= code=0 signal_code=0 cli_effort=$effort
  local dispatch_issue
  dispatch_issue=$(jq -er '.issue' "$handle") || return 66
  [[ $cli_effort != med ]] || cli_effort=medium
  for suffix in .agy-hooks.jsonl .lane-dispatch.jsonl .agy.pid .agy.pgid .agy.conversation .agy.result.json .progress .live .started; do
    if [[ -e $output$suffix || -L $output$suffix ]]; then
      printf 'REFUSED: refusing to overwrite agy evidence: %s\n' "$output$suffix" >> "$log"
      return 73
    fi
  done
  agy_signal() {
    [[ $signal_code != 0 ]] || signal_code=$1
    if [[ -n $runtime_pid ]]; then kill "-$2" "$runtime_pid" 2>/dev/null || :; fi
  }
  trap 'agy_signal 143 TERM' TERM
  trap 'agy_signal 130 INT' INT
  agy_command
  local args=(run "$worktree" "$prompt" "$output" "$model-$cli_effort" "$timeout" "$resume"
    "" "$handle" "$n" "$log" "$work_input")
  if [[ $signal_code == 0 ]]; then
    WRSP_AGY_ISSUE=$dispatch_issue "${cmd[@]}" "${args[@]}" >> "$output" 2>&1 & runtime_pid=$!
    if [[ $signal_code == 143 ]]; then kill -TERM "$runtime_pid" 2>/dev/null || :
    elif [[ $signal_code == 130 ]]; then kill -INT "$runtime_pid" 2>/dev/null || :; fi
    wait "$runtime_pid" || code=$?
    while jobs -p | grep -qx "$runtime_pid"; do wait "$runtime_pid" || code=$?; done
  fi
  trap - TERM INT
  [[ $signal_code == 0 ]] || return "$signal_code"
  return "$code"
}
agy_session_fact() {
  local file=$log.bootstrap.log.agy.conversation sid
  [[ -f $file && ! -L $file ]] && IFS= read -r sid < "$file" &&
    [[ $sid =~ ^[[:xdigit:]]{8}-[[:xdigit:]]{4}-[[:xdigit:]]{4}-[[:xdigit:]]{4}-[[:xdigit:]]{12}$ ]] || return 0
  thread=$sid
  record_fact launch-record session --launch-id "$launch_id" --provider agy --session-id "$thread"
  if ! jq -cn --arg sid "$thread" --arg cwd "$worktree" '{session_id:$sid,cwd:$cwd}' |
    node "$HOME/.agents/hooks/session-role.mjs" record agy >> "$log" 2>&1; then
    echo 'WARNING: agy session-role record not written (#567).' >> "$log"
  fi
}
write_bootstrap_input() { printf '%s\n\n%s' "$sender" "$bootstrap_prompt" > "$log.bootstrap-input"; }
log_line() { printf '%s\n' "$1"; printf '%s\n' "$1" >> "$log"; }
bootstrap() {
  local retry_dir retry_runtime retry_clock first_dispatch launch_deadline reply_deadline admission_deadline logical_id attempt=0 attempt_base prior current code action runtime_pid= runtime_code
  local admission signal reason attempt_row retry_capped retry_reason retry_at retry_delay
  local admission_message='"LAUNCH ADMISSION: override=\(.overridden) expiry=\(.expiresAt) delay=\(.delayMs)"'
  bootstrap_parent_signal() {
    [[ $bootstrap_signal_code != 0 ]] || bootstrap_signal_code=$1
    if [[ -n ${runtime_pid:-} ]]; then kill "-$2" "$runtime_pid" 2>/dev/null || :; fi
  }
  trap 'bootstrap_parent_signal 143 TERM' TERM
  trap 'bootstrap_parent_signal 130 INT' INT
  retry_dir=$lane_script_dir
  if [[ -r $retry_dir/../../../dist/launch-retry-runtime.mjs ]]; then retry_dir=$retry_dir/../../../dist
  else retry_dir=$retry_dir/../../developer/scripts; fi
  retry_runtime=$retry_dir/launch-retry-runtime.mjs
  [[ -r $retry_runtime && -r $retry_dir/launch-retry-policy.mjs && -r $retry_dir/launch-backoff-marker.mjs ]] || { echo 'retry helpers missing; run npm run build / wrsp-agents install.'; return 66; }
  retry_clock=$(node "$retry_runtime" clock) || return 66
  read_fields first_dispatch launch_deadline reply_deadline admission_deadline <<< "$(
    json_fields '
      (.now + .deadlineMs) as $launch | (.now + ($seconds|tonumber)*1000) as $reply |
      [.now, $launch, $reply, ([$launch,$reply]|min)]
    ' --arg seconds "${WRSP_LANE_BOOTSTRAP_TIMEOUT:-$default_lane_reply_timeout}" <<< "$retry_clock" | pack_fields
  )" || return 66
  printf '{\n  "deadlineAt": %s\n}\n' "$admission_deadline" > "$log.admission.request.json"
  runtime_code=0
  [[ $bootstrap_signal_code == 0 ]] || return "$bootstrap_signal_code"
  node "$retry_runtime" lane-admit "$log.admission.request.json" > "$log.admission.json" & runtime_pid=$!
  if [[ $bootstrap_signal_code == 143 ]]; then kill -TERM "$runtime_pid" 2>/dev/null || :
  elif [[ $bootstrap_signal_code == 130 ]]; then kill -INT "$runtime_pid" 2>/dev/null || :; fi
  wait "$runtime_pid" || runtime_code=$?
  while [[ $'\n'$(jobs -p)$'\n' == *$'\n'"$runtime_pid"$'\n'* ]]; do wait "$runtime_pid" || runtime_code=$?; done
  runtime_pid=
  [[ $bootstrap_signal_code == 0 ]] || return "$bootstrap_signal_code"
  [[ $runtime_code != 130 && $runtime_code != 143 ]] || return "$runtime_code"
  # Advisory failures retain no-delay evidence and never refuse a fresh launch.
  if [[ $runtime_code != 0 ]] || ! admission=$(jq -er \
    "select(type == \"object\" and (.delayMs | type == \"number\")) | $admission_message" "$log.admission.json" 2>/dev/null); then
    jq -n --arg override "${WRSP_LAUNCH_BACKOFF_OVERRIDE:-}" '{expiresAt:null,throttledUntil:null,overflow:false,delayMs:0,nextEligibleAt:null,overridden:($override=="1")}' > "$log.admission.json"
    admission=$(jq -r "$admission_message" "$log.admission.json")
  fi
  log_line "$admission"
  logical_id=$launch_id
  write_bootstrap_input
  bootstrap_attempt() {
    node --input-type=module -e '
      import { readFileSync, writeFileSync } from "node:fs";
      const [runtimePath, cwd, log, handle, workInput, stage, attemptBase, ...args] = process.argv.slice(1);
      const { fingerprintWorktree, loadClockDriver, main } = await import(runtimePath);
      const fingerprint = fingerprintWorktree(cwd, log, [handle, workInput]);
      if (stage === "snapshot") console.log(fingerprint);
      else if (stage === "prepare") {
        const [cli, thread, launchDeadline, replyDeadline, ...argv] = args;
        const clock = await loadClockDriver();
        const request = {
          cli, argv, cwd, inputPath: log + ".bootstrap-input", logPath: attemptBase + ".log",
          sessionRecordPointerPath: log + ".session-record", firstOutputMarkerPath: log + ".first-output",
          outputMode: cli === "codex" ? "codex-json" : "claude-json", startupDeadlineAt: Number(launchDeadline),
          wholeReplyTimeoutMs: Math.max(Number(replyDeadline) - clock.now(), 0),
          ...(cli === "claude" ? { nativeSessionId: thread } : {})
        };
        writeFileSync(attemptBase + ".request.json", JSON.stringify(request, null, 2) + "\n");
        console.log(fingerprint);
      } else {
        const [prior, firstDispatchAt, attempts] = args;
        const result = JSON.parse(readFileSync(attemptBase + ".result.json", "utf8"));
        const historyPath = log + ".history.json";
        const history = {
          firstDispatchAt: Number(firstDispatchAt), attempts: Number(attempts),
          startupElapsedMs: result.endedAt - result.dispatchedAt,
          outcome: prior === fingerprint ? result.outcome :
            { ...result.outcome, reason: "work-observed", retryable: false, availability: false },
          retryAfter: result.retryAfter ?? null
        };
        writeFileSync(historyPath, JSON.stringify(history, null, 2) + "\n");
        process.exitCode = await main(["lane-next", historyPath]);
      }
    ' "$retry_runtime" "$worktree" "$log" "$handle" "$work_input" "$@"
  }
  while :; do
    [[ $bootstrap_signal_code == 0 ]] || return "$bootstrap_signal_code"
    attempt=$((attempt + 1)); attempt_base=$log.attempt-$attempt
    provider_command yes || return 66
    # OTEL launch attribution follows this actual attempt, including fresh Claude IDs.
    cmd=(env "OTEL_RESOURCE_ATTRIBUTES=${OTEL_RESOURCE_ATTRIBUTES:+$OTEL_RESOURCE_ATTRIBUTES,}wrsp.launch_id=$launch_id" "${cmd[@]}")
    log_line "LAUNCH ATTEMPT: $attempt id=$launch_id logical=$logical_id deadline=$launch_deadline"
    prior=$(bootstrap_attempt prepare "$attempt_base" "$cli" "$thread" "$launch_deadline" "$reply_deadline" "${cmd[@]}") || return 66
    runtime_code=0
    [[ $bootstrap_signal_code == 0 ]] || return "$bootstrap_signal_code"
    node "$retry_runtime" attempt "$attempt_base.request.json" "$attempt_base.result.json" & runtime_pid=$!
    trap 'bootstrap_parent_signal 143 TERM' TERM
    trap 'bootstrap_parent_signal 130 INT' INT
    if [[ $bootstrap_signal_code == 143 ]]; then kill -TERM "$runtime_pid" 2>/dev/null || :
    elif [[ $bootstrap_signal_code == 130 ]]; then kill -INT "$runtime_pid" 2>/dev/null || :; fi
    wait "$runtime_pid" || runtime_code=$?
    while [[ $'\n'$(jobs -p)$'\n' == *$'\n'"$runtime_pid"$'\n'* ]]; do wait "$runtime_pid" || runtime_code=$?; done
    runtime_pid=
    trap 'bootstrap_parent_signal 143 TERM' TERM
    trap 'bootstrap_parent_signal 130 INT' INT
    [[ -s $attempt_base.result.json && ( $runtime_code == 0 || $runtime_code == 130 || $runtime_code == 143 ) ]] || { [[ $runtime_code != 0 ]] || runtime_code=66; return "$runtime_code"; }
    read_fields thread signal reason code <<< "$(
      json_fields '[(.nativeSessionId // ""), (.signal // ""), .reason,
        (if .signal == "SIGINT" then 130 elif .signal == "SIGTERM" then 143 else (.exitCode // 70) end)]' "$attempt_base.result.json" | pack_fields
    )" || return 66
    if [[ -n $thread ]]; then record_fact launch-record session --launch-id "$launch_id" --provider "$cli" --session-id "$thread"; fi
    bootstrap_attempt decide "$attempt_base" "$prior" "$first_dispatch" "$attempt" > "$log.eligibility.json" || return 66
    read_fields action retry_capped retry_reason retry_at retry_delay attempt_row <<< "$(
      json_fields '
        $a[0] as $eligibility |
        [$eligibility.action, ($eligibility.nextEligibleAt >= $cap), $eligibility.reason,
         $eligibility.nextEligibleAt, $eligibility.delayMs,
         ($r[0] + {logicalId:$logicalId,launchId:$launchId,attempt:$attempt,nextEligibility:$eligibility})]
      ' -n --argjson cap "$reply_deadline" --arg logicalId "$logical_id" --arg launchId "$launch_id" --argjson attempt "$attempt" --slurpfile r "$attempt_base.result.json" --slurpfile a "$log.eligibility.json" | pack_fields
    )" || return 66
    if [[ $runtime_code == 0 && -n $signal ]]; then
      echo "bootstrap timeout/abort: $signal"
      code=70
    fi
    [[ $runtime_code == 0 ]] || code=$runtime_code
    if [[ $reason == whole-reply-timeout ]]; then
      echo "bootstrap timeout/abort: ETIMEDOUT; no reply within ${WRSP_LANE_BOOTSTRAP_TIMEOUT:-$default_lane_reply_timeout}s; set WRSP_LANE_BOOTSTRAP_TIMEOUT=<seconds> to wait longer"
      code=70
    fi
    printf '%s\n' "$attempt_row" >> "$log.attempts.jsonl"
    [[ $bootstrap_signal_code == 0 ]] || return "$bootstrap_signal_code"
    if [[ $action == defer ]]; then
      jq -nr --argjson first "$first_dispatch" --slurpfile r "$attempt_base.result.json" --slurpfile a "$log.eligibility.json" '"throttled: attempts=\($a[0].attempts) elapsedMs=\($r[0].endedAt-$first) last=\($r[0].outcome.reason) next=defer at=\($a[0].nextEligibleAt // $a[0].deadlineAt)"' > "$log.availability"
      printf 'AVAILABILITY: %s\n' "$(cat "$log.availability")" >> "$log"
      return 10
    fi
    if [[ $action == stop && $(jq -r .outcome.reason "$log.history.json") == hard-limit ]]; then
      jq -r .outcome.evidence "$attempt_base.result.json" > "$log.availability"
      printf 'AVAILABILITY: %s\n' "$(cat "$log.availability")" >> "$log"
      return 10
    fi
    [[ $bootstrap_signal_code == 0 ]] || return "$bootstrap_signal_code"
    [[ $action == retry ]] || return "$code"
    # A shorter whole-reply cap is absolute across all bootstrap retries.
    if [[ $retry_capped == true ]]; then echo 'bootstrap timeout/abort: retry exceeds whole-reply cap'; return 70; fi
    printf 'LAUNCH RETRY: reason=%s next=%s wait=%s\n' "$retry_reason" "$retry_at" "$retry_delay" | tee -a "$log"
    [[ $bootstrap_signal_code == 0 ]] || return "$bootstrap_signal_code"
    node "$retry_runtime" wait "$log.eligibility.json" & runtime_pid=$!
    trap 'bootstrap_parent_signal 143 TERM' TERM
    trap 'bootstrap_parent_signal 130 INT' INT
    if [[ $bootstrap_signal_code == 143 ]]; then kill -TERM "$runtime_pid" 2>/dev/null || :
    elif [[ $bootstrap_signal_code == 130 ]]; then kill -INT "$runtime_pid" 2>/dev/null || :; fi
    runtime_code=0; wait "$runtime_pid" || runtime_code=$?
    while jobs -p | grep -qx "$runtime_pid"; do wait "$runtime_pid" || runtime_code=$?; done
    runtime_pid=
    trap 'bootstrap_parent_signal 143 TERM' TERM
    trap 'bootstrap_parent_signal 130 INT' INT
    [[ $bootstrap_signal_code == 0 ]] || return "$bootstrap_signal_code"
    [[ $runtime_code == 0 ]] || return "$runtime_code"
    current=$(bootstrap_attempt snapshot) || return 66
    [[ $prior == "$current" ]] || return 70
    retry_clock=$(node "$retry_runtime" clock) || return 66
    if jq -e --argjson deadline "$launch_deadline" '.now >= $deadline' <<< "$retry_clock" >/dev/null; then echo 'throttled: deadline elapsed before dispatch' > "$log.availability"; return 10; fi
    record_fact launch-record exit --launch-id "$launch_id" --exit-code "$code" --log "$log"
    [[ $bootstrap_signal_code == 0 ]] || return "$bootstrap_signal_code"
    rm -f "$log.session-record" "$log.first-output"
    launch_id=$(uuidgen | tr '[:upper:]' '[:lower:]'); thread=
    [[ $cli != claude ]] || thread=$(uuidgen | tr '[:upper:]' '[:lower:]')
    write_handle --arg launch "$launch_id" '.launch_id=$launch' "$handle"
    lane_start_fact
  done
}
live() {
  [[ -s ${log}.pid ]] || return 1
  pid=$(< "${log}.pid")
  [[ $pid =~ ^[0-9]+$ ]] && ps -p "$pid" >/dev/null 2>&1
}
state() {
  if [[ -f ${log}.exit ]]; then printf 'exited %s' "$(< "${log}.exit")"
  elif live; then printf live
  elif [[ -d $handle.lock ]]; then printf interrupted
  else printf none; fi
}
# Keep the same child-status and stderr behavior when Node initiates a fact.
readonly record_launch='usage_bin=$1; log=$2; shift 2
  if ! command -v "$usage_bin" >/dev/null 2>&1; then
    echo "WARNING: launch record not written: $usage_bin is not on PATH (#196)." >> "$log"
  else
    "$usage_bin" "$@" >/dev/null 2>>"$log" || echo "WARNING: launch record not written: $usage_bin $1 $2 exited $? (#196)." >> "$log"
  fi'
record_fact() { # Same best-effort boundary as launch-worker.sh (#196).
  /bin/bash -c "$record_launch" "$0" "$usage_bin" "$log" "$@"
}
remove_job() {
  if [[ -n ${WRSP_LANE_REMOVE:-} ]]; then
    "$WRSP_LANE_REMOVE" "$1" >/dev/null 2>&1 || true
  else
    launchctl remove "$1" >/dev/null 2>&1 || true
  fi
}
submit() {
  local label=$1
  local self
  self=$(absolute "$0")
  local cmd=(launchctl submit -l "$label" --)
  [[ -z ${WRSP_LANE_SUBMIT:-} ]] || cmd=("$WRSP_LANE_SUBMIT")
  cmd+=(/usr/bin/env "PATH=$PATH" "HOME=$HOME" "TMPDIR=${TMPDIR:-/tmp}")
  [[ -z ${WRSP_ROLES_DIR:-} ]] || cmd+=("WRSP_ROLES_DIR=$(absolute "$WRSP_ROLES_DIR")")
  [[ -z ${WRSP_ROLES_MEMBERS:-} ]] || cmd+=("WRSP_ROLES_MEMBERS=$(absolute "$WRSP_ROLES_MEMBERS")")
  [[ -z ${WRSP_USAGE_BIN:-} ]] || cmd+=("WRSP_USAGE_BIN=$WRSP_USAGE_BIN")
  [[ -z ${WRSP_RUNNER_HOME:-} ]] || cmd+=("WRSP_RUNNER_HOME=$WRSP_RUNNER_HOME")
  [[ -z ${WRSP_LANE_REMOVE:-} ]] || cmd+=("WRSP_LANE_REMOVE=$WRSP_LANE_REMOVE")
  [[ -z ${WRSP_LANE_BOOTSTRAP_TIMEOUT:-} ]] || cmd+=("WRSP_LANE_BOOTSTRAP_TIMEOUT=$WRSP_LANE_BOOTSTRAP_TIMEOUT")
  for key in WRSP_LAUNCH_RETRY_TEST_DRIVER WRSP_LAUNCH_BACKOFF_DIR WRSP_LAUNCH_BACKOFF_OVERRIDE CODEX_HOME CLAUDE_CONFIG_DIR OTEL_RESOURCE_ATTRIBUTES; do
    [[ -z ${!key:-} ]] || cmd+=("$key=${!key}")
  done
  if [[ $cli == agy && -n ${WRSP_LEDGER_HOME:-} ]]; then
    cmd+=("WRSP_LEDGER_HOME=$WRSP_LEDGER_HOME")
  fi
  cmd+=(/bin/bash "$self" run-turn "$handle" "$n" "$label")
  local code=0
  "${cmd[@]}" || code=$?
  if [[ $code != 0 ]]; then remove_job "$label"; fi
  return "$code"
}
send_error() { printf 'REFUSED: %s\n' "$2" >&2; return "$1"; }
admission_tools_available() {
  local tool
  for tool in jq mv rm rmdir "${WRSP_LANE_SUBMIT:-launchctl}" "$@"; do
    command -v "$tool" >/dev/null 2>&1 || return 1
  done
}
send_role() {
  [[ -n $role_id ]] || { send_error 64 "handle $handle has no role_id: it was started with --tier, which #243 removed; relaunch the lane with --role-id"; return 64; }
  [[ $role != developer || $role_id == developer ]] || { send_error 64 'developer requires --role-id developer'; return 64; }
  [[ $role != principal-engineer || $role_id == principal-engineer ]] || { send_error 64 'principal-engineer requires --role-id principal-engineer'; return 64; }
}
send_identity() {
  send_role || return $?
  [[ -d $worktree ]] || { send_error 80 "lane $lane: worktree $worktree is missing; recreate it for this issue or start a new lane for a new issue"; return 80; }
  [[ ${1:-} == pending-thread || -n $send_thread ]] || { send_error 77 'provider thread or session id missing'; return 77; }
}
admit_send() { # Caller owns the turn lock; rollback is byte-for-byte.
  local input=$1 expected_turn=${2:-} before=$handle.previous.$$ code=0
  if ! read_handle "$handle"; then
    rmdir "$handle.lock"; send_error 65 'handle missing or unreadable'; return 65
  fi
  if [[ -n $expected_turn && $n != "$expected_turn" ]]; then
    rmdir "$handle.lock"; send_error 75 'another send advanced the lane while waiting'; return 75
  fi
  send_identity || code=$?
  if [[ $code != 0 ]]; then rmdir "$handle.lock"; return "$code"; fi
  local admission_runtime=$lane_script_dir/../../../dist/lane
  if [[ -d $lane_script_dir/lane-runtime ]]; then admission_runtime=$lane_script_dir/lane-runtime; fi
  # Keep Bash arithmetic and diagnostics for old handles with atypical jq numbers.
  if [[ $n =~ ^[1-9][0-9]{0,14}$ && -r $lane_script_dir/lane-cli.mjs &&
        -r $admission_runtime/admission.mjs ]] &&
     admission_tools_available cp cat date; then
    node "$lane_script_dir/lane-cli.mjs" "$0" "$PWD" "$(command -v bash)" \
      admit-send "$handle" "$cli" "$lane" "$n" "$input" "$pending_verification" "$$" \
      "$redirect_output" "$restore_handle" "$remove_backup" || return $?
    n=$((n + 1)); log=${handle%.lane.json}.turn-$n.log
    announced=yes
    return 0
  fi
  node "$lane_script_dir/lane-finished.mjs" guard "$handle" || code=$?
  if [[ $code != 0 ]]; then rmdir "$handle.lock"; return "$code"; fi
  if ! cp "$handle" "$before"; then rm -f "$before"; rmdir "$handle.lock"; return 69; fi
  n=$((n + 1)); log=${handle%.lane.json}.turn-$n.log
  label=com.whiteroom.wrsp-lane.$lane.$n.$(date +%s)
  if ! { /bin/bash -c "$redirect_output" "$0" "$handle.tmp.$$" jq \
    --argjson n "$n" --arg log "$log" --arg input "$input" --arg label "$label" \
    '.turn=$n | .contact=$log | .next_exchange=$input | .turns += [{n:$n,log:$log,input:$input,label:$label}] | '"$pending_verification" "$handle" &&
    mv -f "$handle.tmp.$$" "$handle"; }; then code=69; fi
  if [[ $code == 0 ]]; then submit "$label" || code=69; fi
  if [[ $code != 0 ]]; then
    atomic "$before"
    rm "$before"; rmdir "$handle.lock"
    send_error 69 'submission failed'; return 69
  fi
  /bin/bash -c "$remove_backup" "$0" "$before"
}
command=${1:-}; [[ $# -eq 0 ]] || shift
case $command in
  help|--help|-h)
    cat <<'HELP'
Usage: lane.sh <command>
  start --role ROLE --cli claude|codex|agy --role-id ID --model MODEL --effort EFFORT
        --worktree DIR --issue N --brief FILE --title TEXT --log FILE
        [--fast] [--selection-reason TEXT] [--slot SLOT]
  start --successor-of HANDLE --brief FILE [--slot SLOT] [--log FILE] [--title TEXT]
        [launch flag overrides]
  send [--when-idle] HANDLE FILE [--await PATTERN --timeout SECONDS]
  event HANDLE assigned|released|blocked|retired [--issue N] [--reason TEXT]
  board [DIR]                     Read-only TSV; defaults to current directory
  check DIR --repo ROOT --state FILE --threshold P [--full]
  watch HANDLE --state FILE --timeout SECONDS
  status HANDLE [--full] | recover HANDLE
  read HANDLE [--cursor N | --finished [--ack-failed [--no-message]]] [--full]
  title --role ROLE --task TEXT [--lane LANE] [--issues TEXT] [--state done]
  verify-pair --cli CLI --role-id ID --model MODEL --effort EFFORT
              --session ID --transcript FILE [--offset N]
  run-turn HANDLE N LABEL         Internal submitted turn
Original briefs are retained in the repository's artifacts Files root before dispatch.
Chained output uses NEXT: JSON records with action, cwd and argv. Pass argv as separate arguments from cwd.
Start/admitted send print watch and status; exited status prints read --finished. Keep full returned handles.
Run the watch NEXT in the background. Its state path is WRSP_LANE_CHECK_STATE or .lane-check.json beside the handle.
Default status: eight content lines. Check: at most 8192 bytes, with a full report on truncation; unchanged stdout is empty.
Watch: read-only per-turn completion hint, bounded to 1..1200 seconds; the lead's check consumes it.
Reads preview at most 4096 payload bytes, naming full source and omitted bytes. --full exposes all output.
Truncated finished previews never acknowledge a turn; reread with --finished --full before sending.
WRSP_RUNNER_HOME overrides discovery from the dashboard LaunchAgent plist (#427).
HELP
    ;;
  watch)
    exec node "$lane_script_dir/lane-watch.mjs" "$@"
    ;;
  check)
    exec node "$lane_script_dir/lane-check-command.mjs" "$@"
    ;;
  board)
    exec node "$lane_script_dir/lane-board.mjs" "$@"
    ;;
  event)
    [[ $# -ge 2 ]] || refuse 64 'missing event arguments'
    case $2 in assigned|released|blocked|retired) ;; *) refuse 64 'invalid manual event';; esac
    # Internal writer options are not part of the manual command.
    manual_handle=$1; manual_event=$2; shift 2
    manual_event_options "$@"
    view event "$manual_handle" "$manual_event" "$@"
    if [[ $manual_event == retired ]]; then
      retired_worktree=$(jq -er '.worktree | select(type == "string" and startswith("/") and length > 1) | . + "/."' "$manual_handle") \
        || refuse 65 'retirement cleanup: handle worktree missing or invalid; event was recorded'
      shared_holders=$(node - "$manual_handle" "$retired_worktree" <<'NODE'
const fs = require('node:fs'), path = require('node:path');
try {
  const current = path.resolve(process.argv[2]), directory = path.dirname(current);
  const worktree = fs.realpathSync(process.argv[3]), holders = [];
  for (const file of fs.readdirSync(directory).filter(name => name.endsWith('.lane.json')).sort()) {
    const filename = path.join(directory, file);
    if (filename === current) continue;
    const handle = JSON.parse(fs.readFileSync(filename, 'utf8'));
    if (!handle || typeof handle.lane !== 'string' || !/^[A-Za-z0-9.-]+$/.test(handle.lane) || typeof handle.worktree !== 'string' || !path.isAbsolute(handle.worktree)) throw new Error('invalid sibling handle: ' + file);
    let otherWorktree;
    try { otherWorktree = fs.realpathSync(handle.worktree); }
    catch (error) { if (error.code !== 'ENOENT') throw error; otherWorktree = path.resolve(handle.worktree); }
    if (otherWorktree !== worktree) continue;
    let text = '';
    try { text = fs.readFileSync(path.join(directory, handle.lane + '.events.jsonl'), 'utf8'); }
    catch (error) { if (error.code !== 'ENOENT') throw error; }
    // A partial append cannot establish retirement. Missing events retain the holder.
    const rows = text.slice(0, text.lastIndexOf('\n') + 1).split('\n').filter(Boolean).map(line => {
      const row = JSON.parse(line);
      if (!row || row.lane !== handle.lane || typeof row.at !== 'string' || !Number.isFinite(Date.parse(row.at)) || typeof row.slot !== 'string' || !Number.isSafeInteger(row.turn) || row.turn < 0 || !Number.isSafeInteger(row.issue) || row.issue < 0 || (row.reason !== null && typeof row.reason !== 'string') || !['started','work-sent','assigned','released','blocked','retired'].includes(row.event)) throw new Error('invalid sibling event: ' + file);
      return row;
    });
    if (rows.at(-1)?.event !== 'retired') holders.push(handle.lane);
  }
  if (holders.length) console.log('KEPT ' + worktree + ': shared worktree held by non-retired lane ' + holders.join(', '));
} catch (error) { console.error('REFUSED: retirement cleanup: ' + error.message + '; event was recorded'); process.exit(65); }
NODE
      ) || refuse 65 'retirement cleanup could not inspect sibling handles; event was recorded'
      if [[ -n $shared_holders ]]; then
        printf '%s\n' "$shared_holders"
      else
        wrsp-preflight worktree-sweep --repo "$retired_worktree" --worktree "$retired_worktree" --remove \
          || refuse 65 'retirement cleanup refused; event was recorded; inspect sweep output'
      fi
    fi
    ;;
  verify-pair) native verify "$@";;
  title)
    role= lane= task= issues= state=
    while [[ $# -gt 0 ]]; do
      [[ $# -ge 2 && -n $2 ]] || refuse 64 'missing argument'
      case $1 in
        --role) role=$2;; --lane) lane=$2;; --task) task=$2;;
        --issues) issues=$2;; --state) state=$2;; *) refuse 64 'unknown argument';;
      esac; shift 2
    done
    # Names table: keep role glyphs in this single block.
    case $role in
      eng-lead) emoji=👽;;
      developer) emoji=👩‍💻;;
      reviewer) emoji=👀;;
      researcher) emoji=🔬;;
      locator) emoji=🔍;;
      ux-principal) emoji=👩‍🎤;;
      principal-engineer) emoji=🧙;;
      batch) emoji=🤖;;
      *) refuse 64 'unknown role';;
    esac
    case $state in '') ;; done) emoji=💀;; *) refuse 64 'unknown state';; esac
    [[ -n $task ]] || refuse 64 'missing task'
    printf '%s%s %s%s\n' "$emoji" "${lane:+ $lane:}" "$task" "${issues:+ $issues}"
    ;;
  start)
    role= cli= role_id= model= effort= worktree= issue= brief= title= log= selection_reason= slot= successor_of= service_tier=
    while [[ $# -gt 0 ]]; do
      if [[ $1 == --fast ]]; then
        [[ -z $service_tier ]] || refuse 64 'duplicate --fast'
        service_tier=fast; shift; continue
      fi
      [[ $# -ge 2 && -n $2 && $2 != --* ]] || refuse 64 'missing argument'
      case $1 in
        --role) role=$2;; --cli) cli=$2;; --role-id) role_id=$2;; --model) model=$2;;
        --effort) effort=$2;; --worktree) worktree=$2;; --issue) issue=$2;;
        --brief) brief=$2;; --title) title=$2;; --log) log=$2;; --selection-reason) selection_reason=$2;;
        --slot) slot=$2;; --successor-of) successor_of=$(absolute "$2");; *) refuse 64 'unknown argument';;
      esac; shift 2
    done
    has_start_inputs() {
      [[ -n $role && -n $cli && -n $model && -n $effort && -n $worktree && -n $issue &&
         -n $brief && -n $title && -n $log ]]
    }
    if [[ -n $successor_of ]]; then
      # A complete explicit start uses normal service when --fast is omitted.
      inherit_tier=yes
      if has_start_inputs && [[ -n $role_id ]]; then inherit_tier=no; fi
      read_successor() {
        node - "$lane_script_dir" "$successor_of" "$slot" "$log" "$title" <<'NODE'
const fs = require('node:fs'), path = require('node:path');
const { execFileSync } = require('node:child_process');
const { homedir } = require('node:os');
const [scripts, supplied, slotOverride, logOverride, titleOverride] = process.argv.slice(2);
const { readRegular } = require(path.join(scripts, 'lane-activity.mjs'));
const input = path.resolve(supplied);
function refuse(code, reason) {
  console.error('REFUSED: ' + reason);
  process.exit(code);
}
function contains(directory, file) {
  const relative = path.relative(directory, file);
  return relative !== '' && relative !== '..' && !relative.startsWith('..' + path.sep) && !path.isAbsolute(relative);
}
function briefsRoots() {
  const home = process.env.WRSP_RUNNER_HOME || execFileSync('plutil', [
    '-extract', 'EnvironmentVariables.WRSP_RUNNER_HOME', 'raw',
    path.join(homedir(), 'Library/LaunchAgents/com.whiteroom.wrsp-dashboard.plist'),
  ], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }).trim();
  const { roots } = JSON.parse(fs.readFileSync(path.join(home, 'files.json'), 'utf8'));
  return roots.flatMap(root => {
    if (root?.artifacts !== true || !root.repository || typeof root.path !== 'string') return [];
    const configured = root.path.startsWith('~/') ? path.join(homedir(), root.path.slice(2)) : root.path;
    if (!path.isAbsolute(configured) || configured.split(path.sep).includes('*')) return [];
    let real;
    try { real = fs.realpathSync(configured); }
    catch (error) { if (error.code === 'ENOENT') return []; throw error; }
    return contains(configured, input) || contains(real, input) ? [real] : [];
  });
}
let roots;
try { roots = briefsRoots(); }
catch { refuse(65, 'cannot locate the configured briefs tree'); }
const outside = 'predecessor handle outside the briefs tree: ' + input;
if (!roots.length) refuse(65, outside);
let handle;
try { handle = fs.realpathSync(input); }
catch { refuse(65, 'predecessor handle missing or unreadable: ' + input); }
if (!roots.some(root => contains(root, handle))) refuse(65, outside);

const stem = path.basename(handle, '.lane.json');
const malformed = 'malformed predecessor record: ' + handle;
if (!handle.endsWith('.lane.json') || !stem) refuse(65, malformed);
const text = value => typeof value === 'string' && value.length > 0 && !value.includes('\0');
let prior;
try { prior = JSON.parse(readRegular(handle).toString('utf8')); }
catch { refuse(65, malformed); }
const fields = ['role', 'cli', 'role_id', 'model', 'effort', 'worktree', 'issue'].map(key => prior?.[key]);
if (prior?.lane !== stem.replace(/[^A-Za-z0-9.-]/g, '-') ||
    !Number.isSafeInteger(prior.turn) || prior.turn < 1 || !fields.every(text) ||
    !path.isAbsolute(prior.worktree) || !/^[0-9]+$/.test(prior.issue) || !text(prior.title) ||
    (prior.slot !== undefined && !text(prior.slot)) ||
    (prior.serviceTier !== undefined && prior.serviceTier !== 'fast')) refuse(65, malformed);

const directory = path.dirname(handle);
const events = path.join(directory, prior.lane + '.events.jsonl');
let last;
try {
  const stat = fs.lstatSync(events, { throwIfNoEntry: false });
  if (stat) {
    if (!stat.isFile()) throw new Error('invalid events file');
    const history = readRegular(events).toString('utf8');
    // Match retirement's complete-event boundary.
    for (const line of history.slice(0, history.lastIndexOf('\n') + 1).split('\n').filter(Boolean)) {
      const row = JSON.parse(line);
      if (row?.lane !== prior.lane || typeof row.at !== 'string' || !Number.isFinite(Date.parse(row.at)) ||
          typeof row.slot !== 'string' || !Number.isSafeInteger(row.turn) || row.turn < 0 ||
          !Number.isSafeInteger(row.issue) || row.issue < 0 ||
          (row.reason !== null && typeof row.reason !== 'string') ||
          !['started', 'work-sent', 'assigned', 'released', 'blocked', 'retired'].includes(row.event)) {
        throw new Error('invalid event');
      }
      last = row.event;
    }
  }
} catch { refuse(65, 'malformed predecessor lifecycle events: ' + events); }
if (last === 'retired') refuse(65, 'predecessor lane is retired: ' + handle);

function advance(label, flag) {
  const suffix = /[0-9]+$/.exec(label);
  if (!suffix) refuse(64, 'cannot derive successor ' + flag + '; specify --' + flag);
  return label.slice(0, suffix.index) + String(BigInt(suffix[0]) + 1n).padStart(suffix[0].length, '0');
}
const oldSlot = prior.slot ?? prior.lane;
const slot = slotOverride || advance(oldSlot, 'slot');
const log = logOverride || path.join(directory, advance(stem, 'log') + '.log');
let title = titleOverride;
if (!title) {
  const escaped = oldSlot.replace(/[.*+?^$(){}|[\]\\]/g, '\\$&');
  const label = new RegExp('(^|[^A-Za-z0-9])(' + escaped + ')(?=$|[^A-Za-z0-9])', 'i');
  if (!label.test(prior.title)) refuse(64, 'cannot derive successor title; specify --title');
  title = prior.title.replace(label, (_, prefix, token) => prefix + (slotOverride || advance(token, 'title')));
}
process.stdout.write([handle, ...fields, prior.serviceTier ?? '', slot, log, title, ''].join('\0'));
NODE
      }
      successor_fields=$(read_successor | pack_fields) || exit $?
      read_fields successor_of prior_role prior_cli prior_role_id prior_model prior_effort prior_worktree prior_issue prior_tier slot log title \
        <<< "$successor_fields" || refuse 65 'cannot read successor fields'
      role=${role:-$prior_role}; cli=${cli:-$prior_cli}; role_id=${role_id:-$prior_role_id}
      model=${model:-$prior_model}; effort=${effort:-$prior_effort}; worktree=${worktree:-$prior_worktree}
      issue=${issue:-$prior_issue}
      [[ $inherit_tier == no ]] || service_tier=${service_tier:-$prior_tier}
    fi
    has_start_inputs || refuse 64 'missing argument'
    [[ -n $role_id ]] || refuse 64 '--role-id is required (#243)'
    [[ $role == developer || $role == ux-principal || $role == principal-engineer ]] || refuse 64 'unknown role'
    [[ $role != principal-engineer || $role_id == principal-engineer ]] || refuse 64 'principal-engineer requires --role-id principal-engineer'
    [[ $role != developer || $role_id == developer ]] || refuse 64 'developer requires --role-id developer'
    [[ $cli == claude || $cli == codex || $cli == agy ]] || refuse 64 'unknown cli'
    bootstrap_timeout=${WRSP_LANE_BOOTSTRAP_TIMEOUT:-$default_lane_reply_timeout}
    [[ $bootstrap_timeout =~ ^[1-9][0-9]*$ ]] && (( ${#bootstrap_timeout} <= 5 && bootstrap_timeout <= 86400 )) || refuse 64 "WRSP_LANE_BOOTSTRAP_TIMEOUT must be a positive integer of seconds up to 86400, not $bootstrap_timeout (#390)"
    [[ $effort != medium ]] || effort=med
    [[ $model != gemini-4-neon || $cli == agy ]] || refuse 64 'gemini-4-neon requires --cli agy (#567)'
    [[ $cli != agy ]] || agy_selection || refuse 64 'agy requires a gemini-4-neon developer pair with a supported effort'
    if [[ $service_tier == fast ]]; then
      if [[ $cli == agy ]]; then
        refuse 64 '--fast is not supported for --cli agy (#570)'
      elif [[ $cli == claude && $model != claude-opus-5-5 && $model != claude-opus-5 ]]; then
        refuse 64 "--fast is only supported for claude-opus-5-5 and claude-opus-5 on --cli claude, not $model (#570)"
      fi
    fi
    [[ $issue =~ ^[0-9]+$ && -r $brief ]] || refuse 64 'invalid issue or unreadable brief'
    stem=$(absolute "${log%.log}"); handle=$stem.lane.json
    log_directory=${stem%/*}; log_directory=${log_directory:-/}
    [[ -d $log_directory ]] || refuse 66 "log directory does not exist: $log_directory"
    [[ ! -e $handle ]] || refuse 65 'handle exists; use send'
    [[ -d $worktree ]] || refuse 66 'worktree not a directory'
    git_dir=$(git -C "$worktree" rev-parse --git-dir) || refuse 66 'worktree is not a Git worktree'
    common_dir=$(git -C "$worktree" rev-parse --git-common-dir) || refuse 66 'worktree is not a Git worktree'
    git_dir=$(cd "$worktree" && cd "$git_dir" && pwd -P) || refuse 66 'cannot resolve worktree Git directories'
    common_dir=$(cd "$worktree" && cd "$common_dir" && pwd -P) || refuse 66 'cannot resolve worktree Git directories'
    [[ $git_dir != "$common_dir" ]] || refuse 66 'worktree is the repository main worktree; create an issue worktree first'
    budget=$(awk -F '\t' -v role_id="$role_id" -v m="$model" -v e="$effort" '$1==role_id && $2==m && $3==e {print $4; exit}' "${WRSP_ROLES_MEMBERS:-$HOME/.agents/roles.members}" 2>/dev/null) || budget=
    [[ $budget =~ ^[0-9]+$ && $budget -gt 0 ]] || refuse 67 "role $role_id has no pair ($model, $effort)"
    if [[ $role == developer ]]; then
      preferred=$(awk -F '\t' '$1=="developer" {print $2 "\t" $3; exit}' "${WRSP_ROLES_MEMBERS:-$HOME/.agents/roles.members}")
      [[ $preferred == "$model"$'\t'"$effort" || $selection_reason =~ [^[:space:]] ]] || refuse 64 'nonpreferred developer pair requires --selection-reason'
    fi
    command -v "$cli" >/dev/null 2>&1 || refuse 69 "$cli is not on PATH"
    # WRSP #249: refuse a CLI below the model's vendor-stated minimum; an unlisted model is never refused.
    minimums=${WRSP_CLI_MINIMUMS:-$HOME/.agents/cli-minimums}
    [[ -r $minimums ]] || refuse 66 "cli-minimums not found: $minimums. Run wrsp-agents install."
    need_fast=0
    [[ $service_tier != fast || $cli != claude ]] || need_fast=1
    min_pair=$(awk -F '\t' -v m="$model" -v c="$cli" -v need_fast="$need_fast" '
      !/^#/ && $1 == m && $2 == c && min == "" { min = $3 }
      /^# claude-fast-minimum([[:space:]]|$)/ {
        fcount++
        if (NF == 2 && $1 == "# claude-fast-minimum" && $2 ~ /^[0-9]+\.[0-9]+\.[0-9]+$/) fmin = $2
        else finvalid = 1
      }
      END {
        if (need_fast && (fcount != 1 || finvalid)) exit 1
        printf "%s|%s", min, (need_fast ? fmin : "")
      }
    ' "$minimums") || refuse 66 "$minimums has no valid Claude fast-mode minimum (#570). Run wrsp-agents install."
    minimum=${min_pair%%|*}
    fast_minimum=${min_pair#*|}
    semver_lt() {
      local a1=${1%%.*} r1=${1#*.} b1=${2%%.*} r2=${2#*.}
      local a2=${r1%%.*} a3=${r1#*.} b2=${r2%%.*} b3=${r2#*.}
      if (( 10#$a1 != 10#$b1 )); then (( 10#$a1 < 10#$b1 )); return; fi
      if (( 10#$a2 != 10#$b2 )); then (( 10#$a2 < 10#$b2 )); return; fi
      (( 10#$a3 < 10#$b3 ))
    }
    if [[ -n $minimum || -n $fast_minimum ]]; then
      installed=$("$cli" --version </dev/null 2>/dev/null | grep -Eo '[0-9]+\.[0-9]+\.[0-9]+' | head -n 1) || installed=
      if [[ -n $minimum ]]; then
        [[ -n $installed ]] || refuse 69 "$cli version unreadable ($cli --version); $model needs $cli $minimum or later."
        if semver_lt "$installed" "$minimum"; then
          refuse 69 "$cli $installed is below $model's minimum $minimum; upgrade $cli to $minimum or later"
        fi
      fi
      if [[ -n $fast_minimum ]]; then
        [[ -n $installed ]] || refuse 69 "$cli version unreadable ($cli --version); --fast needs $cli $fast_minimum or later."
        if semver_lt "$installed" "$fast_minimum"; then
          refuse 69 "$cli $installed is below fast-mode minimum $fast_minimum; upgrade $cli to $fast_minimum or later"
        fi
      fi
    fi
    worktree=$(cd "$worktree" && pwd -P); brief=$(absolute "$brief")
    if [[ $cli == codex && $role == developer ]]; then
      log_dir=$(cd "$(dirname "$stem")" && pwd -P) || refuse 64 'Codex developer lanes require an existing host log directory'
      stem=$log_dir/${stem##*/}; handle=$stem.lane.json
      [[ ! -e $handle ]] || refuse 65 'handle exists; use send'
    fi
    if [[ $cli == agy ]]; then
      agy_command
      agy_preflight=$("${cmd[@]}" preflight "$worktree" 2>&1) || refuse 66 "$agy_preflight"
    fi
    project=$(git -C "$worktree" rev-parse --show-toplevel)
    lane=$(basename "$stem"); lane=${lane//[^A-Za-z0-9.-]/-}
    [[ -n $slot ]] || slot=$lane
    provider=openai
    [[ $cli != claude ]] || provider=anthropic
    [[ $cli != agy ]] || provider=google
    n=1; log=$stem.turn-1.log
    start_projection='({browser:$browser,parent:$parent,slot:$slot,successor_of:(if $successor_of == "" then null else $successor_of end),lane:$lane,role:$role,title:$title,cli:$cli,provider:$provider,host:$host,project:$project,issue:$issue,worktree:$worktree,role_id:$role_id,model:$model,effort:$effort,budget:$budget,contact:$contact,launch_id:$launch_id,thread:$thread,turn:1,next_exchange:"brief",selection_reason:$selection_reason,turns:[{n:1,log:$contact,input:$input,label:$label}]} + (if $service_tier == "" then {} else {serviceTier:$service_tier} end)) |
      if $cli == "agy" or $cli == "codex" then .commonDir = $common_dir else . end |
      '"$pending_verification"
    start_fields=(--argjson browser "$browser_facts" --arg slot "$slot" --arg successor_of "$successor_of" --arg lane "$lane" --arg role "$role" --arg title "$title" --arg cli "$cli" --arg provider "$provider" --arg project "$project" --arg issue "$issue" --arg worktree "$worktree" --arg common_dir "$common_dir" --arg role_id "$role_id" --arg model "$model" --arg effort "$effort" --arg budget "$budget" --arg input "$brief" --arg selection_reason "$selection_reason" --arg service_tier "$service_tier")
    start_runtime=$lane_script_dir/../../../dist/lane
    if [[ -d $lane_script_dir/lane-runtime ]]; then start_runtime=$lane_script_dir/lane-runtime; fi
    if [[ -r $lane_script_dir/lane-cli.mjs && -r $start_runtime/start.mjs ]] && admission_tools_available; then
      mkdir "$handle.lock" 2>/dev/null || refuse 65 'handle exists; use send'
      host=$(hostname -s) || :
      exec node "$lane_script_dir/lane-cli.mjs" "$0" "$PWD" "$(command -v bash)" \
        admit-start "$handle" "$lane" "$cli" "$log" "$$" "$start_projection" "${start_fields[@]}" --arg host "$host" 3>"$handle.tmp.$$"
    fi
    read_fields parent launch_id thread label_time <<< "$(node -e '
      const { randomUUID } = require("node:crypto");
      const c = process.env.CLAUDE_CODE_SESSION_ID, x = process.env.CODEX_THREAD_ID;
      const id = c ?? x;
      const known = (c !== undefined) !== (x !== undefined) && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id ?? "");
      const parent = known ? {provider:c !== undefined ? "claude-code" : "codex",sessionId:id} : null;
      const thread = process.argv[1] === "claude" ? randomUUID() : "";
      process.stdout.write([JSON.stringify(parent), randomUUID(), thread, Math.floor(Date.now()/1000), ""].join("\0"));
    ' "$cli" | pack_fields)"
    label=com.whiteroom.wrsp-lane.$lane.$n.$label_time
    mkdir "$handle.lock" 2>/dev/null || refuse 65 'handle exists; use send'
    write_handle -n "${start_fields[@]}" --argjson parent "$parent" --arg host "$(hostname -s)" \
      --arg contact "$log" --arg launch_id "$launch_id" --arg thread "$thread" --arg label "$label" "$start_projection"
    if ! submit "$label"; then rm -f "$handle"; rmdir "$handle.lock"; refuse 69 'submission failed'; fi
    announce_turn started
    ;;
  send)
    when_idle=no; expected_turn=; await_pattern=; await_timeout=; await_seen=no; timeout_seen=no
    if [[ ${1:-} == --when-idle ]]; then when_idle=yes; shift; fi
    [[ $# -ge 2 && $1 != --* && $2 != --* && -r $2 ]] || refuse 64 'missing argument or unreadable message'
    send_handle=$1; input=$(absolute "$2"); shift 2
    while [[ $# -gt 0 ]]; do
      [[ $# -ge 2 ]] || refuse 64 'missing await argument'
      case $1 in
        --await) [[ $await_seen == no ]] || refuse 64 'duplicate --await'; await_seen=yes; await_pattern=$2;;
        --timeout) [[ $timeout_seen == no ]] || refuse 64 'duplicate --timeout'; timeout_seen=yes; await_timeout=$2;;
        *) refuse 64 'invalid send argument';;
      esac; shift 2
    done
    if [[ $await_seen == yes || $timeout_seen == yes ]]; then
      [[ $await_seen == yes && $timeout_seen == yes ]] || refuse 64 'expected --await PATTERN --timeout SECONDS'
      node "$lane_script_dir/lane-await.mjs" validate "$await_pattern" "$await_timeout" || exit $?
    fi
    load_admission "$send_handle" "$when_idle" || exit $?
    if [[ $when_idle == yes ]]; then
      expected_turn=$n
      while true; do
        load_wait_snapshot "$handle"
        # A live provider can publish its thread after the waiting client starts.
        if [[ -d $handle.lock && ! -e $log.exit ]] && live; then
          send_identity pending-thread || exit $?
        else
          send_identity || exit $?
        fi
        [[ $n == "$expected_turn" ]] || refuse 75 'another send advanced the lane while waiting'
        [[ -d $handle.lock ]] || break
        if [[ ! -e $log.exit ]] && ! live; then refuse 76 "interrupted turn $n; run lane.sh recover $handle"; fi
        sleep 1
      done
    else
      send_identity || exit $?
    fi
    if ! mkdir "$handle.lock" 2>/dev/null; then
      load "$handle"
      if [[ -n $expected_turn && $n != "$expected_turn" ]]; then refuse 75 'another send advanced the lane while waiting'; fi
      if live; then refuse 75 "busy, turn $n live (pid $pid)"; fi
      [[ ! -e $log.exit ]] || refuse 75 "busy, turn $n admission in progress"
      refuse 76 "interrupted turn $n; run lane.sh recover $handle"
    fi
    announced=no
    admit_send "$input" "$expected_turn" || exit $?
    if [[ $announced == no ]]; then announce_turn work-sent --input "$input"; fi
    if [[ $await_seen == yes ]]; then
      exec node "$lane_script_dir/lane-await.mjs" "$cli" "$log" "$n" "$await_pattern" "$await_timeout"
    fi
    ;;
  read)
    [[ $# -ge 1 ]] || refuse 64 'missing handle'
    read_handle=$1; shift
    full=no; finished=no; cursor=0; cursor_seen=no; ack_failed=no; no_message=no
    while [[ $# -gt 0 ]]; do
      case $1 in
        --full) [[ $full == no ]] || refuse 64 'duplicate --full'; full=yes; shift;;
        --finished) [[ $finished == no && $cursor_seen == no ]] || refuse 64 'invalid read arguments'; finished=yes; shift;;
        --ack-failed) [[ $ack_failed == no ]] || refuse 64 'duplicate --ack-failed'; ack_failed=yes; shift;;
        --no-message) [[ $no_message == no ]] || refuse 64 'duplicate --no-message'; no_message=yes; shift;;
        --cursor)
          [[ $finished == no && $cursor_seen == no && $# -ge 2 && $2 =~ ^[0-9]+$ ]] || refuse 64 'invalid read arguments'
          cursor=$2; cursor_seen=yes; shift 2;;
        *) refuse 64 'invalid read arguments';;
      esac
    done
    [[ $no_message == no || ( $finished == yes && $ack_failed == yes ) ]] || refuse 64 '--no-message requires --finished --ack-failed'
    [[ $ack_failed == no || $finished == yes ]] || refuse 64 '--ack-failed requires --finished'
    if [[ $finished == yes ]]; then
      load_admission "$read_handle" || exit $?
      if ! mkdir "$handle.lock" 2>/dev/null; then
        load "$handle"
        if live; then refuse 75 "busy, turn $n live (pid $pid)"; fi
        [[ ! -e $log.exit ]] || refuse 75 "busy, turn $n admission in progress"
        refuse 76 "interrupted turn $n; run lane.sh recover $handle"
      fi
      # The helper reloads under the same admission lock and never reads live logs.
      code=0
      read_args=(read "$handle")
      [[ $full != yes ]] || read_args+=(--full)
      [[ $ack_failed != yes ]] || read_args+=(--ack-failed)
      [[ $no_message != yes ]] || read_args+=(--no-message)
      node "$lane_script_dir/lane-finished.mjs" "${read_args[@]}" || code=$?
      rmdir "$handle.lock"
      exit "$code"
    fi
    load "$read_handle"
    node "$lane_script_dir/lane-output.mjs" "$log" "$cursor" "$full"
    ;;
  status)
    [[ $# -eq 1 || ( $# -eq 2 && $2 == --full ) ]] || refuse 64 'invalid status arguments'
    full=${2:-}; load "$1"
    if [[ $full == --full ]]; then
      jq -r '
        (. as $h | ["lane","role","title","cli","provider","role_id","model","effort","budget","issue","worktree","thread","turn"][] | . + ": " + ($h[.] // "" | tostring)),
        "service-tier: \(.serviceTier // "standard")\nverification-state: \(.verification.state // "unknown")\nverification-phase: \(.verification.phase // "unknown")\nreported-model: \(.verification.reported.model // "unknown")\nreported-effort: \(.verification.reported.effort // "unknown")\nnative-source: \(.verification.source // null | tojson)\nselection-reason: \(.selection_reason // "")"
      ' "$handle"
    else
      jq -r 'def short: tostring | gsub("[\r\n\t]"; " ") | .[0:160]; "lane: \(.lane | short)\nturn: \(.turn | short)\nverification-state: \(.verification.state // "unknown" | short)"' "$handle"
    fi
    lane_state=$(state)
    view status "$handle" "$PWD" "$(command -v bash)" "$full" "$(absolute "$handle")" "$log" "$next_exchange" "$lane_state"
    ;;
  recover)
    [[ $# -eq 1 ]] || refuse 64 'missing handle'; load "$1"
    send_role || exit $?
    [[ -d $handle.lock && ! -e ${log}.exit ]] && ! live || refuse 78 'turn is not interrupted'
    printf 'EXIT:70\n' >> "$log"; printf '70\n' > "${log}.exit"
    rmdir "$handle.lock"; printf 'RECOVERED turn %s\n' "$n"
    ;;
  run-turn)
    [[ $# -eq 3 ]] || refuse 64 'missing turn'
    label=$3; trap 'remove_job "$label"' EXIT
    load "$1"
    [[ $n == "$2" && -d $handle.lock ]] || refuse 78 'turn not admitted'
    if [[ -e ${log}.pid || -e ${log}.exit ]]; then
      printf 'RESPAWN REFUSED: turn %s already ran (pid file present); run lane.sh recover %s\n' "$n" "$handle" >> "$log"
      exit 79
    fi
    launch_id=$(jq -r .launch_id "$handle"); usage_bin=${WRSP_USAGE_BIN:-wrsp-usage}
    work_input= agy_state_failed=0
    finish() {
      local code=$1
      trap - EXIT
      if [[ $(jq -r '.verification.state // ""' "$handle") == pending ]]; then
        local abort_report='.verification | .state="refused" | .reason="turn aborted before native acceptance (exit " + $code + ")"'
        if [[ $cli == agy ]]; then
          save_verification yes "$abort_report" --arg code "$code" || code=73
        else
          save_verification yes "$abort_report" --arg code "$code"
        fi
      fi
      [[ $agy_state_failed == 0 ]] || code=73
      [[ $(tail -n 1 "$log" 2>/dev/null) == "EXIT:$code" ]] || printf 'EXIT:%s\n' "$code" >> "$log"
      if [[ $cli == agy ]] && ! agy_write_state "${log}.exit" "$code"; then
        code=73
        printf 'EXIT:%s\n' "$code" >> "$log"
      fi
      record_fact launch-record exit --launch-id "$launch_id" --exit-code "$code" --log "$log"
      if [[ $cli != agy ]]; then
        printf '%s\n' "$code" > "${log}.exit.tmp.$$"; mv -f "${log}.exit.tmp.$$" "${log}.exit"
      fi
      [[ -z $work_input ]] || rm -f "$work_input"
      rmdir "$handle.lock" 2>/dev/null || true
      remove_job "$label"
      exit "$code"
    }
    trap 'finish 70' EXIT
    if [[ $cli == agy ]]; then
      agy_write_state "${log}.pid" "$$" || finish 73
    else
      printf '%s\n' "$$" > "${log}.pid.tmp.$$"; mv -f "${log}.pid.tmp.$$" "${log}.pid"
    fi
    read_fields model effort budget thread input title issue service_tier <<< "$(
      json_fields '[.model, .effort, .budget, .thread, .turns[-1].input, .title, .issue, (.serviceTier // "")]' "$handle" | pack_fields
    )"
    roles=${WRSP_ROLES_DIR:-$HOME/.agents/roles}
    lane_start_fact() {
      local parent_provider parent_session
      node "$lane_script_dir/../../developer/scripts/retain-brief.mjs" --worktree "$worktree" --brief "$input" --issue "$issue" --launch-id "$launch_id" >> "$log" 2>&1 || finish 66
      args=(launch-record start --launch-id "$launch_id" --issue "$issue" --role "$role" --cli "$cli" --model "$model" --effort "$effort" --worktree "$worktree" --brief "$input" --log "$log")
      [[ -z $service_tier ]] || args+=(--service-tier "$service_tier")
      [[ $cli != claude ]] || args+=(--child-session "$thread")
      if read_fields parent_provider parent_session <<< "$(json_fields 'select(.parent != null) | [.parent.provider, .parent.sessionId]' "$handle" | pack_fields)"; then
        args+=(--parent-provider "$parent_provider" --parent-session "$parent_session")
      fi
      record_fact "${args[@]}"
    }
    if [[ $n == 1 ]]; then lane_start_fact; fi
    if [[ ! -d $worktree ]]; then
      printf 'REFUSED: lane %s: worktree %s is missing; recreate it for this issue or start a new lane for a new issue\n' "$lane" "$worktree" >> "$log"
      trap - EXIT; finish 80
    fi
    cd "$worktree"
    write_handle "$pending_verification" "$handle"
    fail_pair() {
      save_verification "${2:-no}" '.verification | .state="refused" | .reason=$reason' --arg reason "$1"
    }
    [[ $role != developer || $role_id == developer ]] || { fail_pair 'developer requires --role-id developer'; finish 64; }
    [[ $role != principal-engineer || $role_id == principal-engineer ]] || { fail_pair 'principal-engineer requires --role-id principal-engineer'; finish 64; }
    [[ $model != gemini-4-neon || $cli == agy ]] || { fail_pair 'gemini-4-neon requires --cli agy (#567)'; finish 64; }
    [[ $cli != agy ]] || agy_selection || { fail_pair 'agy requires a gemini-4-neon developer pair with a supported effort'; finish 64; }
    if [[ -n $service_tier ]]; then
      [[ $service_tier == fast ]] || { fail_pair "unsupported handle serviceTier: $service_tier"; finish 64; }
      [[ $cli != agy ]] || { fail_pair '--fast is not supported for --cli agy (#570)'; finish 64; }
      [[ $cli != claude || $model == claude-opus-5-5 || $model == claude-opus-5 ]] || { fail_pair "--fast is only supported for claude-opus-5-5 and claude-opus-5 on --cli claude, not $model (#570)"; finish 64; }
    fi
    if ! { work_input=$(mktemp "${log}.work-input.XXXXXX") && { printf '%s\n\n%s\n\n' "$sender" "$browser_preamble" && cat "$input"; } > "$work_input"; } 2>> "$log"; then
      printf 'REFUSED: work input could not be read: %s\n' "$input" >> "$log"
      finish 66
    fi
    turn_runtime=$lane_script_dir/../../../dist/lane
    if [[ -d $lane_script_dir/lane-runtime ]]; then turn_runtime=$lane_script_dir/lane-runtime; fi
    # agy-worker binds its lease and producing marker to its direct Bash
    # parent. Keep that dispatcher on the existing route.
    compiled_timeout=${WRSP_LANE_BOOTSTRAP_TIMEOUT:-$default_lane_reply_timeout}
    if [[ ( $cli == claude || $cli == codex ) && $handle == /* && $log == /* && $input == /* && $worktree == "$PWD" &&
          ( $n != 1 || $compiled_timeout =~ ^[1-9][0-9]{0,4}$ ) &&
          $budget =~ ^[1-9][0-9]{0,14}$ && -r $lane_script_dir/lane-cli.mjs &&
          -r $turn_runtime/turn.mjs && -r $turn_runtime/bootstrap.mjs ]]; then
      coordinator_pid=; coordinator_signal=; coordinator_interrupted=no
      relay_turn_signal() {
        [[ -n $coordinator_signal ]] || coordinator_signal=$1
        coordinator_interrupted=yes
        if [[ -n $coordinator_pid ]]; then kill "-$1" "$coordinator_pid" 2>/dev/null || :; fi
      }
      acknowledge_turn_checkpoint() {
        coordinator_interrupted=yes
        printf '%s\n' "$coordinator_signal" > "$work_input.signal"
        kill -USR2 "$coordinator_pid" 2>/dev/null || :
      }
      trap 'relay_turn_signal TERM' TERM
      trap 'relay_turn_signal INT' INT
      trap acknowledge_turn_checkpoint USR1
      node "$lane_script_dir/lane-cli.mjs" "$lane_script_dir/lane.sh" "$PWD" '' \
        owned-turn "$handle" "$log" "$n" "$cli" "$role" "$role_id" "$model" "$effort" "$budget" "$service_tier" "$thread" "$PWD" \
        "$work_input" "$input" "$issue" "$title" "$launch_id" "$$" "$sender"$'\n\n'"$bootstrap_prompt" \
        "$0" "$dispatch_work" "$redirect_output" "$record_launch" &
      coordinator_pid=$!
      if [[ -n $coordinator_signal ]]; then relay_turn_signal "$coordinator_signal"; fi
      while :; do
        coordinator_interrupted=no
        code=0; wait "$coordinator_pid" || code=$?
        [[ $coordinator_interrupted == yes ]] || break
      done
      trap - TERM INT USR1
      if [[ -r $work_input.signal ]] &&
        { IFS= read -r completed_code && IFS= read -r completed_launch; } < "$work_input.signal" &&
        [[ $completed_code == "$code" ]]; then
        launch_id=$completed_launch
      else
        # Loss of the coordinator before it reports completion is an abort
        # of the owned turn. The Bash owner still publishes exit evidence.
        code=70
        if [[ $n == 1 ]] && latest_launch=$(jq -r .launch_id "$handle"); then launch_id=$latest_launch; fi
      fi
      rm -f "$work_input.signal"
      finish "$code"
    fi
    if [[ $cli == codex && $role == developer ]]; then
      fail_pair 'Codex developer work requires the installed turn coordinator (#585)'
      finish 66
    fi
    validate() {
      local phase=$1 anchor=${2:-} validation_code=0
      local args=(--cli "$cli" --role-id "$role_id" --model "$model" --effort "$effort" --session "$thread" --offset "$offset")
      if [[ $cli == agy && $phase != bootstrap ]]; then
        local prefix_end prefix_sha
        read_fields prefix_end prefix_sha <<< "$(json_fields '[.source.end, .source.prefixSha256]' <<< "$anchor" | pack_fields)" || return 81
        args+=(--prefix-end "$prefix_end" --prefix-sha256 "$prefix_sha")
      fi
      if [[ $phase == bootstrap ]]; then
        verification=$(native bootstrap "$native_path" "${args[@]}" 2>> "$log") || validation_code=$?
        case $validation_code in
          82) fail_pair 'native transcript missing or ambiguous after bootstrap'; return 81 ;;
          83) fail_pair 'native transcript path changed during bootstrap'; return 81 ;;
        esac
      else
        verification=$(native "$phase" "${args[@]}" --transcript "$native_path") || validation_code=$?
      fi
      if [[ -z $verification ]]; then fail_pair 'native validator aborted without a report' yes; return 81; fi
      if ! save_verification no '$report_value' --argjson report_value "$verification"; then
        if [[ $cli == agy ]]; then finish 73; fi
        if [[ $phase == resume && $validation_code == 0 ]]; then finish 70; fi
      fi
      return "$validation_code"
    }
    native_path=; offset=0
    if [[ -n $thread ]]; then
      discovery_code=0; native_path=$(native find "$cli" "$thread" 2>> "$log") || discovery_code=$?
      if [[ $discovery_code != 0 && ( $n != 1 || $discovery_code != 82 ) ]]; then fail_pair 'native transcript missing or ambiguous before qualification'; finish 81; fi
      # A fresh UUID normally has no file; an existing identity always starts at its current end.
      if [[ -n $native_path ]]; then offset=$(wc -c < "$native_path"); offset=${offset//[[:space:]]/}; fi
    fi
    save_verification no '.verification | .source.path=(if $path == "" then null else $path end) | .source.start=$offset | .source.end=$offset' \
      --arg path "$native_path" --argjson offset "$offset"
    if [[ $n == 1 ]]; then
      code=0
      if [[ $cli == agy ]]; then
        write_bootstrap_input || finish 66
        agy_dispatch "$log.bootstrap-input" "$log.bootstrap.log" "${WRSP_LANE_BOOTSTRAP_TIMEOUT:-$default_lane_reply_timeout}" '' || code=$?
        if [[ $code != 73 ]]; then agy_session_fact; fi
        write_handle --arg thread "$thread" '.thread=$thread' "$handle"
      else
        bootstrap_signal_code=0
        bootstrap >> "$log.bootstrap.log" 2>&1 || code=$?
        trap - TERM INT
        [[ $bootstrap_signal_code == 0 ]] || code=$bootstrap_signal_code
      fi
      if [[ $code != 0 ]]; then fail_pair "bootstrap CLI exited $code; see $log.bootstrap.log"; finish "$code"; fi
      write_handle --arg thread "$thread" --arg launch "$launch_id" '.thread=$thread | .launch_id=$launch' "$handle"
      if [[ $cli == codex ]]; then
        if [[ -n $thread ]]; then
          write_handle --arg thread "$thread" '.thread=$thread' "$handle"
          save_verification no '.verification | .source.session=$thread' --arg thread "$thread"
        fi
      fi
      [[ -n $thread ]] || { fail_pair 'native session identity missing from bootstrap'; finish 81; }
      validate bootstrap || finish 81
      native_path=$recorded_path
    else
      if ! read_fields qualification qualification_path offset <<< "$(json_fields '
        (if has("qualification") then .qualification else .turns[-2].verification end) |
        select(.state == "accepted") | [., .source.path, .source.start]
      ' "$handle" | pack_fields)"; then
        fail_pair 'no accepted native qualification; start a qualified new lane'; finish 81
      fi
      [[ $native_path == "$qualification_path" ]] || { fail_pair 'native transcript path changed since qualification'; finish 81; }
      validate resume "$qualification" || finish 81
    fi
    offset=$recorded_end
    prework=$verification
    save_verification no '$report_value | .phase="work" | .state="pending" | .reported={model:null,effort:null,nativeEffort:null} | .source.start=$offset | .source.end=$offset' \
      --argjson report_value "$verification" --argjson offset "$offset"
    code=0
    if [[ $cli == agy ]]; then
      agy_dispatch "$work_input" "$log" "$default_lane_reply_timeout" "$thread" || code=$?
    else
      provider_command no stream-json || finish 66
      if [[ $cli == claude ]]; then
        node "$lane_script_dir/lane-claude-work.mjs" "$log" "$thread" /bin/bash -c "$dispatch_work" \
          "$0" "$work_input" "$log" "${cmd[@]}" || code=$?
      else
        /bin/bash -c "$dispatch_work" "$0" "$work_input" "$log" "${cmd[@]}" || code=$?
      fi
    fi
    validation_code=0; validate work "$prework" || validation_code=$?
    if [[ $code != 0 ]]; then
      printf 'NATIVE CLI EXIT: %s during work; pair report does not replace the native exit\n' "$code" >> "$log"
    elif [[ $validation_code != 0 ]]; then code=81; fi
    if [[ $cli == agy && $code == 0 ]]; then
      outcome=$log.agy.result.json
      if [[ ! -f $outcome || -L $outcome ]] || ! result=$(jq -ces --arg thread "$thread" '
        select(length == 1) | .[0] |
        select(.id == $thread and .code == 0 and .produced == true and .providerStatus == "SUCCESS" and (.response | type == "string" and length > 0)) |
        {type:"agy.result",conversation_id:.id,response}
      ' "$outcome" 2>> "$log"); then
        fail_pair 'missing or invalid contained agy result'
        code=81
      else
        printf '%s\n' "$result" >> "$log"
      fi
    fi
    snapshot=$(view context-snapshot "$handle") || snapshot=$(jq -nc --argjson turn "$n" '{turn:$turn,inputTokens:null,budget:null}')
    if [[ $cli == agy ]]; then
      write_handle --argjson snapshot "$snapshot" '.context=$snapshot' "$handle" || finish 73
    elif /bin/bash -c "$redirect_output" "$0" "$handle.tmp.$$" jq --argjson snapshot "$snapshot" '.context=$snapshot' "$handle"; then
      mv -f "$handle.tmp.$$" "$handle" || printf 'WARNING: context snapshot could not be stored\n' >&2
    else
      printf 'WARNING: context snapshot unavailable\n' >&2
    fi
    trap - EXIT; finish "$code"
    ;;
  *) refuse 64 'unknown subcommand';;
esac
