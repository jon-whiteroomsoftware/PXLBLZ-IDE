#!/usr/bin/env bash
# Launch one confined one-shot worker, researcher or locator.
# WRSP #114, #441. Developer issue work uses lane.sh.
set -euo pipefail
# Test-only (#548): WRSP_TEST_LAUNCH_WAIT_DIVISOR=N (integer 1-100) divides the fixed
# 1 s and 0.1 s sleeps below and multiplies their poll caps, keeping nominal deadlines.
# Unset keeps the exact production waits; any other value warns and keeps them too.
launch_wait_divisor=1 launch_second_wait=1 launch_tenth_wait=0.1
if [[ -n ${WRSP_TEST_LAUNCH_WAIT_DIVISOR+set} ]]; then
  if [[ $WRSP_TEST_LAUNCH_WAIT_DIVISOR =~ ^([1-9][0-9]?|100)$ ]]; then
    launch_wait_divisor=$WRSP_TEST_LAUNCH_WAIT_DIVISOR
    printf -v launch_second_wait '%d.%06d' $(( 1000000 / launch_wait_divisor / 1000000 )) $(( 1000000 / launch_wait_divisor % 1000000 ))
    printf -v launch_tenth_wait '0.%06d' $(( 100000 / launch_wait_divisor ))
  else
    echo "WARNING: WRSP_TEST_LAUNCH_WAIT_DIVISOR must be an integer from 1 to 100; using the default waits (WRSP #548)." >&2
  fi
fi
readonly browser_facts='{"runner":"repo-playwright","iab":"unavailable"}'
readonly browser_preamble="Headless browser capability: browser=$browser_facts. Use the repository's Playwright runner directly for UI verification; skip the in-app-browser probe and fallback announcement."

usage() {
  cat >&2 <<'USAGE'
Usage: launch-worker.sh --cli <codex|claude|agy> --role-id <id> --model <id> --effort <level>
                        --worktree <dir> --brief <file> --log <file> --issue <N>
                        [--profile <codex-profile>] [--fast] [--allow-phrase-hits] [--research] [--locate] [--dry-run] [--detach]
                        [--batch-work-dir <dir> --batch-ledger-home <dir>]
                        [--conversation <uuid> --print-timeout <seconds> (agy)] [--selection-reason <text> (agy developer)]
                        [--launchd-label <label> (internal)] [--context-budget <tokens> (internal)] [--parent-session <provider>:<id> (internal)]
Composes <role instructions> + <brief> into <log>.prompt.md, refuses briefs
that fail the execution policy's banned-phrase check, and runs the worker in
the foreground with all output in <log>. --detach submits it to launchd.
--locate answers one where-question synchronously with read-only search tools and prints the answer;
its --issue is optional and, when given, records the launch as role locator (#240).
Before dispatch, retains the original brief in the repository's artifacts Files root.
WRSP_RUNNER_HOME overrides discovery from the dashboard LaunchAgent plist (#427).
WRSP_LAUNCH_BACKOFF_OVERRIDE=1 bypasses advisory marker admission and records the override.
Successful detached launch prints NEXT: JSON with action, cwd and argv for wrsp-wait.
Pass argv as separate arguments from cwd; retain the full returned log handle.
USAGE
  exit 64
}
# #248: progress signals shared with wrsp-wait.sh.
source "$(cd "$(dirname "$0")" && pwd -P)/worker-progress.sh"

cli= role_id= model= effort= worktree= brief= log= profile= fast=0 allow_hits=0 research=0 locate=0 dry_run=0 detach=0 launchd_label= context_budget= before= issue= parent_session= child_session= launch_id= snapshot_pid= session_pid=
npm_cache= npm_cache_created=0
batch_paths=0 batch_work_dir= batch_ledger_home= batch_snapshot_dir=
record_pid= retry_owned=0 # #248
agy_worker= conversation= print_timeout= selection_reason=
dispatch_common_dir= dispatch_repository= dispatch_mode=
cleanup() {
  if [[ -n $before ]]; then rm -f "$before"; fi
  if [[ ${npm_cache_created:-0} -eq 1 && -n ${npm_cache:-} ]]; then rm -rf -- "$npm_cache"; fi
  if [[ -n $launchd_label ]]; then launchctl remove "$launchd_label" >/dev/null 2>&1 || true; fi
}
otel_encode() {
  local LC_ALL=C value=$1 byte encoded code i
  for ((i=0; i<${#value}; i++)); do
    byte=${value:i:1}
    case "$byte" in
      [A-Za-z0-9._~-]) printf '%s' "$byte" ;;
      *) printf -v code '%d' "'$byte"; printf -v encoded '%%%02X' $(( code & 255 )); printf '%s' "$encoded" ;;
    esac
  done
}
otel_attrs() { # otel_attrs <role>
  local repo inherited=${OTEL_RESOURCE_ATTRIBUTES:-} item result= i has_host=
  repo=$(git -C "$worktree" -c core.fsmonitor=false -c core.hooksPath=/dev/null config --get remote.origin.url 2>/dev/null || true)
  repo=${repo%%[?#]*}
  repo=${repo%/}
  repo=${repo##*/}
  repo=${repo##*:}
  repo=${repo%.git}
  if [[ $inherited =~ [^[:space:]] ]]; then
    while [[ -n $inherited ]]; do
      item=${inherited%%,*}
      if [[ -n $item && $item != wrsp.* ]]; then
        result+="${result:+,}$item"
        if [[ ${item%%=*} == host.name ]]; then has_host=1; fi
      fi
      [[ $inherited == *,* ]] || break
      inherited=${inherited#*,}
    done
  fi
  if [[ -z $has_host ]]; then
    local host; host=$(hostname 2>/dev/null || true)
    if [[ -n $host ]]; then result+="${result:+,}host.name=$(otel_encode "$host")"; fi
  fi
  local keys=(wrsp.role wrsp.repo wrsp.issue wrsp.launch_id)
  local values=("$1" "$repo" "$issue" "$launch_id")
  for ((i=0; i<${#keys[@]}; i++)); do
    [[ -n ${values[i]} ]] || continue
    result+="${result:+,}${keys[i]}=$(otel_encode "${values[i]}")"
  done
  printf '%s' "$result"
}
while [[ $# -gt 0 ]]; do
  case "$1" in
    --cli|--role-id|--model|--effort|--worktree|--brief|--log|--profile|--launchd-label|--context-budget|--issue|--parent-session|--batch-work-dir|--batch-ledger-home|--conversation|--print-timeout|--selection-reason|--dispatch-common-dir|--dispatch-repository) [[ $# -ge 2 ]] || usage ;;
  esac
  case "$1" in
    --cli) cli=$2; shift 2 ;;
    --role-id) role_id=$2; shift 2 ;;
    --model) model=$2; shift 2 ;;
    --effort) effort=$2; shift 2 ;;
    --worktree) worktree=$2; shift 2 ;;
    --brief) brief=$2; shift 2 ;;
    --log) log=$2; shift 2 ;;
    --issue) issue=$2; shift 2 ;;
    --parent-session) parent_session=$2; shift 2 ;;
    --batch-work-dir) batch_paths=1; batch_work_dir=$2; shift 2 ;;
    --batch-ledger-home) batch_paths=1; batch_ledger_home=$2; shift 2 ;;
    --profile) profile=$2; shift 2 ;;
    --conversation) [[ -n $2 ]] || usage; conversation=$2; shift 2 ;;
    --print-timeout) [[ -n $2 ]] || usage; print_timeout=$2; shift 2 ;;
    --selection-reason) [[ $2 =~ [^[:space:]] && $2 != *$'\n'* && $2 != *$'\r'* ]] || usage; selection_reason=$2; shift 2 ;;
    --dispatch-common-dir) [[ -z $dispatch_common_dir && -n $2 ]] || usage; dispatch_common_dir=$2; shift 2 ;;
    --dispatch-repository) [[ -z $dispatch_repository && -n $2 ]] || usage; dispatch_repository=$2; shift 2 ;;
    --allow-phrase-hits) allow_hits=1; shift ;;
    --fast) fast=1; shift ;;
    --research) research=1; shift ;;
    --locate) locate=1; shift ;;
    --dry-run) dry_run=1; shift ;;
    --detach) detach=1; shift ;;
    --launchd-label) launchd_label=$2; trap cleanup EXIT; shift 2 ;;
    --context-budget) context_budget=$2; shift 2 ;;
    *) usage ;;
  esac
done
[[ -n $cli && -n $model && -n $effort && -n $worktree && -n $brief && -n $log ]] || usage
case "$cli" in codex|claude|agy) ;; *) usage ;; esac
refuse() { # refuse <exit code> <message line>...
  local code=$1 message
  shift
  message=$(printf '%s\n' "$@")
  printf '%s\n' "$message" >&2
  printf 'LAUNCH REFUSED: %s\n' "$(printf '%s' "$message" | paste -sd '|' - | sed 's/|/ | /g')"
  # A handle another launch owns keeps its state; wrsp-wait reads .refused before liveness (#122).
  if [[ $retry_owned -eq 0 && -d $(dirname "$log") && ! -e ${log}.availability && ! -L ${log}.availability && ( -n $launchd_label || ( ! -e $log && ! -L $log && ! -e ${log}.pid && ! -L ${log}.pid && ! -e ${log%.log}.prompt.md && ! -L ${log%.log}.prompt.md ) ) ]]; then printf 'LAUNCH REFUSED: %s\n' "$message" > "${log}.refused"; fi
  exit "$code"
}
[[ -n $role_id ]] || refuse 64 "Refusing launch: --role-id <id> is required (#243)."
[[ $role_id != builder ]] || refuse 64 'Refusing launch: builder role was retired (#441); use a developer lane for issue work.'
[[ $model != gemini-4-neon || $cli == agy ]] || refuse 64 'Refusing launch: gemini-4-neon requires --cli agy (#567).'
if [[ $cli == agy ]]; then
  [[ $locate -eq 0 && -z $profile && $batch_paths -eq 0 ]] ||
    refuse 64 'Refusing agy launch: locator, profile and batch path options are unsupported (#567).'
  case "$role_id:$research" in
    developer:0) agy_lane=1 ;;
    researcher:1) agy_lane=researcher ;;
    *) refuse 64 'Refusing agy launch: use --role-id developer or --role-id researcher --research (#567).' ;;
  esac
  [[ $research -eq 0 || -z $conversation ]] ||
    refuse 64 'Refusing agy launch: researcher mode requires a fresh conversation (#567).'
  [[ $model == gemini-4-neon && $effort =~ ^(low|med|medium|high|xhigh)$ ]] ||
    refuse 64 'Refusing agy launch: use model gemini-4-neon and a supported Neon effort (#566).'
  [[ -z $conversation || $conversation =~ ^[[:xdigit:]]{8}-[[:xdigit:]]{4}-[[:xdigit:]]{4}-[[:xdigit:]]{4}-[[:xdigit:]]{12}$ ]] ||
    refuse 64 'Refusing agy launch: --conversation needs a UUID (#566).'
  print_timeout=${print_timeout:-600}
  [[ $print_timeout =~ ^[1-9][0-9]{0,4}$ ]] && (( print_timeout <= 86400 )) ||
    refuse 64 'Refusing agy launch: --print-timeout needs positive seconds up to 86400 (#566).'
  agy_worker="$(cd "$(dirname "$0")" && pwd -P)/agy-worker.mjs"
elif [[ -n $conversation || -n $print_timeout ]]; then
  refuse 64 'Refusing launch: --conversation and --print-timeout are agy-only (#566).'
fi
if [[ -n $selection_reason && ( $cli != agy || $role_id != developer ) ]]; then
  refuse 64 'Refusing launch: --selection-reason is for agy developers (#571).'
fi
if [[ $fast -eq 1 ]]; then
  if [[ $cli == agy ]]; then
    refuse 64 'Refusing launch: --fast is not supported for --cli agy (#570).'
  elif [[ $cli == claude && $model != claude-opus-5-5 && $model != claude-opus-5 ]]; then
    refuse 64 "Refusing launch: --fast is only supported for claude-opus-5-5 and claude-opus-5 on --cli claude, not $model (#570)."
  fi
fi
selector="role:$role_id"
selector_args=(--role-id "$role_id")
member_kind=role member_label=$role_id
members=${WRSP_ROLES_MEMBERS:-$HOME/.agents/roles.members}
if [[ $locate -eq 0 && ! $issue =~ ^[1-9][0-9]*$ ]]; then
  refuse 64 'Refusing launch: --issue <N> is required for worker and research launches (#196).'
fi
if [[ $locate -eq 1 && -n $issue && ! $issue =~ ^[1-9][0-9]*$ ]]; then
  refuse 64 'Refusing launch: a locator --issue must be an issue number (#240).'
fi
# Launch facts: every worker and research launch, and a locator launch given --issue (#196, #240).
records=1
[[ $locate -eq 1 && -z $issue ]] && records=0
usage_bin=${WRSP_USAGE_BIN:-wrsp-usage}
record_fact() { # record_fact <wrsp-usage args...>; never fails the launch (#196)
  if ! command -v "$usage_bin" >/dev/null 2>&1; then
    echo "WARNING: launch record not written: $usage_bin is not on PATH (#196)." >> "$log"
    return 0
  fi
  "$usage_bin" "$@" >/dev/null 2>>"$log" || echo "WARNING: launch record not written: $usage_bin $1 $2 exited $? (#196)." >> "$log"
  return 0
}
if [[ -z $launchd_label && -z $parent_session && -n ${CLAUDE_CODE_SESSION_ID:-} ]]; then
  parent_session="claude-code:$CLAUDE_CODE_SESSION_ID"
fi
# WRSP #134: every path checks membership, the launchd child included, so a members edit after submission or a direct --launchd-label cannot bypass it.
roles=${WRSP_ROLES_DIR:-$HOME/.agents/roles}
# WRSP #253: execution workers and researchers share the installed search bound.
ripgrep_config=${WRSP_RIPGREP_CONFIG:-$HOME/.agents/ripgreprc}
# WRSP #180: launchd does not keep this shell's directory, so forward an absolute path.
[[ $roles == /* ]] || roles=$PWD/$roles
# WRSP #253: the worker and the launchd child run elsewhere, so resolve a relative override here.
[[ $ripgrep_config == /* ]] || ripgrep_config=$PWD/$ripgrep_config
if [[ ! -s $members ]]; then
  refuse 66 "Role members not found: $members. Run wrsp-agents install."
fi
member_effort=$effort
[[ $member_effort == medium ]] && member_effort=med
# WRSP #172: the fourth field is the member's context budget in tokens.
if ! member=$(awk -F '\t' -v label="$member_label" -v model="$model" -v e="$member_effort" \
  '!/^#/ && $1==label && $2==model && $3==e { print "match\t" $4; exit }' "$members") || [[ -z $member ]]; then
  refuse 65 "Refusing launch: $model / $effort is not a member of $member_kind $member_label in $members. Launch a listed member, or edit templates/roles.yaml in WRSP and run wrsp-agents install."
fi
if [[ -z $launchd_label ]]; then
  context_budget=${member#match$'\t'}
  if [[ ! $context_budget =~ ^[1-9][0-9]*$ ]]; then
    refuse 66 "Refusing launch: $members has no context budget for $member_kind $member_label / $model / $member_effort; it was rendered before WRSP #172. Run wrsp-agents install."
  fi
fi
if [[ -n $launchd_label && ! $context_budget =~ ^[1-9][0-9]*$ ]]; then
  refuse 66 'Refusing launch: the detached relaunch has no --context-budget (WRSP #172).'
fi
# WRSP #325: membership carries the sole catalog reserve; budgets stay absolute.
if [[ $cli == claude ]]; then
  if ! reserve=$(awk -F '\t' '/^# claude-auto-compact-reserve([[:space:]]|$)/ { count++; if (NF == 2 && $1 == "# claude-auto-compact-reserve" && $2 ~ /^[1-9][0-9]*$/) value=$2; else invalid=1 } END { if (count != 1 || invalid) exit 1; print value }' "$members"); then
    refuse 66 "Refusing launch: $members has no valid Claude compaction reserve (WRSP #325). Run wrsp-agents install."
  fi
  auto_compact_window=$((context_budget + reserve))
fi
# WRSP #178, #441: every execution and Codex research launch, the launchd child included, applies the neutral confinement profile.
role_settings= role_overrides=()
if [[ $cli != agy && $locate -eq 0 && ( $research -eq 0 || $cli == codex ) ]]; then
  if [[ $cli == claude ]]; then role_file=$roles/restricted.claude.json; else role_file=$roles/restricted.codex.args; fi
  [[ -f $role_file && -r $role_file && -s $role_file ]] || refuse 66 "Refusing launch: restricted execution profile not found: $role_file. Run wrsp-agents install (WRSP #178)."
  if [[ $cli == claude ]]; then
    if ! role_settings=$(jq -cs --argjson b "$auto_compact_window" 'if length == 1 and (.[0] | type) == "object" then .[0] + {autoCompactWindow: $b} else error("not one object") end' "$role_file" 2>/dev/null) \
      || ! jq -e 'type == "object" and (.permissions | type) == "object" and (.permissions.deny | type) == "array" and (.permissions.deny | length) > 0 and all(.permissions.deny[]; type == "string" and length > 0)' <<<"$role_settings" >/dev/null 2>&1; then
      refuse 66 "Refusing launch: restricted execution profile $role_file is not a valid restricted profile (WRSP #178)."
    fi
  else
    role_line_number=0
    skills_re='^skills\.config=\[\{name="[A-Za-z0-9_:-]+",enabled=false\}(,\{name="[A-Za-z0-9_:-]+",enabled=false\})*\]$'
    while IFS= read -r role_line || [[ -n $role_line ]]; do
      role_line_number=$((role_line_number + 1))
      [[ -z $role_line || $role_line == '#'* ]] && continue
      [[ $role_line =~ ^[A-Za-z0-9_.-]+=(true|false)$ || $role_line =~ $skills_re ]] || refuse 66 "Refusing launch: restricted execution profile $role_file line $role_line_number is not a key=true|false override or a skills.config list of {name=\"<skill>\",enabled=false} entries (WRSP #178, #186)."
      role_overrides+=(-c "$role_line")
    done < "$role_file"
    [[ ${#role_overrides[@]} -gt 0 ]] || refuse 66 "Refusing launch: restricted execution profile $role_file has no key=value override (WRSP #178)."
  fi
fi
# WRSP #253: locators keep their existing launch environment.
if [[ $locate -eq 0 ]]; then
  [[ -f $ripgrep_config && -r $ripgrep_config && -s $ripgrep_config ]] || refuse 66 "Refusing launch: ripgrep config not found: $ripgrep_config. Run wrsp-agents install (WRSP #253)."
fi
if [[ $locate -eq 1 && $research -eq 1 ]]; then
  refuse 64 '--locate and --research are separate modes.'
fi
if [[ $locate -eq 1 && $detach -eq 1 ]]; then
  refuse 64 '--locate runs synchronously; drop --detach.'
fi
if [[ $locate -eq 1 && -n $profile ]]; then
  refuse 64 '--locate always uses the locator Codex profile; drop --profile.'
fi
# #556: one-shot work honors the requested role; dedicated modes retain theirs.
launch_role=$role_id
[[ $research -eq 1 ]] && launch_role=researcher
[[ $locate -eq 1 ]] && launch_role=locator
# The requested label grants nothing. Confinement follows the execution mode.
plan_review=0
[[ $research -eq 0 && $locate -eq 0 && $role_id == reviewer ]] && plan_review=1
worker_marker=batch
[[ $plan_review -eq 1 ]] && worker_marker=reviewer
[[ $research -eq 1 ]] && worker_marker=researcher
[[ $locate -eq 1 ]] && worker_marker=locator
if [[ ${WRSP_CODEX_DEVELOPER_LANE:-} == 1 ]]; then
  lane_one_shot=
  case "$worker_marker" in
    reviewer) lane_one_shot=plan-review ;;
    researcher) lane_one_shot=research ;;
    locator) lane_one_shot=locate ;;
  esac
  if [[ -n $lane_one_shot ]]; then
    refuse 66 "From a live lane work turn, run wrsp-lane-dispatch one-shot $lane_one_shot --model <id> --effort <effort> --brief <file> (WRSP #585)."
  fi
fi
if [[ -n $dispatch_common_dir || -n $dispatch_repository ]]; then
  [[ -n $dispatch_common_dir && -n $dispatch_repository ]] ||
    refuse 66 'Dispatch context requires both the shared Git common directory and the repository identity.'
  if [[ $detach -ne 0 || -n $launchd_label || -n $profile || $batch_paths -ne 0 || -z $issue ]]; then
    refuse 66 'Dispatch context requires a foreground, issue-bound, read-only one-shot.'
  fi
  case "$role_id:$research:$locate" in
    reviewer:0:0) dispatch_mode=plan-review ;;
    researcher:1:0) dispatch_mode=research ;;
    locator:0:1) dispatch_mode=locate ;;
    *) refuse 66 'Dispatch context requires a foreground, issue-bound, read-only one-shot.' ;;
  esac
  if ! dispatch_repository=$(jq -ces '
    select(length == 1) | .[0]
    | select(type == "object" and keys == ["originUrl", "rootCommit"]
      and (.rootCommit | type == "string" and test("^[a-f0-9]{40}([a-f0-9]{24})?$"))
      and (.originUrl | . == null or type == "string"))' <<<"$dispatch_repository" 2>/dev/null); then
    refuse 66 'Invalid dispatched repository identity.'
  fi
fi
[[ -d $worktree ]] || { refuse 66 "Worktree not found: $worktree"; }
read_only_helper= read_only_policy= read_only_overrides=()
if [[ -n $dispatch_mode || ( $cli != agy && ( $locate -eq 1 || $research -eq 1 || $plan_review -eq 1 ) ) ]]; then
  read_only_dir=$(cd "$(dirname "$0")" && pwd -P)
  [[ -r $read_only_dir/read-only-launch-profile.mjs || ! -d $read_only_dir/../../../dist ]] || read_only_dir=$read_only_dir/../../../dist
  read_only_helper=$read_only_dir/read-only-launch-profile.mjs
  if [[ ! -r $read_only_helper || ! -r $read_only_dir/codex-lane-profile.mjs ]]; then
    refuse 66 'Read-only launch profile helpers missing. Run npm run build or wrsp-agents install (WRSP #602).'
  fi
fi
read_only_policy_failure() {
  if [[ $1 == retry ]]; then
    printf 'LAUNCH RETRY REFUSED: %s\n' "$2" >> "$log"
  else
    refuse 66 "$2"
  fi
}
refresh_read_only_policy() {
  local phase=$1 override
  [[ -n $read_only_helper ]] || return 0
  local -a paths=("$worktree")
  [[ -z $dispatch_mode ]] || paths+=("$dispatch_common_dir")
  if ! read_only_policy=$(node "$read_only_helper" "$cli" "$HOME" "${paths[@]}" <<<'{}') || [[ -z $read_only_policy ]]; then
    read_only_policy_failure "$phase" 'Cannot apply the read-only launch profile (WRSP #602).'
    return 66
  fi
  if [[ $cli == codex ]]; then
    read_only_overrides=()
    while IFS= read -r override; do read_only_overrides+=(-c "$override"); done <<<"$read_only_policy"
  fi
}
with_claude_deny_rules() {
  jq -ce --argjson policy "$read_only_policy" '
    $policy.permissions.deny as $deny
    | select(($deny | type) == "array" and ($deny | length) > 0)
    | .permissions.deny = ((.permissions.deny // []) + $deny)' <<<"$1"
}
refresh_read_only_policy startup
if [[ $cli == agy ]]; then
  worktree=$(cd "$worktree" && pwd -P)
  agy_environment=(-u CLAUDE_CODE_SESSION_ID -u CODEX_THREAD_ID -u CODEX_SESSION_ID
    -u GIT_DIR -u GIT_COMMON_DIR -u GIT_WORK_TREE
    -u ANTIGRAVITY_CONFIG_REL_DIR -u ANTIGRAVITY_EXECUTABLE_DATA_DIR -u ANTIGRAVITY_PLUGIN_SHIM_DIR -u ANTIGRAVITY_PROJECT_ID)
  if [[ $agy_lane == 1 ]]; then
    agy_environment+=(-u GH_TOKEN -u GITHUB_TOKEN -u GH_ENTERPRISE_TOKEN -u GITHUB_ENTERPRISE_TOKEN -u WRSP_AGY_GITHUB)
    agy_role_environment=(WRSP_ROLE=developer WRSP_AGY_LANE=1 "WRSP_AGY_ISSUE=$issue")
  else
    agy_role_environment=("WRSP_ROLE=$worker_marker" "WRSP_AGY_LANE=$agy_lane")
  fi
  if [[ -n $dispatch_mode ]]; then
    agy_environment+=(-u WRSP_AGY_DISPATCH_GATE_DIRECTORY)
    agy_role_environment+=("WRSP_AGY_DISPATCH_GATE_DIRECTORY=$read_only_policy")
  fi
  if ! agy_preflight=$(env "${agy_environment[@]}" "${agy_role_environment[@]}" node "$agy_worker" preflight "$worktree" 2>&1); then
    refuse 66 "Refusing agy launch: $agy_preflight"
  fi
  for suffix in .agy-hooks.jsonl .agy.pid .agy.pgid .agy.conversation .agy.result.json .progress; do
    [[ ! -e $log$suffix && ! -L $log$suffix ]] || refuse 73 "Refusing to overwrite agy evidence: $log$suffix"
  done
fi
# #560: structured opt-in grants apply only to actual Codex batch execution,
# never to another role whose confined worker marker happens to be batch.
if [[ $batch_paths -eq 1 ]]; then
  [[ $cli == codex && $role_id == batch && $research -eq 0 && $locate -eq 0 ]] || refuse 64 'Refusing launch: batch write paths support only Codex batch execution (#560).'
  [[ -n $batch_work_dir && -n $batch_ledger_home ]] || refuse 64 'Refusing launch: --batch-work-dir and --batch-ledger-home require both nonempty paths (#560).'
  for batch_path in "$batch_work_dir" "$batch_ledger_home"; do
    [[ $batch_path == /* && -d $batch_path ]] || refuse 66 "Refusing launch: batch path must be an absolute existing directory: $batch_path (#560)."
  done
  batch_work_dir=$(cd "$batch_work_dir" && pwd -P)
  batch_ledger_home=$(cd "$batch_ledger_home" && pwd -P)
  batch_snapshot_dir=$batch_ledger_home/ledger/issue-snapshot
  [[ -d $batch_snapshot_dir ]] || refuse 66 "Refusing launch: issue-snapshot directory must already exist: $batch_snapshot_dir (#560)."
  batch_snapshot_real=$(cd "$batch_snapshot_dir" && pwd -P)
  [[ $batch_snapshot_real == "$batch_snapshot_dir" ]] || refuse 66 'Refusing launch: issue-snapshot directory escapes its ledger home through a symlink (#560).'
  batch_operator_home=$(cd "$HOME" && pwd -P)
  batch_checkout=$(cd "$worktree" && pwd -P)
  # A named work path cannot widen access to the home, checkout parent, ledger
  # or credential/settings trees. Canonical aliases retain the same boundary.
  [[ $batch_work_dir != / && "$batch_operator_home/" != "$batch_work_dir/"* && "$batch_checkout/" != "$batch_work_dir/"* ]] || refuse 66 'Refusing launch: batch work directory is too broad (#560).'
  [[ "$batch_work_dir/" != "$batch_ledger_home/"* && "$batch_ledger_home/" != "$batch_work_dir/"* ]] || refuse 66 'Refusing launch: batch work directory overlaps the ledger home (#560).'
  for batch_sensitive in "$batch_operator_home/.ssh" "$batch_operator_home/.agents" "$batch_operator_home/.claude" "$batch_operator_home/.codex" "$batch_operator_home/.config/gh" "$batch_operator_home/.config/wrsp"; do
    [[ ! -d $batch_sensitive ]] || batch_sensitive=$(cd "$batch_sensitive" && pwd -P)
    for batch_grant in "$batch_work_dir" "$batch_snapshot_dir"; do
      [[ "$batch_grant/" != "$batch_sensitive/"* && "$batch_sensitive/" != "$batch_grant/"* ]] || refuse 66 'Refusing launch: batch write directory overlaps credentials or settings (#560).'
    done
  done
fi
# A worktree whose configured hooks directory is missing commits without
# running any hook, and git says nothing (#137). Same rule as
# wrsp-preflight worktree: a relative core.hooksPath resolves against the
# worktree's top level. Research launches never commit; the launchd child
# was already checked at submission. Dispatched plan review uses the verified
# read-only checkout with hooks disabled by the substrate.
if [[ -z $launchd_label && $research -eq 0 && $locate -eq 0 && $dispatch_mode != plan-review ]]; then
  if hooks_configured=$(git -C "$worktree" config --type=path --get core.hooksPath 2>/dev/null) \
    && [[ -n $hooks_configured ]] \
    && hooks_top=$(git -C "$worktree" rev-parse --show-toplevel 2>/dev/null); then
    hooks_resolved=$hooks_configured
    [[ $hooks_resolved == /* ]] || hooks_resolved=$hooks_top/$hooks_resolved
    if [[ ! -d $hooks_resolved ]]; then
      case "$hooks_configured" in
        .husky/_|.husky/_/|*/.husky/_|*/.husky/_/)
          remedy="Run \`npx husky\` in $hooks_top (it needs no network), or copy \`.husky/_\` from the shared checkout, then relaunch." ;;
        *)
          remedy="Install the repository's hooks in $hooks_top so the configured hooks directory exists, then relaunch." ;;
      esac
      refuse 66 "Refusing launch: git hooks are not installed in this worktree. core.hooksPath is \"$hooks_configured\", which resolves to $hooks_resolved, and that directory does not exist, so commits there run no hooks. $remedy"
    fi
  fi
fi
[[ -s $brief ]] || { refuse 66 "Brief missing or empty: $brief"; }
[[ ! -e ${log}.availability && ! -L ${log}.availability ]] || { refuse 73 "Refusing to overwrite availability marker: ${log}.availability"; }
for retained in "${log}.admission.request.json" "${log}.admission.json" "${log}.retry-state.json" "${log}.attempts.jsonl" "${log}.history.json" "${log}.eligibility.json" "${log}".attempt-*.result.json "${log}".attempt-*.result.json.running "${log}".attempt-*.request.json; do
  if [[ -e $retained || -L $retained ]]; then
    retry_owned=1
    refuse 73 "Refusing to overwrite retry state: $retained"
  fi
done
[[ ! -e $log ]] || { refuse 73 "Refusing to overwrite log: $log"; }
rm -f "${log}.refused"
[[ -d $(dirname "$log") ]] || { refuse 66 "Log directory not found: $(dirname "$log")"; }
# WRSP #163: a profile on the OpenRouter provider takes its key from the login
# Keychain (service OPENROUTER_API_KEY, account = login name), never argv or launchd.
provider_key=
if [[ $cli == codex && -n $profile ]] && grep -qE '^[[:space:]]*model_provider[[:space:]]*=[[:space:]]*"openrouter"' "${CODEX_HOME:-$HOME/.codex}/$profile.config.toml" 2>/dev/null; then
  provider_key=OPENROUTER_API_KEY
fi
if [[ -n $provider_key && -z $launchd_label ]] && ! security find-generic-password -s "$provider_key" -a "$(id -un)" >/dev/null 2>&1; then
  refuse 66 "Refusing launch: profile $profile uses OpenRouter, and the login Keychain has no $provider_key item for $(id -un). Add it with: security add-generic-password -s $provider_key -a \"\$USER\" -w"
fi
# WRSP #170: a Codex worker never launches beside a retired Morph server, even
# before Jon trusts the morph-retired hook. Codex lists its own servers, so every
# config form counts; a listing that cannot be read refuses the launch.
# A detaching parent runs no codex; its launchd child checks.
if [[ $cli == codex && $dry_run -eq 0 && $detach -eq 0 ]]; then
  if ! servers=$(codex ${profile:+-p "$profile"} mcp list --json </dev/null 2>/dev/null | jq -r '.[] | select(.enabled != false) | .name' 2>/dev/null); then
    refuse 66 "Refusing launch: could not list Codex MCP servers with \`codex mcp list --json\` and jq, so a retired Morph server cannot be ruled out (#170)."
  fi
  if retired=$(printf '%s\n' "$servers" | grep -iE '^morph') ; then
    refuse 66 "Refusing launch: Codex still configures the retired Morph MCP server $(printf '%s' "$retired" | paste -sd ' ' -) (#170). Remove it from ${CODEX_HOME:-$HOME/.codex}/config.toml, then relaunch."
  fi
fi
if [[ -n $launchd_label ]]; then
  printf '%s\n' "$$" > "${log}.pid.tmp.$$" && mv -f "${log}.pid.tmp.$$" "${log}.pid"
fi

if [[ $locate -eq 1 ]]; then
  skill=${WRSP_LOCATOR_SKILL:-$(cd "$(dirname "$0")/../../locator" && pwd -P)/SKILL.md}
elif [[ $research -eq 1 ]]; then
  skill=${WRSP_RESEARCH_SKILL:-$(cd "$(dirname "$0")/../../researcher" && pwd -P)/SKILL.md}
else
  skill=${WRSP_WORKER_SKILL:-$(cd "$(dirname "$0")/../../batch" && pwd -P)/SKILL.md}
fi
if [[ $skill != /* ]]; then skill="$(cd "$(dirname "$skill")" && pwd -P)/$(basename "$skill")"; fi
[[ -s $skill ]] || { refuse 66 "Worker skill not found: $skill"; }

# Execution policy, Brief content rule 3.
read -r -d '' phrase_check <<'PERL' || true
use strict;
use warnings;
local $/;
open(my $fh, '<', $ARGV[0]) or die "cannot read $ARGV[0]: $!\n"; my $original = <$fh>; close($fh);
my $text = $original;
sub mask { my $s = shift; $s =~ s/[^\n]/ /g; return $s; }
$text =~ s{^[^\S\n]*```[^\n]*(?:\n(?![^\S\n]*```)[^\n]*)*\n[^\S\n]*```[^\n]*}{mask($&)}gme;
$text =~ s{`[^`\n]+`}{mask($&)}ge;
my %lines;
while ($text =~ /establish|decid|choos|choic|determin(?:e|es|ed|ing)\b|investigat|explor|(?:find|figur)[a-z]*\s+out\b|decisions?\s+(?:on|about|between)\b/ig) {
  my $prefix = substr($text, 0, $-[0]);
  $lines{1 + ($prefix =~ tr/\n/\n/)} = 1;
}
my @original_lines = split /\n/, $original;
for my $line (sort { $a <=> $b } keys %lines) {
  print "$line:$original_lines[$line - 1]\n";
}
PERL
if [[ -z $launchd_label && $research -eq 0 && $locate -eq 0 ]]; then
  hits=$(perl -e "$phrase_check" "$brief") || refuse 66 "Refusing launch: the brief phrase check could not run on $brief (execution policy, Execution launcher)."
  if [[ -n $hits && $allow_hits -eq 0 ]]; then
    refuse 65 "Brief fails the banned-phrase check (execution policy, Execution launcher). Remove or relaunch with --allow-phrase-hits after justifying each in the brief:" "$hits"
  fi
  # Structural presence only; the developer reviews the answers' artifacts.
  read -r -d '' slot_check <<'PERL' || true
use strict;
use warnings;
my @required = qw(Source Worktree Changes Preservation Tests Proof Limits);
my %required = map { $_ => 1 } @required;
my (%answers, $current, $fence, $length);
open(my $fh, '<', $ARGV[0]) or die "cannot read $ARGV[0]: $!\n";
while (my $line = <$fh>) {
  $line =~ s/\r?\n\z//;
  if (defined $fence) {
    if ($line =~ /^[^\S\n]*(\Q$fence\E{$length,})[ \t]*$/) { undef $fence; }
    next;
  }
  if ($line =~ /^[^\S\n]*(`{3,}|~{3,})/) {
    $fence = substr($1, 0, 1); $length = length($1);
    next;
  }
  if ($line =~ /^[ \t]*(#{1,2})(?:[ \t]+(.*?)|)[ \t]*$/) {
    my ($level, $name) = (length($1), $2 // '');
    $name =~ s/[ \t]+#+[ \t]*$//;
    $name =~ s/[ \t]+$//;
    undef $current;
    if ($level == 2 && $required{$name}) {
      push @{$answers{$name}}, 0;
      $current = $name;
    }
    next;
  }
  next if $line =~ /^[ \t]*#{3,6}(?:[ \t]|$)/;
  $answers{$current}[-1] = 1 if defined $current && $line =~ /\S/;
}
eof($fh) or die "cannot read $ARGV[0]: $!\n";
close($fh) or die "cannot close $ARGV[0]: $!\n";
for my $name (@required) {
  if (!exists $answers{$name}) { print "Brief slot missing: $name (execution-brief template, #426).\n"; exit; }
}
for my $name (@required) {
  if (grep { !$_ } @{$answers{$name}}) { print "Brief slot blank: $name (execution-brief template, #426).\n"; exit; }
}
PERL
  slot_error=$(perl -e "$slot_check" "$brief") || refuse 66 "Refusing launch: the brief slot check could not run on $brief (execution-brief template, #426)."
  [[ -z $slot_error ]] || refuse 65 "$slot_error"
fi

prompt=${log%.log}.prompt.md
answer=${log%.log}.answer.md
system_prompt=
skill_body() {
  if [[ $plan_review -eq 1 ]]; then
    printf '# One-shot reviewer\n\n'
    printf 'Follow the brief. If it lacks required source, print one `BRIEF GAP:` line naming the gap and exit without changes.\n'
    printf '\nThis is advisory plan review: produce no receipt, grant no approval or publication authority, and satisfy no gate. Do not run candidate review or write review-approval state. No edits, GitHub writes or child agents. Return the independent risks and must-test cases requested by the brief.\n'
    return 0
  fi
  # Strip the skill's YAML frontmatter; the body is the worker's instructions.
  awk -v role="$role_id" -v cli="$cli" -v one_shot="$(( research == 0 && locate == 0 ))" '
    NR==1 && $0=="---" {skip=1; next}
    skip && $0=="---" {skip=0; next}
    !skip {
      if (cli == "agy" && /^1[.] First run .*session-role[.]mjs declare batch/) next
      if (one_shot) gsub(/session-role[.]mjs declare batch/, "session-role.mjs declare " role)
      print
    }
  ' "$skill"
}
if [[ -z $launchd_label ]]; then
  if [[ $dry_run -eq 1 ]]; then
    # A dry run composes into its own file so the real launch's prompt path stays free.
    prompt=${log%.log}.dry-run.prompt.md
    answer=${log%.log}.dry-run.answer.md
  else
    [[ ! -e $prompt ]] || { refuse 73 "Refusing to overwrite prompt: $prompt"; }
    [[ $locate -eq 0 || ( ! -e $answer && ! -L $answer ) ]] || refuse 73 "Refusing to overwrite answer: $answer"
  fi
  {
    if [[ $locate -eq 1 ]]; then
      # WRSP #170: a Claude locator takes the skill as its whole system prompt.
      [[ $cli == codex ]] && { skill_body; printf '\n---\n\n'; }
      printf '# Question\n\n'
    else
      skill_body
      printf '\n---\n\n# Brief (%s, %s / %s)\n\n' "$selector" "$model" "$effort"
    fi
    printf '%s\n\n' "$browser_preamble"
    cat "$brief"
  } > "$prompt"
  if [[ $locate -eq 1 && $cli == claude ]]; then system_prompt=$(skill_body); fi
fi

worktree=$(cd "$worktree" && pwd -P)
abs_brief="$(cd "$(dirname "$brief")" && pwd -P)/$(basename "$brief")"
abs_log="$(cd "$(dirname "$log")" && pwd -P)/$(basename "$log")"
# WRSP #254: children run after cd "$worktree"; they read $prompt and a Codex locator writes $answer by path.
[[ $prompt == /* ]] || prompt=$PWD/$prompt
[[ $answer == /* ]] || answer=$PWD/$answer
abs_self="$(cd "$(dirname "$0")" && pwd -P)/$(basename "$0")"
codex_effort=$effort
[[ $codex_effort == med ]] && codex_effort=medium
if [[ $records -eq 1 ]]; then launch_id=$(uuidgen | tr '[:upper:]' '[:lower:]'); fi
build_worker_command() {
local phase=$1 claude_settings claude_index
if [[ $locate -eq 1 && $cli == codex ]]; then
  # WRSP #170: the launch command restricts a locator's tools; its instructions do not.
  otel=$(otel_attrs locator)
  cmd=(env "OTEL_RESOURCE_ATTRIBUTES=$otel" WRSP_ROLE=locator "WRSP_CONTEXT_BUDGET=$context_budget" codex exec -p locator -m "$model" -c "model_reasoning_effort=$codex_effort" -c "model_auto_compact_token_limit=$context_budget")
  [[ $fast -eq 0 ]] || cmd+=(-c "service_tier=fast")
  cmd+=("${read_only_overrides[@]}" -c 'web_search="disabled"' --ephemeral -o "$answer" -C "$worktree" -)
elif [[ $locate -eq 1 ]]; then
  [[ $records -eq 1 ]] && child_session=$(uuidgen | tr '[:upper:]' '[:lower:]')
  otel=$(otel_attrs locator)
  if [[ $fast -eq 1 ]]; then
    claude_settings=$(jq -cn --argjson b "$auto_compact_window" --arg o "$otel" '{autoCompactWindow: $b, fastMode: true, env: {OTEL_RESOURCE_ATTRIBUTES: $o}}')
  else
    claude_settings=$(jq -cn --argjson b "$auto_compact_window" --arg o "$otel" '{autoCompactWindow: $b, env: {OTEL_RESOURCE_ATTRIBUTES: $o}}')
  fi
  claude_settings=$(with_claude_deny_rules "$claude_settings") || {
    read_only_policy_failure "$phase" 'Cannot merge Claude read-only deny rules (WRSP #602).'
    return 66
  }
  cmd=(env "OTEL_RESOURCE_ATTRIBUTES=$otel" WRSP_ROLE=locator "WRSP_CONTEXT_BUDGET=$context_budget" claude -p --model "$model" --effort "$effort" --settings "$claude_settings" --system-prompt "$system_prompt" --tools Read,Grep,Glob --allowedTools Read,Grep,Glob --strict-mcp-config --disable-slash-commands --setting-sources user --no-session-persistence --output-format text)
  [[ -n $child_session ]] && cmd+=(--session-id "$child_session")
elif [[ $research -eq 1 && $cli == claude ]]; then
  # WRSP #547: headless researchers expose only policy read/search tools.
  child_session=$(uuidgen | tr '[:upper:]' '[:lower:]')
  otel=$(otel_attrs researcher)
  if [[ $fast -eq 1 ]]; then
    claude_settings=$(jq -cn --argjson b "$auto_compact_window" --arg o "$otel" '{autoCompactWindow: $b, fastMode: true, env: {OTEL_RESOURCE_ATTRIBUTES: $o}}')
  else
    claude_settings=$(jq -cn --argjson b "$auto_compact_window" --arg o "$otel" '{autoCompactWindow: $b, env: {OTEL_RESOURCE_ATTRIBUTES: $o}}')
  fi
  claude_settings=$(with_claude_deny_rules "$claude_settings") || {
    read_only_policy_failure "$phase" 'Cannot merge Claude read-only deny rules (WRSP #602).'
    return 66
  }
  cmd=(env "OTEL_RESOURCE_ATTRIBUTES=$otel" WRSP_ROLE=researcher "WRSP_CONTEXT_BUDGET=$context_budget" "RIPGREP_CONFIG_PATH=$ripgrep_config" claude -p --model "$model" --effort "$effort" --settings "$claude_settings" --tools Read,Grep,Glob,WebFetch,WebSearch --allowedTools Read,Grep,Glob,WebFetch,WebSearch --mcp-config '{"mcpServers":{}}' --strict-mcp-config --disable-slash-commands --setting-sources user --session-id "$child_session")
elif [[ $cli == codex ]]; then
  otel=$(otel_attrs "$launch_role")
  cmd=(env "OTEL_RESOURCE_ATTRIBUTES=$otel" "WRSP_ROLE=$worker_marker" "WRSP_CONTEXT_BUDGET=$context_budget" codex exec)
  # WRSP #253: keep the search config in the env prefix.
  cmd=("${cmd[@]:0:4}" "RIPGREP_CONFIG_PATH=$ripgrep_config" "${cmd[@]:4}")
  [[ -n $profile ]] && cmd+=(-p "$profile")
  codex_effort=$effort; [[ $codex_effort == med ]] && codex_effort=medium
  cmd+=(-m "$model" -c "model_reasoning_effort=$codex_effort" -c "model_auto_compact_token_limit=$context_budget")
  [[ $fast -eq 0 ]] || cmd+=(-c "service_tier=fast")
  cmd+=("${role_overrides[@]}")
  if [[ $research -eq 1 ]]; then
    cmd+=("${read_only_overrides[@]}" --skip-git-repo-check -c 'web_search="live"')
  elif [[ $plan_review -eq 1 ]]; then
    cmd+=("${read_only_overrides[@]}")
  else
    # WRSP #253: ~16,000 characters (Jon, 2026-10-20).
    cmd+=(-c tool_output_token_limit=4000)
    cmd+=(-s workspace-write -c sandbox_workspace_write.network_access=true)
    # WRSP #147: linked worktree commits need the common dir writable for index and refs.
    # Network serves web research and localhost; browsers stay on the host runner.
    common=$(git -C "$worktree" -c core.fsmonitor=false -c core.hooksPath=/dev/null rev-parse --path-format=absolute --git-common-dir 2>/dev/null || true)
    [[ -n $common ]] && cmd+=(--add-dir "$common")
    # WRSP #165: Codex 0.160 also refuses a linked worktree's own git dir unless it is a writable root.
    own_gitdir=$(git -C "$worktree" -c core.fsmonitor=false -c core.hooksPath=/dev/null rev-parse --absolute-git-dir 2>/dev/null || true)
    [[ -n $own_gitdir && $own_gitdir != "$common" ]] && cmd+=(--add-dir "$own_gitdir")
    # WRSP #246: the Codex sandbox cannot write ~/.npm; npm pack needs a writable cache.
    if [[ -z $npm_cache ]]; then
      npm_cache="${TMPDIR:-/tmp}"
      npm_cache="${npm_cache%/}/wrsp-npm-cache.$launch_id"
    fi
    cmd+=(--add-dir "$npm_cache")
    if [[ $batch_paths -eq 1 ]]; then
      cmd+=(--add-dir "$batch_work_dir" --add-dir "$batch_snapshot_dir")
    fi
    # WRSP #253: include the search config before adding the npm cache.
    cmd=("${cmd[@]:0:5}" "npm_config_cache=$npm_cache" "${cmd[@]:5}")
  fi
  cmd+=(-C "$worktree" -)
elif [[ $cli == agy ]]; then
  cmd=(env "${agy_environment[@]}" "${agy_role_environment[@]}" node "$agy_worker" run "$worktree" "$prompt" "$abs_log" "gemini-4-neon-$codex_effort" "$print_timeout" "$conversation")
else
  # WRSP #151: headless workers cannot answer prompts; auto mode runs ordinary commands and its classifier refuses risky ones.
  child_session=$(uuidgen | tr '[:upper:]' '[:lower:]')
  otel=$(otel_attrs "$launch_role")
  if [[ $fast -eq 1 ]]; then
    claude_settings=$(jq -c --arg o "$otel" '. + {fastMode: true} | .env = ((.env // {}) + {OTEL_RESOURCE_ATTRIBUTES: $o})' <<<"$role_settings")
  else
    claude_settings=$(jq -c --arg o "$otel" '.env = ((.env // {}) + {OTEL_RESOURCE_ATTRIBUTES: $o})' <<<"$role_settings")
  fi
  if [[ $plan_review -eq 1 ]]; then
    claude_settings=$(with_claude_deny_rules "$claude_settings") || {
      read_only_policy_failure "$phase" 'Cannot merge Claude read-only deny rules (WRSP #602).'
      return 66
    }
  fi
  cmd=(env "OTEL_RESOURCE_ATTRIBUTES=$otel" "WRSP_ROLE=$worker_marker" "WRSP_CONTEXT_BUDGET=$context_budget" claude -p --model "$model" --effort "$effort" --settings "$claude_settings")
  if [[ $plan_review -eq 1 ]]; then
    cmd+=(--tools Read,Grep,Glob --allowedTools Read,Grep,Glob --permission-mode dontAsk --mcp-config '{"mcpServers":{}}' --strict-mcp-config --disable-slash-commands --setting-sources user)
  else
    cmd+=(--permission-mode auto)
  fi
  cmd+=(--session-id "$child_session")
  # WRSP #253: keep the search config in the env prefix.
  cmd=("${cmd[@]:0:4}" "RIPGREP_CONFIG_PATH=$ripgrep_config" "${cmd[@]:4}")
fi
if [[ -n $dispatch_mode && $cli == claude ]]; then
  cmd+=(--safe-mode)
  [[ $plan_review -eq 1 ]] || cmd+=(--permission-mode dontAsk)
  [[ $locate -eq 0 ]] || cmd+=(--mcp-config '{"mcpServers":{}}')
  # Locator omits the RIPGREP_CONFIG_PATH assignment used by the other modes.
  claude_index=5
  [[ $locate -eq 0 ]] || claude_index=4
  if [[ ${cmd[claude_index]} != claude ]] || ! node "$read_only_helper" check-claude-dispatch "$dispatch_mode" "${cmd[@]:$((claude_index + 1))}"; then
    read_only_policy_failure "$phase" 'Unsafe dispatched Claude one-shot launch.'
    return 66
  fi
fi
# #543: native harnesses supply their own identity; keep parent attribution in launcher args only.
if [[ $batch_paths -eq 1 ]]; then cmd=(env "WRSP_LEDGER_HOME=$batch_ledger_home" "${cmd[@]:1}"); fi
cmd=(env -u CLAUDE_CODE_SESSION_ID -u CODEX_THREAD_ID -u CODEX_SESSION_ID "${cmd[@]:1}")
return 0
}
build_worker_command startup

legacy_worker=0
produce_timeout=${WRSP_DETACH_PRODUCE_TIMEOUT:-600}
[[ $produce_timeout =~ ^[1-9][0-9]*$ ]] && (( ${#produce_timeout} <= 5 && produce_timeout <= 86400 )) || refuse 64 "Refusing launch: WRSP_DETACH_PRODUCE_TIMEOUT must be a positive integer of seconds up to 86400, not $produce_timeout (WRSP #248)."
[[ -z ${WRSP_DETACH_PRODUCE_TIMEOUT:-} ]] || (( produce_timeout >= 600 )) || legacy_worker=1
if [[ $cli == agy ]]; then
  legacy_worker=1
  [[ -n ${WRSP_DETACH_PRODUCE_TIMEOUT:-} ]] || produce_timeout=$((print_timeout + 65))
fi

if [[ $detach -eq 1 ]]; then
  label_name=$(basename "$log" .log)
  label="com.whiteroom.wrsp-worker.${label_name//[^A-Za-z0-9.-]/-}.$(date +%s).$$"
  relaunch_args=(--cli "$cli" "${selector_args[@]}" --model "$model" --effort "$effort" --worktree "$worktree" --brief "$abs_brief" --log "$abs_log" --context-budget "$context_budget" --issue "$issue")
  [[ -n $parent_session ]] && relaunch_args+=(--parent-session "$parent_session")
  [[ -n $profile ]] && relaunch_args+=(--profile "$profile")
  if [[ $cli == agy ]]; then
    relaunch_args+=(--print-timeout "$print_timeout")
    [[ -z $conversation ]] || relaunch_args+=(--conversation "$conversation")
    [[ -z $selection_reason ]] || relaunch_args+=(--selection-reason "$selection_reason")
  fi
  [[ $batch_paths -eq 0 ]] || relaunch_args+=(--batch-work-dir "$batch_work_dir" --batch-ledger-home "$batch_ledger_home")
  [[ $research -eq 1 ]] && relaunch_args+=(--research)
  [[ $fast -eq 1 ]] && relaunch_args+=(--fast)
  skill_var=WRSP_WORKER_SKILL
  [[ $research -eq 1 ]] && skill_var=WRSP_RESEARCH_SKILL
  submit=(launchctl submit -l "$label" -- /usr/bin/env)
  [[ $cli != agy ]] || submit+=("${agy_environment[@]}")
  submit+=("PATH=$PATH" "HOME=$HOME" "TMPDIR=${TMPDIR:-/tmp}" "$skill_var=$skill")
  [[ -n ${WRSP_ROLES_DIR:-} ]] && submit+=("WRSP_ROLES_DIR=$roles")
  [[ -n ${WRSP_ROLES_MEMBERS:-} ]] && submit+=("WRSP_ROLES_MEMBERS=$WRSP_ROLES_MEMBERS")
  # WRSP #253: preserve an explicit search config in the detached child.
  [[ -n ${WRSP_RIPGREP_CONFIG:-} ]] && submit+=("WRSP_RIPGREP_CONFIG=$ripgrep_config")
  # WRSP #249: the child reruns the CLI-minimums check, so it reads the same table; launchd does not keep this directory (#180).
  if [[ -n ${WRSP_CLI_MINIMUMS:-} ]]; then
    cli_minimums=$WRSP_CLI_MINIMUMS
    [[ $cli_minimums == /* ]] || cli_minimums=$PWD/$cli_minimums
    submit+=("WRSP_CLI_MINIMUMS=$cli_minimums")
  fi
  [[ -n ${WRSP_USAGE_BIN:-} ]] && submit+=("WRSP_USAGE_BIN=$WRSP_USAGE_BIN")
  [[ $cli != agy || -z ${WRSP_LEDGER_HOME:-} ]] || submit+=("WRSP_LEDGER_HOME=$WRSP_LEDGER_HOME")
  if [[ $cli == agy && $role_id == developer ]]; then
    [[ -z ${GH_CONFIG_DIR:-} ]] || submit+=("GH_CONFIG_DIR=$GH_CONFIG_DIR")
    [[ -z ${XDG_CONFIG_HOME:-} ]] || submit+=("XDG_CONFIG_HOME=$XDG_CONFIG_HOME")
  fi
  [[ -n ${WRSP_RUNNER_HOME:-} ]] && submit+=("WRSP_RUNNER_HOME=$WRSP_RUNNER_HOME")
  if [[ -n ${WRSP_LAUNCH_BACKOFF_DIR:-} ]]; then
    marker_directory=$WRSP_LAUNCH_BACKOFF_DIR
    [[ $marker_directory == /* ]] || marker_directory=$PWD/$marker_directory
    submit+=("WRSP_LAUNCH_BACKOFF_DIR=$marker_directory")
  fi
  [[ -z ${WRSP_LAUNCH_BACKOFF_OVERRIDE:-} ]] || submit+=("WRSP_LAUNCH_BACKOFF_OVERRIDE=$WRSP_LAUNCH_BACKOFF_OVERRIDE")
  [[ -n ${OTEL_RESOURCE_ATTRIBUTES:-} ]] && submit+=("OTEL_RESOURCE_ATTRIBUTES=$OTEL_RESOURCE_ATTRIBUTES")
  # #248: the child's session records live under these homes.
  [[ -n ${CODEX_HOME:-} ]] && submit+=("CODEX_HOME=$CODEX_HOME")
  [[ -n ${CLAUDE_CONFIG_DIR:-} ]] && submit+=("CLAUDE_CONFIG_DIR=$CLAUDE_CONFIG_DIR")
  if [[ -n ${WRSP_LAUNCH_RETRY_TEST_DRIVER:-} ]]; then
    [[ $WRSP_LAUNCH_RETRY_TEST_DRIVER == /* ]] || refuse 64 'WRSP_LAUNCH_RETRY_TEST_DRIVER must be an absolute module path'
    submit+=("WRSP_LAUNCH_RETRY_TEST_DRIVER=$WRSP_LAUNCH_RETRY_TEST_DRIVER")
  fi
  [[ -z ${WRSP_DETACH_PRODUCE_TIMEOUT:-} ]] || submit+=("WRSP_DETACH_PRODUCE_TIMEOUT=$WRSP_DETACH_PRODUCE_TIMEOUT")
  # #248
  submit+=(/bin/bash "$abs_self" "${relaunch_args[@]}" --launchd-label "$label")
fi

if [[ $dry_run -eq 1 ]]; then
  echo "PROMPT: $prompt"
  printf 'COMMAND:'; printf ' %q' "${cmd[@]}"; printf ' < %q > %q 2>&1\n' "$prompt" "$log"
  echo "CWD: $worktree"
  [[ $locate -eq 1 ]] && echo "ANSWER: $answer"
  if [[ $detach -eq 1 ]]; then printf 'SUBMIT:'; printf ' %q' "${submit[@]}"; printf '\n'; fi
  exit 0
fi

command -v "$cli" >/dev/null || { rm -f "$prompt"; refuse 69 "$cli is not on PATH."; }
retry_runtime=
if [[ $locate -eq 0 && $cli != agy ]]; then
  retry_dir=$(dirname "$abs_self")
  [[ ! -r $retry_dir/../../../dist/launch-retry-runtime.mjs ]] || retry_dir=$retry_dir/../../../dist
  retry_runtime=$retry_dir/launch-retry-runtime.mjs
  if [[ ! -r $retry_runtime || ! -r $retry_dir/launch-retry-policy.mjs || ! -r $retry_dir/launch-backoff-marker.mjs ]]; then
    [[ $legacy_worker -eq 1 ]] || refuse 66 'retry helpers missing; run npm run build / wrsp-agents install.'
    retry_runtime=
  fi
fi
# WRSP #249: refuse a CLI below the model's vendor-stated minimum; an unlisted model is never refused.
minimums=${WRSP_CLI_MINIMUMS:-$HOME/.agents/cli-minimums}
[[ -r $minimums ]] || { rm -f "$prompt"; refuse 66 "cli-minimums not found: $minimums. Run wrsp-agents install."; }
minimum=$(awk -F '\t' -v m="$model" -v c="$cli" '!/^#/ && $1 == m && $2 == c { print $3; exit }' "$minimums") || minimum=
fast_minimum=
if [[ $fast -eq 1 && $cli == claude ]]; then
  if ! fast_minimum=$(awk -F '\t' '/^# claude-fast-minimum([[:space:]]|$)/ { count++; if (NF == 2 && $1 == "# claude-fast-minimum" && $2 ~ /^[0-9]+\.[0-9]+\.[0-9]+$/) value=$2; else invalid=1 } END { if (count != 1 || invalid) exit 1; print value }' "$minimums"); then
    rm -f "$prompt"; refuse 66 "$minimums has no valid Claude fast-mode minimum (#570). Run wrsp-agents install."
  fi
fi
if [[ -n $minimum || -n $fast_minimum ]]; then
  installed=$("$cli" --version </dev/null 2>/dev/null | grep -Eo '[0-9]+\.[0-9]+\.[0-9]+' | head -n 1) || installed=
  if [[ -n $minimum ]]; then
    [[ -n $installed ]] || { rm -f "$prompt"; refuse 69 "$cli version unreadable ($cli --version); $model needs $cli $minimum or later."; }
    if [[ $(awk -v a="$installed" -v b="$minimum" 'BEGIN { split(a, x, "."); split(b, y, "."); for (i = 1; i <= 3; i++) if (x[i] + 0 != y[i] + 0) { print (x[i] + 0 < y[i] + 0); exit } print 0 }') == 1 ]]; then
      rm -f "$prompt"; refuse 69 "$cli $installed is below $model's minimum $minimum; upgrade $cli to $minimum or later"
    fi
  fi
  if [[ -n $fast_minimum ]]; then
    [[ -n $installed ]] || { rm -f "$prompt"; refuse 69 "$cli version unreadable ($cli --version); --fast needs $cli $fast_minimum or later."; }
    if [[ $(awk -v a="$installed" -v b="$fast_minimum" 'BEGIN { split(a, x, "."); split(b, y, "."); for (i = 1; i <= 3; i++) if (x[i] + 0 != y[i] + 0) { print (x[i] + 0 < y[i] + 0); exit } print 0 }') == 1 ]]; then
      rm -f "$prompt"; refuse 69 "$cli $installed is below fast-mode minimum $fast_minimum; upgrade $cli to $fast_minimum or later"
    fi
  fi
fi
if [[ $detach -eq 1 ]]; then
  if ! "${submit[@]}"; then
    rm -f "$prompt"
    refuse 69 'launchctl submit failed (in Codex, run this launch as an escalated command)'
  fi
  # launchd can accept a submit and never run the job; hand out a handle only once the child has started (#228).
  timeout=${WRSP_DETACH_START_TIMEOUT:-30}
  deadline=$((SECONDS + timeout))
  while :; do
    if [[ -e ${log}.refused ]]; then
      launchctl remove "$label" >/dev/null 2>&1 || true
      cat "${log}.refused"
      exit 69
    fi
    if [[ -e ${log}.started ]]; then
      # #248: a started worker is presumed not working until its session record shows model output.
      produce_deadline=$((SECONDS + produce_timeout))
      fallback_deadline=$((SECONDS + 2700))
      observed_deadline=
      final_observation=0
      while :; do
        if { [[ $cli == agy ]] && rec=$(worker_progress_path "$log") && worker_progress_produced "$rec"; } ||
          { [[ $cli != agy ]] && rec=$(worker_record_path "$log") && worker_produced "$rec"; }; then
          echo "HANDLE: $(cd "$(dirname "$log")" && pwd -P)/$(basename "$log")"
          echo "LABEL: $label"
          echo "PRODUCING: $rec"
          script_dir=$(cd "$(dirname "$0")" && pwd -P)
          node "$script_dir/next-invocation.mjs" wait "$PWD" "$(command -v bash)" "$script_dir/wrsp-wait.sh" "$(cd "$(dirname "$log")" && pwd -P)/$(basename "$log")"
          exit 0
        fi
        if [[ -e ${log}.exit ]]; then
          launchctl remove "$label" >/dev/null 2>&1 || true
          if [[ $(cat "${log}.exit") == 10 && -s ${log}.availability ]]; then
            echo 'WORKER EXITED availability (10)'
            printf 'AVAILABILITY: %s\n' "$(cat "${log}.availability")"
            tail -n 20 "$log"
            exit 10
          fi
          echo "LAUNCH REFUSED: Detached worker exited $(cat "${log}.exit") before producing model output (WRSP #248)."
          tail -n 20 "$log"
          exit 69
        fi
        [[ $final_observation -eq 0 ]] || break
        if [[ $legacy_worker -eq 1 ]]; then
          ((SECONDS < produce_deadline)) || break
        else
          retry_now=$(node "$retry_runtime" clock | jq -er '.now | select(isfinite)') || { echo 'LAUNCH REFUSED: retry clock unreadable'; exit 66; }
          if [[ -e ${log}.retry-state.json ]]; then
            jq -e --argjson now "$retry_now" '($now|isfinite) and (.firstDispatchAt|type == "number" and isfinite) and (.deadlineAt|type == "number" and isfinite) and .deadlineAt == (.firstDispatchAt + 2700000)' "${log}.retry-state.json" >/dev/null || { echo 'LAUNCH REFUSED: invalid retry state'; exit 66; }
            child_deadline=$(jq -r .deadlineAt "${log}.retry-state.json")
            [[ -z $observed_deadline || $observed_deadline == "$child_deadline" ]] || { echo 'LAUNCH REFUSED: retry deadline changed'; exit 66; }
            observed_deadline=$child_deadline
          fi
          # Retain the owner's fixed deadline even if its state disappears.
          # Production and recorded completion above always take precedence.
          if [[ -n $observed_deadline ]]; then
            if ! jq -en --argjson now "$retry_now" --argjson deadline "$observed_deadline" '$now < $deadline' >/dev/null; then
              retry_owner=$(cat "${log}.started" 2>/dev/null) || retry_owner=
              if ! { [[ $retry_owner =~ ^[1-9][0-9]*$ ]] && kill -0 "$retry_owner" 2>/dev/null; }; then
                final_observation=1
                continue
              fi
            fi
          else
            if ((SECONDS >= fallback_deadline)); then
              final_observation=1
              continue
            fi
          fi
        fi
        sleep 0.5
      done
      # The child owns its prompt and log; after TERM it finishes its end path.
      launchctl remove "$label" >/dev/null 2>&1 || true
      if [[ $legacy_worker -eq 1 ]]; then
        echo "LAUNCH REFUSED: Detached worker started but produced no model output within ${produce_timeout}s; launchd job $label removed (WRSP #248). Set WRSP_DETACH_PRODUCE_TIMEOUT=<seconds> to wait longer (WRSP #390)."
      else
        echo "LAUNCH REFUSED: Detached worker produced no model output or recorded completion within its fixed 2700s allocation; launchd job $label removed (WRSP #357)."
      fi
      exit 69
    fi
    if [[ -e ${log}.exit ]]; then
      # The child ended before starting the worker; its log and handle stay as it left them.
      launchctl remove "$label" >/dev/null 2>&1 || true
      if [[ $(cat "${log}.exit") == 10 && -s ${log}.availability ]]; then
        echo 'WORKER EXITED availability (10)'
        printf 'AVAILABILITY: %s\n' "$(cat "${log}.availability")"
        tail -n 20 "$log"
        exit 10
      fi
      grep '^LAUNCH REFUSED:' "$log" 2>/dev/null ||
        echo "LAUNCH REFUSED: Detached launcher exited $(cat "${log}.exit") before starting the worker (WRSP #228)."
      exit 69
    fi
    ((SECONDS < deadline)) || break
    sleep 0.2
  done
  launchctl remove "$label" >/dev/null 2>&1 || true
  rm -f "$prompt"
  refuse 69 "Detached worker did not start within ${timeout}s; launchd job $label removed (WRSP #228)."
fi

# Provenance for hooks/coordinator-reminder.sh. A snapshot maps every dirty or
# untracked path to a content hash; the paths whose hash changed or appeared
# during the run are the ones this worker touched. Paths the coordinator left
# dirty before the launch and the worker never changed stay unattributed.
# NUL-delimited status keeps paths with whitespace intact; a path containing
# a newline is not representable in worker-touched and is skipped.
snapshot() {
  git -C "$worktree" -c core.fsmonitor=false -c core.hooksPath=/dev/null status --porcelain=v1 -z --untracked-files=all | {
    paths=() hashes=() regular=() positions=()
    count=0 regular_count=0
    while IFS= read -r -d '' entry; do
      code=${entry:0:2}
      path=${entry:3}
      case "$code" in R?|C?|?R|?C) IFS= read -r -d '' _old || true ;; esac
      case "$path" in *$'\n'*) continue ;; esac
      paths[count]=$path
      hashes[count]=absent
      if [[ -f $worktree/$path ]]; then
        regular[regular_count]=$path
        positions[regular_count]=$count
        regular_count=$((regular_count + 1))
      fi
      count=$((count + 1))
    done
    if (( regular_count > 0 )); then
      if batch=$(
        for path in "${regular[@]}"; do
          quoted=${path//\\/\\\\}
          quoted=${quoted//\"/\\\"}
          printf '"%s"\n' "$quoted"
        done | git -C "$worktree" -c core.fsmonitor=false -c core.hooksPath=/dev/null hash-object --stdin-paths 2>/dev/null
      ); then
        index=0
        while IFS= read -r hash; do
          hashes[${positions[index]}]=$hash
          index=$((index + 1))
        done <<< "$batch"
      else
        # A failed batch can emit a prefix; discard it and preserve legacy markers.
        for index in "${positions[@]}"; do
          hash=$(git -C "$worktree" -c core.fsmonitor=false -c core.hooksPath=/dev/null hash-object -- "${paths[index]}" 2>/dev/null) || hash=unreadable
          hashes[index]=$hash
        done
      fi
    fi
    for ((index=0; index<count; index++)); do
      printf '%s\t%s\n' "${hashes[index]}" "${paths[index]}"
    done
  }
}
if [[ $research -eq 0 && $locate -eq 0 && $plan_review -eq 0 ]]; then
  before=$(mktemp "${TMPDIR:-/tmp}/wrsp-provenance.XXXXXX")
  trap cleanup EXIT
  if [[ $cli == codex ]]; then
    if mkdir "$npm_cache" 2>/dev/null; then npm_cache_created=1; fi
  fi
  snapshot > "$before" 2>/dev/null || : > "$before"
fi

printf '%s model:%s effort:%s cli:%s worktree:%s brief:%s\n' "$selector" "$model" "$effort" "$cli" "$worktree" "$brief" > "$log"
if [[ $fast -eq 1 ]]; then
  printf 'LANE_FACTS: {"browser":%s,"serviceTier":"fast"}\n' "$browser_facts" >> "$log"
else
  printf 'LANE_FACTS: {"browser":%s}\n' "$browser_facts" >> "$log"
fi
[[ -z $selection_reason ]] || printf 'SELECTION REASON: %s\n' "$selection_reason" >> "$log"
if ! node "$(cd "$(dirname "$0")" && pwd -P)/retain-brief.mjs" --worktree "$worktree" --brief "$abs_brief" --issue "$issue" --launch-id "$launch_id" >> "$log" 2>&1; then
  echo "EXIT:66" >> "$log"
  printf '66\n' > "${log}.exit.tmp.$$" && mv -f "${log}.exit.tmp.$$" "${log}.exit"
  exit 66
fi
if [[ -n $provider_key ]]; then
  if ! key_value=$(security find-generic-password -s "$provider_key" -a "$(id -un)" -w 2>/dev/null) || [[ -z $key_value ]]; then
    echo "LAUNCH REFUSED: could not read login Keychain item $provider_key for $(id -un); the login keychain may be locked." >> "$log"
    echo "EXIT:66" >> "$log"
    printf '66\n' > "${log}.exit.tmp.$$" && mv -f "${log}.exit.tmp.$$" "${log}.exit"
    exit 66
  fi
  export "$provider_key=$key_value"
  unset key_value
fi
worker_fact_started=0
worker_group_start() {
  local group_script group_ready= group_part group_read_code group_dir
  worker_group_pid=
  # #466: create the group once, before starting Bash. Monitor-mode fork setup
  # races on system Bash and can diagnose setpgid before a subshell body runs.
  # Capture only the inputs/functions used by snapshot and finalization; Perl
  # is already required by launcher admission. Exec retains the direct-child PID.
  group_script=$(
    declare -p log usage_bin worktree issue status cli research locate plan_review legacy_worker \
      first_dispatch logical_id launch_deadline attempt previous_launch_id previous_code \
      abs_log child_session launch_id launch_role answer before attempt_log records worker_fact_started 2>/dev/null || :
    declare -f record_fact snapshot worker_previous_exit worker_retry_state codex_session_id \
      worker_finalize worker_finalize_after_snapshot 2>/dev/null || :
    printf '%s\n' 'set -uo pipefail; set +e' "trap 'exit 143' TERM" \
      'printf "ready\\n" >&6 || exit 66' 'exec 6>&-' '"$@"'
  )
  # The pipe closes on bootstrap failure, so readiness cannot hang waiting for
  # a child that exited. Open both ends before fork, then unlink the FIFO. Keep
  # a normal background child: Bash 3.2 cannot wait for process substitutions.
  group_dir=$(mktemp -d "${TMPDIR:-/tmp}/wrsp-group.XXXXXX") || return 66
  if ! mkfifo "$group_dir/ready"; then rmdir "$group_dir"; return 66; fi
  exec 5<> "$group_dir/ready"
  exec 7< "$group_dir/ready"
  exec 6> "$group_dir/ready"
  exec 5>&-
  rm -f "$group_dir/ready"
  rmdir "$group_dir"
  (
    trap - EXIT
    exec 7<&-
    export BASH_ENV=/dev/null
    exec perl -e 'setpgrp(0,0) or do { warn "worker group placement failed: $!\n"; exit 66 }; exec @ARGV; warn "worker group exec failed: $!\n"; exit 66' \
      "$BASH" +m -c "$group_script" wrsp-helper "$@"
  ) & worker_group_pid=$!
  exec 6>&-
  # TERM remains latched by the caller until readiness and identity capture.
  # A trap can interrupt read; retain any partial marker and drain the pipe.
  while [[ $group_ready != ready ]]; do
    group_part=
    if IFS= read -r -u 7 group_part; then group_read_code=0; else group_read_code=$?; fi
    group_ready+=$group_part
    [[ $group_read_code -eq 0 || $group_read_code -gt 128 ]] || break
  done
  exec 7<&-
  # Failed bootstrap retains its nonzero child status for the caller's wait.
  return 0
}
worker_start_fact() {
worker_fact_started=1
if [[ $records -eq 1 ]]; then
  local recorded_effort=$effort
  [[ $cli != agy ]] || recorded_effort=$member_effort
  start_args=(launch-record start --launch-id "$launch_id" --issue "$issue" --role "$launch_role" --cli "$cli" --model "$model" --effort "$recorded_effort" --worktree "$worktree" --brief "$abs_brief" --log "$abs_log")
  [[ -z $dispatch_mode ]] || start_args+=(--dispatch-repository "$dispatch_repository")
  [[ $fast -eq 1 ]] && start_args+=(--service-tier fast)
  [[ -n $profile ]] && start_args+=(--profile "$profile")
  [[ -n $launchd_label ]] && start_args+=(--label "$launchd_label")
  [[ -n $child_session ]] && start_args+=(--child-session "$child_session")
  [[ -n $parent_session ]] && start_args+=(--parent-provider "${parent_session%%:*}" --parent-session "${parent_session#*:}")
  record_fact "${start_args[@]}"
  # #414: this asynchronous finalization dependency owns a group separate from the model.
  if worker_group_start record_fact snapshot-issue --source launch --repo-dir "$worktree" "$issue"; then
    snapshot_pid=$worker_group_pid
  fi
fi
}
worker_dispatch() {
# Every startup check has passed; the detaching parent hands out a handle only now (#228).
if [[ -n $launchd_label ]]; then
  printf '%s\n' "$$" > "${log}.started.tmp.$$" && mv -f "${log}.started.tmp.$$" "${log}.started"
fi
session_pid= record_pid=
local observer_wakeup_owned=0
if [[ $locate -eq 0 && $legacy_worker -eq 0 ]]; then
  # Own exactly this FIFO; mkfifo refuses any existing path, including a symlink.
  if ! (umask 077; mkfifo "${log}.observer-wakeup"); then status=66; return 66; fi
  observer_wakeup_owned=1
  if ! exec 8<> "${log}.observer-wakeup"; then
    rm -f "${log}.observer-wakeup"
    status=66; return 66
  fi
  node "$retry_runtime" attempt "$attempt_base.request.json" "$attempt_base.result.json" 8>&- >> "$log" 2>&1 &
elif [[ $locate -eq 1 && $cli == claude ]]; then
  (cd "$worktree" && exec "${cmd[@]}" < "$prompt") > "$answer" 2>> "$log" &
else
  (cd "$worktree" && exec "${cmd[@]}" < "$prompt") >> "$log" 2>&1 &
fi
worker_pid=$!
if [[ $locate -eq 0 && $legacy_worker -eq 0 ]]; then
  runtime_pid=$worker_pid
  if [[ $worker_signal_code == 143 ]]; then kill -TERM "$runtime_pid" 2>/dev/null || :
  elif [[ $worker_signal_code == 130 ]]; then kill -INT "$runtime_pid" 2>/dev/null || :; fi
  worker_previous_exit
fi
# #248: launchctl remove stops the CLI by its exact pid; the CLI is reaped before the end path
# below runs, with SIGKILL by that exact pid after the grace.
term_forwarded=0 kill_backstop_pid=
if [[ -n $launchd_label && ( $legacy_worker -eq 1 || $locate -eq 1 ) ]]; then
  grace=${WRSP_WORKER_TERM_GRACE:-10}
  if [[ ! $grace =~ ^[1-9][0-9]{0,4}$ ]] || (( grace > 86400 )); then
    WRSP_WORKER_TERM_GRACE=10
    echo "WARNING: WRSP_WORKER_TERM_GRACE must be an integer from 1 to 86400; using 10 (WRSP #248)." >> "$log"
  fi
  # The backstop polls the reaped marker, so cancelling it needs no signal; KILL fires only while the CLI is unreaped.
  term_backstop() {
    ( polls=$(( ${WRSP_WORKER_TERM_GRACE:-10} * 10 * launch_wait_divisor ))
      while (( polls-- > 0 )); do [[ -e ${log}.reaped ]] && exit 0; sleep "$launch_tenth_wait"; done
      [[ -e ${log}.reaped ]] || kill -KILL "$worker_pid" 2>/dev/null ) & kill_backstop_pid=$!
  }
  trap 'term_forwarded=1; kill "$worker_pid" 2>/dev/null
        [[ -n $kill_backstop_pid ]] || term_backstop' TERM
fi
# The observer branches wait with an integer `read -t 1` and keep their caps.
local poll_scale=$launch_wait_divisor
if [[ $observer_wakeup_owned -eq 1 ]]; then poll_scale=1; fi
if [[ $records -eq 1 && $cli == codex ]]; then
  codex_session_id() { sed -n '1,25p' "${attempt_log:-$log}" 2>/dev/null | sed -n 's/^session id: \([0-9a-f][0-9a-f-]\{35\}\)$/\1/p' | head -1; }
  # WRSP #255: the loop ends on its own once the worker is gone; the end path waits for it and never interrupts a record.
  ( pass=0
    while (( pass++ < 120 * poll_scale )) && kill -0 "$worker_pid" 2>/dev/null; do
      sid=$(codex_session_id); [[ -n $sid ]] && { record_fact launch-record session --launch-id "$launch_id" --provider codex --session-id "$sid"; : > "${log}.session"; exit 0; }
      if [[ $observer_wakeup_owned -eq 1 ]]; then
        [[ ! -e ${log}.reaped ]] && kill -0 "$worker_pid" 2>/dev/null || break
        read -r -t 1 -u 8 || :
      else
        sleep "$launch_second_wait"
      fi
    done ) & session_pid=$!
fi
# #248: name the CLI's session record in <log>.session-record for worker_produced.
if [[ $locate -eq 0 && ( $cli == codex || -n $child_session ) ]]; then
  find_session_record() {
    local matches=() rec sid
    if [[ $cli == claude ]]; then
      matches=("${CLAUDE_CONFIG_DIR:-$HOME/.claude}"/projects/*/"$child_session".jsonl)
    else
      sid=$(codex_session_id)
      [[ -n $sid ]] && matches=("${CODEX_HOME:-$HOME/.codex}"/sessions/*/*/*/rollout-*-"$sid".jsonl)
    fi
    # No nullglob: an unmatched pattern stays literal and fails -e.
    [[ ${#matches[@]} -gt 0 && -e ${matches[0]} ]] || return 1
    rec=${matches[0]}
    [[ $rec == /* ]] || rec=$PWD/$rec
    printf '%s\n' "$rec" > "${log}.session-record.tmp.$$" && mv -f "${log}.session-record.tmp.$$" "${log}.session-record"
  }
  # #248: look while the CLI lives; the reaped marker ends the loop, and the end path looks once more.
  # A 24 h cap bounds the loop if the marker never comes; the produce deadline is capped below it.
  ( pass=0
    while (( pass++ < 86400 * poll_scale )) && [[ ! -e ${log}.reaped ]] && kill -0 "$worker_pid" 2>/dev/null; do
      find_session_record && exit 0
      if [[ $observer_wakeup_owned -eq 1 ]]; then
        [[ ! -e ${log}.reaped ]] && kill -0 "$worker_pid" 2>/dev/null || break
        read -r -t 1 -u 8 || :
      else
        sleep "$launch_second_wait"
      fi
    done ) & record_pid=$!
fi
sampler_pid=
(
  sample_sleep_pid=
  stop_sampler() {
    if [[ -n $sample_sleep_pid ]]; then
      kill "$sample_sleep_pid" 2>/dev/null
      wait "$sample_sleep_pid" 2>/dev/null
    fi
    exit 0
  }
  trap stop_sampler TERM
  descendant_pids() {
    local parent=$1 child
    while IFS= read -r child; do
      [[ $child == "$sampler_pid" ]] && continue
      printf '%s\n' "$child"
      descendant_pids "$child"
    done < <(pgrep -P "$parent" 2>/dev/null || true)
  }
  while [[ ! -e ${log}.reaped ]] && kill -0 "$worker_pid" 2>/dev/null; do
    while IFS= read -r child_pid; do
      child_start=$(LC_ALL=C TZ=UTC ps -o lstart= -p "$child_pid" 2>/dev/null) || continue
      [[ -n $child_start ]] && printf '%s\t%s\n' "$child_pid" "$child_start"
    done < <(descendant_pids "$worker_pid")
    sleep "${WRSP_CHILD_SAMPLE_INTERVAL:-2}" &
    sample_sleep_pid=$!
    wait "$sample_sleep_pid"
    sample_sleep_pid=
  done
) >> "${log}.children" &
sampler_pid=$!
wait "$worker_pid"; status=$?
# #248: a forwarded TERM interrupts wait; reap the CLI before finishing.
while [[ $term_forwarded -eq 1 || ( ${worker_signal_code:-0} != 0 && -n ${runtime_pid:-} ) ]]; do
  term_forwarded=0
  # A wait that TERM interrupted leaves the CLI in the job table; a completed one already set $status.
  jobs -p | grep -qx "$worker_pid" || break
  wait "$worker_pid"; status=$?
done
runtime_pid=
# #248: the CLI is reaped; leave its observer waits alone. #414 arms finalization cancellation below.
[[ -n $launchd_label && ( $legacy_worker -eq 1 || $locate -eq 1 ) ]] && trap '' TERM
# #248: the CLI is reaped; helpers stop on this marker, so the end path never signals a pid that may be stale.
: > "${log}.reaped"
if [[ $observer_wakeup_owned -eq 1 ]]; then printf '\n\n' >&8; fi
if [[ -n $kill_backstop_pid ]]; then wait "$kill_backstop_pid" 2>/dev/null; fi
if [[ -n $session_pid ]]; then
  wait "$session_pid" 2>/dev/null
  if [[ ! -e ${log}.session ]]; then
    sid=$(codex_session_id)
    if [[ -n $sid ]]; then
      record_fact launch-record session --launch-id "$launch_id" --provider codex --session-id "$sid"
      : > "${log}.session"
    fi
  fi
  [[ $legacy_worker -eq 0 && $locate -eq 0 ]] || rm -f "${log}.session"
fi
# #248
if [[ -n $record_pid ]]; then
  wait "$record_pid" 2>/dev/null
  [[ -e ${log}.session-record ]] || find_session_record || true
fi
if [[ $observer_wakeup_owned -eq 1 ]]; then
  exec 8>&-
  rm -f "${log}.observer-wakeup"
  observer_wakeup_owned=0
fi
# #262: the sampler stops on the reaped marker within one sample interval; never signal its possibly reaped pid.
wait "$sampler_pid" 2>/dev/null
live_pids=() live_records=()
while IFS=$'\t' read -r child_pid child_start; do
  [[ -n $child_pid && -n $child_start ]] || continue
  live_start=$(LC_ALL=C TZ=UTC ps -o lstart= -p "$child_pid" 2>/dev/null) || continue
  if [[ $live_start == "$child_start" ]]; then
    live_pids+=("$child_pid")
    live_records+=("$child_pid"$'\t'"$child_start")
  fi
done < <(sort -u "${log}.children")
if [[ ${#live_pids[@]} -gt 0 ]]; then
  printf '%s\n' "${live_records[@]}" > "${log}.live"
  echo "LIVE CHILDREN: ${live_pids[*]}" >> "$log"
fi
rm -f "${log}.children" "${log}.reaped"
}

worker_signal_code=0 runtime_pid=
worker_parent_signal() {
  [[ $worker_signal_code != 0 ]] || worker_signal_code=$1
  [[ -z ${runtime_pid:-} ]] || kill "-$2" "$runtime_pid" 2>/dev/null || :
}
worker_previous_exit() {
  if [[ -n ${previous_launch_id:-} ]]; then
    record_fact launch-record exit --launch-id "$previous_launch_id" --exit-code "$previous_code" --log "$abs_log"
    previous_launch_id=
  fi
}
worker_reap_runtime() {
  runtime_code=0
  if [[ $worker_signal_code == 143 ]]; then kill -TERM "$runtime_pid" 2>/dev/null || :
  elif [[ $worker_signal_code == 130 ]]; then kill -INT "$runtime_pid" 2>/dev/null || :; fi
  wait "$runtime_pid" || runtime_code=$?
  while jobs -p | grep -qx "$runtime_pid"; do wait "$runtime_pid" || runtime_code=$?; done
  runtime_pid=
}
worker_retry_state() {
  jq -cn --arg logicalId "$logical_id" --argjson first "$first_dispatch" --argjson deadline "$launch_deadline" --arg phase "$1" --argjson attempts "$attempt" '{logicalId:$logicalId,firstDispatchAt:$first,deadlineAt:$deadline,phase:$phase,attempts:$attempts}' > "${log}.retry-state.json.tmp.$$" && mv -f "${log}.retry-state.json.tmp.$$" "${log}.retry-state.json"
}
worker_admit() {
  local admission_deadline=$1 runtime_code
  jq -n --argjson deadline "$admission_deadline" '{deadlineAt:$deadline}' > "$log.admission.request.json"
  [[ $worker_signal_code == 0 ]] || return "$worker_signal_code"
  # The launcher is alive during admission; this never claims model production.
  if [[ -n $launchd_label ]]; then
    printf '%s\n' "$$" > "${log}.started.tmp.$$" && mv -f "${log}.started.tmp.$$" "${log}.started"
  fi
  node "$retry_runtime" worker-admit "$log.admission.request.json" > "$log.admission.json" 2>> "$log" & runtime_pid=$!
  worker_reap_runtime
  [[ $worker_signal_code == 0 ]] || return "$worker_signal_code"
  [[ $runtime_code != 130 && $runtime_code != 143 ]] || return "$runtime_code"
  if [[ $runtime_code != 0 ]] || ! jq -e 'type == "object" and (.delayMs | type == "number")' "$log.admission.json" >/dev/null 2>&1; then
    echo 'WARNING: launch backoff admission unavailable; proceeding without delay' >> "$log"
    jq -n --arg override "${WRSP_LAUNCH_BACKOFF_OVERRIDE:-}" '{expiresAt:null,throttledUntil:null,overflow:false,delayMs:0,nextEligibleAt:null,overridden:($override=="1")}' > "$log.admission.json"
  fi
  jq -r '"LAUNCH ADMISSION: override=\(.overridden) expiry=\(.throttledUntil) delay=\(.delayMs)"' "$log.admission.json" | tee -a "$log"
  return 0
}
worker_fingerprint() {
  # Read-only plan reviews skip worktree evidence collection.
  [[ $plan_review -eq 0 ]] || return 0
  node --input-type=module -e 'import {pathToFileURL} from "node:url"; const [runtime,cwd,log,...owned]=process.argv.slice(1); const {fingerprintWorktree}=await import(pathToFileURL(runtime).href); console.log(fingerprintWorktree(cwd,log,owned));' "$retry_runtime" "$worktree" "$abs_log" "$prompt" "${log}.retry-state.json" "${log}.retry-state.json.tmp.$$" "${log}.children" "${log}.reaped" "${log}.live"
}
worker_exhausted() {
  if [[ -s $log.history.json ]] && [[ $(jq -r .outcome.reason "$log.history.json") == transient-rate-or-capacity || $(jq -r .outcome.reason "$log.history.json") == hard-limit ]]; then
    jq -r .outcome.evidence "$log.history.json" > "$log.availability.tmp.$$"
  else
    printf 'throttled: startup-stall-unknown; attempts=%s; launch window exhausted without model output\n' "$attempt" > "$log.availability.tmp.$$"
  fi
  mv -f "$log.availability.tmp.$$" "$log.availability"
  printf 'AVAILABILITY: %s\n' "$(cat "$log.availability")" | tee -a "$log"
  if [[ -s $log.eligibility.json ]]; then
    jq -r '"RETRY SUMMARY: attempts=\(.attempts) last=\(.reason) next=\(.action) next-eligible=\(.nextEligibleAt // .deadlineAt)"' "$log.eligibility.json" | tee -a "$log"
  fi
}
run_worker_retry() {
  trap 'worker_parent_signal 143 TERM' TERM
  trap 'worker_parent_signal 130 INT' INT
  local clock prior current action code runtime_code attempt_base sid native_record
  logical_id=$launch_id attempt=0
  previous_launch_id= previous_code=
  clock=$(node "$retry_runtime" clock) || return 66
  first_dispatch=$(jq -er '.now | select(isfinite)' <<< "$clock") || return 66
  launch_deadline=$(jq -er '.now + .deadlineMs | select(isfinite)' <<< "$clock") || return 66
  worker_retry_state attempt || return 66
  worker_admit "$launch_deadline" || return $?
  prior=$(worker_fingerprint) || return 66
  grace=${WRSP_WORKER_TERM_GRACE:-10}
  if [[ ! $grace =~ ^[1-9][0-9]{0,4}$ ]] || (( grace > 86400 )); then
    grace=10
    echo 'WARNING: WRSP_WORKER_TERM_GRACE must be an integer from 1 to 86400; using 10 (WRSP #248).' >> "$log"
  fi
  while :; do
    [[ $worker_signal_code == 0 ]] || return "$worker_signal_code"
    clock=$(node "$retry_runtime" clock) || return 66
    if jq -e --argjson deadline "$launch_deadline" '.now >= $deadline' <<< "$clock" >/dev/null; then worker_exhausted; return 10; fi
    current=$(worker_fingerprint) || return 66
    [[ $current == "$prior" ]] || return "${code:-66}"
    [[ ! -e ${log}.first-output && ! -s ${log}.live ]] || return "${code:-66}"
    if (( attempt > 0 )) && native_record=$(worker_record_path "$log") && worker_produced "$native_record"; then return "$code"; fi
    [[ $worker_signal_code == 0 ]] || return "$worker_signal_code"
    if (( attempt > 0 )); then
      [[ -z ${snapshot_pid:-} ]] || wait "$snapshot_pid" 2>/dev/null
      [[ $worker_signal_code == 0 ]] || return "$worker_signal_code"
      previous_launch_id=$launch_id previous_code=$code
      worker_fact_started=0
      rm -f "$log.session-record" "$log.first-output"
      launch_id=$(uuidgen | tr '[:upper:]' '[:lower:]')
      child_session=
      if ! refresh_read_only_policy retry 2>>"$log" || ! build_worker_command retry 2>>"$log"; then
        [[ $worker_signal_code == 0 ]] || return "$worker_signal_code"
        return 66
      fi
      [[ $worker_signal_code == 0 ]] || return "$worker_signal_code"
    fi
    attempt=$((attempt + 1)); attempt_base=$log.attempt-$attempt; attempt_log=$attempt_base.log
    worker_retry_state attempt || return 66
    worker_start_fact
    printf 'LAUNCH ATTEMPT: %s id=%s logical=%s deadline=%s\n' "$attempt" "$launch_id" "$logical_id" "$launch_deadline" | tee -a "$log"
    jq -n --arg cli "$cli" --arg cwd "$worktree" --arg input "$prompt" --arg log "$attempt_log" --arg pointer "$log.session-record" --arg marker "$log.first-output" --arg sid "$child_session" --argjson deadline "$launch_deadline" --argjson grace "$((grace * 1000))" --args '{cli:$cli,argv:$ARGS.positional,cwd:$cwd,inputPath:$input,logPath:$log,sessionRecordPointerPath:$pointer,firstOutputMarkerPath:$marker,outputMode:"human",startupDeadlineAt:$deadline,termGraceMs:$grace} + (if $cli == "claude" then {nativeSessionId:$sid} else {} end)' -- "${cmd[@]}" > "$attempt_base.request.json" || return 66
    [[ $worker_signal_code == 0 ]] || return "$worker_signal_code"
    worker_dispatch
    runtime_code=$status
    [[ -s $attempt_base.result.json && ( $runtime_code == 0 || $runtime_code == 130 || $runtime_code == 143 ) ]] || { [[ $worker_signal_code == 0 ]] || return "$worker_signal_code"; return 66; }
    sid=$(jq -r '.nativeSessionId // empty' "$attempt_base.result.json")
    native_record=$(jq -r '.nativeRecordPath // empty' "$attempt_base.result.json")
    if [[ -n $native_record ]]; then printf '%s\n' "$native_record" > "$log.session-record"; fi
    if [[ -n $sid && ! -e ${log}.session ]]; then
      record_fact launch-record session --launch-id "$launch_id" --provider "$cli" --session-id "$sid"
    fi
    rm -f "${log}.session"
    current=$(worker_fingerprint) || return 66
    output=no
    [[ ! -e ${log}.first-output ]] || output=yes
    if native_record=$(worker_record_path "$log") && worker_produced "$native_record"; then output=yes; fi
    jq --argjson first "$first_dispatch" --argjson attempts "$attempt" --arg changed "$([[ $prior == "$current" ]] && echo no || echo yes)" --arg output "$output" --arg live "$([[ -s ${log}.live ]] && echo yes || echo no)" '{firstDispatchAt:$first,attempts:$attempts,startupElapsedMs:(.endedAt-.dispatchedAt),outcome:(if $changed == "yes" then (.outcome + {reason:"work-observed",retryable:false,availability:false}) elif $live == "yes" or .cleanupComplete != true then (.outcome + {reason:"cleanup-uncertain",retryable:false,availability:false}) elif $output == "yes" or .firstOutput then (.outcome + {reason:"produced",retryable:false,availability:false}) else .outcome end),retryAfter:.retryAfter}' "$attempt_base.result.json" > "$log.history.json" || return 66
    node "$retry_runtime" worker-next "$log.history.json" > "$log.eligibility.json" || return 66
    jq -cn --arg logicalId "$logical_id" --arg launchId "$launch_id" --arg sid "$sid" --argjson attempt "$attempt" --slurpfile request "$attempt_base.request.json" --slurpfile result "$attempt_base.result.json" --slurpfile eligibility "$log.eligibility.json" '{logicalId:$logicalId,launchId:$launchId,nativeSessionId:(if $sid == "" then null else $sid end),attempt:$attempt,request:$request[0],result:$result[0],eligibility:$eligibility[0]}' >> "$log.attempts.jsonl" || return 66
    code=$(jq -r 'if .signal == "SIGINT" then 130 elif .signal == "SIGTERM" then 143 elif .signal == "SIGKILL" then 137 else (.exitCode // 66) end' "$attempt_base.result.json")
    action=$(jq -r .action "$log.eligibility.json")
    [[ $worker_signal_code == 0 ]] || return "$worker_signal_code"
    [[ $runtime_code == 0 ]] || return "$runtime_code"
    if [[ $action == defer || ( $action == stop && $(jq -r .outcome.reason "$log.history.json") == hard-limit ) ]]; then
      worker_exhausted
      return 10
    fi
    [[ $action == retry ]] || return "$code"
    [[ $worker_signal_code == 0 ]] || return "$worker_signal_code"
    printf 'LAUNCH RETRY: reason=%s next=%s wait=%s\n' "$(jq -r .reason "$log.eligibility.json")" "$(jq -r .nextEligibleAt "$log.eligibility.json")" "$(jq -r .delayMs "$log.eligibility.json")" | tee -a "$log"
    worker_retry_state backoff || return 66
    [[ $worker_signal_code == 0 ]] || return "$worker_signal_code"
    node "$retry_runtime" wait "$log.eligibility.json" & runtime_pid=$!
    worker_reap_runtime
    [[ $worker_signal_code == 0 ]] || return "$worker_signal_code"
    [[ $runtime_code == 0 ]] || return "$runtime_code"
  done
}
# Expected cancellation statuses must still reach finalization without a dispatch.
set +e
if [[ $cli == agy ]]; then
  trap 'worker_parent_signal 143 TERM' TERM
  trap 'worker_parent_signal 130 INT' INT
  if [[ -z $launchd_label ]]; then
    printf '%s\n' "$$" > "$log.pid"
  fi
  worker_start_fact
  if [[ $worker_signal_code != 0 ]]; then
    status=$worker_signal_code
  else
    "${cmd[@]}" >> "$log" 2>&1 & runtime_pid=$!
    worker_reap_runtime
    status=$runtime_code
  fi
elif [[ $locate -eq 0 && $legacy_worker -eq 0 ]]; then
  run_worker_retry
  status=$?
else
  status=0
  if [[ $locate -eq 0 ]]; then
    trap 'worker_parent_signal 143 TERM' TERM
    trap 'worker_parent_signal 130 INT' INT
    if [[ -n $retry_runtime ]] && admission_clock=$(node "$retry_runtime" clock) && admission_deadline=$(jq -er --argjson seconds "$produce_timeout" '.now + $seconds*1000 | select(isfinite)' <<< "$admission_clock"); then
      worker_admit "$admission_deadline" || status=$?
    else
      echo 'WARNING: launch backoff clock unavailable; proceeding without delay' >> "$log"
    fi
    trap - TERM INT
  fi
  if [[ $worker_signal_code != 0 ]]; then status=$worker_signal_code
  elif [[ $status == 0 ]]; then worker_start_fact; worker_dispatch; fi
fi
worker_finalize() {
if [[ $locate -eq 0 && $legacy_worker -eq 0 ]]; then
  worker_previous_exit
  [[ -z ${first_dispatch:-} ]] || worker_retry_state complete
fi
# WRSP #217: hand the worker's session to the commit hook for the exact tree and HEAD it left staged.
if [[ $locate -eq 0 && $research -eq 0 && $plan_review -eq 0 && $worker_fact_started -eq 1 && ( $legacy_worker -eq 1 || ( -s $log.history.json && $(jq -r .outcome.reason "$log.history.json") =~ ^(produced|work-observed)$ ) ) ]]; then
  worker_session=
  if [[ $cli == claude && -n $child_session ]]; then
    worker_session=claude:$child_session
  elif [[ $cli == codex ]]; then
    sid=$(codex_session_id 2>/dev/null || true)
    [[ -n $sid ]] && worker_session=codex:$sid
  fi
  if [[ -n $worker_session ]] && ! git -C "$worktree" -c core.fsmonitor=false -c core.hooksPath=/dev/null diff --cached --quiet 2>/dev/null \
    && staged_tree=$(git -C "$worktree" -c core.fsmonitor=false -c core.hooksPath=/dev/null write-tree 2>/dev/null) \
    && staged_head=$(git -C "$worktree" -c core.fsmonitor=false -c core.hooksPath=/dev/null rev-parse -q --verify HEAD 2>/dev/null || echo none) \
    && handoff=$(git -C "$worktree" -c core.fsmonitor=false -c core.hooksPath=/dev/null rev-parse --path-format=absolute --git-path wrsp-staged-session 2>/dev/null) \
    && printf '%s %s %s\n' "$worker_session" "$staged_tree" "$staged_head" > "$handoff" 2>/dev/null; then
    echo "STAGED HANDOFF: $worker_session $staged_tree $staged_head" >> "$log"
  fi
fi
# #332: enumerate the selected CLI's last error-shaped line, retaining its original bytes.
# This is a coarse matcher over a mixed human log, not a security boundary.
availability_message() {
  LC_ALL=C awk -v cli="$1" '
    {
      normalized = $0
      gsub(/\033\[[0-9;]*m/, "", normalized)
      sub(/\r$/, "", normalized)
      if ((cli == "codex" && normalized ~ /^ERROR:/) ||
          (cli == "claude" && normalized ~ /^API Error:/)) {
        original = $0
        last = normalized
      }
    }
    END {
      if (cli == "codex") {
        known = last == "ERROR: Selected model is at capacity. Please try a different model." ||
          index(last, "ERROR: rate limit exceeded: ") == 1 ||
          index(last, "ERROR: You’ve hit your usage limit.") == 1 ||
          (index(last, "ERROR: You’ve hit your usage limit for ") == 1 &&
            length(last) > length("ERROR: You’ve hit your usage limit for ")) ||
          last == "ERROR: Quota exceeded. Check your plan and billing details."
      } else {
        known = last ~ /^API Error: (429|529)([[:space:]].*|$)/ ||
          last == "API Error: Server is temporarily limiting requests (not your usage limit)" ||
          last == "API Error: Server is temporarily limiting requests (not your usage limit) · Rate limited"
      }
      if (known) print original
      else exit 1
    }
  ' "$2"
}
if [[ $locate -eq 0 && $legacy_worker -eq 1 && $status -ge 1 && $status -le 127 ]] && availability=$(availability_message "$cli" "$log"); then
  printf '%s\n' "$availability" > "${log}.availability.tmp.$$" && mv -f "${log}.availability.tmp.$$" "${log}.availability"
  status=10
  printf 'AVAILABILITY: %s\n' "$availability" | tee -a "$log"
fi
if [[ $status -eq 10 && -s ${log}.availability ]]; then
  if inventory=$(git -C "$worktree" -c core.fsmonitor=false -c core.hooksPath=/dev/null --no-optional-locks -c core.quotePath=true status --porcelain=v1 --untracked-files=all); then
    if [[ -n $inventory ]]; then
      printf 'UNCOMMITTED CHANGES (preserved):\n%s\n' "$inventory" | tee -a "$log"
    fi
  else
    echo 'WARNING: uncommitted worktree inventory failed; inspect the retained worktree.' | tee -a "$log"
  fi
fi
echo "EXIT:$status" >> "$log"
return "$status"
}

worker_finalize_after_snapshot() {
if [[ $records -eq 1 && $worker_fact_started -eq 1 ]]; then
  if [[ $cli == agy && -f $abs_log.agy.conversation && ! -L $abs_log.agy.conversation ]] &&
    IFS= read -r sid < "$abs_log.agy.conversation" &&
    [[ $sid =~ ^[[:xdigit:]]{8}-[[:xdigit:]]{4}-[[:xdigit:]]{4}-[[:xdigit:]]{4}-[[:xdigit:]]{12}$ ]]; then
    record_fact launch-record session --launch-id "$launch_id" --provider agy --session-id "$sid"
    if ! jq -cn --arg sid "$sid" --arg cwd "$worktree" --arg role "$launch_role" '{session_id:$sid,cwd:$cwd,role:$role}' |
      node "$HOME/.agents/hooks/session-role.mjs" record agy >> "$log" 2>&1; then
      echo 'WARNING: agy session-role record not written (#567).' >> "$log"
    fi
  fi
  record_fact launch-record exit --launch-id "$launch_id" --exit-code "$status" --log "$abs_log"
fi

if [[ $locate -eq 1 ]]; then
  revision=$(git -C "$worktree" -c core.fsmonitor=false -c core.hooksPath=/dev/null rev-parse HEAD 2>/dev/null) || revision=unknown
  if porcelain=$(git -C "$worktree" -c core.fsmonitor=false -c core.hooksPath=/dev/null --no-optional-locks status --porcelain 2>/dev/null); then
    dirty=no
    [[ -n $porcelain ]] && dirty=yes
  else
    dirty=unknown
  fi
  echo "REPOSITORY: $worktree REVISION: $revision DIRTY: $dirty"
  if [[ -s $answer ]]; then
    head -c 8192 "$answer"
    if [[ $(wc -c < "$answer") -gt 8192 ]]; then
      printf '\n[answer truncated at 8192 bytes; full answer in %s]\n' "$answer"
    fi
  else
    echo 'STATUS: ERROR'
    echo "the locator produced no answer; see $log"
    [[ $status -eq 0 ]] && status=70
  fi
fi

# Everything below is best effort: the worker's exit status and its BRIEF GAP
# report are never lost to a provenance failure.
record_provenance() {
  local gitdir after
  gitdir=$(git -C "$worktree" -c core.fsmonitor=false -c core.hooksPath=/dev/null rev-parse --git-dir) || return 1
  [[ $gitdir == /* ]] || gitdir=$worktree/$gitdir
  [[ -d $gitdir/wrsp ]] || mkdir "$gitdir/wrsp" || return 1
  after=$(snapshot) || return 1
  [[ -n $after ]] || return 0
  # Whole snapshot lines form a membership set; emit only new or changed lines.
  # An empty baseline leaves the set empty, so all nonempty after paths count.
  printf '%s\n' "$after" | awk '
    FILENAME == ARGV[1] { seen[$0] = 1; next }
    !($0 in seen) { sub(/^[^\t]*\t/, ""); if ($0 != "") print }
  ' "$before" - >> "$gitdir/wrsp/worker-touched" || true
  return 0
}
if [[ $research -eq 0 && $locate -eq 0 && $plan_review -eq 0 ]]; then
  if ! record_provenance 2>>"$log"; then
    echo "WARNING: worker provenance not recorded; the pre-commit reminder may name this worker's paths." | tee -a "$log" >&2
  fi
fi
# WRSP #344: the finite no-gap grammar and repeated-marker rule in logReportsBriefGap.
if LC_ALL=C grep '^BRIEF GAP:' "$log" | LC_ALL=C grep -viE '^BRIEF GAP:[[:space:]]*(none[[:space:]]*\.?)?[[:space:]]*$|^BRIEF GAP:[[:space:]]*none[[:space:]]*\.[[:space:]]+Deviations:.*$' >/dev/null || LC_ALL=C grep '^BRIEF GAP:.*BRIEF GAP:' "$log" >/dev/null; then
  echo "BRIEF GAP reported; see $log" >&2
fi
return "$status"
}

# #414: only post-model helpers enter these groups; the model has already been reaped.
# Keep cancellation in the owner: foreground shell commands defer traps, but wait on
# an asynchronous group is interruptible. The helper subshell never runs owner cleanup.
finalization_pid= finalization_term_pending=0
worker_publish_exit() {
  if [[ $cli == agy && $agy_lane == 1 ]]; then
    if ! printf '%s\n' "$1" | node "$agy_worker" publish-state "${abs_log}.exit" 2>> "$log"; then
      printf 'EXIT:73\n' >> "$log"
      return 73
    fi
  else
    printf '%s\n' "$1" > "${log}.exit.tmp.$$" && mv -f "${log}.exit.tmp.$$" "${log}.exit"
  fi
}
worker_cancel_finalization() {
  # Atomic terminal publication ends finalization; late launchd removal during
  # owner cleanup must retain the completed worker status (#248).
  [[ ! -e ${log}.exit ]] || return 0
  trap '' TERM
  # Decimal PID lists also work with Bash 3.2's nounset/empty-array behavior.
  local pid active= owned="${snapshot_pid:-} $finalization_pid"
  for pid in $owned; do
    if kill -0 -- "-$pid" 2>/dev/null; then
      kill -TERM -- "-$pid" 2>/dev/null || :
      active="$active $pid"
    fi
  done
  # One total grace, independent of the model's TERM grace. A single sleep avoids
  # multiplying process-start overhead into the deadline on a busy host.
  [[ -z $active ]] || sleep "$launch_second_wait"
  for pid in $active; do
    kill -0 -- "-$pid" 2>/dev/null && kill -KILL -- "-$pid" 2>/dev/null || :
  done
  for pid in $owned; do wait "$pid" 2>/dev/null || :; done
  printf '%s\n' 'CANCELLED: post-model finalization interrupted by TERM' 'EXIT:143' >> "$log"
  worker_publish_exit 143 || { [[ $cli != agy || $agy_lane != 1 ]] || exit 73; }
  exit 143
}
trap worker_cancel_finalization TERM
# Resolve the runtime's latch before finalization emits completion facts.
[[ $worker_signal_code != 143 ]] || status=143
worker_run_finalization() {
  local helper_code group_start_code=0
  # Latch TERM until the new group's identity is captured, then consume the latch.
  # The runtime's earlier latch retains completed-attempt evidence normally.
  trap 'finalization_term_pending=1' TERM
  worker_group_start "$1" || group_start_code=$?
  finalization_pid=$worker_group_pid
  trap worker_cancel_finalization TERM
  [[ $finalization_term_pending == 0 ]] || worker_cancel_finalization
  [[ $group_start_code == 0 ]] || { status=66; return; }
  wait "$finalization_pid" 2>/dev/null
  helper_code=$?
  # Other existing signal latches may interrupt wait without cancelling this
  # phase. Drain the owned child before publishing its actual result.
  while jobs -p | grep -qx "$finalization_pid"; do
    wait "$finalization_pid" 2>/dev/null
    helper_code=$?
  done
  status=$helper_code
  finalization_pid=
}
worker_run_finalization worker_finalize
# Preserve the original snapshot wait after EXIT and before exit telemetry.
if [[ -n ${snapshot_pid:-} ]]; then
  wait "$snapshot_pid" 2>/dev/null
  snapshot_pid=
fi
worker_run_finalization worker_finalize_after_snapshot
if [[ $worker_signal_code == 143 ]]; then
  printf '%s\n' 'CANCELLED: worker interrupted by TERM' 'EXIT:143' >> "$log"
fi
worker_publish_exit "$status" || { [[ $cli != agy || $agy_lane != 1 ]] || status=73; }
exit "$status"
