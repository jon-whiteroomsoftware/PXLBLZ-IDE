import Darwin
import Foundation
import Security

private let service = "wrsp-lane-keychain-unlock"
private let filename = "github.keychain-db"

private func keychainPath(home: String, account: String) -> String? {
    let parts = account.split(separator: "/", omittingEmptySubsequences: false)
    if account != filename {
        guard parts.count == 4, parts[0] == "repositories", parts[3] == filename,
              parts[1].range(of: #"^[a-z0-9][a-z0-9-]*$"#, options: .regularExpression) != nil,
              parts[2].range(of: #"^[a-z0-9_.-]+$"#, options: .regularExpression) != nil,
              parts[2] != ".", parts[2] != ".." else { return nil }
    }

    var path = home
    let directories = [".local", "state", "wrsp", "lane-keychain"] + parts.dropLast().map(String.init)
    for (index, dir) in directories.enumerated() {
        path += "/" + dir
        var info = stat()
        guard lstat(path, &info) == 0, info.st_uid == getuid(),
              info.st_mode & S_IFMT == S_IFDIR, info.st_mode & 0o022 == 0,
              index < 3 || info.st_mode & 0o777 == 0o700 else { return nil }
    }
    path += "/" + filename
    var info = stat()
    guard lstat(path, &info) == 0, info.st_uid == getuid(), info.st_nlink == 1,
          info.st_mode & S_IFMT == S_IFREG, info.st_mode & 0o777 == 0o600 else { return nil }
    return path
}

private func reportStatus(_ status: OSStatus, exitCode: Int32) -> Int32 {
    try? FileHandle.standardError.write(contentsOf: Data("status=\(status)\n".utf8))
    return exitCode
}

private func unlock(account: String) -> Int32 {
    guard let user = getpwuid(getuid()), let homePath = user.pointee.pw_dir else { return 65 }
    let home = String(cString: homePath)
    guard let path = keychainPath(home: home, account: account) else { return 69 }

    var lane: SecKeychain?
    guard SecKeychainOpen(path, &lane) == errSecSuccess, let lane else { return 69 }
    var login: SecKeychain?
    let openStatus = SecKeychainOpen(home + "/Library/Keychains/login.keychain-db", &login)
    guard openStatus == errSecSuccess, let login else { return reportStatus(openStatus, exitCode: 65) }
    var loginStatus: SecKeychainStatus = 0
    let loginQueryStatus = SecKeychainGetStatus(login, &loginStatus)
    guard loginQueryStatus == errSecSuccess, loginStatus & SecKeychainStatus(kSecUnlockStateStatus) != 0 else {
        return reportStatus(loginQueryStatus, exitCode: 65)
    }

    var length: UInt32 = 0
    var password: UnsafeMutableRawPointer?
    let status = SecKeychainFindGenericPassword(login, UInt32(service.utf8.count), service,
                                                 UInt32(account.utf8.count), account, &length, &password, nil)
    defer {
        if let password {
            _ = memset_s(password, Int(length), 0, Int(length))
            SecKeychainItemFreeContent(nil, password)
        }
    }
    if status == errSecItemNotFound { return 66 }
    guard status == errSecSuccess, let password, length > 0 else { return reportStatus(status, exitCode: 67) }
    let unlockStatus = SecKeychainUnlock(lane, length, password, true)
    guard unlockStatus == errSecSuccess else { return reportStatus(unlockStatus, exitCode: 68) }
    var laneStatus: SecKeychainStatus = 0
    let laneQueryStatus = SecKeychainGetStatus(lane, &laneStatus)
    guard laneQueryStatus == errSecSuccess, laneStatus & SecKeychainStatus(kSecUnlockStateStatus) != 0 else {
        return reportStatus(laneQueryStatus, exitCode: 68)
    }
    return 0
}

var noCore = rlimit(rlim_cur: 0, rlim_max: 0)
guard CommandLine.arguments.count == 2,
      setrlimit(RLIMIT_CORE, &noCore) == 0 else { exit(65) }
let interactionStatus = SecKeychainSetUserInteractionAllowed(false)
guard interactionStatus == errSecSuccess else { exit(reportStatus(interactionStatus, exitCode: 65)) }
exit(unlock(account: CommandLine.arguments[1]))
