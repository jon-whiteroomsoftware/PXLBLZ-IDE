#!/usr/bin/env bash
# WRSP #147: worker power-on checks run in the current worktree.
# Browsers, ps and sysctl are host-only and are not checked.
set -uo pipefail

failed=0

run_check() {
  local name=$1 reason stderr_file
  shift
  if ! stderr_file=$(mktemp "${TMPDIR:-/tmp}/wrsp-self-test.XXXXXX"); then
    printf 'FAIL %s: cannot capture stderr\n' "$name"
    failed=1
    return
  fi
  if "$@" > /dev/null 2> "$stderr_file"; then
    printf 'PASS %s\n' "$name"
  else
    reason=$(tail -n 1 "$stderr_file")
    reason=${reason:0:200}
    printf 'FAIL %s: %s\n' "$name" "${reason:-check failed}"
    failed=1
  fi
  rm -f -- "$stderr_file"
}

check_instructions() {
  [[ -r $HOME/.agents/AGENTS.md && -s $HOME/.agents/AGENTS.md ]] || {
    printf 'missing, unreadable or empty %s/.agents/AGENTS.md\n' "$HOME" >&2
    return 1
  }
}

check_skills() {
  [[ -r $HOME/.agents/skills/worker/SKILL.md ]] || {
    printf 'missing or unreadable %s/.agents/skills/worker/SKILL.md\n' "$HOME" >&2
    return 1
  }
}

check_git_write() {
  local inside gitdir file ref result=0 ref_created=0
  inside=$(git rev-parse --is-inside-work-tree) || return 1
  [[ $inside == true ]] || { printf 'not inside a git work tree\n' >&2; return 1; }
  gitdir=$(git rev-parse --git-dir) || return 1
  file=$gitdir/wrsp-self-test.$$
  ref=refs/wrsp/self-test/$$
  if [[ -e $file ]] || git show-ref --verify --quiet "$ref"; then
    printf 'git probe already exists\n' >&2
    return 1
  fi
  if ! (set -C; : > "$file"); then result=1; fi
  if [[ -e $file ]] && ! rm -- "$file"; then result=1; fi
  if git update-ref "$ref" HEAD; then
    ref_created=1
    if git update-ref -d "$ref"; then ref_created=0; else result=1; fi
  else
    result=1
  fi
  if [[ -e $file ]] && ! rm -f -- "$file"; then result=1; fi
  if [[ $ref_created == 1 ]] && ! git update-ref -d "$ref"; then result=1; fi
  return "$result"
}

run_check instructions check_instructions
run_check skills check_skills
run_check git-write check_git_write
run_check loopback node -e 'const server = require("node:net").createServer(); server.once("error", error => { console.error(error.message); process.exitCode = 1 }); server.listen(0, "127.0.0.1", () => server.close())'
run_check network curl -sS -o /dev/null -m 8 "${WRSP_SELF_TEST_URL:-https://github.com}"
exit "$failed"
