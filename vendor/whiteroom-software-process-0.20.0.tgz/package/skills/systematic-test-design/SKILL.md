---
name: systematic-test-design
description: Designs systemic, preventative tests by identifying invariants, behavioral partitions, operation sequences, and fault-sensitive oracles. Use whenever planning or writing tests, especially for stateful or coupled behavior, transformation engines, recurring or review-discovered bugs, or test-suite hardening. Also invoke at planning time, while writing an issue or spec, to record must-test cases, partitions, and the oracle surface in the spec.
---

# Systematic Test Design

## Outcome

Produce the smallest test model that gives convincing evidence for the behavior:

- the stable public or domain boundary under test;
- governing invariants;
- meaningful behavioral partitions;
- representative operation sequences;
- accepted, rejected, and preservation oracles;
- the testing forms that fit the risks;
- residual gaps that remain after implementation.

Use the `tdd` skill to execute this model one red-green-refactor cycle at a time.

## Proportionality gate

Start every test-planning task here, then scale the work to the risk.

A single focused test is enough when one observable behavior completely describes
an isolated change. Use the full workflow when behavior is stateful or coupled,
an output becomes another operation's input, several dimensions affect the
result, defects recur in one family, or review exposes missing systemic coverage.

Do not create a matrix merely to decorate a trivial change.

## Workflow

1. **Name the boundary.** Test through the narrowest stable interface that exposes
   the real behavior. Prefer domain and public interfaces over private helpers.
   Read any applicable current engineering contract before selecting cases.
2. **State the invariants.** Write what must always be true before selecting
   examples. Include preservation rules and legal rejection behavior. If the
   observed interface and contract disagree, report the mismatch rather than
   silently redefining the invariant.
3. **Partition the state space.** Identify dimensions that can change the result,
   then select boundary, representative, and adversarial values. Use risk-based
   or pairwise coverage instead of an exhaustive Cartesian product.
4. **Select sequences.** Exercise outputs as later inputs when edit order,
   retries, round trips, or interactions between operations can reveal defects.
5. **Define the oracles.** Specify the whole evidence for success, rejection, and
   preservation. Avoid partial assertions that allow invalid surrounding state.
6. **Choose the test form.** Prefer reusable contracts for shared invariants,
   tables for partitions, model or property tests for broad state spaces, and
   mutation testing when fault sensitivity remains uncertain. Keep the form fast: follow ~/src/whiteroom-software-process/docs/reference/test-speed.md (no real sleeps, condition waits, deliberate timeouts, shape-compatible mocks).
7. **Execute incrementally.** Use `tdd`; demonstrate each new behavior or
   regression failing against the incomplete or buggy implementation before
   making it pass.
8. **Sweep the defect class.** For a discovered bug, inspect sibling operations,
   ownership scopes, boundary values, and sequences governed by the same rule.
9. **Report evidence.** At handoff, name the invariants, partitions, sequences,
   initial failing evidence, and residual gaps. Counts and coverage percentages
   are supporting measurements, not the conclusion.

## Oracle surface

The oracle asserts against the artifact its consumer sees or opens — the
exported file a slicer loads, the route a user clicks, the rendered frame,
the published page — never generator internals. Source constants, jsdom
projections, prototype routes, and pixel counts are adjacent properties: a
suite can stay green while the consumer-facing artifact is broken, and a
green suite licenses nothing about surfaces it never exercised. When the
consumer surface is expensive to exercise, put one acceptance check at that
surface and keep the cheap adjacent tests as diagnostics, never as the
completion evidence.

## Planning-time use

Invoke this skill while writing an issue or spec, not only at implementation
time. Record in the issue (per `issue-workflow`): the must-test cases, the
partitions that matter, the oracle surface, and where the check runs.
Spec-named cases are the floor at implementation time — implementers add,
never silently drop. Oracle selection belongs up front: chosen in the spec,
it prevents the green-but-broken class instead of documenting it afterward.
Record applicable contract clauses under **Docs impact** and distinguish claims
the selected evidence proves from residual gaps that still rely on review.

## Transformation contract

For pure state transformations, accepted edits should normally prove:

- the input was not mutated;
- the complete output validates;
- observable projection is correct;
- dependent identities and references remain valid.

Rejected edits should normally prove:

- the complete prior state is unchanged;
- no partial side effect escaped;
- the rejection reason is observable when the API exposes one.

## Escalation

Repeated findings in one behavior family trigger stabilization: pause adjacent
feature expansion, strengthen the shared contract or model, sweep the defect
class, and resume only after the systemic evidence passes.

## Examples

- A copy change needs one focused rendering assertion, not a state matrix.
- A timeline move spanning owners needs invariants, boundary partitions,
  reference-preservation checks, and at least one move-then-edit sequence.
- A review-discovered parser bug needs a failing regression plus a sweep of
  sibling syntax forms governed by the same parsing rule.
