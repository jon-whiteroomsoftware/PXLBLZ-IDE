import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { setTimeout } from 'node:timers/promises';
import { readLane, validateState } from './lane-check.mjs';
import { optionalBytes } from './lane-messages.mjs';

function options(args) {
  const [handle, ...flags] = args;
  if (!handle || handle.startsWith('--') || flags.length !== 4) throw new Error('expected HANDLE --state FILE --timeout SECONDS (1..1200)');
  const values = {};
  for (let i = 0; i < flags.length; i += 2) {
    const key = flags[i], value = flags[i + 1];
    if (!['--state', '--timeout'].includes(key) || key in values || !value || value.startsWith('--')) throw new Error('invalid or duplicate watch argument');
    values[key] = value;
  }
  if (!/^[1-9][0-9]{0,3}$/.test(values['--timeout']) || Number(values['--timeout']) > 1200) throw new Error('expected --timeout SECONDS (1..1200)');
  return { handle, stateFile: path.resolve(values['--state']), timeout: Number(values['--timeout']) };
}

/** Notifications are hints: only the awakened lead's check consumes state. */
export async function watchLane({ handle, stateFile, timeout }, { now = () => performance.now(), wait = setTimeout } = {}) {
  const file = fs.realpathSync(handle), directory = path.dirname(file), name = path.basename(file);
  const deadline = now() + timeout * 1000;
  let initial;
  for (;;) {
    const lane = readLane(directory, name, { observeActivity: false });
    initial ??= { identity: lane.identity, turn: lane.turn };
    if (lane.retired || lane.identity !== initial.identity || lane.turn !== initial.turn) {
      return { code: 3, message: `WATCH SUPERSEDED: ${initial.identity} turn ${initial.turn}\n` };
    }
    const bytes = optionalBytes(stateFile);
    let previous;
    if (bytes !== null) {
      let state;
      try { state = JSON.parse(bytes.toString('utf8')); validateState(state); }
      catch (error) { throw new Error(`${stateFile}: ${error.message}`); }
      if (state.directory !== directory) throw new Error(`${stateFile}: directory configuration mismatch`);
      previous = state.lanes.find(row => row.identity === lane.identity);
    }
    const finished = lane.finished.some(row => row.turn === lane.turn);
    const kind = finished && !previous?.finished.includes(lane.turn) ? (lane.land ? 'land-request' : 'finished')
      : lane.review && (lane.review !== previous?.review?.message || lane.turn !== previous?.review?.turn) ? 'review-request' : null;
    if (kind) return { code: 0, message: `signal\t${lane.identity}\tturn\t${lane.turn}\t${kind}\n` };
    const remaining = deadline - now();
    if (remaining <= 0) return { code: 124, message: `WATCH TIMEOUT: ${lane.identity} turn ${lane.turn} after ${timeout}s\n` };
    await wait(Math.min(250, remaining));
  }
}

async function main(args) {
  let parsed;
  try { parsed = options(args); }
  catch (error) { process.stderr.write(`REFUSED: ${error.message}\n`); return 64; }
  try {
    const result = await watchLane(parsed);
    process[result.code === 0 ? 'stdout' : 'stderr'].write(result.message);
    return result.code;
  } catch (error) { process.stderr.write(`REFUSED: ${error.message}\n`); return 65; }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) process.exitCode = await main(process.argv.slice(2));
