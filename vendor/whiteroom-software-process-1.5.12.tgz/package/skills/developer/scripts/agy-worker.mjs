import { execFileSync, fork, spawn } from 'node:child_process'
import { closeSync, lstatSync, mkdtempSync, openSync, readFileSync, readdirSync, realpathSync, renameSync, rmSync, writeFileSync } from 'node:fs'
import { homedir, tmpdir, userInfo } from 'node:os'
import { basename, dirname, isAbsolute, join, resolve } from 'node:path'
import { setTimeout as delay } from 'node:timers/promises'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { issueArtifactDirectory } from './retain-brief.mjs'

const self = fileURLToPath(import.meta.url)
const uuid = /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i

function entry(path) {
  try { return lstatSync(path) } catch (error) {
    if (error.code !== 'ENOENT') throw error
    return undefined
  }
}

function directory(path) {
  const found = entry(path)
  if (!found) return false
  if (!found.isDirectory()) throw new Error('unverified configuration directory ' + path)
  return true
}

function object(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
}

function refuseMcpServers(configDir) {
  const path = join(configDir, 'mcp_config.json')
  const found = entry(path)
  if (!found) return
  if (found.isFile()) {
    try {
      const config = JSON.parse(readFileSync(path, 'utf8').trim() || '{}')
      if (object(config) && Object.keys(config).every(key => key === 'mcpServers')) {
        const servers = config.mcpServers
        if (servers === undefined || (object(servers) && Object.values(servers).every(server => server?.disabled === true))) return
      }
    } catch { /* An unreadable or invalid registry cannot rule out server startup. */ }
  }
  throw new Error('read-only agy MCP servers are configured or cannot be ruled out in ' + path)
}

function refusePluginHooks(plugins, readOnly) {
  if (!directory(plugins)) return
  for (const plugin of readdirSync(plugins, { withFileTypes: true })) {
    const root = join(plugins, plugin.name)
    if (plugin.isSymbolicLink() || (plugin.isDirectory() && entry(join(root, 'hooks.json')))) {
      throw new Error('plugin hooks are present or cannot be ruled out in ' + root)
    }
    if (readOnly && plugin.isDirectory()) refuseMcpServers(root)
  }
}

function gitPermissions(cwd, root) {
  const output = execFileSync('git', ['rev-parse', '--path-format=absolute', '--git-dir', '--git-common-dir'], { cwd, encoding: 'utf8' })
  const paths = output.replace(/\n$/, '').split('\n')
  const invalid = () => new Error('unverified Git metadata for ' + root)
  if (paths.length !== 2 || paths.some(path => !path.startsWith('/'))) throw invalid()
  const [gitDir, common] = paths.map(path => realpathSync(path))
  const dotGit = join(root, '.git')
  const marker = entry(dotGit)
  let readable = []
  let writable
  if (marker?.isDirectory() && gitDir === dotGit && common === dotGit) {
    writable = [dotGit]
  } else if (marker?.isFile() && basename(common) === '.git' && dirname(gitDir) === join(common, 'worktrees')) {
    const backlink = join(gitDir, 'gitdir')
    try {
      if (!entry(backlink)?.isFile() || realpathSync(resolve(gitDir, readFileSync(backlink, 'utf8').trimEnd())) !== dotGit) throw invalid()
    } catch { throw invalid() }
    // A linked commit needs its index and HEAD plus shared object, ref and reflog storage.
    // Keep other worktree administration directories and common config read-only.
    const shared = ['objects', 'refs', 'logs'].map(name => join(common, name))
    for (const path of shared) directory(path)
    readable = [common]
    writable = [gitDir, ...shared]
  } else {
    throw invalid()
  }
  if ([...readable, ...writable].some(path => !permissionPath(path))) throw invalid()
  return { readable, writable }
}

function permissionPath(path) {
  return isAbsolute(path) && path !== '/' && !/[\x00-\x1f\\()*?\[\]]/.test(path)
}

function developerReadPaths(home) {
  const config = process.env.XDG_CONFIG_HOME || join(home, '.config')
  const gh = process.env.GH_CONFIG_DIR || join(config, 'gh')
  const paths = [join(home, '.agents'), join(home, '.local/bin'), join(home, '.local/share/wrsp/host'), join(config, 'wrsp'),
    ...['config.yml', 'hosts.yml', 'state.yml'].map(name => join(gh, name))]
  return paths.filter(isAbsolute).filter(path => entry(path)).map(path => realpathSync(path))
}

function protectedDeveloperState(audit, raw) {
  const log = audit.slice(0, -'.agy-hooks.jsonl'.length)
  return [raw, log, audit, ...['.progress', '.started', '.live', '.pid', '.exit', '.agy.pid', '.agy.pgid',
    '.agy.conversation', '.agy.result.json'].map(suffix => log + suffix)]
}

function configuredPermissions(home) {
  const gemini = join(home, '.gemini')
  const config = join(gemini, 'antigravity-cli')
  if (!directory(gemini) || !directory(config)) return {}
  const settings = join(config, 'settings.json')
  const found = entry(settings)
  if (!found) return {}
  const invalid = () => new Error('unreadable or invalid agy permissions settings')
  if (!found.isFile()) throw invalid()
  let value
  try { value = JSON.parse(readFileSync(settings, 'utf8')) } catch { throw invalid() }
  if (!object(value)) throw invalid()
  const permissions = value.permissions
  if (permissions === undefined) return {}
  if (!object(permissions) || Object.entries(permissions).some(([key, rules]) =>
    !['allow', 'ask', 'deny'].includes(key) || !Array.isArray(rules) || rules.some(rule => typeof rule !== 'string'))) throw invalid()
  return permissions
}

async function preflight(worktree, cache, raw) {
  const lane = process.env.WRSP_AGY_LANE
  const research = lane === 'researcher'
  const readOnly = research || lane === 'reviewer'
  if (!(readOnly ? process.env.WRSP_ROLE === lane : lane === '1' && process.env.WRSP_ROLE === 'batch')) {
    throw new Error('invalid agy lane role marker')
  }
  const cwd = realpathSync(worktree)
  const gitRoot = realpathSync(execFileSync('git', ['rev-parse', '--show-toplevel'], { cwd, encoding: 'utf8' }).trim())
  for (let path = cwd; ; path = dirname(path)) {
    const config = join(path, '.agents')
    if (directory(config)) {
      for (const name of ['hooks.json', 'plugins.json']) {
        const target = join(config, name)
        if (entry(target)) throw new Error('workspace hook or plugin registry exists at ' + target)
      }
      if (readOnly) refuseMcpServers(config)
      refusePluginHooks(join(config, 'plugins'), readOnly)
    }
    if (path === gitRoot) break
    if (path === dirname(path)) throw new Error('could not establish the worktree root')
  }
  const home = homedir()
  const userConfig = join(home, '.gemini/config')
  if (readOnly) refuseMcpServers(userConfig)
  refusePluginHooks(join(userConfig, 'plugins'), readOnly)
  const installed = join(home, '.agents/hooks')
  const helper = await import(pathToFileURL(join(installed, 'session-role.mjs')).href)
  if (typeof helper.isAgyHookRegistration !== 'function') throw new Error('installed agy role gate is unavailable')
  const configPath = helper.agyHooksPath(home)
  let registry
  try { registry = JSON.parse(readFileSync(configPath, 'utf8')) } catch {
    throw new Error('unreadable or invalid agy hook registry at ' + configPath)
  }
  if (!registry || !helper.isAgyHookRegistration(registry[helper.agyHookName])) {
    throw new Error('missing or disabled agy hook in ' + configPath)
  }
  if (readOnly && Object.entries(registry).some(([name, hook]) => name !== helper.agyHookName && hook?.enabled !== false)) {
    throw new Error('additional active agy hooks are configured in ' + configPath)
  }
  const env = { ...process.env }
  delete env.WRSP_AGY_HOOK_LOG
  delete env.WRSP_AGY_WRITE_ROOTS
  const probes = readOnly ? [
    ['read_file', 'allow', { Path: 'AGENTS.md' }],
    ['run_command', 'deny', { CommandLine: 'printf scratch' }],
    ['write_file', 'deny', { Path: 'scratch.txt' }],
    ['edit_file', 'deny', { Path: 'scratch.txt' }],
    ['read_file', 'deny', { Path: 'AGENTS.md', BypassSandbox: true }],
    ...(!research ? [
      ['read_url_content', 'deny', { Url: 'https://example.invalid' }],
      ['finish', 'allow', {}],
    ] : []),
  ] : [
    ['run_command', 'allow', { CommandLine: 'printf scratch' }],
    ['run_command', 'deny', { CommandLine: 'printf scratch', BypassSandbox: true }],
    ['write_file', 'deny', { Path: '/' }],
  ]
  for (const [name, decision, args] of [...probes, ['wrsp_unknown_tool', 'deny', {}]]) {
    const payload = { cwd, hookEventName: 'PreToolUse', toolCall: { name, args } }
    const output = execFileSync('/bin/sh', [join(installed, 'agy-role-gate.sh')], {
      input: JSON.stringify(payload), cwd, env, timeout: 6000, stdio: ['pipe', 'pipe', 'pipe'],
    })
    const verdict = JSON.parse(output.toString('utf8'))
    if (verdict.decision !== decision || typeof verdict.reason !== 'string') {
      throw new Error('installed agy role gate is unavailable for ' + process.env.WRSP_ROLE)
    }
  }
  const permissions = configuredPermissions(home)
  if (readOnly) {
    const settings = { permissions: {
      ...permissions,
      allow: (permissions.allow ?? []).filter(rule => rule.startsWith('read_file(') || (research && rule.startsWith('read_url('))),
      deny: [...new Set([...(permissions.deny ?? []), 'write_file(*)', 'command(*)', 'unsandboxed(*)', 'execute_url(*)', 'mcp(*)',
        ...(!research ? ['read_url(*)'] : [])])],
    } }
    return { settings }
  }
  const git = gitPermissions(cwd, gitRoot)
  if (!cache) return {}
  const issue = process.env.WRSP_AGY_ISSUE
  if (!/^[1-9][0-9]*$/.test(issue)) throw new Error('agy developer dispatch requires an issue number')
  const artifacts = await issueArtifactDirectory({ worktree: gitRoot, issue })
  const nodeBin = dirname(realpathSync(process.execPath))
  const reads = [...git.readable, ...developerReadPaths(home), dirname(nodeBin)]
  const writes = [...git.writable, cache, ...(artifacts ? [artifacts] : [])]
  const protectedReads = [home, userInfo().homedir].flatMap(dir => [join(dir, '.gemini'), join(dir, '.config/gcloud')])
  const protectedWrites = protectedDeveloperState(process.env.WRSP_AGY_HOOK_LOG, realpathSync(raw))
  if ([...reads, ...writes, gitRoot, ...protectedReads, ...protectedWrites].some(path => !permissionPath(path))) {
    throw new Error('invalid agy developer permission path')
  }
  return {
    settings: { permissions: {
      ...permissions,
      allow: [...new Set([...reads.map(path => `read_file(${path})`), ...writes.map(path => `write_file(${path})`), 'read_url(*)'])],
      deny: [...new Set([...(permissions.deny ?? []), 'unsandboxed(*)', ...protectedReads.map(path => `read_file(${path})`),
        ...protectedWrites.map(path => `write_file(${path})`)])],
    } },
    developerEnv: { WRSP_AGY_WRITE_ROOTS: JSON.stringify([gitRoot, ...writes]), npm_config_cache: cache,
      PATH: `${nodeBin}:${process.env.PATH ?? ''}` },
  }
}

function processTable() {
  const table = execFileSync('/bin/ps', ['-ax', '-o', 'pid=,ppid=,pgid=,lstart='], {
    encoding: 'utf8', env: { ...process.env, LC_ALL: 'C', TZ: 'UTC' }, maxBuffer: 8 * 1024 * 1024, timeout: 2000,
  })
  const rows = new Map()
  for (const line of table.split('\n')) {
    const match = /^\s*(\d+)\s+(\d+)\s+(\d+)\s+(.+?)\s*$/.exec(line)
    if (!match) continue
    const [, pid, parent, group, started] = match
    rows.set(Number(pid), { pid: Number(pid), parent: Number(parent), group: Number(group), started })
  }
  if (!rows.has(process.pid)) throw new Error('process ownership table is unavailable')
  return rows
}

function observeTasks(table, anchor, provider, known) {
  if (!provider || !table.has(provider)) return
  const owned = new Set([provider])
  for (let count = 0; count !== owned.size;) {
    count = owned.size
    for (const row of table.values()) if (owned.has(row.parent)) owned.add(row.pid)
  }
  const groups = new Set([anchor, ...[...owned].filter(pid => table.get(pid)?.group === pid)])
  for (const pid of owned) {
    const row = table.get(pid)
    if (row && groups.has(row.group)) known.set(pid, row)
  }
}

function survivors(table, known) {
  return known.filter(row => {
    const current = table.get(row.pid)
    return current?.started === row.started && current.group === row.group
  })
}

function signalGroup(pid, signal) {
  try { process.kill(-pid, signal) } catch (error) { if (error.code !== 'ESRCH') throw error }
}

async function modelGroup(cwd, prompt, model, seconds, resume, raw, schema, cache) {
  const dispatch = Promise.withResolvers()
  const known = new Map()
  let modelProcess
  let inspectError
  let cancelled = false
  function scan() {
    try { observeTasks(processTable(), process.pid, modelProcess?.pid, known) } catch (error) { inspectError = error }
  }
  function stopTasks() {
    const observed = survivors(processTable(), [...known.values()])
    for (const group of new Set(observed.map(row => row.group))) {
      if (group !== process.pid) signalGroup(group, 'SIGKILL')
    }
  }
  function cancel() {
    cancelled = true
    dispatch.resolve(false)
    if (!modelProcess?.pid) return
    // Keep the provider alive while reading ancestry, then stop the exact
    // observed background groups before the provider can orphan them.
    modelProcess?.kill('SIGSTOP')
    scan()
    try { stopTasks() } catch (error) { inspectError = error }
    modelProcess?.kill('SIGKILL')
  }
  process.on('message', message => {
    if (message === 'dispatch') dispatch.resolve(true)
    if (message === 'cancel') cancel()
  })
  process.on('disconnect', () => {
    cancel()
    signalGroup(process.pid, 'SIGKILL')
  })
  const { settings, developerEnv } = await preflight(cwd, cache, raw)
  if (!process.connected) return
  // The supervisor may receive cancellation before this process starts
  // listening. Ask for permission after preflight so it can replay that state.
  process.send({ ready: true })
  const authorized = await dispatch.promise
  if (!process.connected) return
  if (!authorized || cancelled) {
    process.send({ exit: { code: null, signal: null }, known: [], cleanupUncertain: false })
    return
  }
  const argv = ['-p', schema ? '' : readFileSync(prompt, 'utf8'), '--model', model, '--output-format', schema ? 'stream-json' : 'json',
    '--print-timeout', seconds + 's', '--disable-slash-commands', '--sandbox', '--settings', JSON.stringify(settings),
    ...(schema ? ['--input-format', 'stream-json', '--json-schema', schema] : []),
    ...(resume ? ['--conversation', resume] : [])]
  const out = openSync(join(raw, 'stdout'), 'wx', 0o600)
  const err = openSync(join(raw, 'stderr'), 'wx', 0o600)
  let input = 'ignore'
  try {
    if (schema) {
      const request = join(raw, 'input')
      const message = { event: 'user', message: { role: 'user', content: [{ type: 'text', text: readFileSync(prompt, 'utf8') }] } }
      writeFileSync(request, JSON.stringify(message) + '\n', { flag: 'wx', mode: 0o600 })
      input = openSync(request, 'r')
    }
    modelProcess = spawn('agy', argv, { cwd, env: { ...process.env, ...developerEnv }, stdio: [input, out, err] })
    const ended = new Promise((resolve, reject) => {
      modelProcess.once('exit', (code, signal) => resolve({ code, signal }))
      modelProcess.once('error', reject)
    })
    process.send({ pid: modelProcess.pid })
    scan()
    const sampler = setInterval(scan, 250)
    let exit
    try { exit = await ended } finally { clearInterval(sampler) }
    scan()
    stopTasks()
    if (process.connected) process.send({ exit, known: [...known.values()], cleanupUncertain: Boolean(inspectError) })
    // The connected IPC channel keeps this exact group leader alive until
    // the supervisor has killed the remaining inherited process group.
  } finally {
    if (typeof input === 'number') closeSync(input)
    closeSync(out)
    closeSync(err)
  }
}

function transcript(id) {
  const path = join(homedir(), '.gemini/antigravity-cli/brain', id, '.system_generated/logs/transcript_full.jsonl')
  return readFileSync(path, 'utf8').split('\n').filter(Boolean).map(line => JSON.parse(line))
}

function writeSidecar(path, data) {
  const temp = path + '.tmp.' + process.pid
  writeFileSync(temp, data, { flag: 'wx', mode: 0o600 })
  renameSync(temp, path)
}

function failedStep(step) {
  if (step.status === 'ERROR' || (typeof step.error === 'string' && step.error.trim() !== '')) return true
  if (step.type !== 'GENERIC' || step.source !== 'MODEL' || typeof step.content !== 'string') return false
  // agy 1.5.14 marks a completed command step DONE even for a nonzero exit.
  // Read the generated header before command output, which is arbitrary text.
  const exit = /^(?:(?:Created At|Completed At):[^\n]+\n)+Command exited with code (-?\d+)\.(?:\r?\n|$)/.exec(step.content)
  return exit !== null && Number(exit[1]) !== 0
}

function completion(raw, resume, previousStep, hookLog, provider, reviewerModel) {
  const stdout = readFileSync(join(raw, 'stdout'), 'utf8')
  const stderr = readFileSync(join(raw, 'stderr'), 'utf8')
  if (/Authentication required/i.test(stderr)) throw new Error('authentication required')
  let result
  let init
  try {
    if (reviewerModel) {
      const events = stdout.trim().split('\n').map(line => JSON.parse(line))
      const starts = events.filter(event => event.event === 'init')
      const results = events.filter(event => event.event === 'result')
      if (starts.length !== 1 || results.length !== 1 || events.at(-1) !== results[0]) throw new Error('expected one turn')
      init = starts[0]
      result = results[0].result
    } else {
      result = JSON.parse(stdout)
    }
  } catch { throw new Error('invalid agy completion JSON') }
  if (!result || typeof result !== 'object' || Array.isArray(result)) throw new Error('invalid agy completion JSON')
  const id = result.conversation_id
  if (typeof id !== 'string' || !uuid.test(id) || (resume && id !== resume)) {
    throw new Error('invalid agy conversation identity')
  }
  if (init && init.conversation_id !== id) throw new Error('invalid agy conversation identity')
  if (result.finished_reason === 'print_timeout' && (reviewerModel || (provider.code === 3 && result.status === 'ERROR'))) {
    return { id, code: 3, reason: 'print timeout', produced: false }
  }
  if (result.status !== 'SUCCESS' || provider.code !== 0) {
    return { id, code: 1, reason: 'provider error', produced: false }
  }
  const steps = transcript(id).filter(step => Number.isSafeInteger(step.step_index) && step.step_index > previousStep)
  const produced = steps.some(step => step.type === 'PLANNER_RESPONSE' && step.source === 'MODEL')
  const audit = readFileSync(hookLog, 'utf8').split('\n').filter(Boolean).map(line => JSON.parse(line))
  const refused = audit.some(event => event.decision === 'deny')
  const failed = steps.some(failedStep)
  if (reviewerModel) {
    const planner = steps.filter(step => step.type === 'PLANNER_RESPONSE' && step.source === 'MODEL')
    const models = [init?.init?.model, ...planner.map(step => step.model)].filter(model => typeof model === 'string' && model)
    const finalized = audit.some(event => event.type === 'agy-tool' && event.conversationId === id
      && event.name === 'finish' && event.decision === 'allow')
    let reason = 'completed'
    if (refused) reason = 'tool refused'
    else if (failed) reason = 'transcript contains a failed step'
    else if (planner.at(-1)?.status !== 'DONE') reason = 'missing completed model transcript evidence'
    else if (models.some(model => model !== reviewerModel)) reason = 'reviewer identity mismatch'
    else if (!object(result.structured_output)) reason = 'missing structured review output'
    else if (!finalized) reason = 'missing reviewer completion audit'
    return { id, code: reason === 'completed' ? 0 : 1, reason, produced, providerStatus: result.status,
      ...(reason === 'completed' ? { review: result.structured_output, model: models[0] ?? null } : {}) }
  }
  const response = typeof result.response === 'string' ? result.response.trim() : ''
  const reportsFailure = /denied by pre-tool hook|blocked by a pre-tool hook|the (?:requested )?(?:task|turn) failed\b|\bi (?:cannot|can't|could not|couldn't) (?:complete|comply)/i.test(response)
  const reason = refused ? 'tool refused' : failed ? 'transcript contains a failed step' : reportsFailure ? 'response reports failure'
    : !response ? 'empty response' : !produced ? 'missing model transcript evidence' : 'completed'
  const usage = Object.fromEntries(['input_tokens', 'cache_read_tokens', 'output_tokens', 'thinking_tokens', 'total_tokens']
    .flatMap(key => Number.isSafeInteger(result.usage?.[key]) && result.usage[key] >= 0 ? [[key, result.usage[key]]] : []))
  return { id, code: reason === 'completed' ? 0 : 1, reason, produced, response, providerStatus: result.status,
    ...(Object.keys(usage).length ? { usage } : {}) }
}

async function supervise(cwd, prompt, log, model, seconds, resume, schema) {
  const research = process.env.WRSP_AGY_LANE === 'researcher'
  const review = process.env.WRSP_AGY_LANE === 'reviewer'
  if ((research || review) && resume) throw new Error('agy ' + process.env.WRSP_AGY_LANE + ' mode requires a fresh conversation')
  if (review !== Boolean(schema)) throw new Error('agy reviewer mode requires a review schema')
  const audit = log + '.agy-hooks.jsonl'
  const previousStep = resume
    ? transcript(resume).reduce((last, step) => Number.isSafeInteger(step.step_index) ? Math.max(last, step.step_index) : last, -1)
    : -1
  const raw = mkdtempSync(join(tmpdir(), 'wrsp-agy-output-'))
  let cache = ''
  let group
  let finished
  let cancelled = 0
  function cancel(code) {
    if (cancelled !== 0) return
    cancelled = code
    if (group?.connected) group.send('cancel', () => {})
  }
  const term = () => cancel(143)
  const interrupt = () => cancel(130)
  process.on('SIGTERM', term)
  process.on('SIGINT', interrupt)
  let watchdog
  try {
    closeSync(openSync(audit, 'wx', 0o600))
    writeSidecar(log + '.progress', audit + '\n')
    writeSidecar(log + '.started', process.ppid + '\n')
    if (process.env.WRSP_AGY_LANE === '1') cache = realpathSync(mkdtempSync(join(tmpdir(), 'wrsp-agy-npm-')))
    group = fork(self, ['group', cwd, prompt, model, seconds, resume, raw, schema ?? '', cache], {
      cwd, detached: true, stdio: ['ignore', 'ignore', 'inherit', 'ipc'],
      env: { ...process.env, WRSP_AGY_HOOK_LOG: audit },
    })
    const ended = new Promise((resolve, reject) => {
      group.once('exit', resolve)
      group.once('error', reject)
    })
    finished = ended.catch(() => {})
    const result = new Promise((resolve, reject) => {
      group.on('message', event => {
        try {
          if (event.ready && group.connected) group.send(cancelled ? 'cancel' : 'dispatch', () => {})
          if (event.pid) writeSidecar(log + '.agy.pid', event.pid + '\n')
          if (event.exit) resolve(event)
        } catch (error) { reject(error) }
      })
    })
    const outcome = Promise.race([result, ended.then(() => { throw new Error('agy process group exited before reporting completion') })])
    if (group.pid) writeSidecar(log + '.agy.pgid', group.pid + '\n')
    watchdog = setTimeout(() => cancel(3), (Number(seconds) + 60) * 1000)
    const observed = await outcome
    signalGroup(group.pid, 'SIGKILL')
    await finished
    let live = []
    for (let attempt = 0; attempt < 20; attempt++) {
      live = survivors(processTable(), observed.known)
      if (live.length === 0) break
      await delay(25)
    }
    if (live.length !== 0) writeSidecar(log + '.live', live.map(row => row.pid + '\t' + row.started + '\n').join(''))
    if (observed.cleanupUncertain || live.length !== 0) throw new Error('agy process cleanup could not be verified')
    if (cancelled) {
      console.log(cancelled === 3 ? 'AGY FAILED: supervisor deadline expired' : 'CANCELLED: agy process group stopped')
      return cancelled
    }
    const outcomeRecord = completion(raw, resume, previousStep, audit, observed.exit, review ? model : undefined)
    writeSidecar(log + '.agy.conversation', outcomeRecord.id + '\n')
    writeSidecar(log + '.agy.result.json', JSON.stringify(outcomeRecord) + '\n')
    if (outcomeRecord.produced) {
      const fd = openSync(audit, 'a')
      try { writeFileSync(fd, '{"type":"agy-completion"}\n') } finally { closeSync(fd) }
    }
    console.log('AGY ' + (outcomeRecord.code === 0 ? 'COMPLETED: ' : 'FAILED: ') + outcomeRecord.reason)
    if (research && outcomeRecord.code === 0) console.log(outcomeRecord.response)
    return outcomeRecord.code
  } finally {
    clearTimeout(watchdog)
    if (group?.pid && group.exitCode === null && group.signalCode === null) {
      signalGroup(group.pid, 'SIGKILL')
      await finished
    }
    process.removeListener('SIGTERM', term)
    process.removeListener('SIGINT', interrupt)
    rmSync(raw, { recursive: true, force: true })
    if (cache) rmSync(cache, { recursive: true, force: true })
  }
}

const [command, ...args] = process.argv.slice(2)
try {
  if (command === 'preflight') await preflight(args[0])
  else if (command === 'group') await modelGroup(...args)
  else if (command === 'run') process.exitCode = await supervise(...args)
  else throw new Error('unknown agy worker operation')
} catch (error) {
  console.error('AGY FAILED: ' + error.message.split('\n')[0])
  process.exitCode = command === 'preflight' ? 66 : 1
  if (command === 'group' && process.connected) process.disconnect()
}
