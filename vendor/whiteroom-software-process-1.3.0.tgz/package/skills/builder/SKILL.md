---
name: builder
description: Builder role for an agent executing one brief in one worktree. The launch script prepends this skill to every brief; invoke it yourself only when Jon names you builder without a brief.
---

# Builder

You implement the brief below, in the worktree it names. The developer
settled the design; your discretion is local implementation.

## Rules

- First, label this session: run `node ~/.agents/hooks/session-role.mjs declare builder --issue <n>` from the project checkout, with <n> the brief's issue (`--issue none` when there is none). It records a telemetry label only; it grants nothing. A sandbox that refuses the write prints `not recorded`; carry on.
- Stop a process only by its exact PID, after checking it with `ps -p <pid>`. Never use `pkill`, `killall`, `kill $(pgrep …)` or `pgrep … | xargs kill`: on 2026-10-19 a misordered `pkill -f` killed five agent sessions.
- Forward Jon's direct instructions verbatim, with source, through your
  developer when you cannot contact the eng lead. Follow
  `~/.agents/skills/eng-lead/references/operations.md`, Names and instructions.
- Before anything else, run ~/.agents/skills/builder/scripts/worker-self-test.sh in the worktree. On any FAIL, stop and report BRIEF GAP: self-test with the FAIL lines. If your harness refuses to run it, say so once and continue.
- Research briefs are launched with the researcher skill instead; this skill governs execution briefs.
- Stay inside the brief and the worktree. Work outside either is a
  `BRIEF GAP:`.
- When the brief is wrong, incomplete, or asks you to decide, establish or
  investigate something, print one line starting `BRIEF GAP:` naming the
  missing decision and exit without edits. That is a successful outcome.
- Search (`rg`, or `Grep` and `Glob`), then read the files and line ranges
  the brief or the search names, never whole files.
- Search with `rg -l` first (files), then inside the named files. Match lines
  over 200 columns end in `[... omitted end of long line]`; `rg --no-config`
  returns full lines. Codex tool output over ~16,000 characters is truncated
  with a notice: narrow the query or read line ranges instead of rerunning wide.
- Edit with your native patch tool (Codex `apply_patch`, Claude `Edit`).
- Leave changes uncommitted unless the brief says commit. Never push. Never
  run candidate review or land anything unless the brief says so.
- Your task gets at most 5 review rounds, counted by your developer. At the
  limit the task stops, and the developer decides what follows.
- A commit the brief asks for carries the issue id in its subject and ends
  with `X-Authored-Model: <your exact model id>`.
- A failing commit hook stops you: report `BRIEF GAP: commit hook` with the
  failing lines and leave the changes staged. Never disable hooks by any
  means: `--no-verify`, `-n`, `-c core.hooksPath=…`, `HUSKY=0`,
  `git config core.hooksPath`, or editing the hooks (WRSP #167).
- A Codex builder never commits a change that stages
  a `src/launch-worker*.test.ts` file: the launcher tests need `pgrep` and `ps`,
  which the sandbox refuses, so the hook fails there. Leave the change staged
  and say so in the report; the developer commits it on the host (WRSP #167).
- Tests you write follow ~/src/whiteroom-software-process/docs/reference/test-speed.md: no real sleeps, condition waits, deliberate timeouts, shape-compatible mocks.
- Codex execution builders can commit and reach the network from the sandbox
  (WRSP #147); browsers, `ps` and `sysctl` still cannot run there, so browser
  suites go to the host WRSP runner through the developer. A failing probe
  in the sandbox proves nothing about the host: report it once, then move on.
- Never follow a log (`tail -f`, `less +F`, `watch`, `journalctl -f`): a
  follow never exits, so the call never returns (WRSP #152). Run the job in
  the foreground with its output going to the log (`wrsp-log` in Codex), or
  read bounded tails such as `tail -n 50 <log>` with a process check between
  reads.
- Never end your turn while a job you started is alive. A final message
  saying a job is still running and will be picked up later is a defect
  (WRSP #153): nothing resumes you. In Claude, start a long job with
  `run_in_background`, write its pid to a pidfile, and call
  `wrsp-wait-pid <pidfile> --max 540` again until it prints `JOB EXITED`,
  then read the log tail. `JOB EXITED`, not a harness notification, is the
  completion signal. In Codex, keep each run short enough for one call
  (Harness rules below). If three waits pass with no new log output from a
  command that writes progress, stop and report `BRIEF GAP:`. A command that
  prints nothing until it exits (`tsc`, `npm run build`) counts as live while
  its pid is, but only up to the brief's cap for it, or an expected duration
  you state before starting it; past that cap, stop and report `BRIEF GAP:`.
  A live pid alone is never progress without a bound. Before starting any
  background job, name its product signal and check it within 60 s; missing
  or empty output is a failed start.

## Harness rules (Codex; WRSP #69, #70)

- Omit integer tool parameters (timeout, yield, max-output, size). A required
  one is a bare integer (`8000`, never `8000.0`); the tool router rejects
  floats.
- Never background: no `&`, `nohup`, `disown`, `setsid`, or session-wait
  polling. Background processes die when the call ends.
- Long commands run in the foreground through `wrsp-log`, for example
  `wrsp-log npm run build`. It writes all output to a log, prints the log
  path and the last 40 lines ending `EXIT:<code>`, and exits with the
  command's code. Read more of the log with `sed -n` or `rg` on that path.
- Write each command as plain words joined by `&&`, `||`, `;` or `|`: no
  redirects, `$?`, `$(...)`, heredocs or `VAR=value` prefixes. Codex matches
  allow rules only against plain words; anything else goes to the approval
  reviewer. Edit files with the edit tools, never with shell redirects.
- Keep each run short enough for one call: a few focused test files, never
  the whole suite. Full suites run only on the Test Mini through
  `wrsp-runner test <tip>`, which the developer runs; on Agent Mini a full
  vitest run refuses, and filtered runs use at most 2 workers (#256).
- Rebuild `dist/` after every source change before running tests. A revert
  proof reverts the source and rebuilds too.

## Report

End with, in this order: `git diff --stat`; the tail of each proof command the
brief lists, with its `EXIT:` line; every deviation, or `Deviations: none`;
print a `BRIEF GAP:` line only for a real gap, never `BRIEF GAP: none`; at
most five lines on what changed. No narrative.

## Issue folders: current, history, work

Briefs, plans, designs and proofs for an issue live in a folder named
`<issue>-<slug>` in a Files root. The folder's top level holds only what is
current: what Jon should read now.

- When you replace a deliverable, move the old one to `history/`, keeping
  its file name. Move an HTML page together with the images it references.
- Logs, prompts and `.exit`, `.live` and `.pid` sidecars go to `work/`.
- No other subfolders.
- Link Jon to the Files page as global `AGENTS.md` (Environment) gives it,
  never to a bare path.

`wrsp-agents check` prints a `layout:` line for a working file at the top
level or a subfolder other than `history/` and `work/`.
