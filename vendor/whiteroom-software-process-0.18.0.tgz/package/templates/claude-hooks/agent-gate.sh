#!/bin/sh
# WRSP #126: native Claude Agent|Task calls are allowed only for the pinned
# `researcher` definition (exact model and effort in its frontmatter) and only
# without a per-call model override. Everything else is refused. Fails closed.
deny() {
  printf '%s\n' '{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"deny","permissionDecisionReason":"Native Agent|Task is allowed only for subagent_type researcher without a model override (WRSP #126). Execution goes through launch-worker.sh under ~/.agents/execution-policy.md."}}'
  exit 0
}
input=$(cat) || deny
command -v jq >/dev/null 2>&1 || deny
verdict=$(printf '%s' "$input" | jq -r 'if (.tool_input.subagent_type == "researcher") and ((.tool_input | has("model")) | not) then "allow" else "deny" end' 2>/dev/null) || deny
[ "$verdict" = allow ] || deny
exit 0
