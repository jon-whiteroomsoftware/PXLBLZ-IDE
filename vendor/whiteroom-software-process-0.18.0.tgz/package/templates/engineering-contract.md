# <Contract name>

<!--
AUTHORING NOTE

Create a contract only when omitting a fact could make independently
implemented callers, adapters, or maintainers disagree about correct behavior.
Externally imposed compatibility or resource obligations and non-obvious
failure semantics also qualify. A module's existence alone does not.

This is a proportionate outline, not a mandatory form. Omit sections and rows
that add no useful agreement. Explain the agreement before specialized detail.
Keep local mechanics in code, machine-readable shapes in schemas, and
executable examples in tests. Link to those owners instead of narrating call
stacks, copying volatile inventories, or reproducing generated reference.

Current contracts normally live at docs/reference/contracts/<topic>.md.
Proposed guarantees stay in a plan or spec until accepted and implemented.
-->

## Purpose and scope

In two to four sentences, state the agreement, who relies on it, and where the
guarantee ends.

## Ownership and interface

Name the semantic inputs and outputs, durable identities, authoritative state,
and the party allowed to change each one. Include ordering and error obligations
that callers must know; a type signature alone is not the whole interface.

## Invariants

State concise, falsifiable clauses and name the domain each clause covers. Use
stable labels only when tests or issues need to cite individual obligations.

For an open domain, enumerate supported forms, specify fail-closed behavior, or
state the explicit threat-model or coverage scope. Do not claim an unbounded
guarantee from sampled evidence.

## Transitions and failure

Where they affect the agreement, define visibility or commit points,
cancellation, retries, stale work, partial failure, and recovery. Describe the
observable result rather than the internal call sequence.

## Compatibility and limits

Record relevant versions, capabilities, numeric assumptions, unsupported cases,
resource envelopes, and accepted divergences. Link measured constants to their
evidence; estimates are not guarantees.

## Evidence and ownership links

- Owning module or interface:
- Executable evidence:
- Reproducible proof or archived measurement:
- Related ADR, plan, or issue:
- Known gaps:

Link each claim to the evidence that actually exercises it. A nearby test does
not prove a clause it never asserts.
