---
name: review-packet
description: Assemble an exact-range WRSP candidate review packet in a junior-tier subagent. Use before candidate review when the packet would otherwise load range context into the working session. The subagent returns a packet path plus a gap list; the parent verifies coverage mechanically, never by re-reading.
---

# Review Packet Builder

Packet assembly is read-heavy with a paragraph-sized return: question in,
packet out. Keep it out of the main session to preserve prompt cache and
shorten the review session.

## Trigger

Before candidate review, when gathering the range diff, receipts, and context
would load bulk code into the working session.

## Delegate

Launch one subagent at the `junior` tier. The tier resolves model and effort
through the execution policy; never name a model in the launch. Pass exactly:
repository, base sha, tip sha, packet output path.

## The subagent MUST

- Read-only. Assemble, never modify: full diff of base..tip, commit list,
  existing receipts and outcomes touching the range, and the policy
  fingerprint in force.
- Write the packet to the given path and return only: packet path, commit
  count, and gaps (missing receipts, unreadable history, range drift).
- Report gaps fail-closed. A gapped range is reported, never padded or
  approximated.

## The subagent MUST NOT

- Judge code, write findings, or approve anything. Assembly only.
- Return diffs, file contents, or long context to the parent. Anything the
  parent has to read defeats the purpose.

## Oracle

The parent verifies without re-reading:

- Packet exists at the path; commit count matches
  `git rev-list --count base..tip`.
- Every range commit is represented; reported gaps appear in the packet's
  gap list.
- Any check fails: discard and re-run. Never repair by hand-loading context.

## Notes

This skill names the tier so model churn never touches it. If the execution
policy has no `junior` tier yet, the skill is dormant: keep packet assembly
in-session until tiers land.
