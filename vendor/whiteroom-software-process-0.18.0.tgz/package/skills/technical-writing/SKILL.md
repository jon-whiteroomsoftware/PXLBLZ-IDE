---
name: technical-writing
description: Applies the user's layered, direct engineering prose style without changing a document's required content or workflow. Use when drafting or substantially revising reference docs, technical designs, PRDs, plans, issue bodies, handoffs, architecture explanations, or technical community posts; combine it with the artifact-specific skill.
---

# Technical Writing

## Role

Treat this as a style overlay. Other skills decide what the artifact contains,
where it lives, and how it is published. This skill decides how the explanation
unfolds and how the finished prose sounds.

Correctness includes editorial selection. A reference is a map of a system, not
a prose substitute for its code. Explain the concepts, boundaries, invariants,
ownership, data flow, and surprising mechanisms a human needs to form the right
model. Let code remain authoritative for local implementation minutiae whose
prose restatement would add length without improving understanding or decisions.
Do not preserve a detail merely because it is accurate.

For an engineering contract, lead with the agreement independently implemented
callers must share. Admit a fact only when omitting it could change what they
consider correct, or when it states an external compatibility, resource, or
non-obvious failure obligation. Link to owning code and evidence after the
agreement; do not turn the contract into a call-stack narrative.

## Build the reader's path

1. Start with the answer, definition, or two-to-four-sentence shape of the whole.
2. Give the high-level model and name the few concepts everything else depends on.
3. State the literal mechanism before listing consequences or capabilities.
4. Walk forward one causal step per paragraph; make each transition connect the
   previous idea to the next.
5. Move implementation detail, edge cases, and evidence into later or optional
   sections. Information should become less universally necessary as depth grows.

Open every major section with natural framing that locates it in the whole.
Never announce the craft with labels such as “two-sentence summary.”

## Prose rules

- Prefer direct, information-dense engineering prose. Remove throat-clearing,
  repetition, boilerplate, self-congratulation, and meta-commentary.
- Use lists after the reader has a model, not instead of building one. Rewrite a
  laundry list when the reader cannot yet explain the underlying trick.
- Use a well-chosen analogy when it creates a mental anchor, then connect it to
  the literal mechanism. Drop an analogy that needs its own explanation.
- Define unfamiliar terms through context. Expand or avoid acronyms in
  user-facing prose; keep specialized shorthand in specialized sections.
- Prefer the system, component, or behavior as the grammatical subject. Do not
  force passive voice. Reserve first person for authorship, judgment, or lived
  experience; do not wrap routine technical behavior in repeated “I can…” prose.
- Make claims concrete with a small example, call count, state transition, or
  before/after comparison when that materially improves understanding.
- Explain surprising boundaries positively. Do not introduce hypothetical
  alternatives merely to say the design did not choose them.
- Use occasional dry humor when it sharpens the point; never let tone obscure it.
- In public-facing prose (docs, READMEs, posts), avoid vocabulary widely read
  as AI-generated: "load-bearing", delve, crucial, seamless, robust, leverage,
  tapestry, testament, and "not just X but Y" constructions. Watch em-dash
  density in particular — it is the strongest tell. Literal uses (an actual
  load-bearing wall) are fine; prefer plain concrete wording, and sweep for
  the tell list before publishing.

## Revision pass

1. Read only the title and first paragraph of every section. They should form a
   coherent outline from broadest context to narrowest detail.
2. Find feature lists that arrive before the mechanism and repair the missing
   bridge.
3. Move universal facts earlier and sequester expert detail later. For mixed
   audiences, use a primary user-facing layer plus an optional technical layer.
4. Replace vague referents, unexplained acronyms, duplicated conclusions, and
   comparisons that open irrelevant branches.
5. Cut every sentence whose removal preserves meaning. Then restore only the
   context needed to prevent a knowledgeable reader from making a wrong model.
6. Ask whether each implementation detail changes the reader's model, decisions,
   or ability to find the owning code. If not, cut it or replace it with a link
   to the code, evidence, or specialized reference that owns it.

## Compose with content skills

- `personal-voice`: chooses personal cadence, tone, warmth, and interpersonal
  stance. This skill still governs explanatory structure and editorial selection.
- `doc-sweep`: chooses current-truth documents and keeps plans separate.
- `to-prd`: chooses product-decision content and PRD structure.
- `to-issues` and `issue-workflow`: choose executable issue state and templates.
- `handoff`: chooses continuity information and links instead of duplication.

Do not reproduce those skills' templates here. Apply this style after their
content requirements are known.

## Micro-examples

- Replace “Two-sentence summary: …” with the summary itself.
- Replace “That means I can restart the worker” with “The worker can restart”
  when describing system behavior.
- Replace an unexplained internal acronym in a user guide with a contextual
  phrase; retain the acronym where a protocol or format reference needs it.
