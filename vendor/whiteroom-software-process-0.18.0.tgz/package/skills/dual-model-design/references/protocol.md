# Competition Protocol

## Common controls

Apply these controls in every weight:

1. Keep the coordinator out of all substantive reasoning roles.
2. Freeze one Arena Contract before launching workers.
3. Start every candidate, reviewer, and judge in a fresh context.
4. Give peer workers the same arena, source permissions, domain contract, and
   output constraints.
5. Capture worker responses outside the repository. Forbid self-identification,
   model names, and references to unseen competitors.
6. Randomly map raw candidates to stable Candidate A and Candidate B labels.
   Never give the mapping to reviewers or judges.
7. Counterbalance presentation order: when two peer reviewers or judges exist,
   show A first to one and B first to the other.
8. Judge against criteria locked before proposals existed. Authorship, novelty,
   symmetry, verbosity, and compromise are not evidence.
9. Preserve a material disagreement when evidence does not resolve it. Do not
   manufacture consensus.

Blinding is procedural, not cryptographic. A fresh worker has no session memory
of earlier calls, but it may infer model family from style. Identical templates,
anonymous labels, fresh contexts, and counterbalanced order reduce explicit
ownership and presentation bias without pretending to eliminate every signal.

## Quick: three calls

Use for a bounded question with a clear deliverable.

1. Launch one Fable candidate and one Sol candidate concurrently.
2. Anonymize them as Candidate A and Candidate B.
3. Randomly choose a fresh Fable or Sol judge and randomly choose A-first or
   B-first presentation.
4. Let that judge choose A, choose B, or form one coherent synthesis. Its output
   becomes `decision.md` after coordinator-only formatting and path updates.

Do not add review or revision rounds.

## Deliberative: five calls

Use when several decisions interact or the initial tradeoffs deserve scrutiny.

1. Launch and anonymize the two candidates as in Quick.
2. Launch two fresh blind reviewers concurrently with counterbalanced order:
   one sees A then B and the other sees B then A. Randomize which model receives
   which order. Each critiques both candidates and recommends a resolution
   without claiming or revising an authored proposal.
3. Randomly choose a fresh Fable or Sol judge. Give it the Arena Contract, a
   randomly ordered candidate packet, and both anonymous reviews.
4. The judge produces the complete decision.

The judge may select a candidate or synthesize, but a synthesis must be more
coherent against the locked criteria than either source and must state lineage.

## Deep: six calls

Use for broad, consequential, or difficult-to-reverse work.

1. Run the same two candidates and two counterbalanced reviews as Deliberative.
2. Optionally collect human evidence after the candidates and before judgment.
   Give the same feedback to both judges.
3. Launch two fresh judges concurrently with counterbalanced, randomly assigned
   candidate order. Both receive the same reviews and human evidence.
4. If the judges agree substantively, use the more complete judgment as the
   decision and record the independent agreement.
5. If they disagree materially, stop at a human gate. Present the two judgments
   without asking the coordinator to break the tie or automatically buying a
   seventh call.

## Finalization boundary

The coordinator may normalize headings, repair links, record process metadata,
and remove accidental identity disclosures. It must not introduce a new design,
silently reconcile disagreement, or replace a judge's reasoning with its own.

Reveal candidate provenance only after the decision, and only when useful for
diagnosis or an explicitly retained evidence record.
