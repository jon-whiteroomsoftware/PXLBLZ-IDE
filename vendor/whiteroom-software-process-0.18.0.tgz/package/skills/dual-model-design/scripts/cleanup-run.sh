#!/usr/bin/env bash
set -euo pipefail

usage() {
  echo "Usage: $(basename "$0") <run-directory>" >&2
  exit 64
}

[[ $# -eq 1 ]] || usage
run_input=$1
[[ -d "$run_input" ]] || { echo "Run directory not found: $run_input" >&2; exit 66; }

run_dir=$(cd "$run_input" && pwd -P)
scratch_root=$(cd "${TMPDIR:-/tmp}" && pwd -P)
case "$run_dir" in
  "$scratch_root"/dual-model-design.*) ;;
  *)
    echo "Refusing to remove a directory outside the managed scratch root: $run_dir" >&2
    exit 64
    ;;
esac

rm -r -- "$run_dir"
printf 'Removed dual-model scratch directory: %s\n' "$run_dir"
