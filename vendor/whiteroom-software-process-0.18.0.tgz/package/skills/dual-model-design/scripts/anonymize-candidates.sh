#!/usr/bin/env bash
set -euo pipefail

usage() {
  echo "Usage: $(basename "$0") <raw-candidate-1> <raw-candidate-2> <run-directory>" >&2
  exit 64
}

[[ $# -eq 3 ]] || usage
raw_one=$1
raw_two=$2
run_dir=$3

[[ -s "$raw_one" ]] || { echo "Candidate missing or empty: $raw_one" >&2; exit 66; }
[[ -s "$raw_two" ]] || { echo "Candidate missing or empty: $raw_two" >&2; exit 66; }
[[ -d "$run_dir" ]] || { echo "Run directory not found: $run_dir" >&2; exit 66; }

candidate_a="$run_dir/candidate-a.md"
candidate_b="$run_dir/candidate-b.md"
packet_ab="$run_dir/candidates-ab.md"
packet_ba="$run_dir/candidates-ba.md"
for target in "$candidate_a" "$candidate_b" "$packet_ab" "$packet_ba"; do
  [[ ! -e "$target" ]] || { echo "Refusing to overwrite: $target" >&2; exit 73; }
done

random_byte=$(od -An -N1 -tu1 /dev/urandom | tr -d '[:space:]')
if (( random_byte % 2 == 0 )); then
  cp "$raw_one" "$candidate_a"
  cp "$raw_two" "$candidate_b"
  mapping='A=raw-1 B=raw-2'
else
  cp "$raw_two" "$candidate_a"
  cp "$raw_one" "$candidate_b"
  mapping='A=raw-2 B=raw-1'
fi

{
  printf '# Anonymous Candidate Packet\n\n'
  printf '## Candidate A\n\n'
  sed '/^# Anonymous Candidate/d' "$candidate_a"
  printf '\n## Candidate B\n\n'
  sed '/^# Anonymous Candidate/d' "$candidate_b"
} > "$packet_ab"

{
  printf '# Anonymous Candidate Packet\n\n'
  printf '## Candidate B\n\n'
  sed '/^# Anonymous Candidate/d' "$candidate_b"
  printf '\n## Candidate A\n\n'
  sed '/^# Anonymous Candidate/d' "$candidate_a"
} > "$packet_ba"

printf 'Candidate mapping (coordinator only): %s\n' "$mapping"
printf 'A-first packet: %s\n' "$packet_ab"
printf 'B-first packet: %s\n' "$packet_ba"
