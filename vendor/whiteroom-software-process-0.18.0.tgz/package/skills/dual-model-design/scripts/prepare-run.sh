#!/usr/bin/env bash
set -euo pipefail

usage() {
  echo "Usage: $(basename "$0") <workspace-directory> [quick|deliberative|deep]" >&2
  exit 64
}

[[ $# -ge 1 && $# -le 2 ]] || usage
workspace_input=$1
weight=${2:-quick}

[[ -d "$workspace_input" ]] \
  || { echo "Workspace directory not found: $workspace_input" >&2; exit 66; }
case "$weight" in
  quick|deliberative|deep) ;;
  *) usage ;;
esac

workspace=$(cd "$workspace_input" && pwd -P)
scratch_root=${TMPDIR:-/tmp}
[[ -d "$scratch_root" ]] \
  || { echo "Temporary directory not found: $scratch_root" >&2; exit 69; }

run_dir=$(mktemp -d "${scratch_root%/}/dual-model-design.XXXXXX")
skill_dir=$(cd "$(dirname "$0")/.." && pwd -P)
cp "$skill_dir/templates/arena-template.md" "$run_dir/arena.md"

printf 'Workspace: %s\n' "$workspace"
printf 'Weight: %s\n' "$weight"
printf 'Run directory: %s\n' "$run_dir"
printf 'Arena Contract: %s\n' "$run_dir/arena.md"
printf '\nFill and freeze the Arena Contract before launching any worker.\n'
