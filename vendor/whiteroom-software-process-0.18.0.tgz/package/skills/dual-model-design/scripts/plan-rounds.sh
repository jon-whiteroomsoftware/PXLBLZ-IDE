#!/usr/bin/env bash
set -euo pipefail

usage() {
  echo "Usage: $(basename "$0") <quick|deliberative|deep> <run-directory>" >&2
  exit 64
}

[[ $# -eq 2 ]] || usage
weight=$1
run_dir=$2
case "$weight" in
  quick|deliberative|deep) ;;
  *) usage ;;
esac
[[ -s "$run_dir/candidates-ab.md" ]] \
  || { echo "A-first candidate packet not found in: $run_dir" >&2; exit 66; }
[[ -s "$run_dir/candidates-ba.md" ]] \
  || { echo "B-first candidate packet not found in: $run_dir" >&2; exit 66; }

random_bit() {
  local byte
  byte=$(od -An -N1 -tu1 /dev/urandom | tr -d '[:space:]')
  printf '%s' "$((byte % 2))"
}

packet_ab="$run_dir/candidates-ab.md"
packet_ba="$run_dir/candidates-ba.md"

if [[ "$weight" != quick ]]; then
  if [[ $(random_bit) == 0 ]]; then
    printf 'reviewer_claude_packet=%s\n' "$packet_ab"
    printf 'reviewer_codex_packet=%s\n' "$packet_ba"
  else
    printf 'reviewer_claude_packet=%s\n' "$packet_ba"
    printf 'reviewer_codex_packet=%s\n' "$packet_ab"
  fi
fi

if [[ "$weight" == deep ]]; then
  if [[ $(random_bit) == 0 ]]; then
    printf 'judge_claude_packet=%s\n' "$packet_ab"
    printf 'judge_codex_packet=%s\n' "$packet_ba"
  else
    printf 'judge_claude_packet=%s\n' "$packet_ba"
    printf 'judge_codex_packet=%s\n' "$packet_ab"
  fi
else
  if [[ $(random_bit) == 0 ]]; then
    printf 'judge_worker=claude\n'
  else
    printf 'judge_worker=codex\n'
  fi
  if [[ $(random_bit) == 0 ]]; then
    printf 'judge_packet=%s\n' "$packet_ab"
  else
    printf 'judge_packet=%s\n' "$packet_ba"
  fi
fi
