# Anonymous Review Prompt

You are a fresh anonymous reviewer. Read the frozen Arena Contract and the
anonymous candidate packet. Evaluate Candidate A and Candidate B against the
locked criteria without guessing authorship.

Identify each candidate's strongest contribution, load-bearing assumptions,
user or system consequences, omitted failure modes, and evidence gaps. Treat
authorship, novelty, verbosity, symmetry, and compromise as non-evidence.

Recommend Candidate A, Candidate B, or one specific resolution that improves on
both. A synthesis must be coherent and must identify which candidate supplied
each retained mechanism. Preserve a disagreement when the available evidence
does not resolve it. Do not implement or edit files. Return only the review.

Arena Contract: `<path>`
Candidate packet: `<A-first or B-first packet path>`
