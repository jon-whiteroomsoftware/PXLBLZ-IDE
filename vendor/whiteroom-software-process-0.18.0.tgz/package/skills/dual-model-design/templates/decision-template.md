# Decision: <task>

## Decision

State the selected design and confidence first.

## Locked criteria

Record the criteria used to judge the candidates.

## Selected design

Explain the coherent design, its mechanism, and important consequences.

## Why it won

Evaluate the decisive differences against the locked criteria.

## Lineage

Attribute retained mechanisms to Candidate A, Candidate B, or the judge's
necessary synthesis without revealing model identity.

## Strongest rejected alternative

Explain why it lost and what evidence could make it preferable.

## Material dissent and human gates

Preserve unresolved disagreement without returning two complete designs.

## Validation and next step

Name the smallest evidence, prototype, measurement, or implementation slice that
should test the decision.

## Process metadata

- Weight: `<quick | deliberative | deep>`
- Workers: `Claude Fable xhigh; Codex gpt-6-sol high`
- Blindness: `<candidate mapping hidden; presentation order>`
- Exposure: `<solution-neutral | solution-exposed>`
- Judge agreement: `<single judge | independent agreement | human gate>`
