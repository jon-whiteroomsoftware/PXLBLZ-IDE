# Arena Contract: <decision or artifact>

## Objective

State the desired outcome without proposing a solution.

## Weight and target artifact

- Weight: `<quick | deliberative | deep>`
- Required deliverable: `<the exact decision, design, packet, or plan>`
- Applied domain skills or contracts: `<names and relevant requirements>`

## Locked evaluation criteria

List the criteria in priority order. Define what strong evidence looks like for
each criterion before candidates exist.

## Facts and constraints

Separate verified facts, user constraints, repository invariants, budgets, and
compatibility requirements from assumptions.

## Allowed sources

List the exact repository files, domain references, external evidence, or other
material every participant may inspect.

## Required coverage

Serialize the applicable domain skills' output contract and judging rubric.
Do not rely on participants having those skills installed.

## Non-goals

State excluded work, especially implementation and production mutation.

## Open factual questions

List unknown facts without resolving them through a design preference.

## Exposure and contamination

State whether the source or prior conversation exposed a preferred solution.
Use `solution-neutral` or `solution-exposed` and explain the exposure briefly.
