---
name: blind-spot-check
description: Audits a strategic or technical plan for its most consequential blind spot, load-bearing assumption, and weakest-supported conclusion. Use after substantial planning, before committing to a direction, or when the user asks what they are missing, what the agent doubts, or wants to invert, reframe, or stress-test the situation.
---

# Blind Spot Check

Perform a focused epistemic audit of the current conversation, plan, and
available artifacts. Use the existing context; do not ask the user to restate
the plan. This is a concise end-of-planning check, not a comprehensive risk
register or an extended interview.

## Method

1. Reconstruct the objective, proposed approach, and important constraints
   internally. If a misunderstanding would invalidate the audit, state it
   instead of fabricating confidence.
2. Find candidate blind spots among load-bearing assumptions, omitted actors or
   dependencies, irreversible choices, sequencing and feedback problems,
   opportunity costs, operational burden, and failure despite competent
   execution.
3. Rank candidates by consequence, plausibility, and how little attention they
   received. Select only the strongest one.
4. Interrogate its load-bearing belief:
   - What is the plan treating as true?
   - What is known, and what is merely inferred? What evidence could disprove it?
   - How does believing it shape choices or hide alternatives?
   - What plan emerges if this belief cannot be relied on, or if its opposite is true?
5. Identify the material conclusion you are least confident about. Name whether
   the uncertainty comes from missing facts, ambiguous goals, an untested
   assumption, an external dependency, or inherent unpredictability.
6. Choose the smallest experiment, evidence, or decision that would most improve
   the plan or reduce the important uncertainty.

## Response

### Biggest thing you may be missing

Make one direct claim. Explain why it is consequential, identify the belief the
plan needs to be true, and show what changes when the plan is not allowed to
depend on that belief.

### What I am least confident about

Complete: "I am least confident that..." Explain why, distinguish evidence from
inference, and name what information would materially change the assessment.

### Best next move

Give one question, experiment, or decision that most improves the plan from
here.

## Rules

- Prefer one deep observation over an inventory of generic risks.
- Do not summarize the entire conversation before answering.
- Separate known facts, inferences, and speculation.
- Do not confuse an unknown claim with a false one.
- Do not manufacture novelty or reopen settled decisions without material cause.
- If no major blind spot is apparent, say so and report the largest residual risk.
- Critique the plan, not the user. Recommend investigation before wholesale change.
- Default to 300-600 words unless the situation genuinely requires more.
