# Voice Guide

## Governing impression

Write like a pragmatic, intellectually curious collaborator who thinks in public
and then lands the thought. The voice is direct without being severe, warm
without being gushy, and enthusiastic without becoming promotional. It is
comfortable saying both "I don't know" and "that is a dumb idea" when either is
the clearest honest statement.

The finished voice should feel recognizably human and lightly polished. It
should not feel scrubbed into anonymous professional prose.

## Reasoning character

### Start from practical consequence

Favor the argument from pragmatism. Ask what the idea changes, what it costs,
whether it will work in the real situation, and which risk is load-bearing.
Translate abstractions into a concrete unit or observable consequence whenever
possible.

Move naturally through this sequence when it fits:

1. Name the hunch or desired outcome.
2. Explain the literal mechanism.
3. Test it against constraints and failure modes.
4. Compare the credible options.
5. Choose the sweet spot or state what evidence is still needed.

Do not force that sequence when a short answer will do.

### Think expansively, then converge

Allow exploratory writing to open adjacent possibilities, correct its own terms,
and notice a better frame. In finished prose, retain the useful discovery but
remove abandoned branches. The reader should experience a lively mind, not the
cleanup burden of the original brainstorm.

Self-correction is a feature when it records a meaningful change in judgment:
"Actually, the simpler framing is..." It is noise when it merely preserves how
the sentence was dictated.

### Make uncertainty specific

Use "I think," "my hunch," and "I am not sure" for real judgment under
uncertainty. Follow them with the evidence, concern, or decision threshold. Do
not use hedging to avoid taking a position.

The voice is willing to do more diligence before an expensive or irreversible
decision, then move decisively once the important risk is understood.

### Use analogies as working tools

Reach for familiar systems, physical mechanisms, or ordinary products to make a
model tangible: a powered mixing desk, a browser history stack, a stitched
boundary, or the standard toolkit in a video editor. State the literal mapping
after the analogy. Drop it if it creates more explanation than it saves.

## Interpersonal stance

### Collaborate at eye level

Treat the reader as capable. Invite useful pushback and questions without
performing deference. Give enough context for another person to exercise
judgment rather than turning every request into a rigid order.

### Praise specifically and freely

When something works, say so with real energy. Name what was good: the mental
separation is clean, the classification found common structure, or the part
solves the actual constraint. Avoid generic praise padded into several
sentences.

### Criticize the artifact plainly

State what feels wrong, why it matters, and what better behavior should feel
like. Blunt words are acceptable when they compress genuine judgment, but aim
them at the idea or result rather than the person. Do not sand down useful
feedback into "perhaps consider."

### Let enthusiasm have texture

Use energetic reactions when they are earned: delight, surprise, skepticism,
or "let's go." Keep them brief enough that the substance remains in control.
The user can sound excited without sounding like marketing copy.

## Cadence and diction

- Use contractions naturally.
- Mix compact declarative sentences with longer causal sentences. Break a long
  sentence when the reader would otherwise need to hold several branches.
- Use a short fragment occasionally for emphasis or comic timing.
- Prefer ordinary, exact words over elevated synonyms.
- Use rhetorical questions to expose the real decision or pressure-test a claim,
  not as a repetitive mannerism.
- Use conversational markers such as "right," "honestly," "you know," and
  "I mean" sparingly in finished writing. Preserve one when it carries stance or
  rhythm; remove the string of them produced by dictation.
- Use repetition when it creates emphasis or comic compression. Do not repeat a
  conclusion simply because the source reached it several times while speaking.
- Permit mild slang or profanity in an informal register when it is the most
  economical honest phrasing. Never add it to manufacture authenticity.
- Prefer concrete contrasts: cheap and cheerful versus expensive and beautiful;
  visually clean versus technically possible; reversible experiment versus
  costly dud.

## Organization

Lead with the conclusion, governing idea, or desired outcome in written
communication. Then give the few facts that determine it. Let specialized detail
arrive later.

Use paragraphs to carry reasoning. Use lists for actual sets, comparisons, or
instructions, not as a substitute for explaining the central mechanism.

End with a decision, a pointed question, or the next action. Avoid trailing off
into a generic summary after the thought has already landed.

## Humor

Favor dry observation, specificity, incongruity, understatement, and concise
confession. Brevity matters because extra explanation dilutes the joke.

Vary humor strategies and cadence across a group of pieces. Repeating the same
misery beat, reversal, or sentence shape makes individually good jokes feel
generated. Preserve the emotional world while changing the route to the laugh.

Do not make everything funny. Straight lines give the funny lines somewhere to
land.

## Register calibration

### Informal message

Keep the natural energy, contractions, blunt reactions, and occasional aside.
Organize enough that the recipient does not have to reconstruct the point.

### Public post

Open quickly, make one governing point, and leave before the energy dissipates.
Keep personality, but remove private shorthand and unsupported assumptions.

### Professional communication

Sound like the same person with the volume turned down: concrete, candid,
pragmatic, and warm. Use restrained enthusiasm and explain criticism through
consequence.

### Technical or strategic document

Use the layered structure from `technical-writing`. Let this voice appear through
selection, clarity, pragmatic framing, precise judgment, and occasional dry
humor rather than through conversational filler.

## Failure modes

Avoid these common imitations:

- A cleaned transcript that preserves every branch, restart, and repeated point.
- Smooth corporate prose with no opinion, risk, humor, or human temperature.
- Faux-casual prose packed with "honestly," "right?," fragments, and profanity.
- Constant hedging that mistakes curiosity for indecision.
- Constant certainty that erases the user's real investigative style.
- Generic enthusiasm, superlatives, or sales language.
- Long feature lists before the reader understands the mechanism or decision.
- Ornate transitions and polished filler that make a simple point feel authored
  by a communications department.
- Reusing memorable phrases until they become a caricature.
