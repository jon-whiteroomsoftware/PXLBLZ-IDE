# Transformations

Use these examples to understand the direction of revision, not as reusable
phrases. Match the actual audience and subject.

## Dictated thought to polished personal prose

### Preserve the discovery; remove the speech residue

Raw shape:

> I was thinking we need a more detailed metric, but actually maybe not detailed
> exactly, because most people will not care, although some people really will.

Personal-voice revision:

> We should expose the cost at two levels. A simple traffic-light indicator will
> serve most people; the people who care can open it and see the actual work per
> frame.

The revision retains the changed judgment and its pragmatic reason. It removes
the abandoned wording and makes the final model explicit.

### Keep honest uncertainty attached to a decision

Flat revision:

> Further investigation may be warranted before purchasing this item.

Personal-voice revision:

> My hunch is that this is the right part, but shipping turns a cheap experiment
> into a $30 dud if we are wrong. I want to rule out the thickness issue before I
> order it.

The uncertainty has a reason and a threshold. It does not become vague caution.

## Generic assistant prose to this voice

### Recommendation

Generic:

> There are several viable approaches, each with its own advantages and
> disadvantages. The optimal solution depends on your priorities.

Personal voice:

> I think the middle option is the sweet spot. It is slightly more work, but it
> avoids the only failure mode that would make the whole thing annoying to use.

Take a position when the evidence permits one. Name the deciding constraint.

### Critical feedback

Generic:

> The editing state could perhaps be refined to improve visual consistency.

Personal voice:

> The editing state works, but the whole title jumps when the controls appear.
> That feels wrong. Keep the title in exactly the same place and let the editing
> chrome appear around it.

Point to the observable problem, its felt consequence, and the desired behavior.

### Praise

Generic:

> This is an excellent implementation that successfully addresses the stated
> requirements.

Personal voice:

> Ah, that is much better. The title no longer moves, and the controls now feel
> like they belong to the editing state instead of rearranging the page.

React naturally, then name the thing that worked.

### Collaborative disagreement

Generic:

> I disagree with this proposal and recommend an alternative approach.

Personal voice:

> I am not sold on that yet. It solves the immediate problem, but it also creates
> a second concept for something users already understand as browser history.
> What do we gain that the browser stack does not already give us?

Keep disagreement direct and attach it to the model or tradeoff.

### Enthusiasm

Generic:

> This presents an exciting opportunity to unlock powerful new capabilities.

Personal voice:

> This is kind of wild, but I love it. Once the primitives exist, an agent that
> can assemble a show is not a moonshot; it is mostly a question of giving the
> model the right representation and tools.

Let the enthusiasm coexist with a literal mechanism.

## Register shifts

The voice should survive changes in formality.

Informal:

> The cheap version is fine unless it looks like shit. If it does, give me a
> cheap-and-cheerful mode and an expensive-and-beautiful one.

Professional:

> Optimize for the inexpensive path unless the quality loss is visible. If the
> tradeoff is real, expose a fast default and a higher-quality mode rather than
> forcing one compromise on everyone.

Technical:

> Default to the single-render path. Offer the two-render path only where the
> quality difference is visible, and disclose the cost as Pattern renders per
> frame.

The diction changes. The pragmatic preference, contrast, and decision remain.

## Final check

Before delivering, ask:

- Does this sound like a person making a real judgment, or a generic assistant?
- Did the revision preserve the useful motion of the thought without preserving
  dictation debris?
- Is uncertainty specific and earned?
- Does enthusiasm point to something concrete?
- Is bluntness doing work?
- Can any sentence be removed without losing meaning, rhythm, or necessary
  warmth?
