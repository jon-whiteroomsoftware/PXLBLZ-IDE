---
name: personal-voice
description: Apply the user's personal voice to writing without changing the required content, facts, audience, or artifact workflow. Use when the user asks to write, draft, edit, rewrite, or respond in their voice; make something sound like them; or prepare communication they will send, including messages, email, posts, feedback, explanations, and documents. Compose with technical-writing for engineering prose and with artifact-specific skills when present.
---

# Personal Voice

## Role

Treat this skill as a voice overlay. Let the task or artifact skill determine what
the writing must accomplish. Let this skill determine the stance, cadence,
word choice, warmth, and degree of polish.

Read [references/voice-guide.md](references/voice-guide.md) before drafting.
When rewriting existing prose or diagnosing why prose does not sound right,
also read [references/transformations.md](references/transformations.md).

## Interpret the evidence

Treat the user's explicit request and corrections in the current conversation as
the highest authority. Treat prior feedback as stronger evidence than inferred
habits.

Assume most chat messages were dictated through SuperWhisper. Learn cadence,
emphasis, vocabulary, reasoning moves, humor, warmth, and interpersonal stance
from them. Do not reproduce transcription errors, duplicated passages, filler,
run-on syntax, abandoned branches, or accidental word substitutions in finished
writing.

Use polished writing as stronger evidence for grammar and final organization.
When spoken and written evidence differ, preserve the recognizable thought and
attitude of the spoken voice in the cleaner structure of the written voice.

## Choose the register

Infer the register from audience and stakes:

- **Conversational:** Keep contractions, energy, brief asides, and an occasional
  fragment or rhetorical question. Remove only speech residue that impedes the
  reader.
- **Polished personal:** Keep the candor and pragmatic reasoning, but compress
  repetition, resolve self-corrections, and give each paragraph one job.
- **Professional:** Retain directness, warmth, and concrete judgment. Reduce
  slang, profanity, and conversational markers without drifting into corporate
  blandness.
- **Technical:** Apply `technical-writing` after content requirements are known,
  then use this skill for voice. Technical accuracy and the reader's mental model
  take precedence over mimicry.

If the user requests a specific register, follow it even when another register
would normally fit the artifact.

## Draft and revise

1. Identify the audience, decision, emotional stakes, and intended next action.
2. State the governing point early. Build the reasoning through concrete
   mechanisms, consequences, constraints, and tradeoffs.
3. Express judgment plainly. Preserve honest uncertainty where the evidence is
   uncertain; do not weaken settled conclusions with habitual hedging.
4. Use the user's natural warmth, enthusiasm, skepticism, or bluntness at the
   intensity justified by the subject.
5. Remove dictated artifacts, generic assistant language, and AI-tell
   vocabulary ("load-bearing", delve, crucial, seamless, "not just X but Y";
   watch em-dash density — `technical-writing` carries the full tell list).
6. Read the result aloud. It should sound like the user after they had time to
   organize the thought, not like a transcript and not like a copywriter's
   impersonation.

## Preserve boundaries

- Preserve facts, commitments, quotations, and required terminology.
- Do not invent personal experiences, emotions, opinions, relationships, or
  biographical details merely to strengthen the voice.
- Do not add profanity, jokes, slang, rhetorical questions, or verbal tics as
  decoration. Use them only when the source or context supports them.
- Do not make every artifact equally informal. Voice should survive register
  changes without becoming a catchphrase set.
- Follow a mandated organizational or house style when it conflicts with this
  overlay; carry over only the compatible voice traits.

## Compose with other skills

Apply skills in this order:

1. Use the artifact skill to establish required content and workflow.
2. Use `technical-writing` when the artifact explains engineering or product
   concepts.
3. Use this skill to make the result sound like the user.
4. Run a final accuracy and register pass so voice edits do not distort meaning.
