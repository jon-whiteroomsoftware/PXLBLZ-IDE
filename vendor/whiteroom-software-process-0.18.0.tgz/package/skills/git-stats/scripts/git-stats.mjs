#!/usr/bin/env node
import { execFileSync, spawnSync } from 'node:child_process';
import { createServer } from 'node:http';
import { appendFileSync, existsSync, mkdirSync, readFileSync, readdirSync, statSync, writeFileSync } from 'node:fs';
import { dirname, join, relative, resolve, sep } from 'node:path';

const CODE_EXTENSIONS = new Set([
  '.ts', '.tsx', '.js', '.jsx', '.mjs', '.cjs', '.css', '.scss', '.sass', '.less',
  '.html', '.htm', '.sql', '.sh', '.bash', '.zsh', '.py', '.rb', '.go', '.rs',
  '.java', '.kt', '.kts', '.c', '.cc', '.cpp', '.cxx', '.h', '.hpp', '.cs', '.php',
  '.vue', '.svelte', '.swift', '.dart', '.lua', '.r', '.ex', '.exs', '.erl', '.hrl',
]);
const TEST_PATH = /(^|\/)(__tests__|test|tests|spec|specs|fixtures?)(\/|$)|\.(test|spec)\.[^.]+$/i;

function usage(message) {
  if (message) console.error(`Error: ${message}`);
  console.error('Usage: node git-stats.mjs [--repo PATH] [--days N] [--end YYYY-MM-DD] [--timezone IANA_ZONE] [--no-github] [--serve] [--port N]');
  process.exit(message ? 1 : 0);
}

function parseArgs(argv) {
  const options = { repo: process.cwd(), days: 7, end: null, timezone: 'America/Los_Angeles', github: true, serve: false, port: 4173 };
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (arg === '--help' || arg === '-h') usage();
    if (arg === '--no-github') { options.github = false; continue; }
    if (arg === '--serve') { options.serve = true; continue; }
    if (!['--repo', '--days', '--end', '--timezone', '--port'].includes(arg)) usage(`unknown option ${arg}`);
    const value = argv[++index];
    if (!value) usage(`missing value for ${arg}`);
    if (arg === '--repo') options.repo = value;
    if (arg === '--days') options.days = Number(value);
    if (arg === '--end') options.end = value;
    if (arg === '--timezone') options.timezone = value;
    if (arg === '--port') options.port = Number(value);
  }
  if (!Number.isInteger(options.days) || options.days < 1 || options.days > 31) usage('--days must be an integer from 1 to 31');
  if (!Number.isInteger(options.port) || options.port < 1024 || options.port > 65535) usage('--port must be an integer from 1024 to 65535');
  try { new Intl.DateTimeFormat('en-US', { timeZone: options.timezone }).format(); } catch { usage(`invalid timezone ${options.timezone}`); }
  if (options.end && !/^\d{4}-\d{2}-\d{2}$/.test(options.end)) usage('--end must be YYYY-MM-DD');
  return options;
}

function run(command, args, { cwd, input, encoding = 'utf8', allowFailure = false } = {}) {
  const result = spawnSync(command, args, { cwd, input, ...(encoding === 'buffer' ? {} : { encoding }), maxBuffer: 1024 * 1024 * 100 });
  if (result.error) throw result.error;
  if (result.status !== 0 && !allowFailure) throw new Error(`${command} ${args.join(' ')} failed: ${result.stderr || result.stdout}`);
  return result;
}

function git(repo, args, options = {}) { return run('git', args, { cwd: repo, ...options }); }
function gitText(repo, args) { return git(repo, args).stdout.trim(); }
function escapeHtml(value) { return String(value).replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]); }
function formatNumber(value) { return Number(value || 0).toLocaleString('en-US'); }
function signed(value) { return `${value >= 0 ? '+' : ''}${formatNumber(value)}`; }
function formatBytes(bytes) {
  if (!Number.isFinite(bytes)) return 'n/a';
  const units = ['B', 'KiB', 'MiB', 'GiB'];
  let amount = bytes;
  let unit = 0;
  while (amount >= 1024 && unit < units.length - 1) { amount /= 1024; unit += 1; }
  return `${amount >= 10 || unit === 0 ? amount.toFixed(0) : amount.toFixed(1)} ${units[unit]}`;
}

function dateParts(epoch, timezone) {
  const values = new Intl.DateTimeFormat('en-CA', {
    timeZone: timezone, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23',
  }).formatToParts(new Date(epoch));
  return Object.fromEntries(values.filter(({ type }) => type !== 'literal').map(({ type, value }) => [type, Number(value)]));
}

function dateKey(epoch, timezone) {
  const parts = dateParts(epoch, timezone);
  return `${parts.year}-${String(parts.month).padStart(2, '0')}-${String(parts.day).padStart(2, '0')}`;
}

function timezoneOffset(epoch, timezone) {
  const parts = dateParts(epoch, timezone);
  return Date.UTC(parts.year, parts.month - 1, parts.day, parts.hour, parts.minute, parts.second) - epoch;
}

function zonedEndEpoch(key, timezone) {
  const [year, month, day] = key.split('-').map(Number);
  const utc = Date.UTC(year, month - 1, day, 23, 59, 59);
  let epoch = utc - timezoneOffset(utc, timezone);
  epoch = utc - timezoneOffset(epoch, timezone);
  return epoch;
}

function addDays(key, amount) {
  const [year, month, day] = key.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day + amount));
  return date.toISOString().slice(0, 10);
}

function todayKey(timezone) { return dateKey(Date.now(), timezone); }
function labelForKey(key, timezone) {
  const epoch = zonedEndEpoch(key, timezone);
  return new Intl.DateTimeFormat('en-US', { timeZone: timezone, weekday: 'short', month: 'short', day: 'numeric' }).format(new Date(epoch)).replace(',', '');
}

function extension(path) {
  const base = path.slice(path.lastIndexOf('/') + 1).toLowerCase();
  const dot = base.lastIndexOf('.');
  return dot < 0 ? '' : base.slice(dot);
}

function isCodePath(path) { return CODE_EXTENSIONS.has(extension(path)); }
function countLines(buffer) {
  if (!buffer.length || buffer.includes(0)) return 0;
  let lines = 0;
  for (const byte of buffer) if (byte === 10) lines += 1;
  return lines + (buffer.at(-1) === 10 ? 0 : 1);
}

function treeEntries(repo, ref) {
  const buffer = git(repo, ['ls-tree', '-r', '-z', '--full-tree', ref], { encoding: 'buffer' }).stdout;
  return buffer.toString('utf8').split('\0').filter(Boolean).map((record) => {
    const [meta, path] = record.split('\t');
    const [mode, type, sha] = meta.split(' ');
    return { mode, type, sha, path };
  }).filter(({ type }) => type === 'blob');
}

function readBlobs(repo, entries) {
  if (!entries.length) return [];
  const input = entries.map(({ sha }) => `${sha}\n`).join('');
  const output = git(repo, ['cat-file', '--batch'], { input, encoding: 'buffer' }).stdout;
  let offset = 0;
  return entries.map((entry) => {
    const end = output.indexOf(10, offset);
    const header = output.subarray(offset, end).toString('utf8').split(' ');
    offset = end + 1;
    if (header[1] === 'missing') return { ...entry, content: Buffer.alloc(0) };
    const size = Number(header[2]);
    const content = output.subarray(offset, offset + size);
    offset += size + 1;
    return { ...entry, content };
  });
}

const treeStatsCache = new Map();
function treeStats(repo, ref) {
  if (!ref) return { codeLoc: 0, textLoc: 0, testLoc: 0, files: 0, contentBytes: 0 };
  if (treeStatsCache.has(ref)) return treeStatsCache.get(ref);
  const blobs = readBlobs(repo, treeEntries(repo, ref));
  const stats = { codeLoc: 0, textLoc: 0, testLoc: 0, files: blobs.length, contentBytes: 0 };
  for (const { path, content } of blobs) {
    stats.contentBytes += content.length;
    const lines = countLines(content);
    stats.textLoc += lines;
    if (isCodePath(path)) {
      stats.codeLoc += lines;
      if (TEST_PATH.test(path)) stats.testLoc += lines;
    }
  }
  treeStatsCache.set(ref, stats);
  return stats;
}

function firstParentCommits(repo) {
  const output = gitText(repo, ['rev-list', '--first-parent', '--timestamp', 'HEAD']);
  return output ? output.split('\n').map((line) => {
    const [timestamp, hash] = line.split(' ');
    return { timestamp: Number(timestamp) * 1000, hash };
  }) : [];
}

function nonMergeCommits(repo) {
  const output = gitText(repo, ['log', '--no-merges', '--format=%H%x09%ct', 'HEAD']);
  return output ? output.split('\n').map((line) => {
    const [hash, timestamp] = line.split('\t');
    return { hash, timestamp: Number(timestamp) * 1000 };
  }) : [];
}

function churnForCommit(repo, hash) {
  const text = git(repo, ['show', '--format=', '--numstat', '--no-ext-diff', '--no-renames', hash]).stdout;
  let added = 0;
  let deleted = 0;
  for (const line of text.split('\n')) {
    const [a, d] = line.split('\t');
    if (/^\d+$/.test(a) && /^\d+$/.test(d)) { added += Number(a); deleted += Number(d); }
  }
  return { added, deleted };
}

function localWeek(repo, days, end, timezone) {
  const start = addDays(end, -days);
  const keys = Array.from({ length: days }, (_, index) => addDays(start, index));
  const parent = firstParentCommits(repo);
  const commits = nonMergeCommits(repo);
  const rows = keys.map((key) => {
    const endEpoch = zonedEndEpoch(key, timezone);
    const snapshot = parent.find((commit) => commit.timestamp <= endEpoch)?.hash || null;
    const dayCommits = commits.filter((commit) => dateKey(commit.timestamp, timezone) === key);
    const churn = dayCommits.reduce((total, commit) => {
      const change = churnForCommit(repo, commit.hash);
      total.added += change.added;
      total.deleted += change.deleted;
      return total;
    }, { added: 0, deleted: 0 });
    return { key, label: labelForKey(key, timezone), commits: dayCommits.length, codeLoc: treeStats(repo, snapshot).codeLoc, ...churn };
  });
  let previous = treeStats(repo, parent.find((commit) => commit.timestamp <= zonedEndEpoch(addDays(start, -1), timezone))?.hash || null).codeLoc;
  for (const row of rows) {
    row.growth = row.codeLoc - previous;
    row.changed = row.added + row.deleted;
    previous = row.codeLoc;
  }
  const finalLoc = rows.at(-1).codeLoc;
  return {
    start, end, rows, baselineLoc: treeStats(repo, parent.find((commit) => commit.timestamp <= zonedEndEpoch(addDays(start, -1), timezone))?.hash || null).codeLoc,
    total: rows.reduce((total, row) => ({ commits: total.commits + row.commits, added: total.added + row.added, deleted: total.deleted + row.deleted, changed: total.changed + row.changed }), { commits: 0, added: 0, deleted: 0, changed: 0 }),
    finalLoc,
  };
}

function directorySize(path) {
  if (!existsSync(path)) return 0;
  const stat = statSync(path);
  if (!stat.isDirectory()) return stat.size;
  let total = 0;
  for (const entry of readdirSync(path, { withFileTypes: true })) {
    if (entry.isSymbolicLink()) continue;
    total += directorySize(join(path, entry.name));
  }
  return total;
}

function repositorySize(repo) {
  const packed = gitText(repo, ['count-objects', '-vH']).split('\n').find((line) => line.startsWith('size-pack:'))?.split(':').slice(1).join(':').trim() || '0 bytes';
  const checkout = directorySize(repo) - directorySize(join(repo, '.git'));
  const buildDirectory = ['dist', 'build', 'out'].map((name) => join(repo, name)).find(existsSync);
  return { packed, checkout: Math.max(0, checkout), build: buildDirectory ? directorySize(buildDirectory) : 0, buildName: buildDirectory ? relative(repo, buildDirectory) : null };
}

function githubRepository(repo) {
  const origin = gitText(repo, ['remote', 'get-url', 'origin']);
  const match = origin.match(/github\.com[/:]([^/]+)\/([^/]+?)(?:\.git)?$/i);
  return match ? { owner: match[1], name: match[2] } : null;
}

function githubApi(path) {
  const result = run('gh', ['api', '-H', 'Accept: application/vnd.github+json', path], { allowFailure: true });
  if (result.status !== 0) throw new Error((result.stderr || result.stdout || 'GitHub API request failed').trim());
  return JSON.parse(result.stdout);
}

function githubHistory(repo) {
  const repository = githubRepository(repo);
  if (!repository) return { status: 'unavailable', message: 'No GitHub origin remote was found.' };
  try {
    const path = `repos/${repository.owner}/${repository.name}/stats`;
    const codeFrequency = githubApi(`${path}/code_frequency`);
    if (!Array.isArray(codeFrequency)) throw new Error('GitHub is preparing its cached code-frequency statistics; run the skill again shortly.');
    const commitActivity = githubApi(`${path}/commit_activity`);
    const commits = Array.isArray(commitActivity) ? new Map(commitActivity.map((week) => [week.week, week.total])) : null;
    return {
      status: commits ? 'fresh' : 'partial', repository: `${repository.owner}/${repository.name}`,
      message: commits ? null : 'GitHub is still preparing weekly commit counts; additions and deletions are current.',
      weeks: codeFrequency.map(([week, added, deleted]) => ({ week, added, deleted: Math.abs(deleted), commits: commits ? (commits.get(week) || 0) : null })),
    };
  } catch (error) {
    const message = /202/.test(error.message) ? 'GitHub is preparing its cached statistics; run the skill again shortly.' : `GitHub history unavailable: ${error.message}`;
    return { status: 'unavailable', message };
  }
}

function previousData(output) {
  if (!existsSync(output)) return { observations: [] };
  const html = readFileSync(output, 'utf8');
  const match = html.match(/<script id="git-stats-data" type="application\/json">([\s\S]*?)<\/script>/);
  if (!match) return { observations: [] };
  try { return JSON.parse(match[1]); } catch { return { observations: [] }; }
}

function chart(history) {
  if (!history?.weeks?.length) return '';
  const weeks = history.weeks.slice(-52);
  const maximum = Math.max(1, ...weeks.flatMap(({ added, deleted }) => [added, deleted]));
  return `<div class="chart" aria-label="GitHub weekly additions and deletions for the last ${weeks.length} weeks">${weeks.map(({ week, added, deleted, commits }) => {
    const date = new Date(week * 1000).toISOString().slice(0, 10);
    return `<div class="week" title="Week of ${date}: ${commits === null ? 'commit count pending' : `${formatNumber(commits)} commits`}, +${formatNumber(added)}, -${formatNumber(deleted)}"><i class="add" style="height:${Math.max(1, added / maximum * 100)}%"></i><i class="delete" style="height:${Math.max(1, deleted / maximum * 100)}%"></i></div>`;
  }).join('')}</div>`;
}

function monthlyRows(history) {
  if (!history?.weeks?.length) return '';
  const months = new Map();
  for (const week of history.weeks) {
    const month = new Date(week.week * 1000).toISOString().slice(0, 7);
    const total = months.get(month) || { commits: 0, commitDataReady: true, added: 0, deleted: 0 };
    if (week.commits === null) total.commitDataReady = false;
    else total.commits += week.commits;
    total.added += week.added; total.deleted += week.deleted;
    months.set(month, total);
  }
  return [...months.entries()].slice(-12).reverse().map(([month, values]) => `<tr><td>${month}</td><td>${values.commitDataReady ? formatNumber(values.commits) : '—'}</td><td>${formatNumber(values.added)}</td><td>${formatNumber(values.deleted)}</td><td>${signed(values.added - values.deleted)}</td></tr>`).join('');
}

function render({ repo, branch, head, timezone, week, stats, sizes, observations, history, generated }) {
  const totalGrowth = week.finalLoc - week.baselineLoc;
  const localRows = week.rows.map((row) => `<tr><td>${row.label}</td><td>${formatNumber(row.commits)}</td><td>${formatNumber(row.codeLoc)}</td><td>${signed(row.growth)}</td><td>${formatNumber(row.added)}</td><td>${formatNumber(row.deleted)}</td><td>${formatNumber(row.changed)}</td></tr>`).join('');
  const observed = observations.slice(-16).reverse().map(({ date, codeLoc }) => `<tr><td>${escapeHtml(date)}</td><td>${formatNumber(codeLoc)}</td></tr>`).join('') || '<tr><td colspan="2">No observations yet.</td></tr>';
  const historyBody = history?.weeks ? `
    <section><h2>GitHub history</h2><p class="muted">${history.status !== 'fresh' ? `${escapeHtml(history.message)}${history.status === 'stale' ? ' Showing the last saved GitHub data.' : ''}` : `Last ${Math.min(52, history.weeks.length)} weekly buckets from GitHub: additions and deletions across all tracked text. GitHub excludes merge commits.`}</p>
    ${chart(history)}
    <div class="table-wrap"><table><thead><tr><th>Month</th><th>Commits</th><th>Added</th><th>Deleted</th><th>Net</th></tr></thead><tbody>${monthlyRows(history)}</tbody></table></div></section>` : `
    <section><h2>GitHub history</h2><p class="muted">${escapeHtml(history?.message || 'No GitHub history is available.')}${history?.status === 'stale' ? ' Showing the last saved GitHub data.' : ''}</p>${history?.weeks ? chart(history) : ''}</section>`;
  const payload = JSON.stringify({ observations, github: history?.weeks ? { repository: history.repository, weeks: history.weeks } : undefined }).replace(/</g, '\\u003c');
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Git Stats</title>
<style>:root{color-scheme:light dark;--ink:#1f2937;--muted:#64748b;--line:#dbe2ea;--accent:#2563eb;--add:#16a34a;--delete:#dc2626}@media(prefers-color-scheme:dark){:root{--ink:#e5e7eb;--muted:#94a3b8;--line:#334155;--accent:#60a5fa}}*{box-sizing:border-box}body{max-width:1080px;margin:0 auto;padding:40px 24px 64px;font:15px/1.5 ui-sans-serif,system-ui,sans-serif;color:var(--ink)}h1{margin:0;font-size:32px;letter-spacing:-.04em}h2{margin:42px 0 8px;font-size:20px}.meta,.muted{color:var(--muted)}.meta{margin:6px 0 28px}.table-wrap{max-width:100%;overflow-x:auto}table{width:100%;border-collapse:collapse;margin-top:14px;font-variant-numeric:tabular-nums}th,td{padding:8px 10px;border-bottom:1px solid var(--line);text-align:right;white-space:nowrap}th:first-child,td:first-child{text-align:left}tfoot{font-weight:700}.summary{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px}.card{border:1px solid var(--line);border-radius:8px;padding:14px}.card strong{display:block;font-size:20px}.chart{height:180px;display:flex;align-items:end;gap:2px;border-bottom:1px solid var(--line);margin:18px 0}.week{height:100%;min-width:2px;flex:1;display:flex;align-items:end;gap:1px}.week i{display:block;flex:1}.add{background:var(--add)}.delete{background:var(--delete)}@media(max-width:700px){body{padding:24px 12px}table{min-width:680px;font-size:12px}th,td{padding:6px 4px}}</style></head>
<body><header><h1>Git Stats</h1><p class="meta">Generated ${escapeHtml(generated)} · ${escapeHtml(branch)} @ <code>${escapeHtml(head.slice(0, 8))}</code> · ${escapeHtml(timezone)}</p></header>
<section><h2>Last completed ${week.rows.length} days</h2><p class="muted">${escapeHtml(week.start)} through ${escapeHtml(addDays(week.end, -1))}. “Changed” is additions plus deletions. Code LOC counts source-like tracked files, including tests.</p><div class="table-wrap"><table><thead><tr><th>Day</th><th>Commits</th><th>Code LOC at EOD</th><th>LOC growth</th><th>Added</th><th>Deleted</th><th>Changed</th></tr></thead><tbody>${localRows}</tbody><tfoot><tr><td>Period</td><td>${formatNumber(week.total.commits)}</td><td>${formatNumber(week.finalLoc)}</td><td>${signed(totalGrowth)}</td><td>${formatNumber(week.total.added)}</td><td>${formatNumber(week.total.deleted)}</td><td>${formatNumber(week.total.changed)}</td></tr></tfoot></table></div></section>
<section><h2>Repository size now</h2><div class="summary"><div class="card"><strong>${formatNumber(stats.codeLoc)}</strong>raw code lines</div><div class="card"><strong>${formatNumber(stats.textLoc)}</strong>tracked text lines</div><div class="card"><strong>${formatNumber(stats.testLoc)}</strong>test-code lines</div><div class="card"><strong>${formatNumber(stats.files)}</strong>tracked files</div><div class="card"><strong>${formatBytes(stats.contentBytes)}</strong>uncompressed tracked content</div><div class="card"><strong>${escapeHtml(sizes.packed)}</strong>packed Git objects</div><div class="card"><strong>${formatBytes(sizes.checkout)}</strong>working checkout</div>${sizes.buildName ? `<div class="card"><strong>${formatBytes(sizes.build)}</strong>${escapeHtml(sizes.buildName)} output</div>` : ''}</div></section>
<section><h2>Observed LOC history</h2><p class="muted">Saved locally in this ignored report whenever Git Stats runs.</p><div class="table-wrap"><table><thead><tr><th>Observed</th><th>Code LOC</th></tr></thead><tbody>${observed}</tbody></table></div></section>
${historyBody}
<script id="git-stats-data" type="application/json">${payload}</script></body></html>`;
}

const MIME_TYPES = {
  '.css': 'text/css; charset=utf-8', '.gif': 'image/gif', '.htm': 'text/html; charset=utf-8', '.html': 'text/html; charset=utf-8',
  '.ico': 'image/x-icon', '.jpeg': 'image/jpeg', '.jpg': 'image/jpeg', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml', '.txt': 'text/plain; charset=utf-8', '.webp': 'image/webp',
};

function previewPath(repo, pathname) {
  let decoded;
  try { decoded = decodeURIComponent(pathname); } catch { return null; }
  const target = resolve(repo, `.${decoded}`);
  return target === repo || target.startsWith(`${repo}${sep}`) ? target : null;
}

function directoryListing(pathname, entries) {
  const parent = pathname === '/' ? '' : `<li><a href="../">../</a></li>`;
  const links = entries.sort((left, right) => left.name.localeCompare(right.name)).map((entry) => {
    const name = `${entry.name}${entry.isDirectory() ? '/' : ''}`;
    return `<li><a href="${encodeURI(name)}">${escapeHtml(name)}</a></li>`;
  }).join('');
  return `<!doctype html><meta charset="utf-8"><title>Index of ${escapeHtml(pathname)}</title><style>body{max-width:760px;margin:48px auto;padding:0 24px;font:16px/1.5 ui-sans-serif,system-ui,sans-serif}a{color:#2563eb}ul{padding-left:20px}</style><h1>Index of ${escapeHtml(pathname)}</h1><ul>${parent}${links}</ul>`;
}

function startPreviewServer(repo, port) {
  const address = `http://127.0.0.1:${port}/`;
  const server = createServer((request, response) => {
    const url = new URL(request.url || '/', address);
    const pathname = url.pathname.endsWith('/') ? url.pathname : url.pathname;
    const target = previewPath(repo, pathname);
    if (!target) { response.writeHead(403, { 'content-type': 'text/plain; charset=utf-8' }); response.end('Forbidden'); return; }
    try {
      const stat = statSync(target);
      if (stat.isDirectory()) {
        if (!pathname.endsWith('/')) { response.writeHead(302, { location: `${pathname}/${url.search}` }); response.end(); return; }
        const index = join(target, 'index.html');
        if (existsSync(index) && statSync(index).isFile()) {
          response.writeHead(200, { 'content-type': MIME_TYPES['.html'] }); response.end(readFileSync(index)); return;
        }
        response.writeHead(200, { 'content-type': 'text/html; charset=utf-8' }); response.end(directoryListing(pathname, readdirSync(target, { withFileTypes: true }))); return;
      }
      if (!stat.isFile()) throw new Error('Not a file');
      const mime = MIME_TYPES[extension(target)] || 'application/octet-stream';
      response.writeHead(200, { 'content-type': mime, 'content-length': stat.size });
      response.end(readFileSync(target));
    } catch {
      response.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' }); response.end('Not found');
    }
  });
  server.on('error', (error) => {
    if (error.code === 'EADDRINUSE') console.error(`Preview server already uses port ${port}; open ${address}`);
    else console.error(`Preview server failed: ${error.message}`);
    process.exitCode = 1;
  });
  server.listen(port, '127.0.0.1', () => console.log(`Serving ${repo}\nOpen ${address}docs/git-stats.html`));
  for (const signal of ['SIGINT', 'SIGTERM']) process.once(signal, () => server.close(() => process.exit(0)));
}

function ensureIgnored(repo) {
  const exclude = resolve(repo, gitText(repo, ['rev-parse', '--git-path', 'info/exclude']));
  mkdirSync(dirname(exclude), { recursive: true });
  const rule = '/docs/git-stats.html';
  const existing = existsSync(exclude) ? readFileSync(exclude, 'utf8') : '';
  if (!existing.split(/\r?\n/).includes(rule)) appendFileSync(exclude, `${existing && !existing.endsWith('\n') ? '\n' : ''}${rule}\n`);
}

function main() {
  const options = parseArgs(process.argv.slice(2));
  let repo = resolve(options.repo);
  try { repo = gitText(repo, ['rev-parse', '--show-toplevel']); } catch { usage(`${repo} is not a Git repository`); }
  const output = join(repo, 'docs', 'git-stats.html');
  const old = previousData(output);
  const end = options.end || todayKey(options.timezone);
  const week = localWeek(repo, options.days, end, options.timezone);
  const head = gitText(repo, ['rev-parse', 'HEAD']);
  const branch = gitText(repo, ['branch', '--show-current']) || 'detached HEAD';
  const stats = treeStats(repo, head);
  const sizes = repositorySize(repo);
  const now = todayKey(options.timezone);
  const observations = Array.isArray(old.observations) ? old.observations.filter((item) => item && typeof item.date === 'string' && Number.isFinite(item.codeLoc)) : [];
  const previous = observations.findIndex((item) => item.date === now);
  if (previous >= 0) observations[previous] = { date: now, codeLoc: stats.codeLoc };
  else observations.push({ date: now, codeLoc: stats.codeLoc });
  let history = options.github ? githubHistory(repo) : { status: 'unavailable', message: 'GitHub history was skipped.' };
  if (history.status === 'unavailable' && old.github?.weeks?.length) history = { ...old.github, status: 'stale', message: history.message };
  mkdirSync(join(repo, 'docs'), { recursive: true });
  ensureIgnored(repo);
  writeFileSync(output, render({ repo, branch, head, timezone: options.timezone, week, stats, sizes, observations, history, generated: new Intl.DateTimeFormat('en-US', { dateStyle: 'medium', timeStyle: 'short', timeZone: options.timezone }).format(new Date()) }));
  console.log(`Wrote ${relative(repo, output)}`);
  if (options.serve) startPreviewServer(repo, options.port);
}

main();
