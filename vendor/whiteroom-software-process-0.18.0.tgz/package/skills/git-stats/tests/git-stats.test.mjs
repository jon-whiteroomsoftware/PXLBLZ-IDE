import assert from 'node:assert/strict';
import { execFileSync, spawn } from 'node:child_process';
import { existsSync, mkdirSync, mkdtempSync, readFileSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const skillRoot = new URL('..', import.meta.url);
const script = new URL('../scripts/git-stats.mjs', import.meta.url);
const repo = mkdtempSync(join(tmpdir(), 'git-stats-fixture-'));

function git(args, env = {}) {
  return execFileSync('git', args, {
    cwd: repo,
    encoding: 'utf8',
    env: { ...process.env, ...env },
  });
}

git(['init', '-q']);
git(['config', 'user.name', 'Fixture']);
git(['config', 'user.email', 'fixture@example.com']);

function commit(name, content, timestamp) {
  const path = join(repo, name);
  mkdirSync(join(path, '..'), { recursive: true });
  writeFileSync(path, content);
  git(['add', name]);
  git(['commit', '-qm', `update ${name}`], {
    GIT_AUTHOR_DATE: timestamp,
    GIT_COMMITTER_DATE: timestamp,
  });
}

await commit('src/app.ts', 'one\ntwo\n', '2026-07-12T09:00:00Z');
await commit('README.md', 'docs\n', '2026-07-13T10:00:00Z');
await commit('src/app.ts', 'one\ntwo\nthree\n', '2026-07-13T11:00:00Z');

execFileSync('node', [script.pathname, '--repo', repo, '--timezone', 'UTC', '--end', '2026-07-14', '--days', '2', '--no-github'], {
  cwd: repo,
  stdio: 'inherit',
});

const html = readFileSync(join(repo, 'docs/git-stats.html'), 'utf8');
assert.match(html, /Sun Jul 12/);
assert.match(html, /Mon Jul 13/);
assert.match(html, /<td>1<\/td>/);
assert.match(html, /Code LOC at EOD/);
assert.match(html, /<strong>3<\/strong>raw code lines/);
assert.match(readFileSync(join(repo, '.git/info/exclude'), 'utf8'), /\/docs\/git-stats\.html/);

const port = 48000 + Math.floor(Math.random() * 1000);
const preview = spawn('node', [script.pathname, '--repo', repo, '--timezone', 'UTC', '--end', '2026-07-14', '--days', '2', '--no-github', '--serve', '--port', String(port)], {
  cwd: repo,
  stdio: ['ignore', 'pipe', 'pipe'],
});
let output = '';
preview.stdout.on('data', (chunk) => { output += chunk; });
preview.stderr.on('data', (chunk) => { output += chunk; });
try {
  let report;
  for (let attempt = 0; attempt < 25; attempt += 1) {
    try { report = await fetch(`http://127.0.0.1:${port}/docs/git-stats.html`); } catch { /* Server is still starting. */ }
    if (report?.status === 200) break;
    await new Promise((resolveDelay) => setTimeout(resolveDelay, 100));
  }
  assert.ok(report, `preview did not start: ${output}`);
  assert.equal(report.status, 200);
  assert.match(await report.text(), /Git Stats/);
  const listing = await fetch(`http://127.0.0.1:${port}/docs/`);
  assert.equal(listing.status, 200);
  assert.match(await listing.text(), /git-stats\.html/);
} finally {
  preview.kill('SIGTERM');
}

const wtParent = mkdtempSync(join(tmpdir(), 'git-stats-wt-'));
const wt = join(wtParent, 'wt');
git(['worktree', 'add', wt, '-b', 'wt']);
execFileSync('node', [script.pathname, '--repo', wt, '--timezone', 'UTC', '--end', '2026-07-14', '--days', '2', '--no-github'], {
  cwd: wt,
  stdio: 'inherit',
});
assert.ok(existsSync(join(wt, 'docs', 'git-stats.html')));
console.log('git-stats fixture passed');
