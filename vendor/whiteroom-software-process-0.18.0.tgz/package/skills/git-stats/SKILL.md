---
name: git-stats
description: Generates a local HTML Git activity and repository-size report, combining a recent Git-derived daily table with GitHub's cached weekly history, and can serve repository HTML for Codex's internal browser. Use when the user asks for repository stats, code-line counts, commit churn, a weekly Git report, to refresh git-stats.html, or to preview local HTML in Codex.
---

# Git Stats

Run the bundled generator from the repository root:

```bash
node "$CODEX_HOME/skills/git-stats/scripts/git-stats.mjs"
```

It writes `docs/git-stats.html` and adds that path to the checkout-local
`.git/info/exclude`. Do not add it to the repository's tracked `.gitignore`,
stage it, or commit it unless the user explicitly changes that policy.

The report contains:

- the seven completed Pacific-time days ending yesterday, calculated from local Git;
- current repository source/text/test line counts and compact size metrics;
- locally observed code-LOC points retained inside the ignored HTML; and
- GitHub's cached weekly additions, deletions, and commits for longer-range context.

GitHub history is optional. For a repository without a GitHub remote, unavailable
CLI authentication, or a GitHub `202` cache response, still generate the local
sections. Preserve saved GitHub data in the report and label it stale rather than
discarding it.

## Options

Use options only when the user asks for a non-default report:

```bash
node "$CODEX_HOME/skills/git-stats/scripts/git-stats.mjs" \
  --days 14 --timezone America/New_York
```

- `--repo PATH` runs against another local Git checkout.
- `--days N` changes the recent daily window (1–31; default 7).
- `--end YYYY-MM-DD` makes that calendar day exclusive, useful for reproducing a past report.
- `--timezone IANA_ZONE` changes the daily boundary (default `America/Los_Angeles`).
- `--no-github` skips network history, useful for offline checks and tests.

## Internal-browser preview

When the user wants to open the report or browse local HTML in Codex's internal
browser, ensure that the bounded preview server is running. In a terminal the
following command keeps the server in the foreground:

```bash
node "$CODEX_HOME/skills/git-stats/scripts/git-stats.mjs" --serve
```

It serves the repository root only on `127.0.0.1:4173`, with directory listings.
When acting through Codex, check whether port `4173` is already listening first.
If it is not, start the same command as a persistent background process so it
survives the command session; do not start a duplicate server. Then open this
exact URL in the internal browser:

```text
http://127.0.0.1:4173/docs/git-stats.html
```

Any other local HTML in the repository is available at its repository-relative
URL. For example, `docs/example/index.html` is
`http://127.0.0.1:4173/docs/example/index.html`. Relative paths work normally.
Use `--port 4174` only when the default port is occupied. The server binds to
loopback only and never changes repository files beyond the normal report output.

Do not claim the GitHub history is source LOC: GitHub supplies weekly commit and
text-churn aggregates only. The generator excludes merge commits from local churn
to align with GitHub's statistics.

## Verify

Run the fixture test after changing the generator:

```bash
node "$CODEX_HOME/skills/git-stats/tests/git-stats.test.mjs"
```
