---
name: doc-sweep
description: Synchronize project documentation after commits, issue completion, or feature completion. Use when the user asks for a doc sweep, documentation sweep, reference sweep, PRD cleanup, or to make docs match current shipped behavior.
---

# Documentation Sweep

Keep forward-looking planning docs separate from as-built reference docs while making the current repo state easy for agents to consume.

## Inputs

Start from the user's requested scope. If no scope is given, inspect recent commits, the active issue, and changed files to infer what shipped or changed.

Read repo-specific docs before editing:

- `AGENTS.md`
- `CONTEXT.md`
- `docs/agents/`
- active issue or relevant PRD
- relevant technical design documents
- relevant `docs/plans/` and `docs/reference/` files

## Document Roles

- `CONTEXT.md`: canonical domain language, concepts, boundaries, and current conceptual model. Consider it on every doc sweep; update it whenever shipped work introduces, renames, retires, or meaningfully sharpens a domain term or boundary.
- `docs/plans/`: forward-looking PRDs, feature PRDs, technical design documents, milestones, sequencing, open questions, and intended future behavior.
- `docs/reference/product/`: as-built user-facing behavior.
- `docs/reference/technical/`: as-built architecture, algorithms, APIs, commands, data flow, and code organization.
- `docs/reference/contracts/` (or the project's established equivalent):
  current obligations at seams, including ownership, invariants, transitions,
  failure, compatibility, limits, and evidence.
- Issues: live implementation state and progress for active work.

Do not leak planning history into reference docs. Reference docs should not describe milestones, implementation sequencing, abandoned alternatives, temporary compromises, or build process history unless that information remains necessary to understand the current system.

Reference docs are not exhaustive prose mirrors of the implementation. Preserve
the stable concepts, contracts, boundaries, ownership, data flow, and surprising
constraints that help a human reason about the system. Let code and tests own
local mechanics that are easier to inspect than to explain. Link detailed
evidence or specialized reports instead of copying them into the central
reference.

## Workflow

1. Determine what changed.
   - Review the active issue, recent commits, changed files, and user-provided scope.
   - Identify shipped behavior, conceptual changes, and remaining future work.

2. Classify documentation impact.
- Update `CONTEXT.md` if domain language, boundaries, or the conceptual model changed; explicitly decide this on every sweep rather than treating `CONTEXT.md` as background-only.
   - Update product reference docs for user-facing behavior.
   - Update technical reference docs for implementation-relevant behavior.
   - Update applicable engineering contracts when shipped interface obligations
     changed. If code and contract disagree, expose the mismatch for a governing
     decision instead of silently weakening either claim.
   - Update PRDs, feature PRDs, or technical design documents so completed work no longer reads like future scope.
   - Update the issue if progress, remaining work, or docs status changed.

3. Edit only current-truth docs with current truth.
   - Reference docs describe what exists now.
   - Planning docs describe what is still intended, undecided, or future.
   - If implementation differs from the plan, reference docs follow the implementation.

4. Archive completed planning docs when appropriate.
   - Move completed feature PRDs to `docs/plans/archive/` only when they are no longer useful for active planning.
   - Do not delete PRDs by default.
   - Retire or supersede obsolete contracts deliberately and leave a pointer to
     the current agreement. Remove duplicated normative detail from overview
     reference while preserving its conceptual explanation and entry point.

5. Report the sweep.
   - List docs updated.
   - List docs checked but left unchanged.
   - Note unresolved doc gaps, stale plans, or decisions needing user input.
   - State whether reference docs now match the inspected shipped behavior.

## Cadence

- At commit boundaries: check whether technical reference docs need updates; if user-facing behavior changed, also check product reference docs.
- At issue completion: update reference docs only when shipped behavior changes a
  documented concept, contract, boundary, workflow, or important constraint. Do
  not add feature-diary coverage merely to prove that the issue was documented.
- At feature completion: update reference docs, update `CONTEXT.md` if concepts changed, revise PRDs, and archive completed feature PRDs when appropriate.

Do not perform a full documentation sweep on every commit unless requested or the change warrants it.
