---
name: issue-workflow
description: Apply the user's issue-state and cross-agent coordination workflow. Use when starting feature work, finding feature epics or typed children, creating issues, writing spec detail (limits, must-test cases, required proof) into an issue, updating issue progress, claiming work, marking implementation available, handling follow-ups, coordinating commits with issues, or adapting Matt Pocock's to-issues output.
---

# Issue Workflow

Use Matt Pocock's `to-issues` skill for breaking plans into vertical slices. Use this workflow for the user's issue-state conventions around those slices.

## Issue Role

Issues are the primary cross-agent state store for implementation mechanics. They should not be the only home for durable product decisions, architecture rationale, technical design, domain language, or reference behavior. Those belong in PRDs/plans, technical design documents, ADRs/reference docs, `CONTEXT.md`, and commits.

The issue body should optimize for current implementation state: what is in scope, what is done, what remains, what is blocked, what was tested, and what docs changed.

## Feature work

Before starting a new feature, search for and reuse its epic (an existing PRD
issue may already serve); create one only if absent. Before feature work, inspect
children and reuse a suitable bounded typed issue or create the missing child
within the authorized scope. “Do UX for this feature” selects a UX child, not
the epic as an execution issue. Create only real needed work. Surface ambiguous
epics, conflicting parents or claims; preserve them pending resolution.

Use the repository's adopted work-type guide for native parent/sub-issue
attachment and read-back verification, or explicit reciprocal-link fallback when
native grouping is confirmed unavailable. The WRSP guide is
`docs/reference/work-types.md`. Permission/security failures stop the affected
action; fallback supplies no bypass. Do not silently replace a parent.

An epic groups specification and children; definition work that authors its PRD
belongs to a typed child. Preserve existing PRD labels/history when reusing it.
Reference the actual work child in sessions/commits; parent grouping is not a
second execution/spend unit. Shared or maintenance work may remain standalone.
No new epic work-purpose category is required. Future rollups remain future work.

## Typed work

When creating or claiming child or standalone work, read the repository's adopted WRSP work-type
catalog and process contract (`docs/reference/contracts/work-types.md` in WRSP).
Select/check exactly one catalog label by the task's purpose. Missing or multiple
recognized labels are unknown diagnostics, not a new work gate. Keep generic and
state labels separate. Link corrective issues to the bug or findings they address.
Use the contract's correction/history and capture/effective-time procedure.

Prefer bounded sessions; meaningful task/category changes normally start another
session. Incidental actions do not. Mixed sessions remain allowed and unknown.
Reuse existing provider-qualified session IDs, issue worktrees and commit trailers.
A prototype commit remains design; incidental tests/docs stay with the feature.
Observed review activity and machine time remain separate from issue purpose.

## Template

Extend Matt's lean issue template with these sections by default:

```md
## Parent

## What to build

## Limits

## Acceptance criteria

## Required proof

## Tests

## Docs impact

## Progress

## Blocked by
```

- `What to build`: describe the end-to-end vertical slice without duplicating the PRD.
- `Limits`: where the slice stops — named non-goals and boundaries the implementation must not cross. A named decision point ("decide with Jon") halts work there.
- `Acceptance criteria`: observable conditions for done.
- `Required proof`: the evidence that licenses a done claim, named at creation — which surface (running route, exported artifact, screenshot, test run) and which cases. Record available evidence at implementation; attach required completion proof before close.
- `Tests`: the must-test cases and their oracle surface at creation; actual verification as work proceeds. Spec-named cases are the floor — implementers add, never silently drop.
- `Docs impact`: expected doc impact at creation; applicable current engineering
  contracts and proposed contract changes; actual updates/checks as work proceeds.
- `Progress`: meaningful implementation milestones, not every tiny action.
- `Blocked by`: real issue IDs or concrete external blockers, not vague dependencies.

Link to PRDs/plans and technical design documents for durable product and implementation intent. Do not copy large PRD or design-doc sections into issues.

## Spec Detail

The planning agent writes the spec richly; implementation quality is bounded by what the issue carries. When writing or refining an issue:

- Invoke `systematic-test-design` at spec time to choose the must-test cases, partitions, and oracle surface; record them under `Tests` and `Required proof`.
- Identify applicable current engineering contracts and the clauses the slice
  preserves or changes. Keep desired guarantees in the plan/spec until accepted
  and implemented; do not publish them as current reference.
- Choose acceptance criteria selectively: each becomes an invariant that review drives toward, so an unachievable criterion makes review non-convergent. Ask of each: does it quantify over a domain we control (our files, git objects, our config) or an open one (arbitrary shell, free text, third-party behavior)? Open-domain criteria must declare their shape — enumerated forms, a fail-closed default with a named residual, or an explicit threat-model scope.
- For UI slices beyond trivial, link a mock-up or prototype; the mock-up plus `Limits` bound the build. A mock-up constrains shape only — interaction-level acceptance checks belong in `Required proof`.
- Settle the approach, or decide it with Jon, before dispatching an implementation worker; then write exact change locations: files, functions, a call-stack or algorithm skeleton. A brief that leaves a design decision to the worker is unfinished coordinator work (see the execution policy's Brief content section).
- A primary-source fact (dimensions, hardware specs, external contracts) enters the issue as a pinned, cited artifact; work derives from it, never from a re-reading or an agent's earlier restatement.
- Decisions settled in conversation are written into the issue in the same turn; a decision that lives only in chat does not exist.

## Updating Issues

- The issue body is the canonical current state. Edit it for durable updates; use comments for conversation, review discussion, or history that should not clutter current state.
- Agents may rewrite or reorganize the issue body to improve current-state clarity.
- Do not silently reduce scope or weaken acceptance criteria. Meaningful scope changes should be called out; changes that weaken the original intent need user confirmation.
- Update `Progress`, `Tests`, and `Docs impact` whenever commits or implementation discoveries change current state.
- Include commit hashes in progress updates when practical, especially for multi-commit issues.
- Update issue state after committing when recording completed work so the issue can cite the commit hash. Update before committing for claim/status changes, blockers, scope changes, or acceptance-criteria clarification.

## Claiming And Coordination

- Claim or mark an issue in progress before substantial implementation work.
- Use the repo's configured mechanism: label, project status, comment, or issue-body field.
- If no mechanism exists or the configured label/status is unavailable, update the issue body with `Status: in progress` or equivalent. Do not invent or create labels/statuses.
- Claims should include agent/session identity when available, plus a timestamp or date.
- Do not automatically clear stale claims. If an issue has an old in-progress claim and no recent activity, ask before taking it over unless the user explicitly assigns it.

Agents must not create new issue labels or tracker statuses on their own. Ask the user to create or approve missing labels/statuses.

## Implemented

- Use `📦 implemented` when identified commits claim to satisfy the issue's implementation scope. Record the commit hashes or links in the issue body before applying the label. Uncommitted work or one completed part of a larger unfinished issue does not qualify.
- This label replaces `ready-for-review`. It signals available implementation, not successful review, landing, release, or acceptance by Jon. Continue the required review and landing workflow after applying it.
- In the issue body, state the implementation claim, available test/proof results, docs impact, and what remains for review, landing, release, or consumer adoption. Distinguish pending checks from passing checks.
- Remove `📦 implemented` when closing the issue or when further implementation is required; restore it after replacement commits address that work. Remove an existing `ready-for-review` label when applying this convention to an issue.
- Jon approved the exact `📦 implemented` label. Create it when applying this workflow to a repository where it is missing; this approval does not extend to other labels or tracker statuses.
- Link affected engineering contracts and the evidence that demonstrates their
  changed or preserved obligations.
- For repositories using `wrsp-check-issue-proof`, attach evidence in the body
  or a comment on a line beginning `Proof:` followed by the evidence link or
  concrete result. Keep `## Required proof` non-empty; a bold heading alone
  does not satisfy the marker. The checker verifies presence, not sufficiency.
- Leave implemented issues open for Jon to close or explicitly ask an agent to close. The label grants no closure authority; required completion proof and review gates still apply to agent closure.

## Follow-Ups And Splits

- The feature workflow above authorizes only missing tracking issues for the requested feature work. For additional scope, agents may propose sub-issues when an issue is too large or contains separable work, but should ask before creating them unless the user explicitly asked to break work down with `to-issues` or the project workflow grants permission.
- Propose follow-up issues by default. Create them only when clearly actionable, low-controversy, and within an already-approved plan.
- Work needed to satisfy current acceptance criteria stays in the current issue. Adjacent separable work becomes a proposed follow-up or a follow-up section.

## Commits

- Include issue identifiers in implementation commit messages when an issue exists.
- Do not rely on auto-close keywords by default.
- Small process/docs maintenance may use a `no-issue:` commit-message prefix when no issue exists.
- Normal product, architecture, implementation, or multi-step process changes should have an issue or plan reference before commit.
