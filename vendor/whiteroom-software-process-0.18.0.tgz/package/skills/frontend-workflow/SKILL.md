---
name: frontend-workflow
description: Apply the user's frontend implementation and verification workflow for visible web UI changes. Use with frontend-design work, browser verification, responsive checks, Playwright UI flows, screenshots, accessibility basics, visual assets, or design-system decisions.
---

# Frontend Workflow

Use this alongside `frontend-design`. That skill supplies design judgment; this workflow supplies verification and repo-process expectations.

## Text admission

Start with the text required to identify content, operate controls, and understand
the current state. Admit additional text only when it supplies distinct information
needed for the user's task or decision.

For every secondary caption, subtitle, hint, advisory, badge, pill, or explanatory
phrase, name what the user would lose without it. "Helpful context," reassurance,
decoration, and restating the interface do not justify admission. Brevity does not
justify admission.

Text that repeats, paraphrases, or slightly qualifies information already visible
requires a concrete reason tied to preventing a likely mistake or resolving a
consequential ambiguity. Place that information where and when it matters.

Review the rendered interface by removing secondary text first. Restore only what
leaves a demonstrable gap. Apply this to read-only indicators as rigorously as prose.

## Defaults

- Use `frontend-design` for all visible web UI changes unless the change has no meaningful visual/design judgment.
- Let each repo's product, audience, and existing direction set the tone. Do not force one aesthetic across projects.
- Respect existing design systems, component libraries, tokens, spacing, typography, styling conventions, and interaction patterns.
- Build grouping and hierarchy from whitespace, type scale/weight/color, and alignment before reaching for a border or background panel. Boxes are the laziest grouping device; nested chrome (a bordered card inside a bordered section) is a defect on sight. A plain advisory should not be boxed; an actual info state may be. Consistency with an existing boxed area is not sufficient reason to add more boxes.
- Keep UI components local until reuse is clear, unless the repo already has a component system and the element obviously belongs there.
- Keep frontend components thin. Move state transitions, validators, parsers, data shaping, selection logic, workflow rules, and layout-independent interaction logic into pure TypeScript modules or framework-agnostic stores.

## Browser Verification

- After visible UI changes, verify in a browser when the app can reasonably run locally.
- Use the Codex in-app Browser by default for local verification. Use Chrome only when the task depends on logged-in sessions, cookies, extensions, or existing browser state.
- For substantial UI/layout work, check at least desktop and mobile/narrow viewports. For complex responsive layouts, also check a middle/tablet viewport.
- Check for text overflow, clipping, incoherent overlap, unreachable controls, unexpected scrollbars, missing needed scrollbars, and layout breakage during window resizing.
- Check relevant console/runtime errors. Mention console status for substantial UI work.
- Verify interactions whenever changed UI has interactive behavior. Static screenshot review is enough only for static visual changes.
- Include screenshots in the final response when seeing the result helps review: new pages, substantial layouts, responsive fixes, or design polish. For tiny UI edits, mention browser verification instead.

If the app cannot run locally, state why and use the best available substitute.

## Playwright And UI Tests

- Use Playwright heavily for user-flow and smoke testing when useful.
- Maintain small fast smoke checks for basic app usability and larger UI-flow
  suites for release readiness and high-risk workflows when the project warrants
  both. The repository's verification guide owns when each suite runs.
- During repairs, run focused tests for the changed behavior. In repositories
  with authoritative runner evidence, one coordinator runs the required full
  suites on the final committed tip; later gates consume matching records.
  Keep browser acceptance checks and missing full-suite evidence explicit.
- Small smoke suites should cover app launch, primary navigation, core routes, opening/selecting a record or data source when applicable, one representative read path, one representative edit/save/readback path once editing exists, and serious console/runtime error detection.
- Larger UI-flow suites should cover important multi-step workflows: import/dry-run/commit flows, multi-step forms, report configuration, register editing, investment views, validation/warning flows, persistence across restart, responsive checks for key screens, and workflows where user trust depends on seeing the right state over several steps.
- Add committed Playwright tests for critical, reusable, high-risk, or regression-prone UI flows. Verify every new interactive behavior somehow, but do not add a committed Playwright test for every small interaction.

## Fixtures And Privacy

- Use synthetic fixtures by default for automated UI tests.
- Use sanitized fixtures only when genuinely useful and safe.
- Real personal data may be used only for local private investigation and must never be committed, sent to CI, included in screenshots/artifacts, or written into GitHub-visible logs, issues, PRs, docs, fixtures, or examples.
- For non-trivial domains, maintain reusable synthetic fixture/data factories instead of ad hoc fixtures that drift from the domain model.

## Accessibility Baseline

- Use semantic HTML and native controls where practical so ordinary controls are keyboard-operable by default.
- Do not invent custom keyboard shortcut systems casually. Add shortcuts only when the workflow calls for them, and design them deliberately.
- Controls need accessible names; icon-only controls usually need tooltips.
- Forms need labels; focus should not be trapped or lost; hover-only interactions need another path; contrast should be reasonable.
- Do not require formal accessibility tooling by default. Add axe or similar checks only when the project explicitly adopts them.

## Visual Assets

- Prefer native web-rendered visuals for interface graphics: SVG, CSS, canvas, WebGL, charts, icons, and generated geometry.
- Use bitmap images when the UI needs an actual picture, texture, screenshot, generated illustration, product/place/person image, or asset that cannot be better represented as native web graphics.
- Do not use bitmap generation as decorative filler when SVG/CSS/canvas/WebGL would be cleaner, sharper, more responsive, or easier to maintain.
- Use the repo's existing icon library by default. If none exists, prefer a small established icon library such as Lucide for UI controls. Use custom SVG only for domain-specific, brand-specific, or unavailable symbols.

## Performance And Responsiveness

- Consider frontend performance proportionally. Watch for obvious jank, slow startup, layout thrash, excessive re-rendering, and sluggish interactions.
- For data-heavy views, canvas/WebGL, editors, large tables, imports, and financial reports, test with representative scale or fixtures.
- Desktop-first apps still need narrow-window resilience: layouts should degrade gracefully, controls should remain reachable, text should not break, and scroll behavior should make sense.

## Project AGENTS.md

For UI-heavy repos, keep a short frontend direction section in project `AGENTS.md`: product tone, design constraints, styling system, local browser URL, screenshot/capture quirks, and verification expectations. Update it only when durable conventions change.
