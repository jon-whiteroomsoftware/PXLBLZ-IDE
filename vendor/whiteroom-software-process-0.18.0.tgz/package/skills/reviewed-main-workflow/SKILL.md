---
name: reviewed-main-workflow
description: Runs a clean-main, worktree-based delivery process with serialized exact-range review, fast-forward landing, reusable approvals, and gated publication. Use when starting substantive implementation, coordinating concurrent agents, preparing or reviewing a candidate, landing work on main, or pushing a repository that adopts reviewed-main delivery.
---

# Reviewed Main Workflow

## Governing model

Keep the shared checkout clean. Local `main` is the reviewed integration line,
not an implementation workspace. Build substantive vertical slices on
short-lived worktree branches.

Implementation is concurrent. Candidate admission is serialized: rebase one
independent candidate onto the latest reviewed `main`, review its exact base and
tip, then land it immediately without rewriting the approved commits.

Repository instructions define the exact commands, receipt format, deployment
target, and issue workflow. Follow them when they differ from the examples here.

## Start a slice

1. Verify the shared checkout is clean, on `main`, and synchronized with the
   intended reviewed base.
2. Read the engineering contracts applicable to the changed seams. Record
   preserved, changed, or proposed obligations in the issue's docs impact.
3. Claim the issue before substantial work.
4. Create `<repo>-issue-<n>-<slug>` under `~/src/worktrees/` on a short-lived branch.
5. Name the task `#<issue> <short task> [<actual port>]`, omitting the port
   when no server is allocated. When a runtime coordinator exists, use its
   explicit shared or isolated profile and allocated port; use its status and
   release operations for lifecycle management.
6. Implement, test, and commit only in that worktree. Update an affected
   contract and its interface evidence in the same slice as an authorized
   behavior change.
7. Keep dependent work stacked on its unreviewed base; start unrelated work from
   the latest reviewed `main`.

If implementation begins accidentally in the shared checkout, preserve the
complete state in the correct worktree before restoring clean `main`.

## Prepare the candidate

1. Join the landing queue; do not review several independent siblings from the
   same base.
2. Rebase onto the latest reviewed `main` before review, never after approval.
3. Resolve the final base and tip commit identities.
4. Run focused verification and any repository-required fault-sensitive checks.
   Identify the required final full suites and their owner from the repository's
   verification guide. In evidence-enabled repositories, one coordinator submits
   them at the final committed tip and subsequent gates consume matching records.
   Preserve any repository requirement to complete those suites before landing.
5. Compare changed behavior with applicable contract clauses. Check that claims
   match observable evidence and that overview reference does not duplicate
   specialist obligations.
6. When `systematic-test-design` applies, supply its invariants, partitions,
   representative sequences, oracles, and residual gaps to the review packet.
7. Run the repository's explicit-range candidate review, for example:

   ```bash
   npm run review:candidate -- <base> <tip> [--test-design <json>]
   ```

When Jon explicitly directs one supported same-family reviewer for an exact
candidate, translate that instruction into the repository's explicit
model/effort pair, `--allow-same-family`, and a nonblank `--override-reason`;
do not ask for duplicate permission. The exception changes reviewer eligibility
for that candidate only. Never infer it from provider unavailability, use it for
mixed-family candidates, or carry it to a rewritten range. Proof, test, landing,
and publication gates remain independent.

A review with P0/P1 findings withholds approval for that candidate; it is a
repair loop, not a request for fresh user permission. Within the authorized
scope, fix the defect class, verify, commit a new tip, and review the replacement
exact range while the reviews are converging. Keep the failed candidate unlanded.

Classify the actual outcome rather than the word "BLOCKED" or exit code 1:
P0/P1 findings require repair; P2/P3-only findings use advisory coverage below;
permission/security denials, unusable verification, and unrecoverable failures
stop the affected action and require an exact report. Never bypass a protection
or treat missing review evidence as approval. Independent work continues unless
it shares the blocker.

## Review while UI proof is pending

When the installed repository supports deferred UI proof, follow its exact-range
review contract to start code review while captures are produced. Keep the
reviewed code commit unchanged and retain the native pending-record identity.
A pending review supplies no landing or publication approval.

Complete that record through the supported proof-only attachment path. The proof
reviewer inspects the actual capture bytes; final coverage records both review
stages. Unsupported source, policy, or test-design changes require the normal
review path. Preserve original pending records and capture identities when a
completion attempt fails. Final suites still belong to the final committed tip.

A `contract-infeasible` result requires discussion of the named requirement,
unsupported domain, and bounded rescope with Jon. It creates no approval and
does not authorize automatic rescoping or another reviewer to seek a different
judgment. Missing proof remains a prerequisite, not contract infeasibility.

## Land early, land often

An unlanded multi-commit chain is exposure: every time the reviewed base
moves, the whole chain must rebase and re-review, and a fresh full-range
review can reopen findings that earlier per-range reviews had already closed.

When repository policy records advisory-grade findings (for example P2/P3) as
non-terminal coverage, land the reviewed tip immediately on that receipt and
carry each corrective as a new, small candidate cut from the landed main.
Hold a chain unlanded only for terminal findings that block approval outright.

The clean-tail requirement belongs to publication, not landing: satisfy it
with a short corrective candidate on top of main rather than by growing the
unlanded chain through repeated corrective rounds.

## Non-convergence is a stop point

After three consecutive reviews with P0/P1 findings on one candidate lineage,
pause that candidate before a fourth review and discuss the invariant, approach,
or enforcement layer with the user. This threshold applies even when finding
counts are decreasing. Do not evade it by resetting the lineage or acknowledging
the breaker automatically.

Below that threshold, continue authorized repairs when evidence shows progress:
previous failures are covered, the underlying cause is being corrected, and
remaining findings narrow. Fewer findings alone do not prove convergence;
surface a repeated unsound approach earlier. A P2/P3-only result follows the
advisory landing path and ends the consecutive blocking streak. Repeated
advisory corrections and prerequisite/setup failures still need a progress
assessment: what changed, what remains unproved, and why another attempt should
help. When progress stalls, preserve the evidence and discuss changing approach,
narrowing scope, or deferral with the user. Existing gates remain in force;
there is no automatic waiver. Pause independent work only when it shares the
blocker.

## Land without invalidating approval

After approval, confirm `main` still equals the reviewed base and fast-forward it
to the exact reviewed tip:

```bash
git merge --ff-only <candidate-branch>
```

Do not amend, rebase, squash, cherry-pick, or create an unreviewed merge commit.
Changed commit identities or content require new review or the repository's
eligible carry path. In WRSP, later reviewer or policy changes preserve valid
native approvals under their recorded policy; never rewrite their provenance.

After landing, verify the tip is reachable from local `main`, then remove the
worktree and local branch. Update the issue with commits, tests, docs, and any
remaining risk. A candidate commit is progress, not completion: do not close
its issue until the reviewed tip is reachable from `main`.

## Publish

Inspect approval coverage before pushing when the repository provides a status
command:

```bash
npm run review:status -- <remote-base> <local-tip>
```

Pre-push must require one current approval or a contiguous approval chain for
every exact outgoing ref update. Missing, stale, rewritten, or gapped coverage
blocks publication; it does not trigger repeat review of already approved work.
After approval coverage passes, enforce the repository's publication gates.
Where the hook consumes authoritative runner evidence, collect required full
suites once for the final tip and let the hook inspect those records. Where the
hook executes full suites directly, let that gate own their execution. A changed
tip or other evidence identity requires fresh results; focused retries do not
satisfy missing full-suite evidence. Resume known runner jobs after collection
failure before submitting more work.

A failed publication check blocks the push. For a repairable test failure or
missing/stale approval, repair the cause and satisfy the required checks before
retrying publication within existing authorization. Permission/security denials,
unusable verification, and unrecoverable failures stop the affected action;
report the exact reason. Never bypass the gate or count failed checks as proof.
