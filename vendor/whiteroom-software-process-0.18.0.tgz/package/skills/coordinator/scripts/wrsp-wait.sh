#!/usr/bin/env bash
# Wait for a worker's <log>.exit completion file.
set -euo pipefail

if [[ $# -ne 1 && $# -ne 3 ]]; then
  echo 'Usage: wrsp-wait.sh <log> [--max <seconds>] (completion: <log>.exit)' >&2
  exit 64
fi
log=$1
max=540
if [[ $# -eq 3 ]]; then
  if [[ $2 != --max || ! $3 =~ ^[0-9]+$ ]]; then
    echo 'Usage: wrsp-wait.sh <log> [--max <seconds>] (completion: <log>.exit)' >&2
    exit 64
  fi
  max=$3
fi
interval=${WRSP_WAIT_INTERVAL:-5}
start_grace=${WRSP_WAIT_START_GRACE:-60}
start=$(date +%s)

if [[ ! -e $log && ! -e ${log}.pid && ! -e ${log%.log}.prompt.md ]]; then
  echo "WAIT REFUSED: no worker log, pid or prompt at $log"
  exit 1
fi

while :; do
  if [[ -e ${log}.exit ]]; then
    echo "WORKER EXITED $(cat "${log}.exit")"
    tail -n 60 "$log"
    exit 0
  fi
  if [[ -s ${log}.pid ]] && ! kill -0 "$(cat "${log}.pid")" 2>/dev/null; then
    if [[ -e ${log}.exit ]]; then continue; fi
    echo 'WORKER EXITED unknown: no EXIT line, report missing'
    if [[ -f $log ]]; then tail -n 20 "$log"; fi
    exit 4
  fi
  elapsed=$(( $(date +%s) - start ))
  if [[ ! -e ${log}.pid ]] && (( elapsed >= start_grace )); then
    echo "WORKER NOT STARTED: no pid after ${elapsed}s; check launchctl list for the job label"
    exit 5
  fi
  if (( elapsed >= max )); then
    echo "WORKER RUNNING ${elapsed}s"
    exit 2
  fi
  sleep "$interval"
done
