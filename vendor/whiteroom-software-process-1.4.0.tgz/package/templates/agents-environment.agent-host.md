- Jon reads from the laptop and cannot open Agent Mini paths. To show
  Jon a file, copy it under `~/src/wrsp-wt/briefs/<n>-<slug>/` (a plain
  `<slug>/` without an issue) and link
  `http://Agent-Mini.local:8642/files/briefs/<folder>/<file>`; never
  hand Jon a bare path.
- Jon's screenshots reach Agent Mini only when Jon sends them, into
  `~/inbox/screenshots/`; when one is missing, ask Jon to send it.
