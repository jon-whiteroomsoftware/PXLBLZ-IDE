#!/usr/bin/env bash
set -euo pipefail

usage() {
  printf '%s\n' 'Usage: wrsp-telemetry.sh <install|upgrade|rollback [name…]|status|render|verify|print-load|print-restart> [--home DIR] [--cache DIR] [--versions FILE] [--offline] [--ledger-home DIR] [--port-base N] [--grafana-bind ADDR]' >&2
  exit 64
}

field() {
  /usr/bin/plutil -extract "$1" raw -o - "$VERSIONS"
}

current_target() {
  local link="$SHARE/$1-current"
  if [[ -L "$link" ]]; then
    basename "$(readlink "$link")"
  fi
}

switch_target() {
  local name="$1" target="$2"
  rm -f "$SHARE/$name-current.new"
  ln -s "$target" "$SHARE/$name-current.new"
  mv -fh "$SHARE/$name-current.new" "$SHARE/$name-current"
}

# Prints each path part $1 must hold under $2 and does not: its executable
# binary, then its manifest "require" paths (#209: Grafana's bundled plugins).
missing_paths() {
  local i="$1" dir="$2" binary count j path
  binary=$(field "parts.$i.binary")
  if [[ ! -f "$dir/$binary" || ! -x "$dir/$binary" ]]; then printf '%s\n' "$binary"; fi
  count=$(field "parts.$i.require" 2>/dev/null) || count=0
  for ((j = 0; j < count; j++)); do
    path=$(field "parts.$i.require.$j")
    if [[ ! -e "$dir/$path" ]]; then printf '%s\n' "$path"; fi
  done
}

install_parts() {
  local i name version file url expected actual target tmp unpack strip old missing repair
  for ((i = 0; i < COUNT; i++)); do
    name=$(field "parts.$i.name")
    version=$(field "parts.$i.version")
    file=$(field "parts.$i.file")
    expected=$(field "parts.$i.sha256")
    if [[ ! -f "$CACHE/$file" ]]; then
      if [[ "$OFFLINE" == true ]]; then
        printf 'wrsp-telemetry: %s is not in %s (--offline)\n' "$file" "$CACHE" >&2
        exit 2
      fi
      url=$(field "parts.$i.url")
      mkdir -p "$CACHE"
      curl -fsSL -o "$CACHE/$file.part" "$url"
      mv "$CACHE/$file.part" "$CACHE/$file"
    fi
    actual=$(shasum -a 256 "$CACHE/$file")
    actual=${actual%% *}
    if [[ "$actual" != "$expected" ]]; then
      printf 'wrsp-telemetry: sha256 mismatch for %s: expected %s, got %s\n' "$file" "$expected" "$actual" >&2
      exit 3
    fi
    target="$name-$version"
    repair=false
    if [[ -e "$SHARE/$target.repairing" ]]; then
      printf 'wrsp-telemetry: %s has an interrupted repair; re-extracting %s\n' "$target" "$file" >&2
      repair=true
    elif [[ -e "$SHARE/$target" ]]; then
      # An installed part that lost files (#209: Grafana moved its bundled
      # plugins out on a runtime update) is re-extracted from the checked artifact.
      missing=$(missing_paths "$i" "$SHARE/$target")
      if [[ -n "$missing" ]]; then
        printf 'wrsp-telemetry: %s is missing %s; re-extracting %s\n' "$target" "${missing%%$'\n'*}" "$file" >&2
        repair=true
      fi
    fi
    if [[ ! -e "$SHARE/$target" || "$repair" == true ]]; then
      tmp="$SHARE/$target.tmp"
      rm -rf "$tmp"
      unpack=$(field "parts.$i.unpack")
      strip=$(field "parts.$i.strip")
      mkdir -p "$tmp"
      if [[ "$unpack" == tar ]]; then
        tar -xzf "$CACHE/$file" -C "$tmp" --strip-components "$strip"
      else
        unzip -q "$CACHE/$file" -d "$tmp"
      fi
      missing=$(missing_paths "$i" "$tmp")
      if [[ -n "$missing" ]]; then
        rm -rf "$tmp"
        printf 'wrsp-telemetry: %s missing after unpacking %s\n' "${missing%%$'\n'*}" "$file" >&2
        exit 4
      fi
      if [[ "$repair" == true && -e "$SHARE/$target" ]]; then
        # Sync in place so <name>-current never names a missing directory; the
        # marker makes the next run redo a sync that was interrupted.
        : > "$SHARE/$target.repairing"
        rsync -a --delete "$tmp/" "$SHARE/$target/"
        rm -rf "$tmp"
        rm -f "$SHARE/$target.repairing"
        printf '%s %s repaired\n' "$name" "$version"
      elif [[ "$repair" == true ]]; then
        mv "$tmp" "$SHARE/$target"
        rm -f "$SHARE/$target.repairing"
        printf '%s %s repaired\n' "$name" "$version"
      else
        mv "$tmp" "$SHARE/$target"
      fi
    fi
    old=$(current_target "$name")
    if [[ "$old" != "$target" ]]; then
      if [[ -n "$old" ]]; then
        printf '%s\n' "$old" > "$SHARE/$name.previous"
      fi
      switch_target "$name" "$target"
    fi
    printf '%s %s current\n' "$name" "$version"
  done
}

rollback_parts() {
  local requested i name found selected old previous
  local names=() chosen=()
  # Validate the complete request before changing any link or history.
  for ((i = 0; i < COUNT; i++)); do
    names+=("$(field "parts.$i.name")")
  done
  for requested in "$@"; do
    found=false
    for name in "${names[@]}"; do
      if [[ "$requested" == "$name" ]]; then found=true; fi
    done
    [[ "$found" == true ]] || usage
  done
  for name in "${names[@]}"; do
    selected=false
    if [[ "$#" == 0 ]]; then
      if [[ -f "$SHARE/$name.previous" ]]; then selected=true; fi
    else
      for requested in "$@"; do
        if [[ "$requested" == "$name" ]]; then selected=true; fi
      done
    fi
    if [[ "$selected" == true ]]; then
      if [[ ! -f "$SHARE/$name.previous" ]]; then
        printf 'wrsp-telemetry: no previous version for %s\n' "$name" >&2
        exit 5
      fi
      chosen+=("$name")
    fi
  done
  if [[ "${#chosen[@]}" == 0 ]]; then
    printf 'wrsp-telemetry: no previous version for any part\n' >&2
    exit 5
  fi
  for name in "${names[@]}"; do
    selected=false
    for requested in "${chosen[@]}"; do
      if [[ "$requested" == "$name" ]]; then selected=true; fi
    done
    if [[ "$selected" == true ]]; then
      previous=$(<"$SHARE/$name.previous")
      old=$(current_target "$name")
      switch_target "$name" "$previous"
      printf '%s\n' "$old" > "$SHARE/$name.previous"
      printf '%s %s current\n' "$name" "$previous"
    else
      printf '%s unchanged\n' "$name"
    fi
  done
}

status_parts() {
  local i name current previous missing damaged
  for ((i = 0; i < COUNT; i++)); do
    name=$(field "parts.$i.name")
    current=$(current_target "$name")
    previous=none
    if [[ -f "$SHARE/$name.previous" ]]; then previous=$(<"$SHARE/$name.previous"); fi
    damaged=
    if [[ "$current" == "$name-$(field "parts.$i.version")" ]]; then
      missing=$(missing_paths "$i" "$SHARE/$current")
      if [[ -n "$missing" ]]; then damaged=" missing=${missing%%$'\n'*}"; fi
    fi
    printf '%s current=%s previous=%s%s\n' "$name" "${current:-none}" "$previous" "$damaged"
  done
}

check_tokens() {
  if LC_ALL=C grep -Eq '@@[A-Z_]+@@' "$1"; then
    rm -f "$1"
    printf 'wrsp-telemetry: unreplaced token in %s\n' "$2" >&2
    exit 8
  fi
}

render_file() {
  local source="$1" output="$2" mode="$3" token value tmp lint_output
  local expressions=()
  for token in OTLP_PORT VLOGS_PORT VMETRICS_PORT SELF_METRICS_PORT GRAFANA_PORT; do
    expressions+=(-e "s|\"@@${token}@@\"|${!token}|g")
  done
  for token in HOME SHARE_DIR CONFIG_DIR STATE_DIR LOG_DIR LEDGER_HOME ARCHIVE_DIR OTLP_PORT VLOGS_PORT VMETRICS_PORT SELF_METRICS_PORT GRAFANA_PORT GRAFANA_BIND TIMEZONE; do
    # HOME is the render target, not the invoking shell's environment.
    if [[ "$token" == HOME ]]; then value="$RENDER_HOME"; else value="${!token}"; fi
    if [[ "$mode" == 0644 ]]; then
      value=${value//&/\&amp;}
      value=${value//</\&lt;}
      value=${value//>/\&gt;}
      value=${value//\"/\&quot;}
      value=${value//\'/\&apos;}
    fi
    value=${value//\\/\\\\}
    value=${value//&/\\&}
    expressions+=(-e "s|@@${token}@@|${value}|g")
  done
  mkdir -p -m 0700 "$(dirname "$output")"
  tmp=$(mktemp "$output.tmp.XXXXXX")
  sed "${expressions[@]}" "$source" > "$tmp"
  check_tokens "$tmp" "$output"
  chmod "$mode" "$tmp"
  if [[ "$mode" == 0644 ]]; then
    if ! lint_output=$(plutil -lint "$tmp" 2>&1); then
      rm -f "$tmp"
      printf '%s\n' "$lint_output" >&2
      exit 9
    fi
  fi
  mv -f "$tmp" "$output"
  printf 'rendered %s\n' "$output"
}

copy_dashboard() {
  local source="$1" output="$2" tmp
  tmp=$(mktemp "$output.tmp.XXXXXX")
  cat "$source" > "$tmp"
  check_tokens "$tmp" "$output"
  chmod 0600 "$tmp"
  mv -f "$tmp" "$output"
  printf 'rendered %s\n' "$output"
}

render_config() {
  local i name password="$CONFIG_DIR/grafana-admin-password" part file
  for ((i = 0; i < COUNT; i++)); do
    name=$(field "parts.$i.name")
    if [[ ! -d "$SHARE/$name-current" ]]; then
      printf 'wrsp-telemetry: %s is not installed under %s; run install\n' "$name" "$SHARE" >&2
      exit 6
    fi
  done
  if [[ ! -s "$password" || "$(stat -f %Lp "$password" 2>/dev/null)" != 600 ]]; then
    printf 'wrsp-telemetry: %s must exist, be nonempty and have mode 0600\n' "$password" >&2
    exit 7
  fi
  local localtime="${WRSP_TELEMETRY_LOCALTIME:-/etc/localtime}" link
  link=$(readlink "$localtime" 2>/dev/null || true)
  TIMEZONE=${link##*/zoneinfo/}
  if [[ -z "$link" || "$TIMEZONE" == "$link" || -z "$TIMEZONE" ]]; then
    printf 'wrsp-telemetry: cannot read the host timezone from %s\n' "$localtime" >&2
    exit 11
  fi
  umask 077
  mkdir -p -m 0700 "$CONFIG_DIR" "$LOG_DIR/grafana" "$ARCHIVE_DIR"
  for part in victoria-logs victoria-metrics otelcol grafana; do
    mkdir -p -m 0700 "$STATE_DIR/$part"
  done
  for file in otelcol.yaml otelcol-replay.yaml grafana/grafana.ini grafana/provisioning/datasources/wrsp.yaml grafana/provisioning/dashboards/wrsp.yaml; do
    render_file "$TEMPLATES/telemetry/$file" "$CONFIG_DIR/$file" 0600
  done
  mkdir -p -m 0700 "$CONFIG_DIR/grafana/provisioning/plugins" "$CONFIG_DIR/grafana/provisioning/alerting" "$CONFIG_DIR/grafana/dashboards"
  rm -f "$CONFIG_DIR/grafana/dashboards/"*.json
  copy_dashboard "$TEMPLATES/telemetry/grafana/dashboards/README.md" "$CONFIG_DIR/grafana/dashboards/README.md"
  for file in "$TEMPLATES/telemetry/grafana/dashboards/"*.json; do
    [[ -f "$file" ]] || continue
    copy_dashboard "$file" "$CONFIG_DIR/grafana/dashboards/$(basename "$file")"
  done
  for part in victoria-logs victoria-metrics otelcol grafana; do
    file="com.whiteroom.wrsp-$part.plist"
    render_file "$TEMPLATES/launchd/$file" "$CONFIG_DIR/launchd/$file" 0644
  done
  file=$(mktemp "$CONFIG_DIR/ports.env.tmp.XXXXXX")
  for name in OTLP_PORT VLOGS_PORT VMETRICS_PORT SELF_METRICS_PORT GRAFANA_PORT GRAFANA_BIND; do
    printf '%s=%s\n' "$name" "${!name}" >> "$file"
  done
  check_tokens "$file" "$CONFIG_DIR/ports.env"
  chmod 0600 "$file"
  mv -f "$file" "$CONFIG_DIR/ports.env"
  printf 'rendered %s\n' "$CONFIG_DIR/ports.env"
}

verify_parts() {
  local timeout=${WRSP_TELEMETRY_VERIFY_TIMEOUT-60} interval=${WRSP_TELEMETRY_VERIFY_INTERVAL-2}
  local name value host uid start i output state pid last body healthy remaining delay
  local tab=$'\t'
  local parts=(victoria-logs victoria-metrics otelcol grafana)
  local urls reasons pids
  [[ "$timeout" =~ ^[0-9]+$ && "$interval" =~ ^[0-9]+$ ]] || usage
  if [[ ! -f "$CONFIG_DIR/ports.env" ]]; then
    printf '%s\n' 'wrsp-telemetry: missing rendered ports.env; run render' >&2
    exit 6
  fi
  # Only rendered values determine the endpoints; never execute this file.
  OTLP_PORT='' VLOGS_PORT='' VMETRICS_PORT='' SELF_METRICS_PORT='' GRAFANA_PORT='' GRAFANA_BIND=''
  while IFS== read -r name value || [[ -n "$name" ]]; do
    case "$name" in
      OTLP_PORT|VLOGS_PORT|VMETRICS_PORT|SELF_METRICS_PORT|GRAFANA_PORT|GRAFANA_BIND)
        printf -v "$name" '%s' "$value" ;;
    esac
  done < "$CONFIG_DIR/ports.env"
  case "$GRAFANA_BIND" in
    ''|0.0.0.0) host=127.0.0.1 ;;
    ::) host='[::1]' ;;
    *:*) host="[$GRAFANA_BIND]" ;;
    *) host="$GRAFANA_BIND" ;;
  esac
  urls=("http://127.0.0.1:$VLOGS_PORT/health" "http://127.0.0.1:$VMETRICS_PORT/health"
    "http://127.0.0.1:$SELF_METRICS_PORT/metrics" "http://$host:$GRAFANA_PORT/api/health")
  reasons=('' '' '' '')
  pids=('' '' '' '')
  uid=$(id -u)
  start=$SECONDS
  while :; do
    healthy=0
    for ((i = 0; i < ${#parts[@]}; i++)); do
      if [[ -n "${pids[$i]}" ]]; then
        healthy=$((healthy + 1))
        continue
      fi
      if ! output=$(launchctl print "gui/$uid/com.whiteroom.wrsp-${parts[$i]}" 2>/dev/null); then
        reasons[$i]='launchd job not loaded'
        continue
      fi
      state=$(printf '%s\n' "$output" | sed -nE "/^${tab}state = /{s/^${tab}state = //;p;q;}")
      pid=$(printf '%s\n' "$output" | sed -nE "/^${tab}pid = [0-9]+$/{s/^${tab}pid = //;p;q;}")
      if [[ "$state" != running || -z "$pid" ]]; then
        reasons[$i]="launchd state ${state:-unknown}"
        last=$(printf '%s\n' "$output" | sed -nE "/^${tab}last exit code = -?[0-9]+$/{s/^${tab}//;p;q;}")
        if [[ -n "$last" ]]; then reasons[$i]="${reasons[$i]}; $last"; fi
        continue
      fi
      if ! body=$(curl -fsS --max-time 3 "${urls[$i]}" 2>/dev/null); then
        reasons[$i]="no response from ${urls[$i]}"
        continue
      fi
      reasons[$i]="unexpected response from ${urls[$i]}"
      [[ -n "$body" ]] || continue
      case "${parts[$i]}" in
        victoria-logs|victoria-metrics)
          [[ "$body" =~ ^[[:space:]]*OK[[:space:]]*$ ]] || continue ;;
        otelcol) [[ "$body" == *otelcol_* ]] || continue ;;
        grafana) printf '%s\n' "$body" | grep -Eq '"database"[[:space:]]*:[[:space:]]*"ok"' || continue ;;
      esac
      pids[$i]="$pid"
      healthy=$((healthy + 1))
    done
    if ((healthy == ${#parts[@]})); then
      for ((i = 0; i < ${#parts[@]}; i++)); do
        printf 'verified %s pid=%s %s\n' "${parts[$i]}" "${pids[$i]}" "${urls[$i]}"
      done
      return
    fi
    remaining=$((10#$timeout - (SECONDS - start)))
    if ((remaining <= 0)); then break; fi
    delay=$((10#$interval))
    if ((delay > remaining)); then delay=$remaining; fi
    if ((delay > 0)); then sleep "$delay"; fi
  done
  for ((i = 0; i < ${#parts[@]}; i++)); do
    if [[ -z "${pids[$i]}" ]]; then
      printf 'wrsp-telemetry: %s not healthy: %s\n' "${parts[$i]}" "${reasons[$i]}" >&2
    fi
  done
  exit 10
}

print_commands() {
  local command="$1" part label
  # Validate the full set before printing any commands.
  for part in victoria-logs victoria-metrics otelcol grafana; do
    if [[ ! -f "$CONFIG_DIR/launchd/com.whiteroom.wrsp-$part.plist" ]]; then
      printf 'wrsp-telemetry: missing rendered plist for %s; run render\n' "$part" >&2
      exit 6
    fi
  done
  for part in victoria-logs victoria-metrics otelcol grafana; do
    label="com.whiteroom.wrsp-$part"
    if [[ "$command" == print-load ]]; then
      printf 'cp %q ~/Library/LaunchAgents/%s.plist\n' "$CONFIG_DIR/launchd/$label.plist" "$label"
      printf 'launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/%s.plist\n' "$label"
    else
      printf 'launchctl kickstart -k gui/$(id -u)/%s\n' "$label"
    fi
  done
  printf 'wrsp-telemetry.sh verify'
  if [[ "$RENDER_HOME" != "$HOME" ]]; then printf ' --home %q' "$RENDER_HOME"; fi
  printf '\n'
}

main() {
  [[ "$#" -gt 0 ]] || usage
  local command="$1" home="$HOME" link installed=false
  local names=()
  shift
  case "$command" in install|upgrade|rollback|status|render|verify|print-load|print-restart) ;; *) usage ;; esac
  LEDGER_HOME=''
  OTLP_PORT=4318 VLOGS_PORT=9428 VMETRICS_PORT=8428 SELF_METRICS_PORT=8888 GRAFANA_PORT=3000
  # --grafana-bind is the admin escape hatch for a LAN bind.
  GRAFANA_BIND=127.0.0.1
  TEMPLATES=${WRSP_TELEMETRY_TEMPLATES:-"$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"}
  CACHE=''
  VERSIONS="$(dirname "${BASH_SOURCE[0]}")/versions.json"
  OFFLINE=false
  while [[ "$#" -gt 0 ]]; do
    case "$1" in
      --home|--cache|--versions|--ledger-home|--port-base|--grafana-bind)
        [[ "$#" -ge 2 && -n "$2" && "$2" != --* ]] || usage
        case "$1" in
          --home) home="$2" ;;
          --cache) CACHE="$2" ;;
          --versions) VERSIONS="$2" ;;
          --ledger-home) LEDGER_HOME="$2" ;;
          --grafana-bind) GRAFANA_BIND="$2" ;;
          --port-base)
            [[ "$2" =~ ^[0-9]+$ && "${#2}" -le 5 ]] || usage
            OTLP_PORT=$((10#$2))
            ((OTLP_PORT >= 1 && OTLP_PORT <= 65531)) || usage
            VLOGS_PORT=$((OTLP_PORT + 1))
            VMETRICS_PORT=$((OTLP_PORT + 2))
            SELF_METRICS_PORT=$((OTLP_PORT + 3))
            GRAFANA_PORT=$((OTLP_PORT + 4))
            ;;
        esac
        shift 2
        ;;
      --offline) OFFLINE=true; shift ;;
      -*) usage ;;
      *)
        [[ "$command" == rollback ]] || usage
        names+=("$1")
        shift
        ;;
    esac
  done
  CACHE=${CACHE:-"$home/.cache/wrsp/telemetry"}
  SHARE="$home/.local/share/wrsp/telemetry"
  RENDER_HOME="$home"
  SHARE_DIR="$SHARE"
  CONFIG_DIR="$home/.config/wrsp/telemetry"
  STATE_DIR="$home/.local/state/wrsp/telemetry"
  LOG_DIR="$home/Library/Logs/wrsp/telemetry"
  LEDGER_HOME=${LEDGER_HOME:-"$home/.local/state/wrsp/runner-mirror"}
  ARCHIVE_DIR="$LEDGER_HOME/telemetry"
  COUNT=$(field parts)
  case "$command" in
    install) install_parts ;;
    upgrade)
      for link in "$SHARE/"*-current; do
        if [[ -L "$link" ]]; then installed=true; break; fi
      done
      if [[ "$installed" != true ]]; then
        printf 'wrsp-telemetry: nothing installed under %s; run install\n' "$SHARE" >&2
        exit 6
      fi
      install_parts
      ;;
    rollback) rollback_parts ${names[@]+"${names[@]}"} ;;
    status) status_parts ;;
    render) render_config ;;
    verify) verify_parts ;;
    print-load|print-restart) print_commands "$command" ;;
  esac
  case "$command" in
    install|upgrade|rollback)
      printf '%s\n' 'wrsp-telemetry: run render, then print-restart, then verify'
      ;;
  esac
}

if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
  main "$@"
fi
