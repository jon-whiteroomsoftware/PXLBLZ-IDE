This directory holds the view JSON files (#128 lane L).
Copied verbatim by render.
