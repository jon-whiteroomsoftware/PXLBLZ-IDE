#!/bin/sh
# WRSP #171: provision node_modules in a Claude-made worktree at session start,
# because a worktree under .claude/worktrees/ without node_modules resolves the
# main checkout's. Clones the main checkout's node_modules and runs npm ci when
# the lockfiles differ or the clone does not match the lockfile. Then clones
# dist, followed by missing git hooks, from the main checkout; husky is only
# a fallback when no main hooks copy exists. Never writes git config.
# Never blocks a session: every path exits 0.

input=$(cat)
cwd=
if command -v jq >/dev/null 2>&1; then
  cwd=$(printf '%s' "$input" | jq -r '.cwd // empty' 2>/dev/null)
fi
[ -n "$cwd" ] || cwd=$PWD

top=$(git -C "$cwd" rev-parse --show-toplevel 2>/dev/null) || exit 0
case $top in
  */.claude/worktrees/*) ;;
  *) exit 0 ;;
esac

common=$(git -C "$top" rev-parse --path-format=absolute --git-common-dir 2>/dev/null) || exit 0
main=$(dirname "$common")
[ "$main" = "$top" ] && exit 0

# Main's lockfile can move past its installed node_modules (a pull without
# npm ci), so a clone counts only when every installed package.json carries
# the version its lockfile entry names. The hidden lockfile lists every installed
# package, so a package the lockfile no longer names also fails the check (#171).
clone_matches_lock() {
  node -e '
const fs = require("fs")
const path = require("path")
const top = process.argv[1]
const lock = JSON.parse(fs.readFileSync(path.join(top, "package-lock.json"), "utf8"))
const packages = lock && lock.packages
if (!packages || typeof packages !== "object") process.exit(1)
let hidden
try {
  hidden = JSON.parse(fs.readFileSync(path.join(top, "node_modules", ".package-lock.json"), "utf8"))
} catch {
  process.exit(1)
}
const installedPackages = hidden && hidden.packages
if (!installedPackages || typeof installedPackages !== "object") process.exit(1)
for (const [key, entry] of Object.entries(installedPackages)) {
  if (!Object.hasOwn(packages, key)) process.exit(1)
  const locked = packages[key]
  if (entry.link !== true && locked.link !== true && entry.version !== locked.version) process.exit(1)
}
for (const [key, entry] of Object.entries(packages)) {
  if (key.includes("node_modules/") && entry.link !== true && entry.optional !== true &&
      !Object.hasOwn(installedPackages, key)) process.exit(1)
}
for (const [key, entry] of Object.entries(packages)) {
  if (!key.includes("node_modules/") || entry.link === true) continue
  let installed
  try {
    installed = JSON.parse(fs.readFileSync(path.join(top, key, "package.json"), "utf8"))
  } catch (error) {
    if (entry.optional === true && error.code === "ENOENT") continue
    process.exit(1)
  }
  if (!installed || installed.version !== entry.version) process.exit(1)
}
' "$top"
}

provision_deps() {
  [ -f "$top/package.json" ] || return
  if [ -e "$top/node_modules" ] || [ -L "$top/node_modules" ]; then return; fi

  log=$(mktemp "${TMPDIR:-/tmp}/wrsp-worktree-deps.XXXXXX") || return

  if [ -d "$main/node_modules" ] && [ ! -L "$main/node_modules" ]; then
    if cp -Rc "$main/node_modules" "$top/node_modules" >>"$log" 2>&1; then
      if cmp -s "$main/package-lock.json" "$top/package-lock.json"; then
        if clone_matches_lock >>"$log" 2>&1; then
          rm -f "$log"
          echo "WRSP worktree-deps (#171): cloned node_modules from $main; the lockfiles match."
          return
        fi
        rm -rf "$top/node_modules"
      fi
    else
      rm -rf "$top/node_modules"
    fi
  fi

  if (cd "$top" && npm ci --prefer-offline) >>"$log" 2>&1; then
    rm -f "$log"
    echo "WRSP worktree-deps (#171): ran npm ci --prefer-offline in $top."
  else
    echo "WRSP worktree-deps (#171): could not provision node_modules in $top (log: $log). Node will resolve $main/node_modules instead. Remedy: cd $top && cp -Rc $main/node_modules node_modules && npm ci --prefer-offline"
  fi
}

provision_dist() {
  [ -f "$top/package.json" ] || return
  if [ -e "$top/dist" ] || [ -L "$top/dist" ]; then return; fi
  [ -d "$main/dist" ] && [ ! -L "$main/dist" ] || return
  if cp -Rc "$main/dist" "$top/dist" 2>/dev/null; then
    echo "WRSP worktree-deps (#273): cloned dist from $main."
  else
    rm -rf "$top/dist"
    echo "WRSP worktree-deps (#273): could not clone dist from $main. Remedy: cd $top && npm run build"
  fi
}

provision_hooks() {
  configured=$(git -C "$top" config --get core.hooksPath)
  [ -n "$configured" ] || return
  case $configured in
    "$main"/*/_) rel=${configured#"$main"/} ;;
    /*) return ;;
    */_) rel=$configured ;;
    *) return ;;
  esac
  hooks=$top/$rel
  [ -d "$hooks" ] && return
  if [ -d "$main/$rel" ] && [ ! -L "$main/$rel" ]; then
    if mkdir -p "$(dirname "$hooks")" && cp -Rc "$main/$rel" "$hooks" 2>/dev/null; then
      echo "WRSP worktree-deps (#273): cloned git hooks from $main/$rel."
      return
    fi
    rm -rf "$hooks"
  else
    case $configured in
      /*) ;;
      *) if [ -x "$top/node_modules/.bin/husky" ]; then provision_husky; return; fi ;;
    esac
  fi
  echo "WRSP worktree-deps (#273): git hooks are missing in $top: no $main/$rel to clone and no husky binary; commits there run no hooks. Remedy: cd $top && npx husky"
}

provision_husky() {
  husky_dir=${configured%/_}

  hooklog=$(mktemp "${TMPDIR:-/tmp}/wrsp-worktree-hooks.XXXXXX") || return
  if (cd "$top" && ./node_modules/.bin/husky "$husky_dir") >>"$hooklog" 2>&1 && [ -d "$hooks" ] &&
    [ "$(git -C "$top" config --get core.hooksPath)" = "$configured" ]; then
    rm -f "$hooklog"
    echo "WRSP worktree-deps (#171): installed git hooks with husky in $top."
  else
    echo "WRSP worktree-deps (#171): could not install git hooks in $top (log: $hooklog); commits there run no hooks. Remedy: cd $top && npx --no-install husky"
  fi
}

provision_deps
provision_dist
provision_hooks
exit 0
