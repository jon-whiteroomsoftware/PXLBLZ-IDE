#!/bin/sh
# WRSP #232 session role context; the logic lives in the helper.
input=$(cat)
if command -v node >/dev/null 2>&1 && [ -f "$HOME/.agents/hooks/session-role.mjs" ]; then
  printf '%s' "$input" | WRSP_SESSION_ROLE_HELPER="$HOME/.agents/hooks/session-role.mjs" \
    node --input-type=module -e 'import { pathToFileURL } from "node:url"; const m = await import(pathToFileURL(process.env.WRSP_SESSION_ROLE_HELPER).href); m.main(process.argv.slice(1))' -- session-start "$@" 2>/dev/null
fi
exit 0
