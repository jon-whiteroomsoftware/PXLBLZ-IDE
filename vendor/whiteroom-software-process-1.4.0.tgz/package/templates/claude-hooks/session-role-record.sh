#!/bin/sh
# WRSP #263 session-role record: records only; prints nothing and gates nothing.
input=$(cat)
if command -v node >/dev/null 2>&1 && [ -f "$HOME/.agents/hooks/session-role.mjs" ]; then
  printf '%s' "$input" | node "$HOME/.agents/hooks/session-role.mjs" record "$@" >/dev/null 2>&1
fi
exit 0
