#!/bin/sh
# WRSP #178 worker limits and #197 role gate; the logic lives in the helper.
input=$(cat)
if command -v node >/dev/null 2>&1 && [ -f "$HOME/.agents/hooks/session-role.mjs" ]; then
  printf '%s' "$input" | WRSP_SESSION_ROLE_HELPER="$HOME/.agents/hooks/session-role.mjs" \
    node --input-type=module -e 'import { pathToFileURL } from "node:url"; const m = await import(pathToFileURL(process.env.WRSP_SESSION_ROLE_HELPER).href); m.main(process.argv.slice(1))' -- gate "$@"
  status=$?
  [ "$status" -eq 0 ] && exit "$status"
fi

case "${WRSP_ROLE-}" in
  ''|developer|eng-lead|principal-engineer|ux-principal)
    printf '%s\n' '{"systemMessage":"The WRSP role gate helper is unavailable (node or ~/.agents/hooks/session-role.mjs), so this call ran without the role gate; pre-push still guards publication. Run wrsp-agents install to restore it. (WRSP #244)"}'
    ;;
  *)
    printf '%s\n' '{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"deny","permissionDecisionReason":"The WRSP role gate helper is unavailable (node or ~/.agents/hooks/session-role.mjs) and WRSP_ROLE names a restricted or unknown role, so every gated call is refused. Run wrsp-agents install to restore the helper. (WRSP #244)"}}'
    ;;
esac
exit 0
