# Worker progress signals shared by launch-worker.sh and wrsp-wait.sh (WRSP #248).
# Sourced, not executed. A started worker is presumed not working until its
# CLI's session record holds a model-output line; <log>.session-record names
# that record.

# Prints the record named by <log>.session-record when it is an existing regular file.
worker_record_path() { # worker_record_path <log>
  local pointer=$1.session-record record
  [[ -f $pointer ]] || return 1
  record=$(<"$pointer")
  [[ -n $record && -f $record ]] || return 1
  printf '%s\n' "$record"
}

# Prints the file named by <log>.progress when it is an existing regular file.
worker_progress_path() { # worker_progress_path <log>
  local pointer=$1.progress record
  [[ -f $pointer ]] || return 1
  record=$(<"$pointer")
  [[ -n $record && -f $record ]] || return 1
  printf '%s\n' "$record"
}

worker_progress_produced() { # worker_progress_produced <file>
  [[ -s $1 ]]
}

# Claude: an assistant line. Codex: a response_item whose role is not user,
# developer or system; reasoning and tool calls carry no role and count. A
# partial trailing line or a non-JSON line is skipped.
worker_produced() { # worker_produced <record>
  [[ -f $1 ]] || return 1
  jq -R -n -e 'any(inputs | fromjson? | objects; .type == "assistant" or (.type == "response_item" and ((.payload.role? // "") as $r | ["user","developer","system"] | index($r) | not)))' "$1" >/dev/null 2>&1
}

worker_record_size() { # worker_record_size <record>
  stat -f %z "$1" 2>/dev/null || echo 0
}
