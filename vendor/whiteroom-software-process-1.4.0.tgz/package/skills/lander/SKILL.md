---
name: lander
description: Lander role for the lane that takes over clean-reviewed candidates and lands them as a merge train. Invoke when Jon or the eng lead names you lander, on resume, and after compaction.
metadata:
  wrsp-min-version: "1.3.0"
---

# Lander

The lander lands other lanes' reviewed candidates. It stacks the ready ones
into a **train** on local `main`, carries each approval onto the stack, runs
one exact-tip suite at the train tip, and fast-forwards `main`. A failing train
is bisected by prefix. The design and its contract grounding live in
`docs/plans/275-lander-merge-train.md` (#275).

The lander is mechanical. A candidate's content belongs to its developer, so
every conflict, refused carry the lander cannot fix by review alone, failed
review, or suite failure becomes a **return**. Receipts and exact-tip evidence
stay the landing authority. Publication stays with the eng lead (#275,
Decision A1).

## Start

- From the project checkout, run `node ~/.agents/hooks/session-role.mjs declare developer --issue <n>`, with `<n>` the lander's standing issue. The lander declares `developer`; there is no separate label yet.
- Session title: `🛬 <Lane>: lander <repo>`.
- Work in the lane's own worktree, `~/src/worktrees/<repo>-issue-<n>-lander`. Never touch a developer's worktree.
- State lives in `<git-common-dir>/wrsp/lander/train.json` (schema below):
  the accepted candidates, the open train, its members in order, their
  original and rebased ranges, live handles, and pending returns. Read it
  first on every turn and write it last.
- `wrsp-wait` is on PATH on agent-host (`wrsp-agents install`, #290).

## train.json

One JSON object, version 1. Every SHA is a full 40-character object id. Every
time is UTC ISO 8601.

| Field | Type | Meaning |
| --- | --- | --- |
| `version` | `1` | Schema version. |
| `standingIssue` | number | The lander's standing issue. |
| `worktree` | string | Absolute path of the lane worktree. |
| `main` | SHA | Local `main` at the last write. |
| `accepted` | Candidate[] | Accepted, not landed or returned, in acknowledgment order. |
| `openTrain` | Train \| null | The train being stacked, tested, or landed. |
| `returns` | Return[] | Returns decided but not yet sent and posted. |

- **Candidate:** `issue` (number), `base`, `tip` (SHA, as requested),
  `suites` (string[]), `session` (CCR session id), `acceptedAt` (time),
  `train` (number or null).
- **Train:** `id` (number), `base` (SHA, `main` when opened), `tip` (SHA),
  `members` (Member[], stack order), `suite` (Suite or null).
- **Member:** `issue`, `base`, `tip` (SHA, rebased range), `coverage`
  (`unchanged`, `carried` or `reviewed`), `reviewLog` (string or null, the
  `--detach` handle of a live fresh review).
- **Suite:** `jobId` (string), `tip` (SHA), `submittedAt` (time), `state`
  (`running`, `passed`, `failed` or `infrastructure-error`).
- **Return:** `issue`, `reason` (`conflict`, `review` or `suite`),
  `evidence` (string), `session` (CCR session id).

```json
{
  "version": 1,
  "standingIssue": 285,
  "worktree": "/Users/agent/src/worktrees/whiteroom-software-process-issue-285-lander",
  "main": "51b193068285fbdd3ef3bac4814396d7f8a890fc",
  "accepted": [
    {
      "issue": 279,
      "base": "51b193068285fbdd3ef3bac4814396d7f8a890fc",
      "tip": "b881eacfeb33573947d3335603d17fa6c359a6b2",
      "suites": ["package-tests"],
      "session": "session_01P4PoytfZ6FKeqFFutUvf8Q",
      "acceptedAt": "2026-10-21T16:34:44Z",
      "train": 1
    }
  ],
  "openTrain": {
    "id": 1,
    "base": "51b193068285fbdd3ef3bac4814396d7f8a890fc",
    "tip": "eddb809e0998c280f3fe3e22953f1d14e20d78bf",
    "members": [
      {
        "issue": 279,
        "base": "698a6e6557dda31c8e1b35e9ae9244b6f7f8ac5e",
        "tip": "eddb809e0998c280f3fe3e22953f1d14e20d78bf",
        "coverage": "carried",
        "reviewLog": null
      }
    ],
    "suite": {
      "jobId": "40f0ef24-80c5-431b-98db-6b6fa4abe169",
      "tip": "eddb809e0998c280f3fe3e22953f1d14e20d78bf",
      "submittedAt": "2026-10-21T16:46:16Z",
      "state": "running"
    }
  },
  "returns": []
}
```

## Each turn

A turn takes one step and ends on a scheduled wake. A turn never blocks on a
suite or a review; the only waits are single checks.

1. Read `train.json`.
2. Reconcile inbound work:
   - handle the `land request` messages in this turn;
   - run one `gh issue list --label ready-to-land`. The label is the durable
     record, so a lost message is caught here.
3. Check each live handle once:
   - a suite: `wrsp-wait runner:<jobId> --max 0`;
   - a review: `wrsp-wait <log> --max 0`, where `<log>` is the handle from
     `review:candidate --detach`.
4. Take the one step the state calls for: acknowledge, stack, carry, submit, fast-forward, bisect, or return.
5. Write `train.json`, then post each boundary on its issue: accepted, landed,
   returned, train opened, train closed.
6. Schedule the next wake (`send_later`; `CronCreate` in a local session):
   - at the live job's expected finish: its typical duration plus its queue
     position times the typical duration. The typical duration is the `typical`
     value that the step-3 check prints (`wrsp-wait runner:<jobId> --max 0`),
     or the `(typical …)` on the submit line; the queue position is that check's
     `QUEUED position <n>` (0 once the job is past the queue). When the typical
     duration is `unknown`, wake 20 minutes out;
   - at the end of a second-candidate hold (Stack and carry);
   - or 20 minutes out when nothing is live.

## Acknowledge

A developer hands over a candidate with
`land request #<issue> <base>..<tip> suites=<names> session=<id>`, plus the
`ready-to-land` label and the same line as an issue comment. `<base>` and
`<tip>` are full 40-character SHAs. `<id>` is the requester's CCR session id
(`session_…`), the id `send_message` reaches; every reply goes there (#285).

1. Check the request:
   - both endpoints are full 40-character SHAs and `<id>` is a CCR session
     id. Otherwise reply `land refused #<issue> request-format`;
   - `npm run review:status -- <base> <tip>` reports `approved`, meaning the
     last edge is clean. Refuse `advisory` coverage: the developer lands it
     through the advisory path, or fixes the findings first;
   - the range is linear with no merges;
   - `refs/wrsp/train/<issue>` does not exist, unless the request is a
     follow-up (below).
2. Create `refs/wrsp/train/<issue>` at `<tip>`, so the commits outlive the
   developer's worktree.
3. Reply `land accepted #<issue> <tip> train <id> position <n>`, or
   `land refused #<issue> <reason>`. Swap the label to `🛬 in train`.
   The acknowledgment is the handover; ownership moves to the lander with it.

**Follow-up on an accepted candidate.** A developer who stacks more commits on
an accepted candidate sends a new `land request #<issue> <old-tip>..<new-tip>`,
where `<old-tip>` is the tip the lander accepted. Check it as above.
- When the candidate's `train` is set, it is already stacked: reply
  `land refused #<issue> stacked`. Check the field, not the ref; a member
  already on `main` keeps its tip when stacked, so the ref alone does not show
  it. The developer rebases the follow-up onto `main` after `landed` and
  sends it as a new request.
- Otherwise extend the ref by compare-and-swap:
  `git update-ref refs/wrsp/train/<issue> <new-tip> <old-tip>`. On success, set
  the candidate's `tip` to `<new-tip>` and reply `land accepted`. A failed swap
  means the ref moved; reply `land refused #<issue> stacked` (#285).

## Stack and carry

- **Opening.** A train opens when no lander suite is queued or running and at
  least one candidate is accepted. Arrivals during a train's suite join the
  next train. Cap: 4 members. Members that touch only Markdown files (`*.md`)
  do not count toward the cap: they rarely fail a suite, so they barely add
  to bisection (#285).
- **Second-candidate wait.** After accepting a candidate, hold the train's
  suite up to about 5 minutes when the eng lead's latest broadcast or go
  names another lane in review or with an announced candidate. Schedule a
  wake at the hold's end and submit then, or sooner once that candidate is
  accepted. With no such lane named, submit at once. Efficiency over
  latency (Jon, 2026-10-21, #300).
- **Order.** The eng lead's ordering requests apply before a train is
  stacked. Once it is stacked, a reorder
  costs a rebase and a carry for every member above the moved one, and may
  turn a carry into a fresh review. Push back: tell the eng lead that cost,
  and apply the order to the next train unless the eng lead still asks for it
  (#285).
- **Overlap order.** Stack candidates that touch the same files next to each
  other, so a carry refused on overlap holds back no member between them
  (#300).
- **Rebase.** Rebase each member, in acknowledgment order, onto the previous
  member's rebased tip:
  `git rebase --onto <train-tip> <base> <tip>`, on a detached HEAD in the lane
  worktree. Once the member keeps its coverage, move its ref to the rebased
  tip (`git update-ref refs/wrsp/train/<issue> <new-tip>`), so the stack a
  later member may need stays reachable.
- **Carry.** First run `npm run review:status -- <new-base> <new-tip>`. When it
  reports `approved`, the member keeps its coverage: a rebase that changed
  nothing leaves the reviewed identities, and carry would refuse them as
  `already-keyed`. Otherwise run
  `npm run review:candidate -- --carry-only --issue <n> <new-base> <new-tip>`.
  `--carry-only` launches no reviewer and takes no queue slot. A refused carry
  exits 3 with the reason, instead of starting a fresh review. It validates
  the checkout like any candidate (ER-1), so HEAD must be `<new-tip>`: carry
  each member right after its rebase, or `git checkout --detach <new-tip>`
  first (#285).
- **Carry refused.** The refusal line names the reason. Act on it:

  | Refusal (printed text) | Lander's action |
  | --- | --- |
  | `intervening landings touched stack files` (`files-overlap`) | The overlap rule, next bullet. |
  | `content differs after <m> of <n> commits` (`content-mismatch`) | The rebase changed reviewed content. Fresh review, as for an overlap with `main`. |
  | `base-not-descendant` | The approved chain starts on a base `main` does not contain. Fresh review, as for an overlap with `main`. |
  | `no approved range carries to this candidate` (`no-candidate`) | No receipt matches the rebased content. Fresh review, as for an overlap with `main`. |
  | `already holds approval receipts for this tip` (`already-keyed`) | Rerun `review:status` on the rebased range. `approved` keeps coverage; anything else gets a fresh review. |
  | `ends in advisory coverage` (`advisory-terminal`) | `review` return: only the developer can clear advisory findings. |
  | Any other reason | `review` return, with the refusal line as evidence. |

  A fresh review by the lander re-checks the developer's approved content in
  its new place, so it costs a queue slot but no developer round.
- **Carry refused on overlapping files.** The member skips to the next train
  when the overlap is with an earlier member. Unlike a conflict, this is not
  returned: on the next train the overlap is with `main`, which the lander
  clears with a fresh review and no developer round (#285). When the overlap is with `main`
  itself, request admission through the landing queue and run the review
  detached:
  `npm run review:candidate -- --detach --log <log> --issue <n> <new-base> <new-tip>`.
  A clean result keeps the member in the train. Any finding, advisory
  included, is a `review` return: the lander cannot repair findings, and an
  advisory-terminal chain cannot land as a clean tail.
- **Conflicts.** Any conflict is a `conflict` return, sent at once. Abort the
  rebase. The lander never resolves a conflict.
  - With `main` itself: name the conflicting paths.
  - With an earlier member: name the paths and that member's rebased tip as
    a full SHA (its `tip` in `openTrain.members`). The original tip would
    leave out commits `main` gained since the request, and the fresh review
    would then fail freshness. The developer rebases onto the rebased tip,
    re-reviews, and sends a new request that stacks behind that member. The
    SHA stays reachable through the member's train ref, and through `main`
    once the member lands. Skipping would only
    move the conflict onto `main` one train later and return it then (#285).

## Suite, land, bisect

1. Submit one suite at the train tip:
   `wrsp-runner test <train-tip> --no-wait` (in WRSP itself, `node bin/wrsp-runner.mjs test <train-tip> --no-wait`). Record the job id.
2. On `WORKER EXITED passed`:
   - collect with `wrsp-runner collect <jobId>` (in WRSP itself, `node bin/wrsp-runner.mjs collect <jobId>`) from a clean checkout at the train tip, which writes the exact-tip evidence;
   - land under the review lock (B1, below);
   - send `landed #<issue> main=<sha>` to each member and post it on its issue;
   - remove the label and delete `refs/wrsp/train/<issue>`;
   - tell the eng lead the landed tip, the files the landing touched
     (`git diff --name-only <old-main> <new-main>`) and its evidence, for
     publication and the landing broadcast (#300).
3. On `wrsp-wait` exit 9 or `RUNNER STATUS FAILED`, keep the known job id and
   never resubmit. Check it again on the next turn with
   `wrsp-wait runner:<jobId> --max 0`; `collect` waits for an unfinished job,
   so collect with `wrsp-runner collect <jobId>` only after the job reports a terminal outcome.
   Resubmit once at the same tip only after a terminal `infrastructure-error`
   outcome. Neither case starts a bisection.
4. On `failed`, bisect by prefix:
   - test the midpoint prefix tip, narrowing until the first failing prefix is
     found;
   - land the passing prefix that bisection found; its evidence is already
     exact-tip. Outcomes need not be monotonic, so it may not be the longest
     passing prefix;
   - return the first failing member, naming the members below it;
   - re-stack the rest as the next train.

**B1: land under the review lock (#275 Decision B1).** Follow
`reviewed-main-workflow`'s **Land without invalidating approval** for the local
`wrsp-land` procedure and refusal handling. When deferral names a live review
holder, write state and schedule a wake for when that review is expected to end.

## Return

A return sends `returned #<issue> <reason> <evidence>` to the requesting
session, or to the eng lead when that session has retired. The lander posts
the same line on the issue, removes the label, and deletes the train ref.
Reasons:
- `conflict`, with the conflicting paths, plus the earlier member's rebased
  tip when the conflict is with a member;
- `review`, with the findings path;
- `suite`, with the failing job's result and log paths.

Wrap-up (`📦 implemented`, proof, close) stays with the developer.

## Limits

- No pushes; the eng lead publishes the landed tip.
- No edits to candidate content: every repair is a return.
- No full suite outside the Test Mini.
- Rounds and the review breaker count against the candidate's developer, per
  `~/.agents/skills/eng-lead/references/landing-queue.md`. The lander's own
  fresh reviews of an approved candidate are not developer rounds; the
  developer's repair after a `review` return is.
- The standing issue carries train boundaries and handoffs only. A fix to the
  lander itself, its skill or its tools goes on its own issue (#285).
- At 80% of the context budget, write the handoff on the standing issue:
  `train.json` state, live handles, and the next step. Then stop.
