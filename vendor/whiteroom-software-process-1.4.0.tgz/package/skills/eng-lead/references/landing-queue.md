# Landing queue

The eng lead serializes review admission for one project. Developers review
and fast-forward their candidates. Receipts remain the landing authority.

1. The developer sends `X review start base..tip` with full commit IDs, issue,
   worktree, and any review in flight. This requests a slot, not permission to run.
2. The eng lead records one holder and a waiting list. Reply `go` naming the
   lane and the issue when there is no holder. A go admits that lane for that
   issue, not an exact range (#300). A transport receipt is not go.
3. Right before `review:candidate`, the holder fetches local `main`. If `main`
   moved since the request, the holder rebases its unreviewed range onto `main`
   and runs on the new range without a new request or go. A rebase conflict
   keeps the slot only while the holder resolves it promptly, in the same
   turn; otherwise the holder sends `done` unreviewed and the slot is released.
   Only an approved range keeps its range when `main` moves; the carry or the
   lander moves it. Resolve final IDs, verify, and run exact-range review. Keep
   the candidate worktree still during review.
4. Follow reviewed-main-workflow. P0/P1 stays unlanded. A clean or advisory receipt
   permits local fast-forward landing under that contract. Check that a
   contiguous receipt chain from the current main covers the tip, direct or
   carried (`review:status <main> <tip>`). Main movement needs the normal
   fresh-review or eligible carry path with the new range. Queue permission
   never waives that check.
5. Send `X review done tip` with the final reviewed range, landed tips,
   receipt/outcome, findings, corrective work, and publication needs. A failed review also sends
   done, explicitly unlanded. The eng lead acknowledges release before the next
   go. Corrections rejoin the queue.
6. On interruption or missing acknowledgment, preserve the holder. Recover the
   actual review process and main state before release. Elapsed time never proves
   release. Duplicate requests or done messages have no second effect.

**Worked example (#300).** Lane CI sends `CI review start 1111..2222` for #300
while `main` is `1111`. The eng lead replies `go CI #300`. Before CI's turn
starts the review, the lander lands #296 and `main` becomes `3333`. CI fetches,
sees `main` at `3333`, runs `git rebase 3333`, and gets the unreviewed range
`3333..4444`, where `4444` is the rebased `2222`. It runs
`review:candidate -- 3333 4444` at once, with no new request, and reports
`CI review done 3333..4444` with the receipt.

## Landing broadcast (#300)

On every landing, the lander's report to the eng lead names the new `main`
tip and the files the landing touched. The eng lead forwards that line to
every developer lane that holds a slot, is queued for one, or has announced a
candidate:

- A lane that can receive gets it within a minute. Remote sessions queue
  messages, so they count.
- A headless lane in a live turn (`lane.sh send` exit 75) cannot receive. The
  eng lead records the broadcast as pending in its log and re-sends it at the
  lane's next exchange or at the next lane check, whichever comes first.

Each receiving lane rebases its unreviewed work onto the new `main` before its
go, instead of after a freshness refusal. The broadcast saves rework; it is not
the freshness guard. The local-`main` recheck right before `review:candidate`
(step 3) stays mandatory and is that guard. The eng lead
also tells the lander, in each broadcast and at each go, which lanes are in
review or have announced a candidate; the lander's second-candidate wait
(`lander` skill, Stack and carry) reads the latest such message.

## Hot files (#300)

Every lane brief names the shared hot files the lane owns: sections of
`skills/*/SKILL.md`, contract docs under `docs/reference/`, and core modules
such as `src/runner/lifecycle.ts` and `src/runner/executor.ts`. A lane that
needs a hot file another lane owns coordinates with the owner first, through
the eng lead, or waits. The eng lead may connect the two owners directly for
a quick exchange. The lander trains candidates that touch the same files
next to each other.

## Lander (#275)

When the project runs a 🛬 lander lane, a developer whose candidate coverage
ends clean (`review:status` reports `approved`) hands the candidate to the
lander (`lander` skill) instead of landing it, and sends `done` once the
lander acknowledges. The request is
`land request #<n> <base>..<tip> suites=<names> session=<id>`, with full
40-character SHAs and the requester's CCR session id (#285). Advisory coverage stays on the developer's advisory path.
From then on the lander
owns rebase, carry, the exact-tip suite and the fast-forward, and it lands
batches as a merge train.

- **Carry-only runs** (`review:candidate --carry-only`) take no queue slot.
  They write carried receipts before the review lock, launch no reviewer, and
  exit on a refused carry.
- **Fresh reviews** by the lander take a slot like any other review. Trains
  save suites, not reviews: expect a member that overlaps `main` or an
  earlier member to need one. These reviews do not count as developer rounds.
- **Order.** Send ordering requests before the lander stacks a train. A
  reorder after stacking costs carries, and the lander pushes back on it.
- **Landing** goes through `wrsp-land <tip>`. It uses the existing review lock
  (`src/review-lock.ts`) and adds no new lock type, so it never moves main
  under a running review.
- **Second candidate.** After accepting a candidate, the lander holds the
  train's suite up to about 5 minutes while another lane is in review or has
  announced a candidate, then starts the suite: efficiency over latency.
- **Publication** stays with the eng lead. The lander reports each landed tip,
  the files the landing touched, and its exact-tip evidence; the eng lead
  broadcasts the tip and files (Landing broadcast, above).

## Round limit (#238)

A round is one exact-range review, initial or follow-up, whatever its outcome;
a review execution error is not a round.
One `review:candidate` invocation that splits a mixed-family range into runs counts as one round (#291).
Rounds count per allocated task
(eng lead → developer, developer → builder), not per issue. A new lineage,
changed approach, new model or successor lane keeps the count; only Jon
re-scoping resets it.

- The eng lead counts each lane's rounds from `review start`; a developer
  counts its builders' rounds.
- Round 5 is the last. A task without a clean approval after round 5 stops. A
  builder's trip goes to its developer; a developer brings its trip to the
  eng lead with each round's range, findings and what the repair changed.
- The three-consecutive-P0/P1 breaker in reviewed-main-workflow stays the faster
  trip.
- The eng lead resolves a trip once per task: narrow the scope, split the
  task, drop the failing ambition, park it for Jon, or grant one more 5-round
  budget for a changed approach. The note names what changed; another patch on
  the same mechanism is no change. Record the decision and reason on the issue.
- A second trip goes to Jon. Finding acceptance stays Jon's.

## Publication

For publication, record the remote base, full frozen tip, required suites, and
authority source. Create a clean detached worktree at that tip. Run final suites,
collect evidence, inspect review status, and push from that checkout. Evidence
lives in the Git common directory; WRSP's pre-push hook checks that checkout's
HEAD and requires outgoing commits and peeled tags to match it.

Reviews and landings keep advancing main. There is no admission freeze. Use an
explicit `<frozen-tip>:refs/heads/main` push from the detached checkout. Verify
the remote result and log the pushed tip. Do not replace the frozen checkout's
HEAD with main's newer tip or add a newer commit without its evidence.

The eng lead owns final publication-suite submission and collection. Reuse
matching evidence and resume known jobs after transport failure. Developers
may run suites for repair or a repository's landing requirement; share job handles
to avoid duplicate submissions. A focused check is not a full suite. Every full
suite, the eng lead's included, runs on the Test Mini through
`wrsp-runner test <tip>`; a local full run on Agent Mini refuses (#256).

A changed frozen tip needs a new evidence and authority check. Split pushes only
at recorded permitted segment boundaries. Older acceptance never covers added
work. A remote race needs reconciliation and fresh checks, never an automatic
force push. Queue go grants admission, not acceptance or publication authority.
