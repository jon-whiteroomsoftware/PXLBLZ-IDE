# Eng lead operations

Operate one project and only the lane tree you started. The eng-lead skill
defines ownership. A Claude eng lead is the unattended default, with mixed
Claude and Codex developers. A Codex eng lead runs only while Jon drives the
session, with Codex and headless Claude developers.

## Check in

1. On resume and after every compaction, reload the existing issue log and
   `handoff.md`. Keep both current before each risky step: exact frozen and
   publication tips, publication checkout, builder/review/runner identities and
   handles, lane roster, queue owner, next owners and recovery commands,
   next steps, pending operator requests,
   and held pushes. Reconcile them against live issue, job, queue and native
   grant state before the next real action, including current queue permission.
   Saved wakes and review go messages prompt this check; they never authorize
   replay. Unanswered questions remain pending through every compaction.
   Compaction preserves this session's native identity and grant. If the grant
   is no longer this session's, stop leading: actual supersession ends its role.
2. Run `wrsp-agents check`. Read version and warning lines for both CLIs.
   A version warning alone does not fail the command.
3. Upgrade a behind Codex with `npm i -g @openai/codex@latest` only when no lane
   has a live builder or runner job. Recheck. Jon trusts changed hooks in the
   desktop app; the CLI 0.163.0 trust attempt did not persist.
4. Claude updates itself. Report which sessions and Remote Control servers
   started before the installed version. Schedule their handoffs normally.
5. Inspect this session's grant with `wrsp-session-role inspect`. To record Jon's
   assignment, run `wrsp-session-role grant <request.json>` in this session's own
   shell. Copy their words and source verbatim. The helper reads the native id
   from the harness environment. Do not infer it from a Remote label or grant
   after a denial without an existing instruction. Resume and compaction retain it.
6. Read context and status for each developer lane. Use its model budget from
   installed `roles.members`; unknown model or usage stays unknown. Request a
   checkpoint before more work when either is unknown. At 80%, request a handoff, start a
   successor, and obtain its acknowledgment before retirement.
7. The same granted eng lead continues authorized work and lane checks through
   natural auto-compaction, whether Jon is present or away. Context conservation
   does not pause work or trigger an eng-lead handoff at 80%. Consider a successor
   only when Jon asks, Jon is present to grant it, or Remote lineage headroom is
   3 or less. A fresh session needs Jon's grant.
   In Claude remote, read this session's Remote lineage from get-session →
   `lineage`; headroom is `limit − depth`. At headroom 0 a session has no
   `send_later`, scheduled tasks or session creation, and every lane runs one
   level deeper and needs its own wake timer (#308).
   - At headroom 3 or less, ask Jon to start a fresh lineage and record the pending
     request in the log and handoff. Keep existing authorized work moving while
     this session remains the grant holder.
   - At headroom 1 or less, start no lanes or successors.
   - Unknown lineage requires a checkpoint.
8. Confirm priorities, queue requests, publication needs, and Jon's instructions.
   Log each decision with its source and exact affected scope.

Start developer lanes in the installed `developer` role's order:
`gpt-6.1-sol` first through `lane.sh start --cli codex`. Use Opus only when
Sol is unavailable or Jon asks for Opus.

## Claude eng lead

Developer lanes use the headless `lane.sh` routes from either eng-lead home.
The Remote capability column below is reference for other sessions.

| Capability | Claude lane | Codex lane |
| --- | --- | --- |
| Start | Remote session create with title, model, permission mode, and tags. Select the Agent Mini Remote Control environment. A cloud environment skips the host hooks. | Detached `codex exec --json`; record the thread id. |
| Message | Remote send-message with priority now, next, or later. | Next turn: `codex exec resume <id>`. |
| Receive | The lane sends a message to `@parent`. | Read the turn's output. |
| Context use | Remote get-session → `context_usage`. | Latest `token_count.last_token_usage` in the rollout, under `payload.info`; use input tokens, not cumulative totals. |
| Rename | Remote set-title, including the eng lead's own session. | `thread/name/set` only for app-server threads; otherwise update the roster title. |
| Transcript | Remote list-events / get-event. | Rollout matched by `session_meta.id`. |
| Status / retire | Remote get-session status bucket; archive after handoff acknowledgment. | Recorded handle and exit state; retire after handoff acknowledgment. |

## Codex eng lead

| Capability | Claude lane | Codex lane |
| --- | --- | --- |
| Start | Escalated, detached `claude -p --session-id <uuid> --name "<thread name>" --output-format json`. | Detached `codex exec --json`; record the thread id. |
| Message | `claude -p --resume <uuid>`, one turn at a time. | `codex exec resume <id>`, one turn at a time. |
| Receive | Read the turn's JSON output. | Read the turn's output. |
| Context use | `usage` in the turn's JSON. | Latest `token_count.last_token_usage` in the rollout, under `payload.info`. |
| Rename | `--name` on start or resume; qualify resume naming on the host. | `thread/name/set` only for app-server threads; otherwise update the roster title. |
| Transcript | `~/.claude/projects/<slug>/<uuid>.jsonl`. | Rollout matched by `session_meta.id`. |
| Status / retire | Recorded handle and exit state; retire after handoff acknowledgment. | Recorded handle and exit state; retire after handoff acknowledgment. |

Use exact role, model, effort, and budget at start. A route that cannot select
the required pair cannot start that lane. Native bootstrap verification precedes
issue input on every turn; unknown or off-policy pairs refuse. Remote cannot
select developer effort, so its developer route is refused. Non-preferred
developer starts record `--selection-reason` for Sol unavailability or Jon's
explicit Opus request. Permission profiles and handle format remain owned by
`scripts/lane.sh`; it supplies start, send, read, and status.
OpenRouter-backed Codex follows the Codex routes and provider limits.

## Lane turns

- The Codex harness kills background processes when a call ends. A Codex
  eng lead cannot keep an app-server alive between turns. Each headless lane
  turn runs detached under launchd and is waited on with
  `wrsp-wait`, as builders are today.
- Separate `codex exec resume <id>` turns are qualified on Agent Mini with
  codex-cli 0.163.0 (#258). `exec resume` has no `-C`, so `lane.sh` passes it
  on turn 1 only; every turn runs from the lane worktree.
- Hold one lock per lane from turn admission through process exit. Two turns
  never overlap. A failed submission releases only its own lock. Recover an
  interrupted turn from its handle and exit record, not elapsed time.
- A headless lane cannot receive mid-turn. It ends its turn at a queue request,
  handoff, or question for Jon. A queue “go” arrives as its next turn.
  A send during a live turn reports busy; it does not start a second writer.
- Never resume a headless lane interactively while its eng lead may send turns.
  Transfer ownership explicitly first. A fresh successor gets a fresh identity.
- A headless Claude lane has no Remote tools. Its tree is whatever it launches
  through `~/.agents/skills/developer/scripts/launch-worker.sh`.
- Persist lane identity, title, family, provider, host, project, issue, worktree,
  role id, requested and reported model/effort, native source, selection reason,
  budget, contact route, launch handle, and next exchange.
  Match #196 launch attribution; a resume is a turn of the same lane.
- Require acknowledgment for queue ownership, scope changes, and handoffs.
  If contact fails, inspect the handle and process table, read output only after
  exit, and recover that lane.
  An issue comment records intent but does not wake an idle headless process.
  Independent lanes continue. Missing delivery never supplies queue permission.

### Lane script

Installed path: `~/.agents/skills/eng-lead/scripts/lane.sh`.

```text
lane.sh start --role developer|ux-principal --cli claude|codex --role-id <role> --model <model> --effort <effort> --worktree <dir> --issue <N> --brief <file> --title <text> --log <file> [--selection-reason <text>]
lane.sh send <handle> <message-file>
lane.sh read <handle> [--cursor <bytes>]
lane.sh status <handle>
lane.sh recover <handle>
lane.sh title --role <role> [--lane <name>] --task <text> [--issues "#1 #2"] [--state done]
lane.sh verify-pair --cli claude|codex --role-id <id> --model <requested> --effort <requested> --session <native-id> --transcript <path> [--offset <nonnegative-byte-offset>]
```

The handle is `<log without .log>.lane.json`; turn logs are
`<log without .log>.turn-<n>.log`. A `<handle>.lock` directory admits one
turn and remains held until the runner exits. A live turn refuses sends;
an interrupted turn needs `recover`, which checks the pid and exit record.
Failed submission releases the lock and preserves the previous handle.
Every turn removes its launchd job on exit, including refusals and aborts; an aborted turn is recorded as exit 70 with its launch-record exit fact.
A launchd respawn of a killed turn is refused (exit 79) and leaves the turn interrupted for `recover`; no input is replayed.
A missing lane worktree is refused with exit 80 and `worktree <path> is missing; recreate it or start a new lane`: `send` refuses before admitting a turn, and a turn whose worktree vanished after admission writes the refusal and `EXIT:80` to its turn log (#261).
Wait on a turn with
`wrsp-wait <turn-log>`.

Verification may remain pending until the turn exits; pending grants no acceptance.
Status and logs show accepted or refused (exit 81), the phase, and native source.
A work-phase refusal reports drift after dispatch. Relative send handle and
message paths resolve from the sender's cwd.

## Lane check

A lane reports only by message. A lane whose job notification never arrives
sits idle and sends nothing. An empty slot starts nothing on its own. While
any lane is live or the ready list is non-empty, check the actual state on a timer.

- Schedule the next check at most 20 minutes out with the harness's wake
  timer: `send_later` in Claude remote, `CronCreate` in Claude local. The wake
  message names the steps: recheck current issue, grant and queue state, then
  status, nudges, refill. A stale wake or saved go requires that reconciliation;
  never replay an old review go. A harness
  with no wake timer, including a Remote session at lineage headroom 0
  (Check in, step 7), runs the check at the start of each turn. The check runs
  between turns. It is never a wait loop inside a turn.
- Read metadata only: each lane's session status; `ps -p` on its recorded
  review, builder and runner pids; `.exit` markers and file mtimes newer than
  the lane's last message; `git -C <worktree> status --short`; and one
  `wrsp-wait.sh <log> --max 0` per launch handle.
- Never read, tail or follow a running process's log or output, and never loop
  on `sleep`. Read a log's tail once, after the process exits.
- Nudge a lane that is idle on finished work, meaning an `.exit` marker or a
  dead pid newer than its last message. Name the finished job and its exit code.
- For a lane blocked on another lane, confirm the blocker has moved since the
  last check: its session is working, or its HEAD or status has changed. If
  it hasn't, nudge the blocker.
- Log each nudge.
- End every check by reconciling the authorized inventory and refilling
  executable ready-list work within the lane cap; log each start. Keep parked
  issues and explicit exclusions parked. Report and reconcile missing or stale issue state; it is
  uncertainty, never proof that no work remains.
- Before retiring the last lane, record concrete blocked actions and remaining
  authorized work in the existing issues, log and handoff, and refill executable
  work within the cap. When the authorized inventory is exhausted or every
  remaining action is blocked, retire idle lanes and stop checks. Keep no empty
  polling lanes.
- `wrsp-wait.sh` on a `lane.sh` turn handle reports only running or exited; exits 8 (not producing) and 3 (stalled) come only from `launch-worker.sh` handles.

## Names and instructions

Use the eng-lead skill's role emoji table. The developer skill carries the
same table. Shape: `<emoji>[ <Lane>]: <task>[ #issues]`. Follow these examples:

- `👽 Agent Mini migration #174 #196 #197`
- `👩‍💻 G: event capture #196`
- `💀 F: laptop ledger #192`

The colon appears only after a lane letter. Rename on assignment, changed work,
successor pickup, and completion. Replace the role emoji with 💀 at completion
and keep task text. Promotion changes 👩‍💻 to 👽. Titles grant no authority.

Jon names a Codex eng lead's thread at start. Tell them the new name when its
scope changes. Use Remote titles for Remote lanes, `--name` for Claude headless
lanes, and `thread/name/set` for Codex app-server threads. Other Codex CLI lanes
keep their desired title in the roster. Never edit app databases to rename.
Name descendant launch records with 🔧, 👩‍🎤, 👀, 🔬, or 🔍 as appropriate.
Keep #196 launch identities intact; this work does not change the builder launcher.

Lanes in this tree forward Jon's direct instructions verbatim to the eng lead
and record their source on the issue in the same turn. Builders without issue
access send the exact words through their developer. A lane outside this tree
records Jon's words on its issue; it is not managed by this eng lead.

Never hand Jon a bare file path. Share a file the way global `AGENTS.md`
(Environment) says; where it names no Files link, link a pushed file or publish
the content on the issue. Apply this to drafts, handoffs, logs, proof, and
decisions as well as finished documents.

## Pushes while Jon is away

Jon approved this rule; “you” refers to Jon:

> a push proceeds without you when it has full review coverage or recorded acceptance and passing evidence at the exact commit. It waits for you only when it does one of these:
>
> - changes review, receipt, evidence or gate semantics, or a contract consumers see;
> - installs hooks that need re-trust;
> - tags or releases;
> - force-pushes or deletes a remote ref.

Reuse Jon's existing approval only for the risky action and exact scope it covers.
A new material release fact holds remaining release actions: a promised installed
operation fails, consumer impact changes, or release proof is invalidated. Resume
under the original go only after verified correction within that scope. Unresolved
material defects or uncovered scope wait for Jon; shipping a defect as a known
limitation requires their explicit acceptance. Unchanged limitations already
disclosed and accepted, and advisories unrelated to release promises, consumer
impact or proof, do not reopen the go. Record the new fact, scope, correction proof
or accepted limitation, and Jon's approval source on the release issue; link that
disposition from the publication log before resuming. Disclose accepted limitations
in release notes and consumer handoffs. Otherwise hold the push. An eng lead
assignment is role authority, not findings acceptance or approval of every risky action.
Use the landing-queue and operator-acceptance references for the actual checks.
Publishing from a frozen checkout lets reviews and landings continue on main.

A step needing Jon blocks only that step. Within the assigned goal, continue
authorized preparation, analysis and independent issues while it waits; keep
parked issues and explicit exclusions parked. Report and reconcile missing or
stale issue state rather than treating it as proof that no work remains.
Group prepared sudo installs, laptop actions, hook re-trust and product questions
into one operator window; each still waits for its own required instruction.
Keep unanswered requests pending in the log and handoff through compaction.

## Visibility

See only the tree you started. Jon accepts missing visibility into threads they
start in another app. Discovery of every chat is not a completion requirement.
Do not send peer messages to laptop sessions; their inbound refusal still applies.

Remote events expose the connected conversation, subject to pagination and tool
availability. They do not expose private reasoning or promise every local tool
byte. Same-host Claude transcripts and Codex rollouts expose persisted events
and usage. Match identity and read only relevant, bounded ranges for this project.
Missing files, truncation, persistence settings, and provider differences limit
that view. OpenRouter adds no Remote or cross-session capability. Missing usage
stays unknown; request a checkpoint. The usage ledger is counters, not a transcript.
