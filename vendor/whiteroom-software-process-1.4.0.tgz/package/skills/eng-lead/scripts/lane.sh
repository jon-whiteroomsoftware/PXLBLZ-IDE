#!/usr/bin/env bash
# WRSP #197: one detached process per lane turn; identity survives process exit.
set -euo pipefail

refuse() { printf 'REFUSED: %s\n' "$2" >&2; exit "$1"; }
absolute() { case $1 in /*) printf '%s\n' "$1";; *) printf '%s/%s\n' "$PWD" "$1";; esac; }
load() {
  [[ -r $1 ]] && jq -e 'type == "object" and (.turn | type == "number")' "$1" >/dev/null 2>&1 || refuse 65 'handle missing or unreadable'
  handle=$1
  n=$(jq -r .turn "$handle")
  log=$(jq -r .contact "$handle")
}
atomic() { cat > "$handle.tmp.$$"; mv -f "$handle.tmp.$$" "$handle"; }
# Native metadata only: never infer served configuration from argv or assistant prose.
native() {
  node - "$@" <<'NODE'
const fs = require('node:fs');
const path = require('node:path');
const args = process.argv.slice(2);
const normalize = value => value === 'medium' ? 'med' : value;
if (args[0] === 'find') {
  const [, cli, session] = args;
  if (!session || /[/\\]/.test(session)) process.exit(81);
  const root = path.join(process.env.HOME, cli === 'claude' ? '.claude/projects' : '.codex/sessions');
  const matches = [];
  function walk(dir, depth) {
    for (const entry of fs.readdirSync(dir, {withFileTypes:true})) {
      const file = path.join(dir, entry.name);
      if (entry.isDirectory() && (cli === 'codex' || depth === 0)) walk(file, depth + 1);
      else if (entry.isFile() && (cli === 'claude' ? entry.name === session + '.jsonl' : entry.name.startsWith('rollout-') && entry.name.endsWith('-' + session + '.jsonl'))) matches.push(file);
    }
  }
  try { walk(root, 0); } catch (error) { if (error.code !== 'ENOENT') { console.error(error.message); process.exit(81); } }
  if (matches.length !== 1) { console.error('native transcript ' + (matches.length ? 'ambiguous' : 'missing') + ' for ' + session); process.exit(matches.length ? 81 : 82); }
  console.log(path.resolve(matches[0]));
  process.exit(0);
}
if (args.shift() !== 'verify') process.exit(64);
const options = {};
const allowed = new Set(['--cli','--role-id','--model','--effort','--session','--transcript','--offset']);
for (let i = 0; i < args.length; i += 2) {
  if (!allowed.has(args[i]) || options[args[i]] !== undefined || !args[i+1] || args[i+1].startsWith('--')) process.exit(64);
  options[args[i]] = args[i+1];
}
if (!['claude','codex'].includes(options['--cli']) || ['--role-id','--model','--effort','--session','--transcript'].some(key => !options[key]) || !/^\d+$/.test(options['--offset'] || '0')) process.exit(64);
const start = Number(options['--offset'] || 0);
if (!Number.isSafeInteger(start)) process.exit(64);
const cli = options['--cli'];
const session = options['--session'];
const report = {
  state:'refused', phase:'bootstrap',
  requested:{role:options['--role-id'],model:options['--model'],effort:normalize(options['--effort'])},
  reported:{model:null,effort:null,nativeEffort:null},
  source:{provider:cli,session,path:path.resolve(options['--transcript']),start,end:start}, reason:''
};
function fail(reason) { throw new Error(reason); }
function field(values, label, norm = value => value) {
  const supplied = values.filter(value => value !== undefined);
  if (!supplied.length) return null;
  if (supplied.some(value => typeof value !== 'string' || !value.trim())) fail('unknown native ' + label);
  if (new Set(supplied.map(norm)).size !== 1) fail('conflicting native ' + label);
  return supplied[0];
}
try {
  const bytes = fs.readFileSync(report.source.path);
  report.source.end = bytes.length;
  if (start > bytes.length || (start > 0 && bytes[start-1] !== 10)) fail('invalid native offset or truncation');
  if (bytes.length && bytes[bytes.length-1] !== 10) fail('truncated native record');
  let position = 0;
  const rows = new TextDecoder('utf-8', {fatal:true}).decode(bytes).split('\n').slice(0,-1).map(line => {
    const at = position; position += Buffer.byteLength(line) + 1;
    try {
      const row = JSON.parse(line);
      if (!row || typeof row !== 'object' || Array.isArray(row)) fail('malformed native record');
      return {at,row};
    } catch { if (at < start) return {at,row:{}}; fail('malformed native record'); }
  });
  if (cli === 'codex') {
    const ids = rows.filter(({row}) => row.type === 'session_meta').map(({row}) => row.payload?.id);
    if (!ids.length || ids.some(id => id !== session)) fail('native session identity mismatch or missing');
  }
  let context;
  let assistant;
  for (const {at,row} of rows) {
    if (at < start) continue;
    if (cli === 'codex' && row.type === 'turn_context') context = row.payload;
    if (cli === 'claude' ? row.type === 'assistant' && !row.isSidechain && !row.parentToolUseID && !row.parent_tool_use_id : row.type === 'response_item' && row.payload?.type === 'message' && row.payload.role === 'assistant') {
      assistant = row; break;
    }
  }
  if (!assistant) fail('missing fresh parent assistant metadata');
  if (cli === 'claude' && assistant.sessionId !== session) fail('native session identity mismatch');
  if (cli === 'claude' && assistant.message?.role !== 'assistant') fail('missing native assistant role');
  const value = cli === 'claude' ? assistant : context;
  if (!value) fail('missing fresh turn context before first assistant');
  const settings = cli === 'codex' ? value.collaboration_mode?.settings : undefined;
  report.reported.model = field(cli === 'claude' ? [value.message?.model] : [value.model], 'model');
  report.reported.nativeEffort = field(cli === 'claude' ? [value.perTurnEffort,value.effort] : [value.effort,value.reasoning_effort], 'effort', normalize);
  report.reported.effort = normalize(report.reported.nativeEffort);
  if (cli === 'codex') {
    field([value.model,settings?.model], 'model');
    field([value.effort,value.reasoning_effort,settings?.reasoning_effort], 'effort', normalize);
  }
  if (!report.reported.model || !report.reported.effort) fail('missing native model or effort');
  let members;
  try { members = fs.readFileSync(process.env.WRSP_ROLES_MEMBERS || path.join(process.env.HOME,'.agents/roles.members'),'utf8').split('\n').map(line => line.split('\t')); }
  catch { fail('role membership source missing or unreadable'); }
  const member = (model,effort) => members.some(([role,m,e,budget]) => role === report.requested.role && m === model && normalize(e) === effort && /^\d+$/.test(budget) && Number(budget) > 0);
  if (!member(report.reported.model,report.reported.effort)) fail('native pair is not a current positive-budget role member');
  if (!member(report.requested.model,report.requested.effort)) fail('requested pair is not a current positive-budget role member');
  if (report.requested.model !== report.reported.model || report.requested.effort !== report.reported.effort) fail('native pair differs from requested pair');
  report.state = 'accepted';
} catch (error) { report.reason = error.message; }
console.log(JSON.stringify(report));
process.exit(report.state === 'accepted' ? 0 : 81);
NODE
}
pending() {
  jq '.verification={state:"pending",phase:"bootstrap",requested:{role:.role_id,model:.model,effort:(if .effort == "medium" then "med" else .effort end)},reported:{model:null,effort:null,nativeEffort:null},source:{provider:.cli,session:.thread,path:null,start:0,end:0},reason:""} | .turns[-1].verification=.verification' "$handle" | atomic
}
save_verification() {
  jq --argjson report "$verification" '.verification=$report | .turns[-1].verification=$report' "$handle" | atomic
  jq -nr --argjson v "$verification" --arg selection "$(jq -r '.selection_reason // ""' "$handle")" '$v | "PAIR \(.state | ascii_upcase) phase=\(.phase) requested=\(.requested.model)/\(.requested.effort) native=\(.reported.model // "unknown")/\(.reported.effort // "unknown") source=\(.source | tojson) reason=\(.reason) selection-reason=\($selection)"' >> "$log"
}
provider_command() {
  local fresh=$1 cli_effort=$effort override
  [[ $cli_effort != med ]] || cli_effort=medium
  cmd=(env WRSP_ROLE=developer "WRSP_CONTEXT_BUDGET=$budget")
  if [[ $cli == claude ]]; then
    cmd+=(claude -p --model "$model" --effort "$cli_effort" --settings "$roles/developer.claude.json" --permission-mode bypassPermissions)
    if [[ $fresh == yes ]]; then cmd+=(--session-id "$thread" --name "$(jq -r .title "$handle")"); else cmd+=(--resume "$thread"); fi
    cmd+=(--output-format json)
  else
    cmd+=(codex exec)
    [[ $fresh == yes ]] || cmd+=(resume "$thread")
    cmd+=(--json -m "$model" -c "model_reasoning_effort=$cli_effort" -c "model_auto_compact_token_limit=$budget")
    while IFS= read -r override || [[ -n $override ]]; do
      [[ -z $override || $override == \#* ]] || cmd+=(-c "$override")
    done < "$roles/developer.codex.args"
    [[ $fresh != yes ]] || cmd+=(-C "$worktree")
    cmd+=(-)
  fi
}
bootstrap() {
  # The issue file is never opened here. Bound only the metadata exchange.
  node -e '
    const {spawnSync} = require("node:child_process");
    const result = spawnSync(process.argv[1], process.argv.slice(2), {
      input:"Startup metadata verification only. Reply exactly LANE_READY. Do not use tools, claim an issue, edit files, launch children, or perform issue work. The issue brief arrives in a later message.",
      stdio:["pipe",1,2], timeout:90000
    });
    if (result.error || result.signal) { console.error("bootstrap timeout/abort: " + (result.error?.message || result.signal)); process.exit(70); }
    process.exit(result.status ?? 70);
  ' "${cmd[@]}"
}
live() {
  [[ -s ${log}.pid ]] || return 1
  pid=$(cat "${log}.pid")
  [[ $pid =~ ^[0-9]+$ ]] && ps -p "$pid" >/dev/null 2>&1
}
state() {
  if [[ -f ${log}.exit ]]; then printf 'exited %s' "$(cat "${log}.exit")"
  elif live; then printf live
  elif [[ -d $handle.lock ]]; then printf interrupted
  else printf none; fi
}
record_fact() { # Same best-effort boundary as launch-worker.sh (#196).
  if ! command -v "$usage_bin" >/dev/null 2>&1; then
    echo "WARNING: launch record not written: $usage_bin is not on PATH (#196)." >> "$log"
    return 0
  fi
  "$usage_bin" "$@" >/dev/null 2>>"$log" || echo "WARNING: launch record not written: $usage_bin $1 $2 exited $? (#196)." >> "$log"
  return 0
}
remove_job() {
  if [[ -n ${WRSP_LANE_REMOVE:-} ]]; then
    "$WRSP_LANE_REMOVE" "$1" >/dev/null 2>&1 || true
  else
    launchctl remove "$1" >/dev/null 2>&1 || true
  fi
}
submit() {
  local label=$1
  local self
  self=$(absolute "$0")
  local cmd=(launchctl submit -l "$label" --)
  [[ -z ${WRSP_LANE_SUBMIT:-} ]] || cmd=("$WRSP_LANE_SUBMIT")
  cmd+=(/usr/bin/env "PATH=$PATH" "HOME=$HOME" "TMPDIR=${TMPDIR:-/tmp}")
  [[ -z ${WRSP_ROLES_DIR:-} ]] || cmd+=("WRSP_ROLES_DIR=$(absolute "$WRSP_ROLES_DIR")")
  [[ -z ${WRSP_ROLES_MEMBERS:-} ]] || cmd+=("WRSP_ROLES_MEMBERS=$(absolute "$WRSP_ROLES_MEMBERS")")
  [[ -z ${WRSP_USAGE_BIN:-} ]] || cmd+=("WRSP_USAGE_BIN=$WRSP_USAGE_BIN")
  [[ -z ${WRSP_LANE_REMOVE:-} ]] || cmd+=("WRSP_LANE_REMOVE=$WRSP_LANE_REMOVE")
  cmd+=(/bin/bash "$self" run-turn "$handle" "$n" "$label")
  local code=0
  "${cmd[@]}" || code=$?
  if [[ $code != 0 ]]; then remove_job "$label"; fi
  return "$code"
}
command=${1:-}; [[ $# -eq 0 ]] || shift
case $command in
  verify-pair) native verify "$@";;
  title)
    role= lane= task= issues= state=
    while [[ $# -gt 0 ]]; do
      [[ $# -ge 2 && -n $2 ]] || refuse 64 'missing argument'
      case $1 in
        --role) role=$2;; --lane) lane=$2;; --task) task=$2;;
        --issues) issues=$2;; --state) state=$2;; *) refuse 64 'unknown argument';;
      esac; shift 2
    done
    # Names table: keep role glyphs in this single block.
    case $role in
      eng-lead) emoji=👽;;
      developer) emoji=👩‍💻;;
      builder) emoji=🔧;;
      reviewer) emoji=👀;;
      researcher) emoji=🔬;;
      locator) emoji=🔍;;
      ux-principal) emoji=👩‍🎤;;
      principal-engineer) emoji=🧙;;
      batch) emoji=🤖;;
      *) refuse 64 'unknown role';;
    esac
    case $state in '') ;; done) emoji=💀;; *) refuse 64 'unknown state';; esac
    [[ -n $task ]] || refuse 64 'missing task'
    printf '%s%s %s%s\n' "$emoji" "${lane:+ $lane:}" "$task" "${issues:+ $issues}"
    ;;
  start)
    role= cli= role_id= model= effort= worktree= issue= brief= title= log= selection_reason=
    while [[ $# -gt 0 ]]; do
      [[ $# -ge 2 && -n $2 && $2 != --* ]] || refuse 64 'missing argument'
      case $1 in
        --role) role=$2;; --cli) cli=$2;; --role-id) role_id=$2;; --model) model=$2;;
        --effort) effort=$2;; --worktree) worktree=$2;; --issue) issue=$2;;
        --brief) brief=$2;; --title) title=$2;; --log) log=$2;; --selection-reason) selection_reason=$2;; *) refuse 64 'unknown argument';;
      esac; shift 2
    done
    [[ -n $role && -n $cli && -n $model && -n $effort && -n $worktree && -n $issue && -n $brief && -n $title && -n $log ]] || refuse 64 'missing argument'
    [[ -n $role_id ]] || refuse 64 '--role-id is required (#243)'
    [[ $role == developer || $role == ux-principal ]] || refuse 64 'unknown role'
    [[ $role != developer || $role_id == developer ]] || refuse 64 'developer requires --role-id developer'
    [[ $cli == claude || $cli == codex ]] || refuse 64 'unknown cli'
    [[ $effort != medium ]] || effort=med
    [[ $issue =~ ^[0-9]+$ && -r $brief ]] || refuse 64 'invalid issue or unreadable brief'
    stem=$(absolute "${log%.log}"); handle=$stem.lane.json
    [[ ! -e $handle ]] || refuse 65 'handle exists; use send'
    [[ -d $worktree ]] || refuse 66 'worktree not a directory'
    budget=$(awk -F '\t' -v role_id="$role_id" -v m="$model" -v e="$effort" '$1==role_id && $2==m && $3==e {print $4; exit}' "${WRSP_ROLES_MEMBERS:-$HOME/.agents/roles.members}" 2>/dev/null) || budget=
    [[ $budget =~ ^[0-9]+$ && $budget -gt 0 ]] || refuse 67 "role $role_id has no pair ($model, $effort)"
    if [[ $role == developer ]]; then
      preferred=$(awk -F '\t' '$1=="developer" {print $2 "\t" $3; exit}' "${WRSP_ROLES_MEMBERS:-$HOME/.agents/roles.members}")
      [[ $preferred == "$model"$'\t'"$effort" || $selection_reason =~ [^[:space:]] ]] || refuse 64 'nonpreferred developer pair requires --selection-reason'
    fi
    command -v "$cli" >/dev/null 2>&1 || refuse 69 "$cli is not on PATH"
    # WRSP #249: refuse a CLI below the model's vendor-stated minimum; an unlisted model is never refused.
    minimums=${WRSP_CLI_MINIMUMS:-$HOME/.agents/cli-minimums}
    [[ -r $minimums ]] || refuse 66 "cli-minimums not found: $minimums. Run wrsp-agents install."
    minimum=$(awk -F '\t' -v m="$model" -v c="$cli" '!/^#/ && $1 == m && $2 == c { print $3; exit }' "$minimums") || minimum=
    if [[ -n $minimum ]]; then
      installed=$("$cli" --version </dev/null 2>/dev/null | grep -Eo '[0-9]+\.[0-9]+\.[0-9]+' | head -n 1) || installed=
      [[ -n $installed ]] || refuse 69 "$cli version unreadable ($cli --version); $model needs $cli $minimum or later."
      if [[ $(awk -v a="$installed" -v b="$minimum" 'BEGIN { split(a, x, "."); split(b, y, "."); for (i = 1; i <= 3; i++) if (x[i] + 0 != y[i] + 0) { print (x[i] + 0 < y[i] + 0); exit } print 0 }') == 1 ]]; then
        refuse 69 "$cli $installed is below $model's minimum $minimum; upgrade $cli to $minimum or later"
      fi
    fi
    worktree=$(cd "$worktree" && pwd -P); brief=$(absolute "$brief")
    project=$(git -C "$worktree" rev-parse --show-toplevel)
    lane=$(basename "$stem"); lane=${lane//[^A-Za-z0-9.-]/-}
    launch_id=$(uuidgen | tr '[:upper:]' '[:lower:]'); thread=; provider=openai
    if [[ $cli == claude ]]; then provider=anthropic; thread=$(uuidgen | tr '[:upper:]' '[:lower:]'); fi
    n=1; log=$stem.turn-1.log
    label=com.whiteroom.wrsp-lane.$lane.$n.$(date +%s)
    mkdir "$handle.lock" 2>/dev/null || refuse 65 'handle exists; use send'
    jq -n --arg lane "$lane" --arg role "$role" --arg title "$title" --arg cli "$cli" --arg provider "$provider" --arg host "$(hostname -s)" --arg project "$project" --arg issue "$issue" --arg worktree "$worktree" --arg role_id "$role_id" --arg model "$model" --arg effort "$effort" --arg budget "$budget" --arg contact "$log" --arg launch_id "$launch_id" --arg thread "$thread" --arg input "$brief" --arg label "$label" --arg selection_reason "$selection_reason" \
      '{lane:$lane,role:$role,title:$title,cli:$cli,provider:$provider,host:$host,project:$project,issue:$issue,worktree:$worktree,role_id:$role_id,model:$model,effort:$effort,budget:$budget,contact:$contact,launch_id:$launch_id,thread:$thread,turn:1,next_exchange:"brief",selection_reason:$selection_reason,turns:[{n:1,log:$contact,input:$input,label:$label}]}' | atomic
    pending
    if ! submit "$label"; then rm -f "$handle"; rmdir "$handle.lock"; refuse 69 'submission failed'; fi
    printf 'HANDLE: %s\n' "$handle"
    ;;
  send)
    [[ $# -eq 2 && -r $2 ]] || refuse 64 'missing argument or unreadable message'
    load "$(absolute "$1")"; input=$(absolute "$2")
    [[ -n $(jq -r '.role_id // ""' "$handle") ]] || refuse 64 "handle $handle has no role_id: it was started with --tier, which #243 removed; relaunch the lane with --role-id"
    [[ $(jq -r .role "$handle") != developer || $(jq -r .role_id "$handle") == developer ]] || refuse 64 'developer requires --role-id developer'
    worktree=$(jq -r .worktree "$handle")
    [[ -d $worktree ]] || refuse 80 "worktree $worktree is missing; recreate it or start a new lane"
    if ! mkdir "$handle.lock" 2>/dev/null; then
      if live; then refuse 75 "busy, turn $n live (pid $pid)"; fi
      refuse 76 "interrupted turn $n; run lane.sh recover $handle"
    fi
    if [[ -z $(jq -r '.thread // empty' "$handle") ]]; then rmdir "$handle.lock"; refuse 77 'provider thread or session id missing'; fi
    before=$(cat "$handle")
    n=$((n + 1)); log=${handle%.lane.json}.turn-$n.log
    label=com.whiteroom.wrsp-lane.$(jq -r .lane "$handle").$n.$(date +%s)
    jq --argjson n "$n" --arg log "$log" --arg input "$input" --arg label "$label" '.turn=$n | .contact=$log | .next_exchange=$input | .turns += [{n:$n,log:$log,input:$input,label:$label}]' "$handle" | atomic
    pending
    if ! submit "$label"; then printf '%s\n' "$before" | atomic; rmdir "$handle.lock"; refuse 69 'submission failed'; fi
    printf 'HANDLE: %s\n' "$handle"
    ;;
  read)
    [[ $# -eq 1 || ( $# -eq 3 && $2 == --cursor && $3 =~ ^[0-9]+$ ) ]] || refuse 64 'invalid read arguments'
    load "$1"; cursor=${3:-0}
    if [[ -f $log ]]; then
      size=$(wc -c < "$log"); count=$((size - cursor)); (( count >= 0 )) || count=0
      (( count <= 65536 )) || count=65536
      dd if="$log" bs=1 skip="$cursor" count="$count" 2>/dev/null
      cursor=$((cursor + count))
    fi
    printf '\nCURSOR: %s\n' "$cursor"
    ;;
  status)
    [[ $# -eq 1 ]] || refuse 64 'missing handle'; load "$1"
    jq -r '. as $h | ["lane","role","title","cli","provider","role_id","model","effort","budget","issue","worktree","thread","turn"][] | . + ": " + ($h[.] // "" | tostring)' "$handle"
    jq -r '"verification-state: \(.verification.state // "unknown")\nverification-phase: \(.verification.phase // "unknown")\nreported-model: \(.verification.reported.model // "unknown")\nreported-effort: \(.verification.reported.effort // "unknown")\nnative-source: \(.verification.source // null | tojson)\nselection-reason: \(.selection_reason // "")"' "$handle"
    printf 'state: %s\nturn-log: %s\nnext-exchange: %s\n' "$(state)" "$log" "$(jq -r .next_exchange "$handle")"
    ;;
  recover)
    [[ $# -eq 1 ]] || refuse 64 'missing handle'; load "$1"
    [[ -d $handle.lock && ! -e ${log}.exit ]] && ! live || refuse 78 'turn is not interrupted'
    printf 'EXIT:70\n' >> "$log"; printf '70\n' > "${log}.exit"
    rmdir "$handle.lock"; printf 'RECOVERED turn %s\n' "$n"
    ;;
  run-turn)
    [[ $# -eq 3 ]] || refuse 64 'missing turn'
    label=$3; trap 'remove_job "$label"' EXIT
    load "$1"
    [[ $n == "$2" && -d $handle.lock ]] || refuse 78 'turn not admitted'
    if [[ -e ${log}.pid || -e ${log}.exit ]]; then
      printf 'RESPAWN REFUSED: turn %s already ran (pid file present); run lane.sh recover %s\n' "$n" "$handle" >> "$log"
      exit 79
    fi
    launch_id=$(jq -r .launch_id "$handle"); usage_bin=${WRSP_USAGE_BIN:-wrsp-usage}
    finish() {
      local code=$1
      trap - EXIT
      if [[ $(jq -r '.verification.state // ""' "$handle") == pending ]]; then
        verification=$(jq --arg code "$code" '.verification | .state="refused" | .reason="turn aborted before native acceptance (exit " + $code + ")"' "$handle")
        save_verification
      fi
      [[ $(tail -n 1 "$log" 2>/dev/null) == "EXIT:$code" ]] || printf 'EXIT:%s\n' "$code" >> "$log"
      record_fact launch-record exit --launch-id "$launch_id" --exit-code "$code" --log "$log"
      printf '%s\n' "$code" > "${log}.exit.tmp.$$"; mv -f "${log}.exit.tmp.$$" "${log}.exit"
      rmdir "$handle.lock" 2>/dev/null || true
      remove_job "$label"
      exit "$code"
    }
    trap 'finish 70' EXIT
    printf '%s\n' "$$" > "${log}.pid.tmp.$$"; mv -f "${log}.pid.tmp.$$" "${log}.pid"
    cli=$(jq -r .cli "$handle"); model=$(jq -r .model "$handle"); effort=$(jq -r .effort "$handle")
    budget=$(jq -r .budget "$handle"); thread=$(jq -r .thread "$handle"); worktree=$(jq -r .worktree "$handle")
    input=$(jq -r '.turns[-1].input' "$handle")
    role_id=$(jq -r '.role_id // ""' "$handle")
    roles=${WRSP_ROLES_DIR:-$HOME/.agents/roles}
    if [[ $n == 1 ]]; then
      args=(launch-record start --launch-id "$launch_id" --issue "$(jq -r .issue "$handle")" --role "$(jq -r .role "$handle")" --cli "$cli" --model "$model" --effort "$effort" --worktree "$worktree" --brief "$input" --log "$log")
      [[ $cli != claude ]] || args+=(--child-session "$thread")
      record_fact "${args[@]}"
    fi
    if [[ ! -d $worktree ]]; then
      printf 'REFUSED: worktree %s is missing; recreate it or start a new lane\n' "$worktree" >> "$log"
      trap - EXIT; finish 80
    fi
    cd "$worktree"
    pending
    fail_pair() {
      verification=$(jq --arg reason "$1" '.verification | .state="refused" | .reason=$reason' "$handle")
      save_verification
    }
    [[ $(jq -r .role "$handle") != developer || $role_id == developer ]] || { fail_pair 'developer requires --role-id developer'; finish 64; }
    native_path=; offset=0
    if [[ -n $thread ]]; then
      discovery_code=0; native_path=$(native find "$cli" "$thread" 2>> "$log") || discovery_code=$?
      if [[ $discovery_code != 0 && ( $n != 1 || $discovery_code != 82 ) ]]; then fail_pair 'native transcript missing or ambiguous before bootstrap'; finish 81; fi
      # A fresh UUID normally has no file; an existing identity always starts at its current end.
      if [[ -n $native_path ]]; then offset=$(wc -c < "$native_path"); offset=${offset//[[:space:]]/}; fi
    fi
    verification=$(jq --arg path "$native_path" --argjson offset "$offset" '.verification | .source.path=(if $path == "" then null else $path end) | .source.start=$offset | .source.end=$offset' "$handle")
    save_verification
    fresh=no; [[ $n != 1 ]] || fresh=yes
    provider_command "$fresh"
    code=0; bootstrap > "$log.bootstrap.log" 2>&1 || code=$?
    if [[ $n == 1 && $cli == codex ]]; then
      thread=$(jq -Rnr 'first(inputs | fromjson? | select(.type == "thread.started") | .thread_id // empty) // empty' "$log.bootstrap.log")
      if [[ -n $thread ]]; then
        jq --arg thread "$thread" '.thread=$thread' "$handle" | atomic
        record_fact launch-record session --launch-id "$launch_id" --provider codex --session-id "$thread"
        verification=$(jq --arg thread "$thread" '.verification | .source.session=$thread' "$handle")
        save_verification
      fi
    fi
    if [[ $code != 0 ]]; then fail_pair "bootstrap CLI exited $code; see $log.bootstrap.log"; finish "$code"; fi
    [[ -n $thread ]] || { fail_pair 'native session identity missing from bootstrap'; finish 81; }
    discovered=$(native find "$cli" "$thread" 2>> "$log") || { fail_pair 'native transcript missing or ambiguous after bootstrap'; finish 81; }
    [[ -z $native_path || $native_path == "$discovered" ]] || { fail_pair 'native transcript path changed during bootstrap'; finish 81; }
    native_path=$discovered
    validate() {
      local phase=$1 validation_code=0
      verification=$(native verify --cli "$cli" --role-id "$role_id" --model "$model" --effort "$effort" --session "$thread" --transcript "$native_path" --offset "$offset") || validation_code=$?
      if [[ -z $verification ]]; then fail_pair 'native validator failed without a report'; return 81; fi
      verification=$(jq --arg phase "$phase" '.phase=$phase' <<< "$verification")
      save_verification
      return "$validation_code"
    }
    validate bootstrap || finish 81
    offset=$(jq -r .source.end <<< "$verification")
    verification=$(jq --argjson offset "$offset" '.phase="work" | .state="pending" | .reported={model:null,effort:null,nativeEffort:null} | .source.start=$offset | .source.end=$offset' <<< "$verification")
    save_verification
    provider_command no
    code=0; "${cmd[@]}" < "$input" >> "$log" 2>&1 || code=$?
    validation_code=0; validate work || validation_code=$?
    if [[ $code != 0 ]]; then
      printf 'NATIVE CLI EXIT: %s during work; pair report does not replace the native exit\n' "$code" >> "$log"
    elif [[ $validation_code != 0 ]]; then code=81; fi
    trap - EXIT; finish "$code"
    ;;
  *) refuse 64 'unknown subcommand';;
esac
