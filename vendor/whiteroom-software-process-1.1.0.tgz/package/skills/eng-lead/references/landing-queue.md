# Landing queue

The eng lead serializes review admission for one project. Developers review
and fast-forward their candidates. Receipts remain the landing authority.

1. The developer sends `X review start base..tip` with full commit IDs, issue,
   worktree, and any review in flight. This requests a slot, not permission to run.
2. The eng lead records one holder and a waiting list. Reply `go` with the exact
   range when there is no holder. A transport receipt is not go.
3. After go, the developer rebases onto reviewed main if needed. A changed
   range needs a replacement request and go. Resolve final IDs, verify, and run
   exact-range review. Keep the candidate worktree still during review.
4. Follow reviewed-main-workflow. P0/P1 stays unlanded. A clean or advisory receipt
   permits local fast-forward landing under that contract. Check main still equals
   the reviewed base. Main movement needs the normal fresh-review or eligible
   carry path with the new range. Queue permission never waives that check.
5. Send `X review done tip` with reviewed and landed tips, receipt/outcome,
   findings, corrective work, and publication needs. A failed review also sends
   done, explicitly unlanded. The eng lead acknowledges release before the next
   go. Corrections rejoin the queue.
6. On interruption or missing acknowledgment, preserve the holder. Recover the
   actual review process and main state before release. Elapsed time never proves
   release. Duplicate requests or done messages have no second effect.

## Round limit (#238)

A round is one exact-range review, initial or follow-up, whatever its outcome;
a review execution error is not a round. Rounds count per allocated task
(eng lead → developer, developer → builder), not per issue. A new lineage,
changed approach, new model or successor lane keeps the count; only Jon
re-scoping resets it.

- The eng lead counts each lane's rounds from `review start`; a developer
  counts its builders' rounds.
- Round 5 is the last. A task without a clean approval after round 5 stops. A
  builder's trip goes to its developer; a developer brings its trip to the
  eng lead with each round's range, findings and what the repair changed.
- The three-consecutive-P0/P1 breaker in reviewed-main-workflow stays the faster
  trip.
- The eng lead resolves a trip once per task: narrow the scope, split the
  task, drop the failing ambition, park it for Jon, or grant one more 5-round
  budget for a changed approach. The note names what changed; another patch on
  the same mechanism is no change. Record the decision and reason on the issue.
- A second trip goes to Jon. Finding acceptance stays Jon's.

## Publication

For publication, record the remote base, full frozen tip, required suites, and
authority source. Create a clean detached worktree at that tip. Run final suites,
collect evidence, inspect review status, and push from that checkout. Evidence
lives in the Git common directory; WRSP's pre-push hook checks that checkout's
HEAD and requires outgoing commits and peeled tags to match it.

Reviews and landings keep advancing main. There is no admission freeze. Use an
explicit `<frozen-tip>:refs/heads/main` push from the detached checkout. Verify
the remote result and log the pushed tip. Do not replace the frozen checkout's
HEAD with main's newer tip or add a newer commit without its evidence.

The eng lead owns final publication-suite submission and collection. Reuse
matching evidence and resume known jobs after transport failure. Developers
may run suites for repair or a repository's landing requirement; share job handles
to avoid duplicate submissions. A focused check is not a full suite. Every full
suite, the eng lead's included, runs on the Test Mini through
`wrsp-runner test <tip>`; a local full run on Agent Mini refuses (#256).

A changed frozen tip needs a new evidence and authority check. Split pushes only
at recorded permitted segment boundaries. Older acceptance never covers added
work. A remote race needs reconciliation and fresh checks, never an automatic
force push. Queue go grants admission, not acceptance or publication authority.
