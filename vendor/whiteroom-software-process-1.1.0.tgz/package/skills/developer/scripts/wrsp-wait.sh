#!/usr/bin/env bash
# Wait for a worker's <log>.exit completion file; exit 6 for live children, exit 7 for a refused launch.
# A live launch-worker handle that shows no model output within the produce grace exits 8;
# one whose session record stops growing for --stall seconds exits 3 (WRSP #248).
set -euo pipefail
source "$(cd "$(dirname "$0")" && pwd -P)/worker-progress.sh"

usage() {
  echo 'Usage: wrsp-wait.sh <log> [--max <seconds>] [--stall <seconds>] (completion: <log>.exit)' >&2
  exit 64
}
[[ $# -ge 1 ]] || usage
log=$1
shift
max=540
stall=${WRSP_WAIT_STALL:-600}
seen_max=0 seen_stall=0
while [[ $# -gt 0 ]]; do
  [[ $# -ge 2 && $2 =~ ^[0-9]+$ ]] || usage
  case "$1" in
    --max) [[ $seen_max -eq 0 ]] || usage; seen_max=1; max=$2 ;;
    --stall) [[ $seen_stall -eq 0 ]] || usage; seen_stall=1; stall=$2 ;;
    *) usage ;;
  esac
  shift 2
done
[[ $stall =~ ^[0-9]+$ ]] || usage
produce_grace=${WRSP_WAIT_PRODUCE_GRACE:-90}
progress=${log}.progress-seen
interval=${WRSP_WAIT_INTERVAL:-5}
start_grace=${WRSP_WAIT_START_GRACE:-60}
start=$(date +%s)

if [[ ! -e $log && ! -e ${log}.pid && ! -e ${log%.log}.prompt.md && ! -e ${log}.refused ]]; then
  echo "WAIT REFUSED: no worker log, pid or prompt at $log"
  exit 1
fi

while :; do
  if [[ -e ${log}.exit ]]; then
    code=$(cat "${log}.exit")
    if [[ -s ${log}.live ]]; then
      live_pids=$(paste -sd ' ' "${log}.live")
      echo "WORKER EXITED $code WITH LIVE CHILDREN: $live_pids"
      tail -n 60 "$log"
      exit 6
    fi
    echo "WORKER EXITED $code"
    tail -n 60 "$log"
    exit 0
  fi
  if [[ -e ${log}.refused ]]; then
    echo 'LAUNCH REFUSED'
    cat "${log}.refused"
    exit 7
  fi
  if [[ -s ${log}.pid ]] && ! kill -0 "$(cat "${log}.pid")" 2>/dev/null; then
    if [[ -e ${log}.exit ]]; then continue; fi
    echo 'WORKER EXITED unknown: no EXIT line, report missing'
    if [[ -f $log ]]; then tail -n 20 "$log"; fi
    exit 4
  fi
  elapsed=$(( $(date +%s) - start ))
  if [[ ! -e ${log}.pid ]] && (( elapsed >= start_grace )); then
    echo "WORKER NOT STARTED: no pid after ${elapsed}s; check launchctl list for the job label"
    exit 5
  fi
  # #248: a launch-worker handle (<log>.started) must show model output, then keep its session record growing; lane.sh turn handles have no .started and only report running or exited.
  if [[ -s ${log}.pid && -e ${log}.started ]]; then
    now=$(date +%s)
    seen_size= seen_at= seen_flag=
    if [[ -f $progress ]]; then read -r seen_size seen_at seen_flag < "$progress" || true; fi
    [[ $seen_size =~ ^[0-9]+$ && $seen_at =~ ^[0-9]+$ && $seen_flag == produced ]] || seen_size= seen_at=
    rec=$(worker_record_path "$log") || rec=
    if [[ -z $seen_at ]]; then
      if [[ -n $rec ]] && worker_produced "$rec"; then
        seen_size=$(worker_record_size "$rec") seen_at=$now
        printf '%s %s produced\n' "$seen_size" "$seen_at" > "$progress.tmp.$$" && mv -f "$progress.tmp.$$" "$progress"
      else
        started_at=$(stat -f %m "${log}.started" 2>/dev/null) || started_at=$now
        since=$(( now - started_at ))
        if (( since >= produce_grace )); then
          echo "WORKER NOT PRODUCING: no model output ${since}s after start; check the worker's session"
          exit 8
        fi
      fi
    else
      size=$(worker_record_size "$rec")
      if [[ $size != "$seen_size" ]]; then
        printf '%s %s produced\n' "$size" "$now" > "$progress.tmp.$$" && mv -f "$progress.tmp.$$" "$progress"
      # Whole-second clocks: strictly greater guarantees at least --stall real seconds unchanged.
      elif (( now - seen_at > stall )); then
        echo "WORKER STALLED: session record unchanged for $(( now - seen_at ))s"
        exit 3
      fi
    fi
  fi
  if (( elapsed >= max )); then
    echo "WORKER RUNNING ${elapsed}s"
    exit 2
  fi
  sleep "$interval"
done
