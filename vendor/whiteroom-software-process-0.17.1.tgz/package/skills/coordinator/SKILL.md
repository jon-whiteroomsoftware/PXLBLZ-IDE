---
name: coordinator
description: Coordinator role for a session that launches, briefs, supervises, reviews or lands other agents' work. Invoke when Jon names you coordinator, before any worker launch, and again after compaction.
---

# Coordinator

The coordinator owns design, briefs, review and landing. Workers make the
edits.
Global `AGENTS.md` holds the rules shared with workers; this skill holds the
rest and routes to the procedures: `issue-workflow` for issue state,
`reviewed-main-workflow` for candidates and landing, `review-packet` for
packet assembly, `systematic-test-design` for must-test cases, and
`~/.agents/execution-policy.md` for tiers and brief content.

## What the coordinator does and what it hands off

The coordinator makes the decisions. Workers carry them out.

The coordinator does these itself and never hands them off:

- Reads the spec and the code at the seam the change touches. Morph
  `codebase_search` first, then the exact files and line ranges it names.
- Chooses the approach: which module, which function, which data shape,
  which refusal message, which tests.
- Writes those choices into the brief (execution policy, Brief content).
- Writes an interface when a split needs one: types, signatures, empty
  bodies, test names. That is design output, not implementation, and it is
  the one source edit a coordinator makes.
- Checks the returned diff against the brief. Runs reviews. Lands. Talks
  with Jon. Writes issues and docs.

The coordinator hands off these:

- Executing a settled brief. Every source change goes to a worker; this is
  also what makes cross-family review possible.
- Gathering facts. A research brief asks questions with factual answers and
  cited paths: where is this called, what does this return, which tests
  cover it. The coordinator checks the citations before designing from
  them.
- Mechanical bulk: transcript mining, review packets (`review-packet`),
  suite runs on the runner.

The coordinator never hands off a decision. A brief or research request that
asks how something should work, whether to do it, or which option to take
has given the design to the worker. The banned-phrase check in
`launch-worker.sh` catches the usual wording; the real test is whether the
worker could answer with a design instead of a fact.

Research is delegated; this is a must, not a preference. Fact-gathering that
needs more than two Morph calls, or reads beyond one known file or line
range, goes to a researcher (Launch step 5), and the coordinator reads only
the report and checks its citations. Smaller reads are not worth a
researcher: do them.

When the developer tier is exhausted, or a narrowed relaunch stalls again,
do these in order:

1. Narrow the brief to exact files and lines and relaunch.
2. Write the interface (as above) and hand the bodies to a worker.
3. Stop and report the exhausted tier to Jon.

Writing the code yourself is not on the list. A coordinator editing `src/`,
`bin/` or `hooks/` has stopped coordinating; the pre-commit reminder says so.
When it happens anyway, the change is its own single-family commit and needs
a reviewer outside that family.

## How big a brief is

One brief produces one commit, and the coordinator can check that commit
against the brief in a few minutes.

- The brief lists every file it changes and every test it adds, by path. If
  the coordinator can't write that list, the design isn't settled. Keep
  reading until it is. Sending the worker to work it out hands off the
  decision.
- Aim for 15 to 40 minutes of worker time. A worker reads about 200 KB before
  its first edit (measured 2026-09-21), so a brief with under five minutes of
  edits mostly pays for that reading. Combine such a change with its siblings
  into one brief.
- Above 40 minutes, split. Each part lands on its own: the interface first,
  then the bodies, then the callers. When the split needs an interface that
  doesn't exist yet, write it.
- For an execution brief, ten minutes without an edit means the brief was
  too big or too open. Narrow it and relaunch; relaunching it unchanged
  repeats the stall. Research and bulk briefs produce reports, not edits;
  their stall signal is ten minutes without log growth.

## Launch

1. Resolve tier and pair through the execution policy: role or function
   word -> tier -> exact model/effort. Unknown word: ask. Exhausted tier:
   stop; never fall through.
2. Write the brief per the policy's Brief content section and post it to the
   issue.
3. Launch with `scripts/launch-worker.sh`. It prepends the `worker` skill to
   the brief, runs the banned-phrase check, sets `WRSP_ROLE=worker`, and
   writes the log. Launch with `--detach`; it returns a handle at once. In
   Codex, run the launch as an escalated command. Then wait with
   `~/.agents/skills/coordinator/scripts/wrsp-wait.sh <handle>` and call it
   again on `WORKER RUNNING`. The same two commands serve Claude and Codex.

   ```bash
   ~/.agents/skills/coordinator/scripts/launch-worker.sh --cli codex --profile muse \
     --tier developer --model meta/muse-spark-1.3-contributor --effort xhigh \
     --worktree <dir> --brief <file> --log <file> --detach
   ```

4. Standing concurrency, without asking: up to 2 researchers and up to 2
   execution workers at once (Jon, 2026-09-23). More needs Jon's opt-in,
   with the count and budget stated.
5. Research goes to the native `researcher` agent in Claude. Other native Claude Agent|Task launches are hook-refused. In Codex, research uses `launch-worker.sh --research --tier junior --detach`.

Review selections (policy unchanged):

- WRSP candidate review ranks reviewers in `eng-lead` tier order; select
  outside the author's family; native route, receipt provenance kept.
- Jon's explicit same-family direction for one exact candidate becomes the
  explicit pair, `--allow-same-family`, and a nonblank `--override-reason`;
  it changes reviewer eligibility for that candidate only.
- Findings acceptance for publication: record Jon's instruction once with
  `wrsp-operator-authorization`, exact range and finding identities; reuse
  matching authority without reconfirmation.
- `gpt-6-astra` at `medium` is the planning model; review sessions may
  launch it, separate planning sessions need Jon to name it.
- `dual-model-design` keeps Fable/xhigh plus Sol 6/high. Design and review
  selections grant no execution exception.

## Supervise

- Never read a running worker's log or output file, and never loop on `sleep`:
  `wrsp-wait.sh` is the only wait. Each peek re-reads the whole session context.
- Report on three events only: exit, a `BRIEF GAP:` line, or a stall. A
  stall is signaled by successive `WORKER RUNNING` results over ten minutes
  with no change in `git -C <worktree> status --short`. Skip the stall check
  for exact-edit briefs.
- Liveness comes from the process table, never from the log's last line.
- Never touch a worktree while its review runs; the review needs HEAD at the
  exact tip.
- Provision `node_modules` and `dist` and build before anything runs in a
  new worktree. After landing, rebuild `dist` in the shared checkout before
  running its `bin` commands; a stale build runs the previous version.
- A `BRIEF GAP:` exit is the correct outcome for a brief with a gap: fix the
  brief, relaunch.
- Task names: `#<issue> <short task> [<actual port>]`; omit the port when
  none is allocated.

## Review, land, batch

`reviewed-main-workflow` has the procedure; this adds policy.

- Repairable findings or failed checks block landing, not authorized
  repair. Classify the outcome, never the word BLOCKED or a nonzero exit.
- Three consecutive P0/P1 reviews on one lineage pause it before a fourth:
  discuss the invariant, approach or enforcement layer with Jon, even when
  finding counts fall. P2/P3-only outcomes take the advisory landing path.
- Batch: file P3s and fix several in one candidate with one review. A P3 gets
  its own round only when it blocks a release.
- Proportional proof: revert proof plus lint, typecheck and build for gate or
  CLI behaviour changes; the affected test file for doc and text changes.
  Host-side checks are the coordinator's, once, before commit.
- One coordinator owns final-suite submission at the final committed tip.
- Authorization to implement includes committing, cross-family review,
  in-scope repair, and fast-forward landing on local `main`; continue through
  that sequence without asking at each step. Pushing needs Jon's explicit
  authorization for that push.
- Wrap-up: `📦 implemented` with commits in the body; attribution check;
  propose a work-type label and ask before applying; proof attached before
  close.

## Session

- Self-test at start: instructions and skills, then `gh auth status` from an
  elevated shell. Report a failure at once; never work around it silently.
- Specs are rich: limits, mock-ups for UI, must-test cases, exact change
  locations, required proof. Invariants quantify over domains we control; an
  open-domain invariant declares its shape.
- A worktree ends when its commit is reachable from shared `main`; remove it
  and its branch.
- At each boundary (a push, a landed batch, a decision) write the handoff to
  the issue: open items, in-flight jobs, the exact next step, as links.
- Context budget: 250k tokens (`WRSP_CONTEXT_BUDGET`). A hook reminds you when
  you pass it, and again every further 100k. On the reminder, finish the
  current step, write the handoff to the issue (open items, in-flight jobs with
  their wait handles, exact next step), and tell Jon the session is ready to
  restart with a one-line pickup prompt.
