---
name: dual-model-design
description: Run a high-power, artifact-first competition between fresh Claude Fable xhigh and Codex gpt-5.6-sol xhigh workers, with anonymous candidates, blind judging, and Quick, Deliberative, or Deep weights. Compose applicable domain skills into a shared arena contract for technical design, product or UX design, Pixelblaze visual and Show design, architecture, planning, or other consequential decisions. Use when the user asks for dual-model design, a Claude-versus-Codex competition, independent proposals, blind comparison, or multi-model deliberation.
---

# Dual-Model Design

Run the competition; let domain skills define the arena. The coordinating model
must not compete, review, or adjudicate. Launch fresh high-power workers for
every reasoning role so neither the starting model nor a prior author receives
an ownership advantage.

## Preserve the model floor

- Use Claude Fable at `xhigh` for every Claude role.
- Use `gpt-5.6-sol` at `xhigh` for every Codex role.
- This workflow never authorizes Astra as a worker or subagent. An Astra
  coordinator launches the same Fable/`xhigh` and Sol/`xhigh` roles.
- Never silently substitute a cheaper model, lower effort, or the coordinating
  model. If either approved worker is unavailable, stop and report the failure.
- Scale cost by changing the number of rounds, not the quality of the workers.

The user has deliberately approved the additional reasoning cost and these
model choices for this workflow. Repository rules still govern source access,
domain behavior, and writes.

## Choose the weight

Default to **Quick** unless scope or the user calls for more:

| Weight | Fresh calls | Use |
| --- | ---: | --- |
| Quick | 3 | One bounded, thorny decision |
| Deliberative | 5 | Several coupled decisions or meaningful tradeoffs |
| Deep | 6 | Large, consequential, or difficult-to-reverse designs |

Announce the chosen weight and call count before launching workers. Read
[protocol.md](references/protocol.md) for the exact stages, stopping rules, and
blindness controls.

## Freeze the arena

1. Identify the precise decision or artifact being competed.
2. Read every applicable domain skill and its required references. Use explicit
   user-selected skills; otherwise select the smallest relevant set.
3. Distill their requirements into one solution-neutral Arena Contract using
   [arena-template.md](templates/arena-template.md). Include the objective,
   ranked criteria, facts, constraints, allowed sources, required deliverable,
   non-goals, and contamination disclosure.
4. Give every contestant and judge the same frozen contract. Never assume both
   model environments have the same skills installed; serialize the relevant
   domain rules and output contracts into the arena.
5. Keep proposed answers out of the arena. If the source already advocates a
   solution, mark the run `solution-exposed` instead of claiming unanchored
   ideation.

Domain skills determine what good work contains. For example:

- Technical work may draw from repository instructions, domain docs,
  `feature-research`, `improve-codebase-architecture`, `prototype`, and
  `technical-writing` as applicable.
- Pixelblaze work may compete on a Visual Direction Packet, Visual Performance
  Plan, or Installation Show composition using the existing PXLBLZ skills.
- UI work may use `frontend-design`, `frontend-workflow`, or a prototype skill.

Do not run a domain skill's implementation phase merely to create competing
designs. Stop each candidate at the artifact named by the Arena Contract; pass
the selected artifact into the normal downstream workflow only when asked.

## Run with anonymous scratch artifacts

Run the scripts in this order; later scripts require artifacts created by the
earlier ones:

1. Run `scripts/prepare-run.sh <workspace> <quick|deliberative|deep>` to create a
   private temporary run directory.
2. Fill and freeze its `arena.md`. Create identical candidate prompts from
   [candidate-prompt.md](templates/candidate-prompt.md).
3. Launch the initial Fable and Sol candidates concurrently when the host
   permits it. Do not ask workers to edit named proposal files; capture their
   final responses with [run-worker.sh](scripts/run-worker.sh).
4. Only after both candidates succeed, run `scripts/anonymize-candidates.sh` to
   assign Candidate A and Candidate B randomly and create A-first and B-first
   packets.
5. Only after anonymization, run
   `scripts/plan-rounds.sh <weight> <run-directory>` to randomize the
   single-judge assignment or counterbalance paired reviewers and judges.
6. Launch the reviews and judgments required by the chosen weight.

Keep raw candidates, anonymous packets, reviews, and judgments in the private
run directory.

Fresh reviewers use [review-prompt.md](templates/review-prompt.md). Fresh judges
use [judge-prompt.md](templates/judge-prompt.md) and return the complete decision
contract in [decision-template.md](templates/decision-template.md). Do not reveal
model identity before judgment or ask a participant to revise "its own" work.

## Finish tersely

Produce one durable `decision.md` by default. It must contain the decision,
locked criteria, selected design, strongest rejected alternative, lineage,
material dissent, validation, confidence, and process metadata. An explicit
`retain evidence` request may add `evidence.md` containing the anonymous inputs
and reviews.

Do not preserve routine scratch files. After verifying the durable result, run
`scripts/cleanup-run.sh <run-directory>`. If a worker fails, preserve the
temporary directory for diagnosis and report its path; never fabricate the
missing independent result.

Do not implement, commit, push, or mutate production artifacts unless the user
separately asks for the selected design to proceed.
