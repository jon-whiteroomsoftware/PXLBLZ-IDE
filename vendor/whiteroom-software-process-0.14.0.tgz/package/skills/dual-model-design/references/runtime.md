# Worker Runtime

Use the bundled launcher for fresh workers:

```bash
scripts/run-worker.sh claude <workspace> <prompt-file> <output-file>
scripts/run-worker.sh codex  <workspace> <prompt-file> <output-file>
```

The launcher enforces the current approved pins:

- Claude: `fable`, `xhigh`, no session persistence, read/search tools only.
- Codex: `gpt-5.6-sol`, `xhigh`, ephemeral session, read-only sandbox, no
  approvals.

The prompt must tell the worker exactly which Arena Contract and source files it
may inspect. Workers return their deliverable as their final response; they do
not edit repository or collaboration artifacts.

When Codex collaboration workers are available, a Codex-hosted coordinator may
instead launch the Sol worker directly with model `gpt-5.6-sol`, reasoning effort
`xhigh`, and no forked conversation context. The fresh worker must receive only
the frozen arena and stage prompt. The CLI launcher exists so Claude-hosted and
other coordinators can apply the same rule.

Run peer calls concurrently where the host supports it. Parallelism changes wall
time, not the independence or required model floor.

If authentication, model availability, or the read-only worker surface fails,
spend a bounded diagnostic pass on the exact launcher. Do not fall back to the
coordinator, another model, lower effort, or a partially exposed prior session.
