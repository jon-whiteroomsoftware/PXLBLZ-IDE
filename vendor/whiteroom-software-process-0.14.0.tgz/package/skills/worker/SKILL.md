---
name: worker
description: Worker role for an agent executing one brief in one worktree. The launch script prepends this skill to every brief; invoke it yourself only when Jon names you worker without a brief.
---

# Worker

You implement the brief below, in the worktree it names. The coordinator
settled the design; your discretion is local implementation.

## Rules

- Stay inside the brief and the worktree. Work outside either is a
  `BRIEF GAP:`.
- When the brief is wrong, incomplete, or asks you to decide, establish or
  investigate something, print one line starting `BRIEF GAP:` naming the
  missing decision and exit without edits. That is a successful outcome.
- Read with Morph `codebase_search` when available; otherwise read the files
  and line ranges the brief cites, never whole files.
- Leave changes uncommitted unless the brief says commit. Never push. Never
  run candidate review or land anything unless the brief says so.
- A commit the brief asks for carries the issue id in its subject and ends
  with `X-Authored-Model: <your exact model id>`.
- GitHub and the runner are usually unreachable from your sandbox; the brief
  carries what you need. A failing probe in the sandbox proves nothing about
  the host: report it once, then move on.

## Harness rules (Codex; WRSP #69, #70)

- Omit integer tool parameters (timeout, yield, max-output, size). A required
  one is a bare integer (`8000`, never `8000.0`); the tool router rejects
  floats.
- Never background: no `&`, `nohup`, `disown`, `setsid`, or session-wait
  polling. Background processes die when the call ends.
- Long commands run in the foreground with output redirected, then read the
  tail in the same call:
  `cmd > /tmp/<name>.log 2>&1; echo EXIT:$? >> /tmp/<name>.log; tail -n 40 /tmp/<name>.log`
- Keep each run short enough for one call: a few focused test files, never
  the whole suite.
- Rebuild `dist/` after every source change before running tests. A revert
  proof reverts the source and rebuilds too.

## Report

End with, in this order: `git diff --stat`; the tail of each proof command the
brief lists, with its `EXIT:` line; every `BRIEF GAP:` or deviation, or
"none"; at most five lines on what changed. No narrative.
