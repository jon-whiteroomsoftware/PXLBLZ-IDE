# White Room software process

Shared process tooling for repositories developed by many agents: an
exact-range review gate with immutable receipts and cross-model-family
routing, staged-test selection, and test-suite meta-checks. Consumed as a
vendored release tarball; configured per repository by one `wrsp.config.mjs`.

## The process

WRSP gates exact-range review and publication. An agent or human currently
coordinates worktrees, review admission, fast-forward landing, and final-suite
submission. The standing dispatch coordinator and automatic land-queue executor
remain target-state work.

Usage reports show token classes first and versioned list-price equivalents
second; the [usage ledger contract](docs/reference/contracts/usage-ledger.md#class-splits-and-list-price-equivalents) defines coverage and units.

```mermaid
flowchart LR
  W["Commit"] --> V["Verify"]
  V --> R["Review range"]
  R --> L["Land"]
  L --> T["Final suites"]
  T --> P["Push gate"]
```

This is the successful delivery path in this repository. The coordinator
serializes review and landing; native receipts authorize the exact candidate.
Publication independently checks contiguous coverage ending clean or explicit
finding acceptance for the exact outgoing range, then required test evidence
for the final tip. Consumer repositories retain their own suite and landing requirements.

### Principles

- Every completion claim needs evidence at the surface the consumer sees.
- Anything that should be running emits a liveness signal. Silence is an alarm.
- Humans own intent and acceptance. Machines own scheduling and verification.
- Unattended wall-clock is cheap. Tokens and human attention are not.

### State

- Repository files and issues are the durable state. Agent memory never is.
- `📦 implemented` marks issues with identified commits claiming to satisfy their implementation scope. The issue body records review, landing, release, and adoption separately. Jon owns closure; the shared `issue-workflow` skill owns label transitions.
- `AGENTS.md` instructs agents; `CLAUDE.md` is a symlink to it. `CONTEXT.md` defines domain language.
- `docs/plans/` holds proposed intent. `docs/reference/` holds as-built truth. Issues hold executable progress.
- [Engineering contracts](docs/reference/engineering-contracts.md) hold current obligations at seams inside reference; ADRs hold accepted consequential choices and rationale.

### Development

- The shared checkout stays clean on `main`. All substantive work happens in worktrees.
- One issue per slice. Slices are vertical and independently shippable.
- Each agent gets its own worktree, dev server, and synthetic identity.
- Every commit names its authoring model in an `X-Authored-Model:` trailer.
- Read applicable contracts before changing a seam. Preserve them unless the spec authorizes a change; update accepted behavior and its contract in the same slice.

### Testing

- TDD for behavior changes. Coverage concentrates in pure logic; UI stays thin.
- Oracle strategy is chosen per subsystem at design time: property-based and differential tests wherever dual implementations or invertible transforms exist.
- Contract evidence exercises the observable agreement at its interface and identifies clauses or residual gaps the cited checks do not prove.
- Meta-checks gate the suite itself: every spec runs in some gate; locators match live source.
- Flaky tests enter a registry with owner and expiry, not lore.
- Mutation testing is periodic qualification of high-risk engines, not a routine gate.

### Review and landing

- Review binds to an exact commit range. Code changes require replacement-range review; supported proof-only attachments can reuse their completed code stage.
- Direct approval is bound to exact hashes. Rewrites need fresh coverage or a qualifying content-identical carry recorded in new receipts; later policy changes preserve valid native approvals under their recorded rules.
- Review routes to the opposite model family. Fallbacks are recorded, never silent.
- P0/P1 findings create no approval and require repair, verification, and replacement-range review while the candidate converges. P2/P3 findings create advisory coverage: land that tip, then review its corrective range before publication.
- Three consecutive P0/P1-blocked reviews on one candidate lineage pause the next reviewer launch. Discuss the invariant or approach with Jon before any deliberate one-attempt acknowledgement.
- Review checks changed behavior against applicable engineering contracts and their observable evidence.
- The coordinator serializes admission: rebase onto reviewed main, review the exact range, fast-forward land, then remove the worktree.
- One final-suite owner submits required suites for the final committed tip. The publication gate consumes matching evidence.

### Publication

- Push requires a contiguous receipt chain ending clean or scoped operator acceptance of the exact outgoing range's findings, plus green required-suite evidence for the exact outgoing tip.
- Pushing requires explicit authorization. Deploying is decoupled from pushing.

### Agent-side hook protection

Jon's installed Claude and Codex command guards reject the supported Git
verification-bypass forms before execution. They cover direct commit, push,
and merge commands, including absolute paths ending in `/git`, at enumerated
shell command boundaries. Codex also has narrow forbidden prefix rules.
Wrappers, Git global options before the subcommand, aliases, and specialized
tool paths remain outside the declared scope; quoting can cause false positives.
Codex's wider user hook requires explicit trust after restart or modification.
Installation alone is not live enforcement proof. Issue #8 tracks activation.
The separate [execution policy](templates/execution-policy.md) governs worker
selection; its [host-hook adoption inputs](docs/reference/evidence/issue31-execution.md)
record the native Claude Agent/Task limitation and deployment verification.

### Dispatch target

The standing coordinator and land-queue executor are not implemented. Their
intended responsibilities are:

- Poll ready-labeled issues, spawn implementers into worktrees, and own the review and landing queue.
- Escalate stuck work as an issue comment rather than retrying silently.
- Post a periodic digest so a missing digest reveals stalled coordination.
- Keep concurrency small: extra implementers buy rebase churn, not throughput.

## Mechanism

The [local runner host guide](docs/reference/local-runner.md) records the Mac mini trust boundary, pinned prerequisites, provisioning procedure, and `wrsp-runner doctor` check.
The [test-evidence contract](docs/reference/contracts/test-evidence.md) defines how collected runner results bind to one exact tip and when the independent publication gate refuses them.

The [exact-range review engineering contract](docs/reference/contracts/exact-range-review.md)
owns the current identity, outcome, coverage, carry, freshness, and failure
obligations. This section keeps only the operational map and command context.
The [non-convergence contract](docs/reference/contracts/review-non-convergence.md)
owns repeated-terminal admission, control records, and round telemetry.

**Candidate review.** `wrsp-review-candidate <base> <tip>` resolves an explicit
Git range. It either carries eligible existing coverage into receipts for the
new identities or sends the complete commit list, every per-commit changed line,
and one shared set of unchanged endpoint context to the configured reviewer
path. The changed-line series retains intermediate edits and reversions; shared
context carries immutable revision, blob, path, and line references for
readable source inspection without repeating it around every commit. Before
either reviewer starts, the gate measures the complete request, including
project policy and systematic test-design context, and fails with the measured
size and remediation when it exceeds 1,048,576 characters. It never truncates
the review packet. Resulting immutable JSON receipts live under
`.git/wrsp/review-approvals/v1/` in the shared Git common directory.

**Non-convergence.** Completed review outcomes are immutable control facts under
`.git/wrsp/review-outcomes/v1/`. After three consecutive P0/P1 outcomes sharing
an exact base and following the current tip's ancestry, the next candidate
review exits before reviewer launch with the renegotiate-contract message.
Clean and advisory outcomes reset the streak; sibling histories do not combine.
`--acknowledge-non-convergence` admits one deliberate attempt and creates no
durable override. Every completed or refused attempt also appends best-effort
measurement to `.git/wrsp/review-rounds.jsonl`; that log never drives behavior.

**Routing.** Commits signal their authoring model with an
`X-Authored-Model:` trailer. The reviewer tier is ordered Fable High, Astra
Medium, Sol 5.6 High, then Opus 5 Extra High. For work authored by one known
model family, the route tries only reviewers from the other family in that
order. GPT-authored work therefore tries Fable, then Opus; Claude-authored work
tries Astra, then Sol.

An unavailable or unusable reviewer advances to the next eligible model. A
valid review with findings stops the route so correction can proceed. Exhausting
eligible models fails the review. Mixed-family ranges cannot establish full
cross-family coverage and need to be split; unsignalled authorship remains
explicitly unverified.

An explicit reviewer choice applies to one candidate:

```bash
npm run review:candidate -- <base> <tip> \
  --reviewer-model claude-opus-5 --reviewer-effort xhigh
```

This selects Opus 5 Extra High with no fallback. To permit a fallback, supply
both `--fallback-reviewer-model` and `--fallback-reviewer-effort` from the
supported pairs. Unsupported selections fail before provider launch. The next
invocation without selection flags uses the ranked tier.

Jon can authorize a supported same-family reviewer for one exact candidate by
supplying the explicit primary pair, the opt-in flag, and a nonblank reason:

```bash
npm run review:candidate -- <base> <tip> \
  --reviewer-model gpt-6-astra --reviewer-effort medium \
  --allow-same-family \
  --override-reason 'Jon explicitly selected Astra for this exact candidate.'
```

All four inputs are required together. The exception changes reviewer-family
eligibility for this invocation only; it does not enable implicit fallback,
mixed-family candidates, or reviewer shopping after valid findings. An
explicit fallback still requires both of its supported pair arguments. The
opt-in is rejected with `--defer-ui-proof` and `--complete-ui-proof`. The
ranked cross-family route remains the default on later invocations.

A clean same-family result writes a version-3 native receipt whose structured
provenance names the exact base/tip, reason, and explicit operator assertion.
Candidate and status output say `approved with override`, show the reviewer and
reason, and retain actual `crossFamily=false`. An unnecessary opt-in used with
a cross-family reviewer remains recorded as requested without claiming the
exception was exercised. A later check and publication of the unchanged exact
range reuse that receipt without another flag or paid review. Rewritten ranges
cannot carry it, even when their patches are byte-identical.

Native approvals retain the reviewer, effort, and policy facts that authorized
them. A later model or policy change does not revoke an existing approval;
ordinary status and push checks still require exact, contiguous commit coverage ending
in a clean approval. Runtime permission to invoke a provider remains separate.
The local receipt ledger records an operator assertion; it is not cryptographic
proof that Jon typed the instruction. Version 1 ordinary and version 2 composed
receipts remain valid, while readers that do not understand version 3 reject
its exception semantics instead of silently accepting them. Finding acceptance
for publication is implemented below; the remaining generalized requirement
adapters are tracked in issue #56.

**Accepting review findings for publication.** When Jon explicitly accepts the
findings and authorizes publication, the agent records that instruction once.
`wrsp-operator-authorization inspect <base> <tip>` returns the exact source and
finding identities plus structured permission status. Write a JSON request with
`baseSha`, `tipSha`, all returned `sourceIds`, all `findings[].id` values as
`findingIds`, and `actor`, `instruction`, `source`, and `reason`. The instruction
must actually authorize publication of this range. `expiresAt` is optional.
Run `wrsp-operator-authorization accept <request.json>` to save it, and keep the
request outside tracked source so recording authority does not change the tip.

Push and status then report `publication authorized by override`, retain the
unresolved findings, and reuse matching authority without another review or
confirmation. `list` inspects records; `revoke <id> <reason>` withdraws one.
A changed outgoing range or a new intersecting review needs new acceptance.
Tests and artifact requirements remain independent. Historical advisory receipts
work directly; older terminal reviews lack full finding identities and need a
new full review before their findings can be accepted. See the
[operator-authorization contract](docs/reference/contracts/operator-authorization.md)
for scope, compatibility, record lifetime, and the local trust boundary.

**Review outcomes.** A completed P0/P1 review reports `CANDIDATE REPAIR
REQUIRED`; an infeasible claimed contract reports `CANDIDATE CONTRACT DISCUSSION
REQUIRED` with the unsupported domain and a bounded rescope. The three-round
non-convergence breaker reports `CANDIDATE REVIEW PAUSED` before a fourth launch;
provider, prerequisite, validation, and other gate execution failures report
`CANDIDATE REVIEW ERROR`. Each remains nonzero. The [exact-range review
contract](docs/reference/contracts/exact-range-review.md) owns decision bounds
and coverage; feasibility discussion leaves the deterministic breaker unchanged.

For an ordinary completed candidate review:

```mermaid
flowchart TD
  R["Review result"] -->|"Clean or P2/P3 only"| C["Record coverage"]
  R -->|"P0/P1"| F["Repair and verify"]
  F --> N{"3 consecutive blocking rounds?"}
  N -->|"No"| V["Review replacement range"]
  N -->|"Yes"| D["Discuss before another review"]
  R -->|"Contract infeasible"| D
```

A provider or prerequisite failure supplies no review judgment or approval.
Missing proof can be retried at its own stage. Neither changes the blocking
streak, and switching workers never resets that streak.

**Carry diagnostics.** Every carry attempt appends one JSON line to
`.git/wrsp/carry-log.jsonl` with a carried, refused, or no-candidate outcome.
This telemetry makes refused-carry cost measurable without making the log an
approval authority.

**Serialization.** Concurrent reviews queue on `.git/wrsp/review.lock`,
claimed by `mkdir` (the one POSIX create-if-absent that refuses even an empty
existing directory). Locks are never reaped automatically; a dead holder fails
the run with explicit cleanup instructions, exactly like git's `index.lock`.

**Publication.** The pre-push hook reads Git's ref-update packet and checks the
relevant outgoing ranges against stored receipts. Missing coverage prints the
exact `review:candidate` command; pre-push never repeats substantive review,
then enforces the repository's publication checks. Runner-enabled consumers
can require [exact-tip test evidence](docs/reference/contracts/test-evidence.md)
from their configured authoritative suites. Their hook consumes those records;
it does not execute the same suites again. This package's `.husky/pre-push`
requires the configured `package-tests` evidence after review coverage. Run
`node bin/wrsp-runner.mjs test HEAD` on the final committed tip before pushing.
A valid same-family override receipt changes only review coverage; missing
required test evidence still blocks this hook independently.

**Staged-test selection.** `wrsp-test-staged` typechecks when staged paths can
affect a TypeScript project, runs staged and colocated tests, and adds fixed
regression suites for configured high-risk boundaries. A boundary may use the
default Vitest command or a named specialized runner. Exact paths and prefixes
are authoritative ownership; staged-content predicates inspect additions and
deletions only to advise when a matching file has no owner. Renames preserve
both old and new paths, so moving a covered source cannot shed its gate. When
a test is selected by a specialized runner, that ownership removes the same
test from default focused and invariant work instead of running it twice.

**Layout fault gate.** `findLayoutFaults` walks a rendered subtree and returns
structured collapsed-text, overflow, containment-escape, and must-fit faults.
Consumers declare intentional overflow or escape and ignored subtrees through
DOM annotations instead of maintaining product-specific forks of the detector.
Rendered text uses browser text rectangles rather than `clientWidth`, which is
legitimately zero for inline elements.

`wrsp-check-layout-gate` runs a consumer-owned browser test through a configured
runner. The package fixture contains both a 64px positive control and a
deliberate overflow. The command must exit zero and emit exactly one valid
report; zero-width/no-layout controls, missing or wrong faults, missing,
duplicate, or malformed reports, and command failures all fail closed. This
proves real geometry. The consumer separately proves that its production
stylesheet and fonts are loaded, because the package cannot know those
product-specific entrypoints.

Consumers import the browser-safe modules through
`@whiteroom/software-process/layout-faults` and
`@whiteroom/software-process/layout-canary`. The auditor recognizes three
policy annotations by default:

- `data-layout-ignore` excludes a complete subtree.
- `data-layout-allow="overflow-x overflow-y escape-x escape-y"` records
  intentional geometry; `escape` permits both axes.
- `data-layout-must-fit` requires the element's full horizontal content to
  remain visible even when ordinary overflow is allowed.

The nearest enclosing `data-testid` becomes the stable location in each fault.
Options can replace the annotation and location names or supply measurement
adapters for contract tests.

**UI proof gate.** A green component or jsdom suite says nothing about the
route a user actually opens, and "done" claims backed by nothing else were the
audit's largest automatable failure cluster. When a consumer commits a
`wrsp-ui-proof.json` policy file at the repository root —
`{ "pathPatterns": ["^src/components/", "\\.css$"], "proofDirectory":
".wrsp/ui-proof" }` (proofDirectory optional) — an ordinary candidate review
whose diff touches any matching path requires at least one valid,
fresh UI proof record before reviewer launch: a JSON file in the proof
directory of the form
`{ "version": 1, "issue": "861", "route": "/studio/shows/new", "operation":
"Create a three-scene Show and play it through", "captures":
["docs/proof/new-show.png"], "capturedAtCommit": "<full commit id>" }`.
Records and captures are read from the candidate tip's tree, never the live
filesystem — an untracked file or a path outside the repository cannot
satisfy a gate whose approval covers the exact range. Captures must carry
real screenshot or recording bytes (PNG, JPEG, WebM, or MP4 magic bytes) — a
passing test run has no such artifact to point at. The record doubles as the
proof attached to the issue.

Freshness binds proof to content: `capturedAtCommit` must be a full immutable
commit id (a ref like `HEAD` would re-resolve to every future tip) that is an
ancestor of (or equal to) the candidate tip, with no UI-pattern path changed
since; diffs run rename-blind so renaming a matched file away still counts as
changing it. Only the record files themselves and captures validated as real
capture bytes are exempt from counting as UI-affecting changes — a rejected
record's claimed "captures" stay in the triggering set — so committing honest
proof cannot trigger the gate or mark the proof stale, and dishonest records
cannot erase the paths that triggered it. The normal flow is capture at the
implementation commit, then commit the record and captures as the tip. A
stale or malformed record is reported but does not veto a separate valid
fresh record; everything ambiguous fails closed.

Policy binds to the range, not the checkout — and it is deliberately a
pure-data file rather than a `wrsp.config.mjs` section, because the gate
must evaluate policy at historical revisions and executable configuration
cannot be trusted there: code controls its own output and serialization,
reads files that resolve against the wrong revision, and cannot be
faithfully materialized. The gate reads `wrsp-ui-proof.json` as a blob from
BOTH ends of the range and gates the candidate under the union, so a range
that narrows or deletes the policy is still held to the policy it started
from, while policy changes stay reviewable as ordinary candidates. A policy
file that exists but cannot be read or parsed fails closed; whatever branch
the check happens to run from can never substitute its own patterns.
`wrsp-review-candidate` ordinarily enforces the gate before taking the review lock;
`wrsp-check-ui-proof <base> <tip>` runs the same check standalone for
self-checks and hooks.

Code review can also start while captures are produced:

```mermaid
flowchart LR
  T["Code tip"] --> C["Code review"]
  T --> B["Browser captures"]
  C --> P["Pending code<br/>record"]
  B --> E["Proof-only<br/>commit"]
  P --> I["Review actual<br/>images"]
  E --> I
  I --> A["Composed<br/>coverage"]
```

The diagram shows successful composition: pending code supplies no approval.
Both stages must complete with clean or advisory outcomes; advisory findings
remain visible in the composed receipt and need correction before publication.
Source or policy changes require replacement-code review.

```sh
wrsp-review-candidate <base> <code-tip> --defer-ui-proof
# Commit a supported complete proof-only package, then:
wrsp-review-candidate <base> <final-tip> --complete-ui-proof <pending-id>
```

The first command reports an awaiting-proof identity, with no approval. The
second reviews actual PNG/JPEG images and the proof-only history, then records
both reviewer scopes in final exact-range coverage. Missing or insufficient
proof preserves the completed code review. See the [UI proof composition
contract](docs/reference/contracts/ui-proof-composition.md) for supported
attachments, retry behavior, limits, and historical receipt compatibility.

**Exported-artifact oracle.** Generator-internal assertions cannot prove that
the file a consumer opens contains the intended result. Consumer oracle tests
call `runArtifactOracle` with the real export entrypoint and assertions over
the exported bytes. The helper rejects a missing or empty export, reads the
file before invoking those assertions, then emits one versioned report naming
the deliverable and recording its path, byte count, and sha256 digest.

`wrsp-check-artifact-oracle` runs every configured deliverable test, using the
built-in Vitest/basic command unless that deliverable names a specialized
runner. Each command must exit zero and emit exactly one valid report whose
name matches the configured deliverable and whose byte count is positive.
Command errors and nonzero exits, absent, duplicate, malformed, mismatched, or
zero-byte reports all produce a per-deliverable failure. The checker evaluates
every deliverable before failing the gate, so one broken export cannot hide
another. Consumers import the Node-safe helper through
`@whiteroom/software-process/artifact-oracle`.

**Suite meta-checks.** `wrsp-check-e2e-coverage` fails when an authenticated
Playwright spec is named by no npm script — an unrun spec is indistinguishable
from a passing one. `wrsp-check-e2e-locators` fails when a spec names a
user-facing string live source no longer produces, with a shrink-only ratchet
for known staleness and a separate never-gating bucket for names assembled
mostly from runtime data.

**Environment preflight.** A probe that fails inside an agent sandbox is not
evidence about host state, and the audit counted seven "gh auth is broken /
the network is down" claims manufactured exactly that way. `wrsp-preflight
blocker <gh-auth|network> [--host]` runs a sandbox canary first — an
attempted write outside the workspace root, which agent sandboxes deny — and
a denied canary yields `SANDBOX-LOCAL` (exit 3) regardless of the probe
result and regardless of `--host`: the canary is direct evidence of a
sandbox, so it vetoes a mistaken attestation. A passing probe is `HOST OK`
(a real success is real anywhere). A failing probe is promoted to
`HOST FAILURE` only under an explicit `--host` attestation that the shell
runs unsandboxed — a write canary proves only filesystem freedom, and a
sandbox can allow the write while still blocking network or credential
access — otherwise the verdict is `INDETERMINATE` (exit 3) with the
re-run-elevated instruction, so no blocker claim reaches the user on
sandbox-shaped evidence. `wrsp-preflight
worktree` refuses substantive work started in the shared checkout (a linked
worktree's git dir differs from the common dir — mechanical, no path
conventions), and `wrsp-preflight port <n>` reports the owning process of a
port collision before a dev server claims it, instead of after the second
server wedges the first.

**Worktree setup order.** A fresh worktree has no dependencies and no build
output, so run `npm ci`, then `npm run build`, then
`npm run preflight -- worktree` — in that order. `npm run preflight`
invokes `node bin/preflight.mjs`; a missing `dist/` refuses fail-closed
naming its remedy (`npm ci` first when `node_modules/` is also missing,
otherwise `npm run build`). Presence of `dist/` alone is sufficient to run:
installed consumers carry build output without `node_modules/`.
Without network, copy both directories from the
shared checkout with `cp -a` (plain `cp -r` breaks the `node_modules/.bin`
symlinks): `cp -a ~/src/<repo>/node_modules ~/src/<repo>/dist <worktree>/`,
then `npm run build` when tooling allows.

**Closed-issue proof check.** Issues name their required proof at planning
time (a `## Required proof` section: which surface, which cases) and attach
the evidence before close. `wrsp-check-issue-proof [--since-days N]` makes
the closure half mechanical: every issue closed as completed in the window
must have a non-empty `## Required proof` section and an attached proof — a
line beginning `Proof:` with content, in the body or any comment. Issues
closed as not planned are exempt. The check exits nonzero listing each
violating issue, so it runs standalone, in CI, or as a periodic sweep. It
proves a proof was attached, not that it is honest or sufficient — that
stays with candidate review. It is a best-effort audit report over an
eventually consistent tracker API: every detectable inconsistency —
truncated listings, unstable or duplicate-bearing pagination walks,
malformed timestamps, unknown arguments — fails closed, but transactional
completeness against concurrent tracker mutation is impossible over this
API and is not claimed; a closure racing one run is caught by the next
sweep.

## Adoption

Adopt executable WRSP tooling from the vendored release tarball. Adopt process
guidance and templates from the same tagged source: start with
[`templates/engineering-contract.md`](templates/engineering-contract.md), put
current contracts under the consumer's reference tree, and point project
instructions to the applicable contracts. The
[engineering-contract guidance and distribution manifest](docs/reference/engineering-contracts.md#adoption-and-distribution-manifest)
records the canonical shared-skill sources and their separate deployment path.
Execution workers follow the [execution policy](templates/execution-policy.md);
adopt its canonical reference together with the global instruction pointer and
[reviewed host-hook inputs](docs/reference/evidence/issue31-execution.md).

1. **Install** from a vendored release tarball. In this repository, at the
   release tag, run `npm pack` and commit the tarball into the consumer
   (e.g. `vendor/whiteroom-software-process-0.4.0.tgz`):

   ```json
   "devDependencies": {
     "@whiteroom/software-process": "file:vendor/whiteroom-software-process-0.4.0.tgz"
   }
   ```

   A `file:` tarball needs no credentials, so clean `npm ci` succeeds in
   unauthenticated builders — CI runners and git-integrated deploy builds
   (Cloudflare Pages) included. A `github:...#tag` pin on this private
   repository works only where GitHub credentials are available and will
   break any unauthenticated build; use it for local-only experiments, not
   for a repository that deploys. Upgrading is replacing the tarball and
   updating the pinned filename. Add the repository to the Consumers list in
   this package's `AGENTS.md` in the same change that vendors the first
   tarball — that list is how releases find every repository needing a bump.

   Codex users can optionally install the [candidate-review allowance](docs/reference/codex-review-allowance.md)
   to reduce repeated review-launch prompts across trusted projects. This is a
   user setting activated by restarting Codex; no application deployment is needed.

2. **Configure** with an optional `wrsp.config.mjs` at the repository root.
   Every section is optional; defaults suit a plain TypeScript repository.

   ```js
   export default {
     review: {
       // Appended to the review prompt. Participates in the policy
       // fingerprint: receipts retain the policy used for their review.
       projectPolicy: 'Project-specific reviewer instructions.',
     },
     selection: {
       typecheckExact: ['vite.config.ts'],
       typecheckPatterns: ['^src/.*\\.[cm]?[jt]sx?$'],
       typecheckArgs: ['tsc', '-b', 'tsconfig.json', '--pretty', 'false'],
       runners: {
         layout: ['npm', 'run', 'test:layout', '--'],
         node: ['node', '--test'],
       },
       boundaries: [
         {
           name: 'compiler',
           exact: ['src/engine/compiler.ts'],
           prefixes: ['src/engine/passes/'],
           tests: ['src/engine/compiler.test.ts'],
         },
         {
           name: 'controller-layout',
           exact: ['src/components/ControllerPanel.tsx'],
           tests: ['src/components/ControllerPanel.layout.test.tsx'],
           runner: 'layout',
         },
       ],
       advisories: [{
         name: 'unmapped-layout-change',
         pathPatterns: ['^src/.*\\.(tsx|css)$'],
         // Regexes inspect staged additions and deletions.
         diffPatterns: ['(?:flex|grid|min-w-|overflow-|truncate)'],
         message: 'Add the affected surface to the layout manifest.',
       }],
     },
     layout: {
       runner: 'layout',
       canaryTest: 'src/test/layout-canary.layout.test.ts',
     },
     artifacts: {
       deliverables: [
         {
           name: 'show-export',
           test: 'src/export/show-export.oracle.test.ts',
           runner: 'node',
         },
       ],
     },
     e2e: {
       specDirectory: 'e2e',
       authSpecSuffix: '.auth.spec.ts',
       staleLocatorAllowlist: 'e2e/known-stale-locators.json',
       liveSourceDirectory: 'src',
     },
   }
   ```

3. **Wire npm scripts** to the bins, keeping the canonical names:

   ```json
   "review:candidate": "wrsp-check-node && wrsp-review-candidate",
   "review:status": "wrsp-check-node && wrsp-review-status",
   "review:push": "wrsp-check-node && wrsp-review-push",
   "test:staged": "wrsp-check-node && wrsp-test-staged",
   "check:artifact-oracle": "wrsp-check-artifact-oracle",
   "check:layout-gate": "wrsp-check-layout-gate",
   "check:ui-proof": "wrsp-check-ui-proof",
   "check:e2e-coverage": "wrsp-check-e2e-coverage",
   "check:e2e-locators": "wrsp-check-e2e-locators"
   ```

   The consumer canary test must match the configured real-browser project:

   ```ts
   import { expect, it } from 'vitest'
   import {
     assertLayoutCanaryReport,
     formatLayoutCanaryReport,
     runLayoutCanary,
   } from '@whiteroom/software-process/layout-canary'

   it('proves the layout runner can measure', () => {
     const report = runLayoutCanary()
     console.log(formatLayoutCanaryReport(report))
     expect(assertLayoutCanaryReport(report)).toBe(report)
   })
   ```

   Add a consumer-owned sentinel that asserts a production CSS utility's
   computed geometry after `document.fonts.ready`. The package canary's inline
   styles prove browser measurement, not product stylesheet fidelity.

4. **Install hooks** from `hooks/` into `.husky/` (or your hook manager),
   adjusting publication checks to the repository. For runner-enabled
   consumers, declare required suites and have pre-push check their exact-tip
   evidence. Keep the [verification plan](docs/reference/local-runner.md#verification-plan)
   aligned with the actual hook; copying a hook does not wire evidence reuse.
   Include `hooks/prepare-commit-msg`: it records an available provider session
   identity without blocking commits. Ambiguous nested-provider environments
   leave attribution to the reader; see the [session join contract](docs/reference/contracts/usage-ledger.md#mandatory-reader-and-query).
   Name task worktrees `<repo>-issue-<n>-<slug>` so session queries can recover
   the issue when no trailer exists. `wrsp-preflight worktree` warns on missing
   issue segments while retaining the linked-worktree success status.

5. **Round-trip once**: commit on a branch, run
   `npm run review:candidate -- <base> <tip>`, confirm the receipt with
   `npm run review:status -- <base> <tip>`, land with `git merge --ff-only`,
   and push through the gate.

## Development

`npm test` runs the package's own suite. The repository dogfoods its own gate:
commits are reviewed through `npm run review:candidate` and pushes pass
through the evidence-consuming `.husky/pre-push`. The generic `hooks/pre-push`
template retains direct local tests for consumers that have not adopted runner
evidence.

### Reusable authenticated captures

Consumers can import `captureScenario` from
`@whiteroom/software-process/capture-scenario` and supply their maintained
browser adapter. A named scenario declares route, viewport, synthetic session,
distinct device count and visible prerequisites. WRSP checks those observations
around capture and writes an external, copy-ready package containing the current
UI proof record and PNG. Inspect it, commit its proof files, then run authoritative
verification on the final clean tip. See the
[capture scenario contract](docs/reference/contracts/capture-scenarios.md) for
adapter ownership, failure cleanup and the unchanged proof boundary.

### Collect local agent usage

`wrsp-usage ingest` saves Claude Code and Codex transcript counters as session
summaries and copies them to the configured runner's usage ledger. The command
scans every Claude project directory, including subagents, and every Codex
session directory. It makes no model calls. Run it daily so Claude's default
30-day non-desktop retention does not erase usage before collection:

```sh
wrsp-usage ingest
wrsp-usage sessions --since 7
wrsp-usage sessions --since 7 --json
```

The sessions view shows lifetime counters for sessions active within the chosen
window, grouped by provider, model, and effort. Input, output, cache, and reasoning
classes remain separate. Child sessions have their own identity and count once;
legacy worker totals remain labeled `wrapper-reported`. Issue association is a
reader-derived rule, so the saved summaries remain raw facts. Unknown model or
effort stays unknown. This slice provides no rates or price estimates.

The [usage ledger contract](docs/reference/contracts/usage-ledger.md#transcript-sessions)
owns counters, cursor recovery, local paths, and shipping semantics. Session rows
are stored in JSONL only. The dashboard’s `/issues` view presents transcript
sessions alongside issue process records, with separate source subtotals; the
version-1 board JSON and commit notes retain their existing scope. The `/` and
`/machine` view brings slot, suite, job and host facts together with issue links and observed
live activity, without usage figures. See the
[issue view](docs/reference/contracts/runner-dashboard.md#issue-process-view).
The [Work home](docs/reference/contracts/runner-dashboard.md#work-home) groups project activity into local-day windows with issue-number and title filtering.

Refresh the known Mini issue titles using the laptop's GitHub CLI login:

```sh
wrsp-usage sync-titles --json
wrsp-usage ingest --sync-titles --json
```

The first command backfills retained issues without reading transcripts. The
second also refreshes titles when transcript files are unchanged; title failures
do not fail token collection. `--dashboard-url` (or `WRSP_DASHBOARD_URL`) selects
the target dashboard, defaulting to `http://10.42.0.2:8642`; SSH publication uses
the configured runner host. Select the dashboard belonging to that same runner.
The summary reports skipped/missing coverage and operational failures. Work and
issue detail show cache freshness on hover. See the
[title cache contract](docs/reference/contracts/issue-title-sync.md).

To opt the existing daily collector into title refresh, add `--sync-titles` to
its `ProgramArguments` and ensure its `PATH` includes the installed `gh` binary.
Keep its existing schedule. Authentication stays on the laptop.

Upgrade a runner's mandatory reader before treating its unknown-kind diagnostic
as a transcript-data failure.

For optional daily laptop collection, copy
[`templates/wrsp-usage-ingest.plist`](templates/wrsp-usage-ingest.plist) to
`~/Library/LaunchAgents/com.whiteroom.wrsp-usage-ingest.plist`. Replace each
placeholder with an absolute path. Use a real Node binary and a stable installed
WRSP build that includes `dist/`, outside a disposable worktree. Launchd does not
expand shell variables in `ProgramArguments`; keep the runner destination in
`~/.config/wrsp/runner.json`. Create `~/.local/state/wrsp/ingest/` first for the
output logs, validate the filled plist with `plutil -lint`, then load it with:

```sh
launchctl bootstrap "gui/$(id -u)" "$HOME/Library/LaunchAgents/com.whiteroom.wrsp-usage-ingest.plist"
launchctl print "gui/$(id -u)/com.whiteroom.wrsp-usage-ingest"
```

Inspect `launchd.stdout.log` and `launchd.stderr.log` in the ingest state directory
for counts and failures. The template runs on load and every 86,400 seconds;
sleep and logout can delay collection. Manual `ingest` also retries pending
shipping even when transcripts have not grown. Installing this optional schedule
is an explicit operator action; the command never installs hooks or a job itself.

An abruptly killed collector can leave `ingest.lock` behind. Subsequent attempts
exit with an error in `launchd.stderr.log` instead of writing competing cursors.
Inspect the recorded owner before removing the lock:

```sh
cat "$HOME/.local/state/wrsp/ingest/ingest.lock"
ps -p "$(cat "$HOME/.local/state/wrsp/ingest/ingest.lock")" -o pid,lstart,command
```

If `ps` shows no process for that PID, the owner has exited; remove that exact
lock and run a manual collection to verify recovery:

```sh
rm "$HOME/.local/state/wrsp/ingest/ingest.lock"
wrsp-usage ingest --json
```

If the PID still exists, leave the lock in place until its owner is confirmed
finished. An invalid lock PID or corrupt cursor file requires inspection; deleting
cursor state to clear an error can replay old summaries. The mandatory reader
collapses repeated versions, but preserving state avoids unnecessary shipping.

## Typed work issues

The [typed issue guide](docs/reference/work-types.md) covers catalog adoption,
human and agent creation, bounded sessions and corrections. `wrsp-work-types`
provides catalog, plan/apply/check, and diagnostic issue inspection.
