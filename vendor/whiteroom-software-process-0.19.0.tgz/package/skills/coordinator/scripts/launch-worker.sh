#!/usr/bin/env bash
# Launch one execution worker with the worker skill prepended to its brief.
# WRSP #114. Sets WRSP_ROLE=worker so the pre-commit reminder stays silent.
set -euo pipefail

usage() {
  cat >&2 <<'USAGE'
Usage: launch-worker.sh --cli <codex|claude> --tier <name> --model <id> --effort <level>
                        --worktree <dir> --brief <file> --log <file>
                        [--profile <codex-profile>] [--allow-phrase-hits] [--research] [--dry-run] [--detach]
                        [--launchd-label <label> (internal)]
Composes <worker skill body> + <brief> into <log>.prompt.md, refuses briefs
that fail the execution policy's banned-phrase check, and runs the worker in
the foreground with all output in <log>. --detach submits it to launchd.
USAGE
  exit 64
}

cli= tier= model= effort= worktree= brief= log= profile= allow_hits=0 research=0 dry_run=0 detach=0 launchd_label= before=
cleanup() {
  if [[ -n $before ]]; then rm -f "$before"; fi
  if [[ -n $launchd_label ]]; then launchctl remove "$launchd_label" >/dev/null 2>&1 || true; fi
}
while [[ $# -gt 0 ]]; do
  case "$1" in
    --cli|--tier|--model|--effort|--worktree|--brief|--log|--profile|--launchd-label) [[ $# -ge 2 ]] || usage ;;
  esac
  case "$1" in
    --cli) cli=$2; shift 2 ;;
    --tier) tier=$2; shift 2 ;;
    --model) model=$2; shift 2 ;;
    --effort) effort=$2; shift 2 ;;
    --worktree) worktree=$2; shift 2 ;;
    --brief) brief=$2; shift 2 ;;
    --log) log=$2; shift 2 ;;
    --profile) profile=$2; shift 2 ;;
    --allow-phrase-hits) allow_hits=1; shift ;;
    --research) research=1; shift ;;
    --dry-run) dry_run=1; shift ;;
    --detach) detach=1; shift ;;
    --launchd-label) launchd_label=$2; trap cleanup EXIT; shift 2 ;;
    *) usage ;;
  esac
done
[[ -n $cli && -n $tier && -n $model && -n $effort && -n $worktree && -n $brief && -n $log ]] || usage
case "$cli" in codex|claude) ;; *) usage ;; esac
if [[ -z $launchd_label ]]; then
  members=${WRSP_TIER_MEMBERS:-$HOME/.agents/tiers.members}
  [[ -s $members ]] || { echo "Tier members not found: $members. Run wrsp-agents install or wrsp-agents tiers apply." >&2; exit 66; }
  member_effort=$effort
  [[ $member_effort == medium ]] && member_effort=med
  if ! grep -qxF "$(printf '%s\t%s\t%s' "$tier" "$model" "$member_effort")" "$members"; then
    echo "Refusing launch: $model / $effort is not a member of tier $tier in $members. Launch a listed member, or edit ~/.agents/tiers.yaml and run wrsp-agents tiers apply." >&2
    exit 65
  fi
fi
if [[ $research -eq 1 && $cli == claude ]]; then
  echo '--research runs on the codex route; Claude research uses the native researcher agent.' >&2
  exit 64
fi
[[ -d $worktree ]] || { echo "Worktree not found: $worktree" >&2; exit 66; }
# A worktree whose configured hooks directory is missing commits without
# running any hook, and git says nothing (#137). Same rule as
# wrsp-preflight worktree: a relative core.hooksPath resolves against the
# worktree's top level. Research launches never commit; the launchd child
# was already checked at submission.
if [[ -z $launchd_label && $research -eq 0 ]]; then
  if hooks_configured=$(git -C "$worktree" config --type=path --get core.hooksPath 2>/dev/null) \
    && [[ -n $hooks_configured ]] \
    && hooks_top=$(git -C "$worktree" rev-parse --show-toplevel 2>/dev/null); then
    hooks_resolved=$hooks_configured
    [[ $hooks_resolved == /* ]] || hooks_resolved=$hooks_top/$hooks_resolved
    if [[ ! -d $hooks_resolved ]]; then
      case "$hooks_configured" in
        .husky/_|.husky/_/|*/.husky/_|*/.husky/_/)
          remedy="Run \`npx husky\` in $hooks_top (it needs no network), or copy \`.husky/_\` from the shared checkout, then relaunch." ;;
        *)
          remedy="Install the repository's hooks in $hooks_top so the configured hooks directory exists, then relaunch." ;;
      esac
      echo "Refusing launch: git hooks are not installed in this worktree. core.hooksPath is \"$hooks_configured\", which resolves to $hooks_resolved, and that directory does not exist, so commits there run no hooks. $remedy" >&2
      exit 66
    fi
  fi
fi
[[ -s $brief ]] || { echo "Brief missing or empty: $brief" >&2; exit 66; }
[[ ! -e $log ]] || { echo "Refusing to overwrite log: $log" >&2; exit 73; }
[[ -d $(dirname "$log") ]] || { echo "Log directory not found: $(dirname "$log")" >&2; exit 66; }
if [[ -n $launchd_label ]]; then
  printf '%s\n' "$$" > "${log}.pid.tmp.$$" && mv -f "${log}.pid.tmp.$$" "${log}.pid"
fi

if [[ $research -eq 1 ]]; then
  skill=${WRSP_RESEARCH_SKILL:-$(cd "$(dirname "$0")/../../researcher" && pwd -P)/SKILL.md}
else
  skill=${WRSP_WORKER_SKILL:-$(cd "$(dirname "$0")/../../worker" && pwd -P)/SKILL.md}
fi
if [[ $skill != /* ]]; then skill="$(cd "$(dirname "$skill")" && pwd -P)/$(basename "$skill")"; fi
[[ -s $skill ]] || { echo "Worker skill not found: $skill" >&2; exit 66; }

# Execution policy, Brief content rule 3.
pattern='establish|decid|decis|choos|choic|determin|investigat|explor|(find|figur)[a-z]* +out'
if [[ -z $launchd_label && $research -eq 0 ]]; then
  if hits=$(grep -niE "$pattern" "$brief") && [[ $allow_hits -eq 0 ]]; then
    echo "Brief fails the banned-phrase check (execution policy, Brief content 3). Remove or relaunch with --allow-phrase-hits after justifying each in the brief:" >&2
    printf '%s\n' "$hits" >&2
    exit 65
  fi
fi

prompt=${log%.log}.prompt.md
if [[ -z $launchd_label ]]; then
  if [[ $dry_run -eq 1 ]]; then
    # A dry run composes into its own file so the real launch's prompt path stays free.
    prompt=${log%.log}.dry-run.prompt.md
  else
    [[ ! -e $prompt ]] || { echo "Refusing to overwrite prompt: $prompt" >&2; exit 73; }
  fi
  {
    # Strip the skill's YAML frontmatter; the body is the worker's instructions.
    awk 'NR==1 && $0=="---" {skip=1; next} skip && $0=="---" {skip=0; next} !skip' "$skill"
    printf '\n---\n\n# Brief (tier:%s, %s / %s)\n\n' "$tier" "$model" "$effort"
    cat "$brief"
  } > "$prompt"
fi

worktree=$(cd "$worktree" && pwd -P)
abs_brief="$(cd "$(dirname "$brief")" && pwd -P)/$(basename "$brief")"
abs_log="$(cd "$(dirname "$log")" && pwd -P)/$(basename "$log")"
abs_self="$(cd "$(dirname "$0")" && pwd -P)/$(basename "$0")"
if [[ $cli == codex ]]; then
  role=worker
  [[ $research -eq 1 ]] && role=researcher
  cmd=(env "WRSP_ROLE=$role" codex exec)
  [[ -n $profile ]] && cmd+=(-p "$profile")
  cmd+=(-m "$model" -c "model_reasoning_effort=$effort")
  [[ $research -eq 1 ]] && cmd+=(-s read-only --skip-git-repo-check)
  cmd+=(-C "$worktree" -)
else
  cmd=(env WRSP_ROLE=worker claude -p --model "$model" --effort "$effort" --permission-mode acceptEdits)
fi

if [[ $detach -eq 1 ]]; then
  label_name=$(basename "$log" .log)
  label="com.whiteroom.wrsp-worker.${label_name//[^A-Za-z0-9.-]/-}.$(date +%s)"
  relaunch_args=(--cli "$cli" --tier "$tier" --model "$model" --effort "$effort" --worktree "$worktree" --brief "$abs_brief" --log "$abs_log")
  [[ -n $profile ]] && relaunch_args+=(--profile "$profile")
  [[ $research -eq 1 ]] && relaunch_args+=(--research)
  skill_var=WRSP_WORKER_SKILL
  [[ $research -eq 1 ]] && skill_var=WRSP_RESEARCH_SKILL
  submit=(launchctl submit -l "$label" -- /usr/bin/env "PATH=$PATH" "HOME=$HOME" "TMPDIR=${TMPDIR:-/tmp}" "$skill_var=$skill" /bin/bash "$abs_self" "${relaunch_args[@]}" --launchd-label "$label")
fi

if [[ $dry_run -eq 1 ]]; then
  echo "PROMPT: $prompt"
  printf 'COMMAND:'; printf ' %q' "${cmd[@]}"; printf ' < %q > %q 2>&1\n' "$prompt" "$log"
  echo "CWD: $worktree"
  if [[ $detach -eq 1 ]]; then printf 'SUBMIT:'; printf ' %q' "${submit[@]}"; printf '\n'; fi
  exit 0
fi

command -v "$cli" >/dev/null || { [[ $detach -eq 1 ]] && rm -f "$prompt"; echo "$cli is not on PATH." >&2; exit 69; }
if [[ $detach -eq 1 ]]; then
  if ! "${submit[@]}"; then
    rm -f "$prompt"
    echo 'LAUNCH REFUSED: launchctl submit failed (in Codex, run this launch as an escalated command)'
    exit 69
  fi
  echo "HANDLE: $(cd "$(dirname "$log")" && pwd -P)/$(basename "$log")"
  echo "LABEL: $label"
  exit 0
fi

# Provenance for hooks/coordinator-reminder.sh. A snapshot maps every dirty or
# untracked path to a content hash; the paths whose hash changed or appeared
# during the run are the ones this worker touched. Paths the coordinator left
# dirty before the launch and the worker never changed stay unattributed.
# NUL-delimited status keeps paths with whitespace intact; a path containing
# a newline is not representable in worker-touched and is skipped.
snapshot() {
  git -C "$worktree" status --porcelain=v1 -z --untracked-files=all | {
    while IFS= read -r -d '' entry; do
      code=${entry:0:2}
      path=${entry:3}
      case "$code" in R?|C?|?R|?C) IFS= read -r -d '' _old || true ;; esac
      case "$path" in *$'\n'*) continue ;; esac
      if [[ -f $worktree/$path ]]; then
        hash=$(git -C "$worktree" hash-object -- "$path" 2>/dev/null) || hash=unreadable
      else
        hash=absent
      fi
      printf '%s\t%s\n' "$hash" "$path"
    done
  }
}
if [[ $research -eq 0 ]]; then
  before=$(mktemp "${TMPDIR:-/tmp}/wrsp-provenance.XXXXXX")
  trap cleanup EXIT
  snapshot > "$before" 2>/dev/null || : > "$before"
fi

printf 'tier:%s model:%s effort:%s cli:%s worktree:%s brief:%s\n' "$tier" "$model" "$effort" "$cli" "$worktree" "$brief" > "$log"
set +e
(cd "$worktree" && "${cmd[@]}" < "$prompt") >> "$log" 2>&1
status=$?
echo "EXIT:$status" >> "$log"

# Everything below is best effort: the worker's exit status and its BRIEF GAP
# report are never lost to a provenance failure.
record_provenance() {
  local gitdir after
  gitdir=$(git -C "$worktree" rev-parse --git-dir) || return 1
  [[ $gitdir == /* ]] || gitdir=$worktree/$gitdir
  [[ -d $gitdir/wrsp ]] || mkdir "$gitdir/wrsp" || return 1
  after=$(snapshot) || return 1
  [[ -n $after ]] || return 0
  # Lines present after the run and absent before: new paths or changed content.
  # An empty pattern file matches nothing, so a clean baseline attributes all.
  printf '%s\n' "$after" | grep -vxF -f "$before" | cut -f2- | grep -v '^$' >> "$gitdir/wrsp/worker-touched" || true
  return 0
}
if [[ $research -eq 0 ]]; then
  if ! record_provenance 2>>"$log"; then
    echo "WARNING: worker provenance not recorded; the pre-commit reminder may name this worker's paths." | tee -a "$log" >&2
  fi
fi
if grep -q '^BRIEF GAP:' "$log"; then
  echo "BRIEF GAP reported; see $log" >&2
fi
printf '%s\n' "$status" > "${log}.exit.tmp.$$" && mv -f "${log}.exit.tmp.$$" "${log}.exit"
exit "$status"
