# <project> Agent Guide

<!-- TEMPLATE. Copy to a repo as AGENTS.md, symlink CLAUDE.md -> AGENTS.md,
delete sections that do not apply, and replace every line. Project files
carry only what the global ~/.agents/AGENTS.md cannot: this project's
facts, oracles, and deliberate overrides. Keep the global file's register:
terse bullets, each under 20 words. -->

Two lines: what the project is, who consumes it, and what this file is not.

## Glossary

- Capitalized domain codenames defined here, or one pointer to CONTEXT.md.

## Start here

- Ordered doc map: read X before architecture changes, Y before behavior
  changes.
- Point to applicable engineering contracts by subsystem or through
  `docs/reference/contracts/README.md`; agents need not load unrelated ones.

- Point feature grouping and issue creation/claiming to the adopted work-type catalog and process contract.

## Invariants

- Properties every change must preserve, each stated as a falsifiable
  claim.

## Architecture map

- Directory-to-responsibility list; the seams that must not be crossed.

## Commands

```bash
# the exact lint, typecheck, test, build, run commands
```

- Fresh-worktree order: `npm ci`, then `npm run build`, then install git
  hooks when the hooks directory is generated (`npx husky` for husky), then
  `npm run preflight -- <check>`; never check before provisioning.
- Offline is sandbox-normal: clone `node_modules/` from the shared checkout
  (`cp -Rc` on macOS APFS; `cp -a` elsewhere).

## Verification

- Project oracles: which suite covers which surface; the consumer-visible
  artifact each asserts against.
- Contract pointers: owning module or interface, executable evidence, measured
  proof, and known gaps for each applicable seam.
- Required proof forms for this repo (capture path, render command,
  exported artifact).
- Capture quirks and known false signals.
- Run required committed-tip suites with `wrsp-runner test <tip>`; inspect the
  printed local failure paths, fix, commit, and re-test. Exit 1 is a product
  failure, 2 infrastructure, 3 cancelled or unknown, and 4 unavailable.
  Only transport failure returns 4; daemon status errors return 2 verbatim.
  Never infer fallback from 4. Use `--backend local` only with operator
  permission and committed `runner.allowLocalBackend: true`. Before asking for
  another review round, inspect the lineage's spend and red state with
  `wrsp-runner usage <base> <tip>`.
- Ignore `.wrsp/` and custom `wrsp-runner test --into` directories in Git.

## Landing and publication

- Worktree, review, and push rules beyond the global defaults.
- What publication actually deploys, and its gates.

## Local runtime

- Ports, profiles, shared resources, credentials, sandbox traps on this
  machine.

## Product tone and UI

- Voice, styling system, local URL, screenshot conventions. Omit for
  non-UI repos.

## Boundaries

- Privacy, sensitivity, publication, and provenance limits on what may be
  committed.

## Global overrides

- Each global rule this repo deliberately reverses, with the reason.
  Empty means none.
